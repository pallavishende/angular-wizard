
// URL : Application ID
export const defaultEndpointsValue = {
    'https://dev.gateway.bridge.viacom.com': '9940d03f-29dd-4051-9b23-e22ec301e19e',
    'https://graph.microsoft.com/v1.0': 'https://graph.microsoft.com',
    'https://aliasextsvcstg.viacom.com': 'https://viacom.onmicrosoft.com/vmsapistg'
};
export const qaEndpointsValue = {
    'https://qa.gateway.bridge.viacom.com': '9b584a98-d7d8-4dde-be82-509109ac4bfa',
    'https://graph.microsoft.com/v1.0': 'https://graph.microsoft.com'
};

export const defaultAdalClientId = '5d941428-f872-42d6-a4c4-5ea0c89a3938';
export const qaAdalClientId = '99f0904f-2b7f-4d85-bbdc-38a5439b9ef1';
export const devGatewayUrl = 'https://dev.gateway.bridge.viacom.com';
export const qaGatewayUrl = 'https://qa.gateway.bridge.viacom.com';

export const localhostConfiguration =  {
    config:
    {
        adal: {
            tenant: 'viacom.onmicrosoft.com',
            clientId: defaultAdalClientId,
            endpoints: defaultEndpointsValue
        },
        gatewayUrl: devGatewayUrl
    }
};

