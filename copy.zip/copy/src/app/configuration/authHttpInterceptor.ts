import { Injectable, Injector, Inject, NgZone } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpErrorResponse
} from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { DOCUMENT } from '@angular/platform-browser';
import { EnvironmentService } from '../services/environment.service';
import { AdalService } from '../shared/auth/adal.service';
import 'rxjs/add/operator/do';
import { SystemAlertsService } from 'app/services/system-alerts.service';

const environmentConfigUrl = `/config.json`;

@Injectable()
export class AuthHttpInterceptor implements HttpInterceptor {

  constructor( @Inject(DOCUMENT) private document: Element, private ngZone: NgZone, private adalService: AdalService, private injector: Injector, private environmentService: EnvironmentService, private alerts: SystemAlertsService) { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (request.url !== environmentConfigUrl) {
      return this.getToken(request.url)
        .switchMap((token) => {
          if (this.adalService.userInfo) {
            this.adalService.userInfo.isAuthenticated = true;
          }
          return this.ngZone.run(() => {
            return next.handle(request.clone({ setHeaders: { Authorization: `Bearer ${token}` } })).pipe(this.enterZone(this.ngZone));
          });
        }).catch((error: HttpErrorResponse) => {
          if (typeof error === 'string') {
            // redirection was happening outside ngzone
             return this.ngZone.run(() => {
              // ref: https://docs.microsoft.com/en-us/azure/active-directory/develop/reference-aadsts-error-codes
              if (/AADSTS50058/.test(error) || /AADSTS50132/.test(error) || /AADSTS50133/.test(error)) {
                console.log('Session timed out!');
                this.alerts.addErrorAlerts('Your session has expired. Please login again to continue.');
                this.router.navigateByUrl('/login');
                return Observable.empty();
              } else {
                console.log('Token error, logging out.', error);
                this.alerts.addErrorAlerts('Your session has expired. Please login again to continue.');
                this.router.navigateByUrl('/login');
                return Observable.empty();
              }
            });
          }
          return Observable.throw(error);
        });
    } else {
      return next.handle(request.clone());
    }
  }

  /**
   * for reference, check this out:
   * https://stackoverflow.com/questions/39767019/app-initializer-raises-cannot-instantiate-cyclic-dependency-applicationref-w
   */
  public get router(): Router {
    return this.injector.get(Router);
  }

  private getToken(url): Observable<string> {
    const aliasAssetDetailsUrl = this.environmentService.isRuntimeEnvironmentGreaterThan(4) ? this.environmentService.getAliasEndpoints().aliasAssetDetailsUrl : this.environmentService.getAliasEndpoints().aliasStgAssetDetailsUrl;
    const aliasAssetRestrictionsUrl = this.environmentService.isRuntimeEnvironmentGreaterThan(4) ? this.environmentService.getAliasEndpoints().aliasAssetRestrictionUrl : this.environmentService.getAliasEndpoints().aliasStgAssetRestrictionUrl;
    if (url === aliasAssetDetailsUrl || url.split('?')[0] === aliasAssetRestrictionsUrl) {
      return this.getUserTokenForAlias();
    } else {
      const endpointResource = this.adalService.GetResourceForEndpoint(url);
      return this.adalService.acquireToken(endpointResource).do(() => {
        this.removeAdalFrameForResource(endpointResource);
     }, () => {
      this.removeAdalFrameForResource(endpointResource);
    });
    }
  }

  private getUserTokenForAlias(): Observable<string> {
    const aliasResource = this.environmentService.isRuntimeEnvironmentGreaterThan(4) ? this.environmentService.getAliasEndpoints().aliasAzureADResourceUrl : this.environmentService.getAliasEndpoints().aliasStgAzureADResourceUrl;
    return this.adalService.acquireToken(aliasResource).do(() => {
       this.removeAdalFrameForResource(aliasResource);
    }, () => {
      this.removeAdalFrameForResource(aliasResource);
   });
  }

  private enterZone<T>(zone: NgZone) {
    return (source: Observable<T>) => {
      return new Observable((sink: Observer<T>) => {
        return source.subscribe({
          next(x) { zone.run(() => sink.next(x)); },
          error(e) { zone.run(() => sink.error(e)); },
          complete() { zone.run(() => sink.complete()); }
        });
      });
    };
  }
  private removeAdalFrameForResource(resource: string) {
    // removing only the resources iframe after callback, to prevent other tokens getting cancelled/timeout
    const iFrames = this.document.getElementsByTagName('iframe');
    for (let i = 0; i < iFrames.length; i++) {
      if (iFrames[i].id.startsWith('adalRenewFrame' + resource)) {
        iFrames[i].remove();
      }
    }
  }
}
