import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invalid-requests-base',
  templateUrl: './invalid-requests-base.component.html',
  styleUrls: ['./invalid-requests-base.component.scss']
})
export class InvalidRequestsBaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
