import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';

import { InvalidRequestsBaseComponent } from './invalid-requests-base.component';

describe('InvalidRequestsBaseComponent', () => {
  let component: InvalidRequestsBaseComponent;
  let fixture: ComponentFixture<InvalidRequestsBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      declarations: [ InvalidRequestsBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvalidRequestsBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});