import { Component, OnInit } from '@angular/core';
// import { SiteHeaderComponent } from '../../shared/site-header/site-header.component';
import { Location } from '@angular/common';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.scss']
})
export class PageNotFoundComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private location: Location
  ) { }

  ngOnInit() {
    if (this.route.snapshot.queryParams['returnUrl']) {
      this.location.go(this.route.snapshot.queryParams['returnUrl']);
    }
  }

}
