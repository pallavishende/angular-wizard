import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SiteHeaderComponent } from '../shared/site-header/site-header.component';
import { InvalidRequestsBaseComponent } from './invalid-requests-base/invalid-requests-base.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const InvalidRequestsRoutes: Routes = [
  { path: '', component: InvalidRequestsBaseComponent,
    children: [
      // { path: '', component: SiteHeaderComponent, outlet: 'header' },
      // { path: '', redirectTo: '404', pathMatch: 'full' },
      // { path: '404', component: PageNotFoundComponent },
    ]
  }
];

@NgModule({
  imports: [ RouterModule.forChild(InvalidRequestsRoutes) ],
  exports: [ RouterModule ]
})

export class InvalidRequestsRoutesModule {}