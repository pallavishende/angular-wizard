import { HtmlFormatDirective } from './html-format.directive';

describe('HtmlFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new HtmlFormatDirective(null, null);
    expect(directive).toBeTruthy();
  });
});
