import { Directive, ElementRef, OnChanges, Input } from '@angular/core';
import { UtilityService } from '../services/utility.service';

@Directive({
  selector: '[html-format-directive]'
})
export class HtmlFormatDirective implements OnChanges {
  @Input() text: string;

  constructor(private elRef: ElementRef, private utilityService: UtilityService) {
  }

  /* this directive defines the base styling for the statuses.
     the colors etc are defined by the css classes that correspond to status name
     since this is supposed to be a global sharable component, all the status styles will be in styles.scss
  */
  ngOnChanges(c) {
    if (this.text) {
      // this.elRef.nativeElement.innerHTML =  this.text.replace(/\r?\n/g, '<br />');
      this.text = this.convert(this.text);
      this.elRef.nativeElement.innerHTML =  this.text.replace(/\r?\n/g, '');
    }
  }

  public convert(value) {
    const convertedText = this.utilityService.getHyperLinkFromText(value);
    return convertedText;
  }
}
