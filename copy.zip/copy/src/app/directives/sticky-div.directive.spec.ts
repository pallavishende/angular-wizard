import { StickyDivDirective } from './sticky-div.directive';

xdescribe('StickyDivDirective', () => {
  it('should create an instance', () => {
    const directive = new StickyDivDirective(null, null);
    expect(directive).toBeTruthy();
  });
});
