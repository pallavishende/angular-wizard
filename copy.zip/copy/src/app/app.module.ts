import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthHttpInterceptor } from './configuration/authHttpInterceptor';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';

import { AppRoutesModule } from './app-routes.module';
import { LoginModule } from './login/login.module';
import { SharedModule } from './shared/shared.module';
import { InvalidRequestsModule } from './invalid-requests/invalid-requests.module';
import { OnboardingModule } from './onboarding/onboarding.module';

import { SystemAlertsService } from './services/system-alerts.service';
import { ToasterModule } from 'angular2-toaster';
import { LoadingMaskComponent } from './shared/loading-mask/loading-mask.component';
import { LoadingMaskService } from './shared/loading-mask/loading-mask.service';
import { StorageService } from './services/storage.service';

import { HttpClientModule, HttpClient } from '@angular/common/http';
import { SecretService } from './services/secret.service';
import { Location, LocationStrategy, PathLocationStrategy, APP_BASE_HREF } from '@angular/common';
import { LoginService } from './login/login.service';
import { ConfigurationManagerService } from './configuration/configuration-manager.service';
import { configurationLoader } from './configuration/configurationLoader';
import { EnvironmentService } from './services/environment.service';
import { ConfigService } from './services/config.service';
import { UserService } from './services/user.service';
import { NavigationService } from './services/navigation.service';
import { AdalService } from './shared/auth/adal.service';

@NgModule({
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  declarations: [
    AppComponent,
    LoadingMaskComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    LoginModule,
    InvalidRequestsModule,
    BrowserAnimationsModule,
    OnboardingModule,
    HttpClientModule,
    AppRoutesModule,
    SharedModule,
    ToasterModule
  ],
  providers: [
    Location,
    {provide: LocationStrategy, useClass: PathLocationStrategy },
    {provide: APP_BASE_HREF, useValue: '/'},
    NavigationService,
    HttpClient,
    SystemAlertsService,
    LoadingMaskService,
    StorageService,
    AdalService,
    UserService,
    SecretService,
    LoginService,
    ConfigurationManagerService,
    EnvironmentService,
    {
      provide: APP_INITIALIZER,
      useFactory: configurationLoader,
      deps: [ ConfigurationManagerService ],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthHttpInterceptor,
      multi: true
    },
    ConfigService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
