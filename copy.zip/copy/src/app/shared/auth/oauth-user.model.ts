export interface OAuthUser {
    isAuthenticated: boolean;
    userName: string;
    loginError: string;
    profile: any;
}