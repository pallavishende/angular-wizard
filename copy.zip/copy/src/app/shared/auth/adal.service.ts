import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/bindCallback';
import * as AuthenticationContext from 'adal-angular';
import { OAuthUser } from './oauth-user.model';

@Injectable()
export class AdalService {

    private adalContext: AuthenticationContext;
    private oauthUser: OAuthUser = {
        isAuthenticated: false,
        userName: '',
        loginError: '',
        profile: {}
    };

    public init(configOptions: AuthenticationContext.Options) {
        if (!configOptions) {
            throw new Error('You must set config, when calling init.');
        }

        // redirect and logout_redirect are set to current location by default
        const existingHash = window.location.hash;
        let pathDefault = window.location.href;
        if (existingHash) {
            pathDefault = pathDefault.replace(existingHash, '');
        }

        configOptions.redirectUri = configOptions.redirectUri || pathDefault;
        configOptions.postLogoutRedirectUri = configOptions.postLogoutRedirectUri || pathDefault;
        configOptions.loadFrameTimeout = 12000;

        // create instance with given config
        this.adalContext = AuthenticationContext.inject(configOptions);

        // loginresource is used to set authenticated status
        this.updateDataFromCache(this.adalContext.config.loginResource);
    }

    public isInAuthIframeOrCallback() {
       const isCallback = this.adalContext.isCallback(window.location.hash);
       return isCallback || (window !== window.parent);
    }

    public isUserAuthenticated() {
        if(this.adalContext) {
            const token = this.adalContext.getCachedToken(this.adalContext.config.loginResource);
            this.oauthUser.isAuthenticated = token !== null && token.length > 0;
            return this.oauthUser.isAuthenticated;
        } else {
            return false;
        }
    }

    public get config(): AuthenticationContext.Options {
        return this.adalContext.config;
    }

    public get userInfo(): OAuthUser {
        return this.oauthUser;
    }

    public resetUserInfo() {
        this.oauthUser = {
            isAuthenticated: false,
            userName: '',
            loginError: '',
            profile: {}
        };
    }

    public login(): void {
        this.adalContext.login();
    }

    public loginInProgress(): boolean {
        return this.adalContext.loginInProgress();
    }

    public logOut(): void {
        this.resetUserInfo();
        this.adalContext.logOut();
    }

    public handleWindowCallback(): void {
       this.adalContext.handleWindowCallback();
       this.refreshDataFromCache();
    }

    public getCachedToken(resource: string): string {
        return this.adalContext.getCachedToken(resource);
    }

    public acquireToken(resource: string) {
        const _this = this;   // save outer this for inner function

        let errorMessage: string;
        return Observable.bindCallback(acquireTokenInternal, function (token: string) {
            if (!token && errorMessage) {
                throw (errorMessage);
            }
            return token;
        })();

        function acquireTokenInternal(cb: any): string {
            let s = '';

            _this.adalContext.acquireToken(resource, (errorDescription: string, tokenOut: string, error: string) => {
                if (errorDescription) {
                    // update local authstate and user if errored
                    _this.refreshDataFromCache();
                    console.log('AuthToken Error', error);
                    _this.adalContext.error('Error when acquiring token for resource: ' + resource, errorDescription);
                    errorMessage = errorDescription;
                    cb(<string>null);
                } else {
                    cb(tokenOut);
                    s = tokenOut;
                }
            });
            return s;
        }
    }

    public getUser(): Observable<AuthenticationContext.UserInfo> {
        return Observable.bindCallback<AuthenticationContext.UserInfo>((cb: (u: AuthenticationContext.UserInfo) => AuthenticationContext.UserInfo) => {
            this.adalContext.getUser(function (error: string, user: AuthenticationContext.UserInfo) {
                if (error) {
                    this.adalContext.error('Error when getting user', error);
                    cb(null);
                } else {
                    cb(user);
                }
            });
        })();
    }

    public clearCache(): void {
        this.adalContext.clearCache();
    }

    public clearCacheForResource(resource: string): void {
        this.adalContext.clearCacheForResource(resource);
    }

    public info(message: string): void {
        this.adalContext.info(message);
    }

    public verbose(message: string): void {
        this.adalContext.verbose(message);
    }

    public GetResourceForEndpoint(url: string): string {
        return this.adalContext.getResourceForEndpoint(url);
    }

    public refreshDataFromCache() {
        this.updateDataFromCache(this.adalContext.config.loginResource);
    }

    private updateDataFromCache(resource: string): void {
        const token = this.adalContext.getCachedToken(resource);
        this.oauthUser.isAuthenticated = token !== null && token.length > 0;
        const user = this.adalContext.getCachedUser() || { userName: '', profile: undefined };
        this.oauthUser.userName = user.userName;
        this.oauthUser.profile = user.profile;
        this.oauthUser.loginError = this.adalContext.getLoginError();
    };
}
