import { Component, OnInit, OnDestroy, Input, Output, ViewChild, EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';

import { AwsS3ConfigService } from '../../../services/aws-s3-config.service';

@Component({
  selector: 'app-file-preview',
  templateUrl: './file-preview.component.html',
  styleUrls: ['./file-preview.component.scss']
})
export class FilePreviewComponent implements OnInit, OnDestroy {

  @Input('previewFileSubject') previewFileSubject: Subject<File>;
  @Output('onPreviewModalClose') onModalCloseEvent = new EventEmitter<boolean>();
  @ViewChild('filePreviewModal') filePreviewModal;
  @ViewChild('previewImage') previewImageElement: HTMLImageElement;
  previewFile: File & { pathUrl?: string, originalName?: string };
  isPreviewLoaded: boolean = false;

  constructor(private awsS3ConfigService: AwsS3ConfigService) { }

  ngOnInit() {
    // subscribing to the preview file subject received as an @Input
    this.previewFileSubject.subscribe((data: File) => {
      this.previewFile = data;
      this.showFilePreview();
    });
  }

  showFilePreview() {
    this.filePreviewModal.open();
    this.awsS3ConfigService.getPreSignedUrl(this.previewFile).subscribe((data) => {
      console.log('This is the signed url received from AWS');
      this.previewFile['pathUrl'] = data;
    });
  }

  onPreviewModalClose() {
    delete this.previewFile;
    this.isPreviewLoaded = false;
  }

  ngOnDestroy() {
    if (this.previewFileSubject) {
      this.previewFileSubject.unsubscribe();
    }
  }
}
