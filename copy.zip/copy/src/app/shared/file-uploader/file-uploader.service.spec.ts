import { TestBed, inject } from '@angular/core/testing';
import { Http, ConnectionBackend, RequestOptions, BaseRequestOptions } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { MockBackend, MockConnection } from '@angular/http/testing';

import { FileUploaderService } from './file-uploader.service';
import { ConfigService } from '../../services/config.service';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';

xdescribe('FileUploaderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule ],
      providers: [ FileUploaderService,
      ConfigService,
      EnvironmentService,
      ConfigurationManagerService,
      BaseRequestOptions
      ]
    });
  });

  it('should be created', inject([FileUploaderService], (service: FileUploaderService) => {
    expect(service).toBeTruthy();
  }));
});
