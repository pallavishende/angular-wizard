import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomEditorComponent } from './custom-editor.component';
import { UserService } from '../../services/user.service';
import { EnvironmentService } from '../../services/environment.service';
import { StorageService } from '../../services/storage.service';
import { ConfigService } from '../../services/config.service';
import { UtilityService } from '../../services/utility.service';
import { LoginService } from '../../login/login.service';
import { SecretService } from '../../services/secret.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';

import { AdalService } from '../../shared/auth/adal.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';

describe('CustomEditorComponent', () => {
  let component: CustomEditorComponent;
  let fixture: ComponentFixture<CustomEditorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule, HttpClientModule ],
      declarations: [ CustomEditorComponent ],
      providers: [ UserService,
                   LoginService,
                   SecretService,
                   StorageService,
                   UtilityService,
                   ConfigurationManagerService,
                   ConfigService,
                   EnvironmentService,
                   AdalService,
                   HttpClient,
                   HttpHandler ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
