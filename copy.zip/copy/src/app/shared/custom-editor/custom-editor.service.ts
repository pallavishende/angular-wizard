import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class CustomEditorService {

  getCommentFromEditor = new EventEmitter();

  constructor() { }
}
