import {
  Component, AfterViewInit, OnDestroy, OnInit, OnChanges, SimpleChanges,
  Input, Output, EventEmitter, NgZone
} from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'tinymce';
import 'tinymce/themes/modern';
import 'tinymce/plugins/table';
import 'tinymce/plugins/link';
import 'tinymce/plugins/autolink';
import 'tinymce/plugins/lists';
import 'tinymce/plugins/advlist';
import 'tinymce/plugins/paste';
import 'tinymce/plugins/textcolor';
import '../../../assets/mentions';
import { orderBy } from 'lodash';
import { UserService } from '../../services/user.service';
import { UtilityService } from '../../services/utility.service';
import { Subject } from 'rxjs';

declare var tinymce: any;

@Component({
  selector: 'app-custom-editor',
  templateUrl: './custom-editor.component.html',
  styleUrls: ['./custom-editor.component.scss']
})
export class CustomEditorComponent implements OnInit, OnChanges, AfterViewInit, OnDestroy {

  @Input() textareaValue = '';
  @Input() elementId = 'customEditor';
  @Input() focus: boolean;
  @Input() customEditorServiceInstance;
  @Input() parentIdentifier;
  @Input() enableUserMentions = true;
  @Input() editorDimension = { height: '100px' };
  @Input() updateCustomEditor: Observable<string>;

  @Output() onEditorContentChange = new EventEmitter();
  @Output() blurEvent = new EventEmitter();

  editor;
  editorObj = {
    content: '',
    mentionedUsers: [],
    isValidContent: false,
    readyToPostComment: false,
    eventType: null
  };
  isContentEmpty = true;
  usersList;
  displayNames = [];
  isFocused = false;
  subscriptions = new Subscription();
  contentChangedDebouncer = new Subject();

  constructor(private ngZone: NgZone, private userService: UserService, private utilityService: UtilityService) {
   }

  ngOnInit() {
    this.editorObj.content = this.textareaValue;
    this.initContentChangeDebouncer();
    // subscribe to instance event emitter object only if instance is received from parent component
    if (this.customEditorServiceInstance) {
      this.subscriptions.add(this.customEditorServiceInstance.getCommentFromEditor.subscribe(() => {
        this.editorObj.readyToPostComment = true;
        this.editorObj.mentionedUsers = this.getMentionedUsers();
        this.emitContentChangedEvent();
      }));
    }
    if (typeof this.updateCustomEditor !== 'undefined') {
      this.subscriptions.add(this.updateCustomEditor.subscribe((data) => {
        if (typeof this.parentIdentifier !== 'undefined' && this.parentIdentifier === data['parentIdentifier']) {
          this.updateCustomEditorContent(data['description']);
        }
      }));
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (typeof changes['textareaValue'] !== 'undefined' && changes['textareaValue'].currentValue === '' && changes['textareaValue'].previousValue !== '') {
      this.updateCustomEditorContent();
    }
  }

  ngAfterViewInit() {
    tinymce.init({
      // note: editor id can't start with a numeral, known TinyMCE bug: https://github.com/tinymce/tinymce/issues/3011
      selector: '#id-' + this.elementId,
      plugins: ['link', 'autolink', 'table', 'lists', 'paste', 'mentions', 'textcolor'],
      skin_url: '/assets/skins/lightgray',
      height: this.editorDimension.height,
      toolbar: [
        'bold italic underline strikethrough forecolor | bullist numlist | link unlink'
      ],
      content_style: '.mce-content-body {font-family: \'Roboto\', sans-serif;font-size: 14px;color: #5F6770;}',
      statusbar: false,
      menubar: false,
      link_context_toolbar: true,
      link_title: false,
      target_list: false,
      default_link_target: '_blank',
      link_assume_external_targets: true,
      forced_root_block: false,
      paste_as_text: true,
      mentions_fetch: (query, success) => {
        if (this.enableUserMentions) {
          this.getUsers(query, success);
        }
      },
      mentions_menu_complete: (editor, userinfo) => {
        let span;
        span = editor.getDoc().createElement('span');
        span.className = 'mention';
        // span.style.fontWeight = 700;
        span.appendChild(editor.getDoc().createTextNode('@' + userinfo.name));
        span.style.backgroundColor = 'rgba(149,176,204,0.5)';
        span.style.marginRight = '5px';  // adding a space after the mentioned user name in the editor
        return span;
      },
      setup: editor => {
        this.editor = editor;
        editor.on('keyup change', (e) => {
          this.ngZone.run(() => {
            this.editorObj.content = editor.getContent();
            this.editorObj.mentionedUsers = this.getMentionedUsers();
            this.emitEvent('keyup');
          });
        });
        editor.on('focus', (e) => {
          this.ngZone.run(() => {
            this.isFocused = true;
          });
        });
        editor.on('blur', (e) => {
          this.ngZone.run(() => {
            this.isFocused = false;
            this.emitEvent('blur');
          });
        });
      }
    });
    this.subscriptions.add(this.ngZone.onStable.first().subscribe(() => {
      if (this.textareaValue) {
        tinymce.get('id-' + this.elementId).setContent(this.textareaValue);
      }
      if (this.focus) {
        tinymce.execCommand('mceFocus', false, 'id-' + this.elementId);
      }
      this.setCursorPosition();
      this.emitEvent('init');
    }));
  }

  setCursorPosition() {
    // Set cursor position at end
    tinymce.activeEditor.selection.select(tinymce.activeEditor.getBody(), true);
    tinymce.activeEditor.selection.collapse(false);
  }

  updateCustomEditorContent(content?: string) {
    const tinymceElement = tinymce.get('id-' + this.elementId);
    if (tinymceElement !== null) {
      if (typeof content === 'undefined') {
        tinymceElement.setContent(this.textareaValue);
      } else {
        tinymceElement.setContent(content);
      }
    }
  }

  emitEvent(eventType: string) {
    if (eventType === 'keyup' || eventType === 'init') {
      if (this.editorObj.content.replace(/&nbsp;|\s/g, '') !== '' && !this.editorObj.isValidContent) {
        this.editorObj.isValidContent = true;
      } else if (this.editorObj.content.replace(/&nbsp;|\s/g, '') === '' && this.editorObj.isValidContent) {
        this.editorObj.isValidContent = false;
      }
      this.editorObj.eventType = eventType;
      this.contentChangedDebouncer.next(this.editorObj);
    } else {
      this.blurEvent.emit(this.editorObj);
    }
  }

  getMentionedUsers() {
    if (tinymce.activeEditor && tinymce.activeEditor.plugins) {
      return tinymce.activeEditor.plugins.mentions.getUsers();
    }
  }

  getUsers(query, success) {
    this.subscriptions.add(this.userService.getUsers(query.term, 5).subscribe(
      (data) => {
        let names = [];
        for (const user of data['content']) {
          names.push({ 'id': user.id + '', 'fullName': user.displayName, 'name': user.displayName, 'email': user.login });
        };

        // sorting the names list
        names = orderBy(names, (user) => {
          return user['fullName'].toLowerCase();
        }, 'asc');
        success(names);
      },
      (error) => {
        console.log('Error: cannot load users from UPD.');
      }
    ));
  }

  initContentChangeDebouncer() {
    this.contentChangedDebouncer.debounceTime(300).subscribe(data => {
      this.emitContentChangedEvent();
    });
  }

  emitContentChangedEvent() {
    this.editorObj.content = this.utilityService.getHyperLinkFromText(this.editorObj.content);
    this.onEditorContentChange.emit(this.editorObj);
  }

  getStyle() {
    if (this.isFocused) {
      return {
        'border': '1px solid #2AB7E8',
        'border-radius': '3px',
        'box-shadow': '0 0 2px 0 rgba(42, 183, 232, 0.5)',
      };
    } else {
      return { 'border': '1px solid rgba(255, 255, 255, 0)' };
    }
  }

  ngOnDestroy() {
    tinymce.remove(this.editor);
    this.subscriptions.unsubscribe();
  }
}
