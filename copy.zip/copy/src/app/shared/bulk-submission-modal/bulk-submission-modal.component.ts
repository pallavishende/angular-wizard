import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { remove, cloneDeep } from 'lodash';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';

@Component({
  selector: 'app-bulk-submission-modal',
  templateUrl: './bulk-submission-modal.component.html',
  styleUrls: ['./bulk-submission-modal.component.scss'],
  providers: [CustomEditorService]
})
export class BulkSubmissionModalComponent implements OnInit, OnDestroy {

    lineItemListForSubmission = [];
    assetListModal = [];
    activityEventsMap = {};
    orderName = '';
    modalType;
    attachmentsStatus: any = {};
    submissionComment = '';
    oldSubmissionMsg = '';
    status = '';
    submmitedActivity = [];
    selectAllCheckbox = false;
    initializeEditorSummary = false;
    isValidDescription: boolean;
    submissionPayload = {};
    activitySubmissionObj;
    showBackSelectionButton = true;
    allowAttachments: false;
    title = '';
    isCommentOptional = false;

    constructor(public dialogRef: MatDialogRef<BulkSubmissionModalComponent>, 
        public customEditorService: CustomEditorService,
        private router: Router,
        @Inject(MAT_DIALOG_DATA) public data: any) {
        this.assetListModal = data.assetListModal;
        this.activityEventsMap = data.activityEventsMap;
        this.orderName = data.orderName;
        this.modalType = data.modalType;
        this.status = data.status;
        this.allowAttachments = data.allowAttachments;
        this.title = data.title;
        this.isCommentOptional = data.isCommentOptional;

        dialogRef.disableClose = true;
        if (this.modalType === 'submissionModalSummary') {
          this.showBackSelectionButton = false;
          this.lineItemListForSubmission = this.assetListModal;
          this.submissionPayload['submmisionList'] = {lineItemListForSubmission: this.lineItemListForSubmission};
        }
    }

    ngOnInit() {
        this.initializeEditorSummary = true;
    }

    isAssetAlreadyAddedtoOrder(activityId) {
        if (this.lineItemListForSubmission && (this.lineItemListForSubmission.findIndex(order => order.activityId === activityId)) > -1) {
          return true;
        } else {
          return false;
        }
    }

    getSubmittedDate(activityId) {
        return this.activityEventsMap[activityId] && this.activityEventsMap[activityId].status === 'COMPLETED'
        ? this.activityEventsMap[activityId].createdDate :
        (this.activityEventsMap[activityId] && (this.activityEventsMap[activityId].status === 'TO_DO' || this.activityEventsMap[activityId].status === 'REJECTED') ? 'Updating' : '');
    }

    isAssetSubmitted(asset) {
        return (asset.status === 'COMPLETED') ||
        ((asset.status === 'TO_DO' || asset.status === 'REJECTED') && this.activityEventsMap[asset.activityId]);
    }

    isAssetsSelected() {
        return this.lineItemListForSubmission && this.lineItemListForSubmission.length > 0;
    }

    clearSelectedAssets() {
        this.lineItemListForSubmission = [];
        this.attachmentsStatus = {};
        this.submissionComment = '';
        this.oldSubmissionMsg = '';
        this.submissionPayload = {};
      }

      addToPreorder($event) {
        $event.stopPropagation();
        const isChecked = $event.target.checked;
        const itemId = $event.target.attributes['data-id'].value;
        const itemsArray = this.assetListModal;
        const item = itemsArray.filter(function (obj) {
          return obj.activityId.toString() === itemId;
        });
        if (isChecked) {
          this.lineItemListForSubmission.push(item[0]);
          this.submmitedActivity[itemId] = item[0];
        } else {
          this.selectAllCheckbox = false;
          delete this.submmitedActivity[itemId];
          remove(this.lineItemListForSubmission, (clip) => {
            return item[0].activityId === clip.activityId;
          });
        }

        this.submissionPayload['submmisionList'] = {lineItemListForSubmission: this.lineItemListForSubmission};
      }

      addAllToPreorder(event) {
        const isChecked = event.target.checked;
        this.selectAllCheckbox = isChecked;
        if (isChecked) {
          this.assetListModal.forEach(item => {
            if (item.status === 'TO_DO' || item.status === 'REJECTED') {
              this.submmitedActivity[item.activityId] = item;
              this.lineItemListForSubmission.push(item);
            }
          });
        } else {
          remove(this.lineItemListForSubmission, (clip) => {
            return true;
          });
        }
        this.submissionPayload['submmisionList'] = {lineItemListForSubmission: this.lineItemListForSubmission};
      }

      contentChanged(event) {
        this.activitySubmissionObj = event;
        this.submissionPayload['activitySubmissionObj'] = event;
        if (event.isValidContent) {
          // this.renderer.addClass(this.submitDescriptionBtn.nativeElement, 'ready');
          this.isValidDescription = true;
          this.submissionComment = event.content;
          this.oldSubmissionMsg = event.content;
          this.submissionPayload['submissionComment'] = event.content;
        } else {
          if (this.submissionComment) {
            this.submissionComment = event.content;
            this.oldSubmissionMsg = event.content;
            this.submissionPayload['submissionComment'] = event.content;
          }
          // this.renderer.removeClass(this.submitDescriptionBtn.nativeElement, 'ready');
          this.isValidDescription = false;
        }
      }

    updateAttachmentsMetadata(event) {
        this.attachmentsStatus = event;
        this.submissionPayload['attachmentsStatus'] = event;
    }

    checkComment(content) {
        if (!this.isCommentOptional) {
          if (content) {
            const filtered = content.toString().replace(/&nbsp;|\s\n/g, '');
            const removeBr = filtered.toString().replace(/[<]br[^>]*[>]/gi, '');
            return removeBr.trim() !== '';
          }
        } else {
          return true;
        }
      }

    backToAssetSlectionModal() {
        this.modalType = 'sumissionModal';
    }

    getCommentFromEditor() {
        this.customEditorService.getCommentFromEditor.emit();
        console.log('fetching comment..:');
    }

    onNoClick(): void {
        this.dialogRef.close();
    }

    onNextClick() {
        this.modalType = 'submissionModalSummary';
    }

    nav() {
        this.router.navigate(['consult/' + this.data.link]);
    }

    ngOnDestroy() {

    }

}
