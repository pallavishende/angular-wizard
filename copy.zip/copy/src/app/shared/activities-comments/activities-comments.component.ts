import { Component, OnInit, OnDestroy, AfterViewChecked, Input, Output, EventEmitter, ViewChild, TemplateRef } from '@angular/core';
import { MatDialog } from '@angular/material';
import { UserService } from '../../services/user.service';
import { UtilityService } from '../../services/utility.service';
import { ActivitiesCommentsService } from './activities-comments.service';
import { CustomEditorService } from '../custom-editor/custom-editor.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-activities-comments',
  templateUrl: './activities-comments.component.html',
  providers: [ActivitiesCommentsService, CustomEditorService],
  styleUrls: ['../../activities/activities.scss', './activities-comments.component.scss']
})
export class ActivitiesCommentsComponent implements OnInit, OnDestroy, AfterViewChecked {

  @Input() activityId: any;  // deprecated
  @Input() disableUserComments: boolean;
  @Input() orderId: number;
  @Input() currentBundleId: string;
  @Input() isSubActivity;
  @Output() addingComment = new EventEmitter<any>();
  @Output() commentsCountStream = new EventEmitter<any>(true);
  @Output() serviceIntance = new EventEmitter<any>();
  @Output() eventData = new EventEmitter<any>();
  @ViewChild('postCommentBtn') postCommentBtn;
  @ViewChild('deleteCommentDialog') deleteCommentDialog: TemplateRef<any>;

  isCommentValid: boolean;
  showCommentArea: boolean;
  editCommentArea: boolean;
  comment: string;
  selectedComment: any;
  commentEditorObj: any;
  commentsCount = 0;
  activityTypesList;
  loggedInUser: any;
  subscriptions = new Subscription();
  scrolled = false;
  editCommentIndex: number;
  editCommentText = '';
  replyToCommentObj: {
    parentId: string,
    parentComment: string,
    createdBy: string,
    eventType: string,
    createdDate: string,
    activityTypeId: number
  };

  constructor(private userService: UserService,
    private utilityService: UtilityService,
    public activitiesCommentsService: ActivitiesCommentsService,
    public customEditorService: CustomEditorService,
    private dialog: MatDialog) {}

  ngOnInit() {
    this.setCommentsCount();
    this.activitiesCommentsService.commentStream.subscribe(data => {
      this.eventData.emit(data);
    });

    this.activitiesCommentsService.commentsCountStream.subscribe(data => {
      console.log(data);
    });

    this.activityTypesList = this.utilityService.getActivityTypesList();
    this.serviceIntance.emit(this.activitiesCommentsService);
    this.getOrderComments();
    this.loggedInUser = this.userService.getUserLoginInfo();
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    console.log('fetching comment..:');
  }

  getOrderComments() {
    this.activitiesCommentsService.getOrderCommentsAndEvents(this.orderId);
  }

  postComment(parentId?: string) {
    const email = [];
    for (const user of this.commentEditorObj.mentionedUsers) {
      email.push(user.email);
    }
    const commentObj = {
      message: this.comment,
      createdByEmail: this.userService.getUserLoginInfo().email,
      orderId: this.orderId,
      mentionedUserEmails: email,
      parentId: parentId
    };
    this.activitiesCommentsService.postComment(commentObj, this.orderId, this.currentBundleId, this.isSubActivity);
    if (typeof parentId !== 'undefined') {
      delete this.replyToCommentObj;
    }
  }

  addCommentEvent(isAddingComment: boolean) {
    this.addingComment.emit(
      {
        isAddingComment: !this.showCommentArea,
        activityId: this.activityId
      });
    this.showCommentArea = isAddingComment;
    this.editCommentArea = false;
  }

  editCommentEvent(isEditingComment: boolean, editCommentIndex: number, isTimelineCommentEdited?: any, userComment?: any ) {
   if (!isTimelineCommentEdited) {
    this.addingComment.emit(
      {
        isAddingComment: !isEditingComment,
        activityId: this.activityId
      });
   }
    this.editCommentArea = isEditingComment;
    this.editCommentIndex = editCommentIndex;
    this.showCommentArea = false;
    if (userComment) {
      this.editCommentText = userComment.message ? userComment.message : userComment.comment.message;
    }
  }

  updatePostComment(userComment: any) {
    const email = [];
    const userCommentObject: any = {};
    for (const user of this.commentEditorObj.mentionedUsers) {
      email.push(user.email);
    }
    userCommentObject.id =  userComment.commentId ? userComment.commentId : userComment.id;
    userCommentObject.createdByEmail = this.userService.getUserLoginInfo().email;
    userCommentObject.tenantId = userComment.tenantId;
    userCommentObject.isChildEvent = (userComment.isChildEvent !== null &&  userComment.isChildEvent !== undefined) ? userComment.isChildEvent : userComment.comment.isChildEvent;
    userCommentObject.mentionedUserEmails = email.length === 0 ? null : email ;
    userCommentObject.message = this.comment;
    userCommentObject.attachments = userComment.attachments === null ? [] : userComment.attachments ;
    userCommentObject.attachmentIds = userComment.attachmentIds === null ? [] : userComment.attachmentIds ;
    this.activitiesCommentsService.updateComment(userCommentObject, this.orderId);
  }

  updatePostTimeLineComment(userTimeLineComment: any) {
    const email = [];
    for (const user of this.commentEditorObj.mentionedUsers) {
      email.push(user.email);
    }
   const userComment: any = {};
   userComment.id =  userTimeLineComment.commentId ? userTimeLineComment.commentId : userTimeLineComment.id;
   userComment.createdByEmail = this.userService.getUserLoginInfo().email;
   userComment.tenantId = userTimeLineComment.tenantId;
   userComment.isChildEvent = userTimeLineComment.comment.isChildEvent;
   userComment.mentionedUserEmails = email.length === 0 ? null : email ;
   userComment.message = this.comment;
   userComment.attachmentIds = userTimeLineComment.attachmentIds === null ? [] : userTimeLineComment.attachmentIds ;
   this.activitiesCommentsService.updateTimeLineComment(userComment, this.activityId);
  }

  contentChanged(event) {
    this.commentEditorObj = event;
    this.comment = this.commentEditorObj.content;
    this.isCommentValid = !!this.comment;
  }

  setCommentsCount(): void {
    this.commentsCountStream.emit(this.activitiesCommentsService.commentsCountStream);
  }


  openDeleteCommentDialog(userComment: any): void {
    this.selectedComment = userComment;
    userComment.activityId = this.activityId;
    this.dialog.open(this.deleteCommentDialog, {
      width: '560px',
      height: '200px'
    });
  }

  deleteUserComment() {
    this.selectedComment.isDeleted = true;
    const isActivityComment = this.selectedComment.type === 'COMMENTED';
    this.activitiesCommentsService.deleteComment(this.selectedComment, this.orderId, isActivityComment);
    delete this.selectedComment;
  }

  replyToComment(userComment: any, activityTypeId) {
    this.replyToCommentObj = {
      parentId: userComment.commentId || userComment.id,
      parentComment: userComment.comment ? userComment.comment.message : userComment.message,
      createdBy: userComment.createdBy.displayName,
      createdDate: userComment.createdDate,
      eventType: userComment.type,
      activityTypeId: activityTypeId
    };
    this.showCommentArea = true;
  }

  resetCommentsObj() {
    this.comment = '';
    if (typeof this.replyToCommentObj !== 'undefined') {
      delete this.replyToCommentObj;
    }
  }

  get userCommentCollection() {
    return this.activitiesCommentsService.userCommentCollection;
  }

  get isCommentsPosting(): boolean {
    return this.activitiesCommentsService.isCommentsPosting;
  }

  get isCommentsLoading(): boolean {
    return this.activitiesCommentsService.isCommentsLoading;
  }

  get parentCommentsObj() {
    return this.activitiesCommentsService.parentCommentsObj;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  ngAfterViewChecked() {
    const currentURL = window.location.href;
    if (currentURL.indexOf('#') !== -1) {
      const commentID = currentURL.slice(currentURL.indexOf('#') + 1);
      const pointedComment = document.getElementById(commentID);
      if (pointedComment && !this.scrolled) {
        pointedComment.scrollIntoView();
        setTimeout(() => {
          pointedComment.removeAttribute('id');
          this.scrolled = true;
          history.pushState('', document.title, window.location.pathname + window.location.search);
        }, 300);
      }
    }
  }
}
