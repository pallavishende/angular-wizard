import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { ActivitiesService } from '../../activities/activities.service';
import { SystemAlertsService } from '../../services/system-alerts.service';

@Injectable()
export class ActivitiesCommentsService implements OnDestroy {

  private commentsCountSubject = new BehaviorSubject(0);
  commentsCountStream = this.commentsCountSubject.asObservable();

  private notifyChanges: BehaviorSubject<{}> = new BehaviorSubject(new Object());
  commentStream = this.notifyChanges.asObservable();
  subscriptions = new Subscription();
  comment: string;
  userCommentCollection = [];
  parentCommentsObj = {};
  isCommentsLoading: boolean;
  isCommentsPosting: boolean;

  constructor(private activitiesService: ActivitiesService, private alerts: SystemAlertsService) { }

    postComment(commentObj, orderId: number, currentBundleId?: string, isSubActivity?: boolean) {
    this.isCommentsPosting = true;
    let postCommentObservable;
    if (typeof currentBundleId === 'undefined') {
      postCommentObservable = this.activitiesService.postOrderComment(commentObj, orderId);
    } else {
      postCommentObservable = this.activitiesService.postActivityComment(commentObj, currentBundleId, isSubActivity);
    }
    this.subscriptions.add(postCommentObservable
      .subscribe(
        (data: any) => {
          this.isCommentsPosting = false;
          this.getOrderCommentsAndEvents(orderId);
        },
        (error: any) => {
          this.isCommentsPosting = false;
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
  }

  updateComment(commentObj: any, orderId: number) {
    this.isCommentsPosting = true;
    this.subscriptions.add(this.activitiesService.updateComment(commentObj)
      .subscribe(
        (data: any) => {
          this.isCommentsPosting = false;
          this.getOrderCommentsAndEvents(orderId);
        },
        error => {
          this.isCommentsPosting = false;
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
  }

  updateTimeLineComment(commentObj: any, activityId?: string) {
    this.isCommentsPosting = true;
    this.subscriptions.add(this.activitiesService.updateComment(commentObj)
      .subscribe(
        (data: any) => {
          this.isCommentsPosting = false;
        },
        error => {
          this.isCommentsPosting = false;
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
  }

  deleteComment(commentObj: any, orderId: number, isActivityComment?: boolean) {
    this.subscriptions.add(this.activitiesService.deleteComment(commentObj.id, isActivityComment).subscribe(
      (data) => {
        console.log('The selected comment has been successfully deleted.');
        this.getOrderCommentsAndEvents(orderId);
      },
      (error) => {
        this.alerts.addErrorAlerts('The comment could not be deleted. Please try again.');
        commentObj.isDeleted = false;
      }
    ));
  }

  getOrderCommentsAndEvents(orderId: number) {
    this.isCommentsLoading = true;
    this.activitiesService.getOrderCommentsAndEvents(orderId).subscribe(
      (data) => {
        this.isCommentsLoading = false;
        this.userCommentCollection = data;
        this.emitCommentsEvent();
        this.setParentComments();
      },
      (error) => {
        console.error('Error occured.', error);
      });
  }


  setParentComments() {
    this.parentCommentsObj = {};
    this.userCommentCollection.forEach(userCommentObj => {
      const userComment = userCommentObj.comment || userCommentObj;
      const userCommentParentId = userComment.parentId;
      if (userCommentParentId) {
        const parentComment = this.userCommentCollection.find((comment) => {
          return comment.commentId === userCommentParentId || comment.id === userCommentParentId;
        });
        if (typeof parentComment !== 'undefined') {
          if (typeof parentComment.comment !== 'undefined') {
            // assigning the createdBy object from root
            parentComment.comment.createdBy = parentComment.createdBy;
          }
          this.parentCommentsObj[userCommentParentId] = parentComment.comment || parentComment;
        }
      }
    });
  }

  emitCommentsEvent(): void {
    this.commentsCountSubject.next(this.userCommentCollection.length);
    this.notifyChanges.next(this.userCommentCollection);
  }

  getLatestCommentEvent(event, type: string) {
    let resultEvent;
    event.forEach(comment => {
      if (comment.type === type) {
        // TO DO: remove this condition check when backend fixes duplicated events for edit copy
        if (comment.activityTypeId === 3) {
          if (comment.commentId) {
            resultEvent = comment;
          }
        } else {
          resultEvent = comment;
        }
      }
    });
    return resultEvent;
  }

  getReSubmitMessage(activityId: number) {
    const submissionEvents = this.userCommentCollection.filter(comment => comment.type === 'CONTENT_SUBMITTED');
    let preSubmissionMessage = '';
    if (submissionEvents.length) {
      for (let i = submissionEvents.length - 1; i >= 0; i--) {
        if (submissionEvents[i].activityId === activityId && submissionEvents[i].comment) {
          preSubmissionMessage = submissionEvents[i].comment.message;
          break;
        }
      }
    }
    return preSubmissionMessage;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
