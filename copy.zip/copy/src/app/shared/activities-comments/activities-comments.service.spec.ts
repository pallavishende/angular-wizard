import { TestBed, inject } from '@angular/core/testing';

import { ActivitiesCommentsService } from './activities-comments.service';

xdescribe('ActivitiesCommentsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ActivitiesCommentsService]
    });
  });

  it('should be created', inject([ActivitiesCommentsService], (service: ActivitiesCommentsService) => {
    expect(service).toBeTruthy();
  }));
});
