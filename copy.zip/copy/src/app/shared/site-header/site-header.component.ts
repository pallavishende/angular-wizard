import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../../login/login.service';
import { UserService } from '../../services/user.service';
import { NavigationService } from '../../services/navigation.service';
import { ConfigService } from '../../services/config.service';
import { StorageService } from 'app/services/storage.service';

@Component({
  selector: 'app-site-header',
  templateUrl: './site-header.component.html',
  styleUrls: ['./site-header.component.scss'],
  providers: [LoginService]
})
export class SiteHeaderComponent implements OnInit {
  headerData;
  userLoginInfo;
  userInitial = '';
  photoLoaded: boolean;
  activeOrdersTab;
  activeActivitiesTab;
  currentPageRoute: string;
  userGuideUrl: string;
  showBanner: boolean = false;

  constructor(
    private activatedRoute: ActivatedRoute,
    private loginService: LoginService,
    private router: Router,
    private userService: UserService,
    private navigationService: NavigationService,
    private configService: ConfigService,
    private storageService: StorageService
  ) { }

  logout($event) {
    $event.preventDefault();
    if (this.loginService.logout()) {
      this.router.navigate(['login']);
    }
  }

  getUserLoginInfo() {
    this.userLoginInfo = this.userService.getUserLoginInfo() || { displayName: '' };
    this.userInitial = this.userLoginInfo.firstName.charAt(0) || '';
    this.userService.getUserPhoto((this.photoLoadHandler), this);
  }

  private photoLoadHandler(result: string, callerComponent: any) {
    const image = document.getElementById('user-photo-header');
    if (result !== null && image) {
      image.setAttribute('src', result);
      callerComponent.photoLoaded = true;
    } else {
      callerComponent.setPhotoLoaded;
    }
  }

  closebanner() {
    this.showBanner = false;
    this.storageService.removeBannerObjFromLocal();
  }

  ngOnInit() {
    this.headerData = this.activatedRoute.data;
    this.getUserLoginInfo();
    this.activeOrdersTab = this.navigationService.getActiveOrdersListTab();
    this.activeActivitiesTab = this.navigationService.getActiveActivitiesTab();
    this.userGuideUrl = this.configService.userGuideUrl;
    this.currentPageRoute = this.router.url;
    this.showBanner = this.storageService.getBannerObjFromLocal();
  }
}