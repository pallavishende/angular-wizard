import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shared-base',
  templateUrl: './shared-base.component.html',
  styleUrls: ['./shared-base.component.scss']
})
export class SharedBaseComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
