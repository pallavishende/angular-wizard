import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAssetsWidgetComponent } from './add-assets-widget.component';

xdescribe('AddAssetsWidgetComponent', () => {
  let component: AddAssetsWidgetComponent;
  let fixture: ComponentFixture<AddAssetsWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddAssetsWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAssetsWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
