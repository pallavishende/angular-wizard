import { Component, OnInit, OnDestroy, Input, Output, EventEmitter, Renderer2, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { find, forEach, remove, map } from 'lodash';

import { CatalogService } from '../../catalog/catalog.service';
import { Order } from '../../models/order';
import { AssetInput } from '../../models/asset-input';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';

@Component({
  selector: 'app-add-assets-widget',
  templateUrl: './add-assets-widget.component.html',
  providers: [CustomEditorService],
  styleUrls: ['./add-assets-widget.component.scss']
})
export class AddAssetsWidgetComponent implements OnInit, OnDestroy {

  @ViewChild('dropDownContainer') dropDownContainer;

  @Input() activeVmid: string;
  @Input() activeDsid: string;
  @Input() order: Order;
  @Input() showArchiveAssets = false;
  @Input() showCustomAsset = true;
  @Input() defaultTab = AddAssetTabs.Archive;
  @Input() parentDialogRef: any;

  @Output() selectedAssets = new EventEmitter<any>();

  subscriptions = new Subscription();
  versionSubscription: Subscription;
  showEllipsisLoader = false;
  catalogItemDetails;
  selectedVersionName: string;
  dataLoaded: boolean;
  hasVersions: boolean;
  materialId: number;
  hasVersionInfo: boolean;
  versionCount: number;
  activeTab: string;
  isVersionContentRestricted: boolean;
  isTitleDuplicate = false;
  initializeEditor = false;
  customClip = {};
  customClipTitle = '';
  customClipSource = '';
  tabs: Array<any>;
  newCustomAsset = new AssetInput();
  orderType: string;

  showClipsWhenEmpty = false;
  searchVersionDetailsObj: any = {};

  constructor(private renderer: Renderer2, public catalogService: CatalogService, public customEditorService: CustomEditorService) { }

  ngOnInit() {
    if (this.defaultTab === AddAssetTabs.Custom) {
      this.activeTab = AddAssetTabs.Custom;
    } else {
      this.getItemDetails();
      this.activeTab = AddAssetTabs.Archive;
    }
    this.setTabOrder();
    this.initializeNewAsset();
    this.setOrderType();
  }

  getItemDetails() {
    this.showEllipsisLoader = true;
    this.subscriptions.add(this.catalogService.getItemDetails(this.activeVmid).subscribe(
      data => {
        this.catalogItemDetails = data.contentDetails;
        if (this.catalogItemDetails.versions.length) {
          this.activeDsid = this.catalogItemDetails.versions[0].dsid;
          if (this.catalogItemDetails.versions.length > 0) {
            this.selectedVersionName = find(this.catalogItemDetails.versions, ['dsid', this.activeDsid])['name'];
          }
          this.showEllipsisLoader = false;
          if (this.activeDsid) {
            this.getVersionDetails();
          }
        } else {
          this.dataLoaded = true;
          this.showEllipsisLoader = false;
          this.hasVersions = false;
        }
      },
      error => {
        this.showEllipsisLoader = false;
        console.log('Error occurred while getting the item details..');
      }
    ));
  }

  setTabOrder(): void {
    this.tabs = [AddAssetTabs.Archive, AddAssetTabs.Custom];
    if (this.defaultTab === AddAssetTabs.Custom) {
      this.tabs = this.tabs.reverse();
      this.initializeCustomEditor();
    } else if (!this.showCustomAsset) {
      this.tabs.splice(1, 1);
    }
  }

  setOrderType(): void {
    this.orderType = this.order.metadata.orderType;
  }

  editorContentChanged(event): void {
    this.newCustomAsset.inOutPoint = event.content;
  }

  initializeNewAsset(): void {
    const newAsset = this.generateEmptyAsset();
    this.newCustomAsset = newAsset;
  }

  initAssetAdditionalInfo(): void {
    this.newCustomAsset.inOutPoint = '';
  }

  validateCustomInput(): boolean {
    return this.customClipTitle.trim().length > 0 && this.customClipSource.replace(/&nbsp;|\s/g, '').length > 0;
  }

  validateCustomAsset(): boolean {
    if (this.activeTab === AddAssetTabs.Archive) {
      return true;
    } else {
      return this.newCustomAsset.assetName.trim() !== '' &&
      this.newCustomAsset.assetSource !== '' &&
      (this.newCustomAsset.inOutPoint === null ||
      this.newCustomAsset.inOutPoint.replace(/&nbsp;|\s/g, '') !== '');
    }
  }

  getVersionDetails() {
    this.searchVersionDetailsObj = {};
    this.showEllipsisLoader = true;
    if (this.catalogItemDetails.hasVersions) {
      this.hasVersions = true;
      if (!this.catalogService.selectedVersion.dsid) {
        this.catalogService.selectedVersion = this.catalogItemDetails.versions[0];
      }
      if (!this.catalogService.selectedVersion.name) {
        for (const version of this.catalogItemDetails.versions) {
          if (version.dsid === this.catalogService.selectedVersion.dsid) {
            this.catalogService.selectedVersion.name = version.name;
            break;
          }
        }
      }
      if (this.versionSubscription) {
        this.versionSubscription.unsubscribe();
      }
      this.versionSubscription = this.catalogService.getVersionDetails(this.activeVmid, this.activeDsid).subscribe(
        (data) => {
          this.showEllipsisLoader = false;
          this.dataLoaded = true;
          this.hasVersionInfo = true;
          this.versionCount = data.assetMaterial.clips.length;
          const searchVersionDetailsObjRaw = data.assetMaterial;
          if (searchVersionDetailsObjRaw) {
            this.materialId = searchVersionDetailsObjRaw.material_id;
          }

          forEach(this.order.lineItems, (lineItem) => {
            if (searchVersionDetailsObjRaw) {
              forEach(searchVersionDetailsObjRaw.clips, (clip) => {
                if (clip && (lineItem.metadata[0].clipId === clip.id || (typeof lineItem.metadata[0].assetInputs !== 'undefined' &&
                lineItem.metadata[0].assetInputs[0].clipId === clip.id))) {
                  searchVersionDetailsObjRaw.clips.splice(searchVersionDetailsObjRaw.clips.indexOf(clip), 1);
                }
              });
            }
          });

          this.searchVersionDetailsObj = searchVersionDetailsObjRaw;
        },
        (errorData) => {
          this.showEllipsisLoader = false;
          console.log('Error occurred while getting the version details..');
          if (errorData.error.status === `FORBIDDEN`) {
            if (errorData.error.message === `Unable to open content for version with VMID [${this.catalogItemDetails.vmid}] and DSID [${this.catalogService.selectedVersion.dsid}]` ||
              errorData.error.message === `Unable to preview proxy for version with VMID [${this.catalogItemDetails.vmid}] and DSID [${this.catalogService.selectedVersion.dsid}]`) {
              this.isVersionContentRestricted = true;
            }
          } else {
            if (this.isVersionContentRestricted) {
              this.isVersionContentRestricted = false;
            }
          }
          this.hasVersionInfo = false;
          this.dataLoaded = true;
        }
      );
    } else {
      this.showEllipsisLoader = false;
      this.hasVersions = false;
      this.dataLoaded = true;
    }
  }

  loadItemVersion(version, event) {
    event.stopPropagation();
    if (this.catalogService.selectedVersion.dsid !== version.dsid) {
      this.activeDsid = version.dsid;
      this.selectedVersionName = version.name;
      this.catalogService.selectedVersion = version;
      this.getVersionDetails();
    }
    this.renderer.removeClass(this.dropDownContainer.nativeElement, 'open');
  }

  onTabChange(e) {
    this.activeTab = e.tab.textLabel;
    this.clearDialogContent();
    if (this.activeTab === AddAssetTabs.Custom) {
      this.initializeCustomEditor();
    } else if (this.activeTab === AddAssetTabs.Archive && typeof this.catalogItemDetails === 'undefined') {
      this.getItemDetails();
    }
  }

  initializeCustomEditor(): void {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  addToPreorder($event) {
    $event.stopPropagation();
    const isChecked = $event.target.checked;
    const itemId = $event.target.attributes['data-id'].value;
    const itemsArray = this.searchVersionDetailsObj['clips'];
    const item = itemsArray.find((obj) => {
      return obj.id.toString() === itemId;
    });
    item.versionDsid = this.activeDsid;
    if (isChecked) {
      this.catalogService.catalogOrderClipsArr.push(item);
    } else {
      remove(this.catalogService.catalogOrderClipsArr, (clip) => {
        return item.id === clip.id;
      });
    }
  }

  contentChanged(e) {
    this.customClipSource = e.content;
  }

  addItemToOrder() {
    const clipArray = this.catalogService.catalogOrderClipsArr;
    if (this.activeTab === AddAssetTabs.Custom) {
      this.selectedAssets.emit(this.newCustomAsset);
    } else {
      for (let i = 0; i < clipArray.length; i++) {
        let clipItem;
        if (clipArray[i]['type'] === 'custom' && clipArray[i]['clipTitle']) { // case custom clip
          clipItem = {
            'metadata': [{
              'clipTitle': clipArray[i]['clipTitle'],
              'clipSource': this.customClipSource.trim()
            }]
          };
        }
      }
    this.selectedAssets.emit(clipArray);
  }
  this.closeDialog();
}

  isClipAlreadyAddedtoOrder(clipTitle) {
    if (map(this.catalogService.catalogOrderClipsArr, 'id').indexOf(clipTitle) > -1) {
      return true;
    } else {
      return false;
    }
  }

  clearDialogContent() {
    this.customClip = {};
    this.customClipTitle = '';
    this.customClipSource = '';
    this.catalogService.catalogOrderClipsArr = [];
    this.newCustomAsset = this.generateEmptyAsset();
    this.isTitleDuplicate = false;
    this.initializeEditor = false;
  }

  closeDialog() {
    this.parentDialogRef.closeAll();
  }

  resetClipSelection(): void {
    this.catalogService.catalogOrderClipsArr = [];
  }

  generateEmptyAsset(): AssetInput {
    const asset: AssetInput = {
      assetNumber: `Asset ${this.order.lineItems.length + 1}`,
      assetName: '',
      assetSource: '',
      inOutPoint: null,
      clipId: null
    };
    return asset;
  }

  ngOnDestroy() {
    if (this.versionSubscription) {
      this.versionSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
    this.resetClipSelection();
  }

}

enum AddAssetTabs {
  Archive = 'CHOOSE FROM CATALOG',
  Custom = 'ADD CUSTOM ASSET'
}

