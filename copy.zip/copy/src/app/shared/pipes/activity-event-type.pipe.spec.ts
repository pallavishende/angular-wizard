import { ActivityEventTypePipe } from './activity-event-type.pipe';

describe('ActivityEventTypePipe', () => {
  it('create an instance', () => {
    const pipe = new ActivityEventTypePipe();
    expect(pipe).toBeTruthy();
  });
});
