import { OrderMilestoneDatePipe } from './order-milestone-date.pipe';

describe('OrderMilestoneDatePipe', () => {
  it('create an instance', () => {
    const pipe = new OrderMilestoneDatePipe();
    expect(pipe).toBeTruthy();
  });
});
