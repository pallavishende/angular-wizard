import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'textHyperLink'
})
export class TextHyperLinkPipe implements PipeTransform {
  transform(content: string) {
    const text = content.toString();
    if (text.match( /(href)|(src)/i )) {
      return text; // text already has a hyper link in it
    }
    const exp = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    const text1 = text.replace(exp, "<a target='_blank' href='$1'>$1</a>");
    const exp2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
    const emailPattern = /[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/;
    // const matched_str = text1.match(emailPattern);
    return text1.replace(exp2, '$1<a target="_blank" href="http://$2">$2</a>');
  }
}
