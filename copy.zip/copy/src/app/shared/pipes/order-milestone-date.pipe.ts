import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderMilestoneDate',
  pure: true
})
export class OrderMilestoneDatePipe implements PipeTransform {

  transform(value: Array<any>, milestoneName: string): any {
    let milestoneDate: string;
    for (const milestoneObj of value) {
      if (milestoneObj.status === milestoneName) {
        milestoneDate = milestoneObj.createdDate;
        break;
      }
    };
    return milestoneDate;
  }
}
