import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'activityEventType'
})
export class ActivityEventTypePipe implements PipeTransform {

  transform(value: any, activityTypeId?: any): any {
    let transformedValue = '';
    switch (value) {
      case 'CONTENT_SUBMITTED':
        if (activityTypeId === 14 || activityTypeId === 3) {
          transformedValue = 'Completed';
        } else {
          transformedValue = 'Submitted for approval';
        }
        break;

      case 'REJECTED':
        transformedValue = 'Rejected';
        break;

      case 'REOPENED':
        transformedValue = 'Reopened';
        break;

      case 'CLOSED':
        transformedValue = 'Closed';
        break;

      case 'START_WORK':
        transformedValue = 'Started work';
        break;

      case 'APPROVED':
        transformedValue = 'Approved';
        break;

      case 'PUBLISHED':
        transformedValue = 'Completed';
        break;

      case 'CONTENT_QA':
        transformedValue = 'QA - Video completed';
        break;

      case 'ORDER_COMMENTED':
        transformedValue = 'Commented';
        break;

      case 'COMMENTED':
        transformedValue = 'Commented';
        break;
    }
    return transformedValue;
  }

}
