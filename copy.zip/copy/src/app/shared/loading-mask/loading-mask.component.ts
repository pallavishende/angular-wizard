import { Component, OnInit, OnDestroy } from '@angular/core';
import { LoadingMaskService } from './loading-mask.service';

@Component({
    selector: 'app-loading-mask',
    templateUrl: './loading-mask.component.html',
    styleUrls: ['./loading-mask.component.scss']
})

export class LoadingMaskComponent implements OnInit, OnDestroy {

    constructor(private loadingMaskService: LoadingMaskService) {}

    ngOnInit() {}

    get loadingState(){
        return this.loadingMaskService.loadingState;
    }
    get loadingAnimator(){
        return this.loadingMaskService.loadingAnimator;
    }

    ngOnDestroy() {
        this.loadingMaskService.disableLoadingMask();
        this.loadingMaskService.loadingState = false;
    }

}
