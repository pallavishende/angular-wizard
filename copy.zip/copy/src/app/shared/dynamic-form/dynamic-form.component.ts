import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';
import { DynamicFormBase } from './dynamic-form-base';
import { DynamicFormBaseService } from './dynamic-form-control.service';
import { forEach } from 'lodash';

@Component({
  selector: 'app-dynamic-form',
  templateUrl: './dynamic-form.component.html',
  styleUrls: ['./dynamic-form.component.scss'],
  providers: [ DynamicFormBaseService ]
})
export class DynamicFormComponent implements OnInit {

  @Input() formControls: DynamicFormBase<any>[] = [];
  @Input() form: FormGroup;
  @Output() onDeleteFormGroup = new EventEmitter<any>();
  pressOrderMedilisoConstant = ['downloadable', 'passwordProtected', 'expirationDate'];
  initializeEditor = false;
  payLoad = '';
  formErrors = {
    Request: this.RequestErrors()
  };
  validationMessages = {
    Request: {
    }
  };

  constructor() {}

  ngOnInit() {
    this.initializeCustomEditor();
  }

  initializeCustomEditor() {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  onSubmit() {
    this.payLoad = JSON.stringify(this.form.value);
  }

  updateInstructionsForm(event, prameterName, index) {
    const Request = <FormArray>this.form['controls'].Request;
    const x = index;
      let X = <FormGroup>Request.at(index);
      X.value[prameterName] = event;
  }

  updateCheckbox(event, prameterName, index) {
    if (prameterName === 'Custom') {
      this.clearFormValue ('dimensions', event, index);
    }
  }

  updateDropDownChangeField(event, controlType, prameterName, index) {
    if (controlType === 'DeliveryMethod') {

      event = prameterName === 'Other';
      this.clearFormValue('deliveryLocation', event, index);

      event = prameterName === 'Mediasilo';
      this.pressOrderMedilisoConstant.forEach(orderConstant => {
        this.clearFormValue(orderConstant, event, index);
      });
      this.clearFormValue('deliveryOptions', event, index);
    }
  }

  clearFormValue (controlName, event, index) {
    let controls = this.formControls[index];
      forEach(controls, (ctrl: any) => {
        if (ctrl.key === controlName) {
          ctrl.hidden = !event;
          if (!event) {
            ctrl.value = null;
            ctrl.checked = false;
            let Request = <FormArray>this.form['controls'].Request;
            let X = <FormGroup>Request.at(index);
            X.controls[controlName].setValue(null,  {onlySelf: false, emitEvent: true});
          }
        }
      });
  }

  getAspectRatioIcon(label: string) {
    return typeof label !== 'undefined' ? 'ratio-' + label.replace(':', '-').replace(/[^0-9-]/g, '') : '';
  }

  removeFormGroup(requestType) {
    this.onDeleteFormGroup.emit(requestType);
  }

  isValid(key) { return this.form.controls[key].valid; }

  RequestErrors() {
    return [{
    }];
  }
}
