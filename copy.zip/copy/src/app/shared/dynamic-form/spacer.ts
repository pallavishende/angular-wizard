import { DynamicFormBase } from './dynamic-form-base';

export class Spacer extends DynamicFormBase<string> {
  controlType = 'spacer';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
  }
}
