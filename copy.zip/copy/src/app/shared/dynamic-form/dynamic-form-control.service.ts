import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DynamicFormBase } from './dynamic-form-base';

@Injectable()
export class DynamicFormBaseService {

  constructor() { }

  toFormGroup(dyamicForm: DynamicFormBase<any>[] ) {
    let group: any = {};
    
    dyamicForm.forEach(formControl => {
      let formControlValue: any = formControl.value || '';
      if (formControl.controlType === 'checkbox') {
        formControlValue = formControl.value || false;
      }

      group[formControl.key] = formControl.required ? new FormControl(formControlValue, Validators.required)
                                              : new FormControl(formControlValue);
    });
    return new FormGroup(group);
  }
}