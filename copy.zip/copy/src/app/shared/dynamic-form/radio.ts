import { DynamicFormBase } from './dynamic-form-base';

export class Radio extends DynamicFormBase<string> {
  controlType = 'radio';
  options: {key: string, label: string, value: string, disabled: boolean}[] = [];
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.options = options['options'] || [];
    this.type = options['type'] || '';
  }
}
