import { DynamicFormBase } from './dynamic-form-base';

export class Textarea extends DynamicFormBase<string> {
  controlType = 'textarea';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
  }
}