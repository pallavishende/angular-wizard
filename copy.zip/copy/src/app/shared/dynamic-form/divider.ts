import { DynamicFormBase } from './dynamic-form-base';

export class Divider extends DynamicFormBase<string> {
  controlType = 'divider';
  type: string;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] || '';
  }
}
