import { Injectable } from '@angular/core';
import { DynamicFormBase } from './dynamic-form-base';
import { Textbox } from './textbox';
import { Textarea } from './Textarea';
import { dropdown } from './dropdown';
import { Checkbox } from './checkbox';
import { Radio } from './radio';
import { Label } from './Label';
import { Divider } from './divider';

@Injectable()
export class RequestformService {

  getForm(formFields, requesyType, instructions) {
    let instructionsForm: DynamicFormBase<any>[] = [];

    formFields[requesyType].forEach(field => {
      let formFieldsModify = Object.assign({}, field);
      let fieldValue = instructions.filter(inst => inst.label === field.key && inst.type === requesyType);
      if (fieldValue.length > 0) {
        formFieldsModify.value = fieldValue[0].values[0];
        formFieldsModify.hidden = false;
      }
      let newFormField;
      switch (formFieldsModify.type) {
        case'dropdown':
          newFormField = new dropdown(formFieldsModify);
          instructionsForm.push(newFormField);
          break;
        case'textbox':
          newFormField = new Textbox(formFieldsModify);
          instructionsForm.push(newFormField);
          break;
        case'textarea':
          newFormField = new Textarea(formFieldsModify);
          instructionsForm.push(newFormField);
          break;
        case'label':
          newFormField = new Label(formFieldsModify);
          instructionsForm.push(newFormField);
          formFieldsModify.options.forEach(val => {
            val.checked = false;
            const subFieldValue = instructions.filter(inst => inst.label === val.key && inst.type === requesyType);
            if (subFieldValue.length > 0) {
              val.checked = Boolean(subFieldValue[0].values[0]);
              val.value = val.checked;
            } else {
              val.checked = false;
              val.value = false;
            }
            newFormField = new Checkbox(val);
            instructionsForm.push(newFormField);
          });
          break;
        case'radio':
          newFormField = new Radio(formFieldsModify);
          instructionsForm.push(newFormField);
          break;
        case 'divider':
          newFormField = new Divider(formFieldsModify);
          instructionsForm.push(newFormField);
          break;
      }
    });
    return instructionsForm.sort((a, b) => a.order - b.order);
  }
}
