export class DynamicFormBase<T> {
    value: string;
    key: string;
    label: string;
    required: boolean;
    disabled: boolean;
    order: number;
    controlType: string;
    checked: boolean;
    hidden: boolean;
    class: string;
    placeholder: string;
    formField: string;
    defaultValue: string;
    aspectRato: string;
    tooltip: string;
    defaultHidden: boolean;

    constructor(options: {
        value?: string,
        key?: string,
        label?: string,
        required?: boolean,
        disabled?: boolean,
        order?: number,
        controlType?: string,
        checked?: boolean,
        hidden?: boolean,
        class?: string,
        placeholder?: string,
        formField?: string,
        defaultValue?: string,
        aspectRato?: string;
        tooltip?: string;
        defaultHidden?: boolean;
      } = {}) {
      this.value = options.value;
      this.key = options.key || '';
      this.label = options.label || '';
      this.required = !!options.required;
      this.disabled = options.disabled || false;
      this.order = options.order === undefined ? 1 : options.order;
      this.controlType = options.controlType || '';
      this.checked = options.checked || false;
      this.hidden = options.hidden || false;
      this.class = options.class || 'col-md-12';
      this.placeholder = options.placeholder || '';
      this.formField = options.formField || 'form-field';
      this.defaultValue = options.defaultValue || '';
      this.aspectRato = options.aspectRato || '';
      this.tooltip = options.tooltip;
      this.defaultHidden = options.defaultHidden || false;
    }
  }