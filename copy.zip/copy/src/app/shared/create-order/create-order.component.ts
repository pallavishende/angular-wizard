import { Component, Input, OnChanges, SimpleChanges, TemplateRef, OnDestroy } from '@angular/core';
import { CatalogService } from '../../catalog/catalog.service';
import { MatDialog } from '@angular/material';
import { UtilityService } from '../../services/utility.service';
import { Activity } from '../../models/activity';
import { Subscription } from 'rxjs/Subscription';
import { OrderRequestTypes } from 'app/models/bridge-order/shared.model';
import { BridgeUI } from 'app/models/bridge-order/bridge-ui.model';
import { UserService } from 'app/services/user.service';
import { OrdersService } from 'app/orders/orders/orders.service';
import { VideoOrderModel } from 'app/models/bridge-order/order-models/video-order.model';
import { PressOrderModel } from 'app/models/bridge-order/order-models/press-order.model';

@Component({
  selector: 'app-create-order',
  templateUrl: './create-order.component.html',
  styleUrls: ['./create-order.component.scss']
})

/* TO DO: integrate create order in catalog pages with this component */

export class CreateOrderComponent implements OnChanges, OnDestroy {
  @Input() contentDetails;
  @Input() mirrorOrderId; // when create order from another order, it is used as a mirror reference. Id is used for link orders
  subscriptions = new Subscription();
  orderContentType;
  orderType = '';
  orderName = '';
  isFullEpisode = false;
  OrderRequestTypes = OrderRequestTypes;
  videOrderRequestTypeList;
  videoOrderRequestType;
  brandList;
  brand;

  constructor(
    private catalogService: CatalogService,
    private utilityService: UtilityService,
    private userService: UserService,
    private ordersService: OrdersService,
    private dialog: MatDialog
  ) {
    const requestTypeEnumkeys = Object.keys(OrderRequestTypes);
    this.videOrderRequestTypeList = requestTypeEnumkeys;
    this.videoOrderRequestType = this.videOrderRequestTypeList[0];
    this.getAllBrands();
  }

  openDialog(ref: TemplateRef<any>, width, height) {
    this.dialog.open(ref, {
      width: width + 'px',
      height: height + 'px'
    });
    this.orderName = '';
    this.isFullEpisode = false;
  }

  createNewOrderPayload() {
    let contentType = this.orderContentType.toUpperCase();
    if (contentType === 'EVENT' || contentType === 'MOVIE') {
      contentType = 'SPECIAL';
    }

    const userLoginInfo = this.userService.getUserLoginInfo();

    const uiOrder = BridgeUI.Order.createNewOrder(
      this.orderName,
      {
          vmId: this.contentDetails.vmid,
          contentType: contentType,
          orderType: this.orderType.toUpperCase() as any,
          isFullEpisode: this.isFullEpisode,
          isNewOrder: true,
          brand: this.brand ? this.brand.name : '',
          requestType: null,
          orderInstruction: this.ordersService.createOrderInstructions()
      },
      userLoginInfo['firstName'] + ' ' + userLoginInfo['familyName'],
      userLoginInfo['email']
    );

    if ((uiOrder.isPressOrder() || uiOrder.isVideoOrder())) {
      const orderModel = <VideoOrderModel|PressOrderModel>uiOrder.orderModel;
      if (this.catalogService.catalogOrderClipsArr.length > 0) {
        for (let i = 0; i < this.catalogService.catalogOrderClipsArr.length; i++) {
          orderModel.addAsset({
              clipTitle: this.catalogService.catalogOrderClipsArr[i].title,
              clipId: this.catalogService.catalogOrderClipsArr[i].id,
              dsId: this.catalogService.selectedVersion.dsid,
              clipDSId: this.catalogService.catalogOrderClipsArr[i].clipDSID,
              clipSource: null,
              duration: null,
              inOutPoint: null
          });
        }
      } else {
        // start with blank asset
        orderModel.addAsset({
          clipTitle: '',
          clipId: null,
          dsId: null,
          clipDSId: null,
          clipSource: '',
          duration: null,
          inOutPoint: null
        });
      }
    }

    if (uiOrder.isVideoOrder()) {
      uiOrder.metadata.requestType = this.videoOrderRequestType ? OrderRequestTypes[this.videoOrderRequestType] as any : null;
      uiOrder.videoModel.requestType = uiOrder.metadata.requestType;
    }

    const linkedOrders = this.mirrorOrderId ? [this.mirrorOrderId] : [];
    this.catalogService.createOrder(uiOrder.generateDSOrder(), this.orderType, linkedOrders);
    this.orderType = '';
  }

  getVideoRequestType() {
    return this.videoOrderRequestType;
  }

  setVideoOrderRequestType(requestType) {
    this.videoOrderRequestType = requestType;
  }

  getVideoOrderBrand() {
    return this.brand;
  }

  setVideoOrderBrand(brand) {
    this.brand = brand;
  }

  getAllBrands() {
    this.subscriptions.add(this.catalogService.getAllBrands().subscribe(
      data => {
        this.brandList = data['brandsResult'];
        const brandTitle = this.contentDetails && this.contentDetails.originBrandName !== 'n/a' ? this.contentDetails.originBrandName : this.brandList[0].name;
        this.brand = this.brandList.filter(brand => brand.name === brandTitle)[0];
      }));
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.contentDetails.currentValue) {
      if (this.contentDetails.contentType) {
        this.orderContentType = this.contentDetails.contentType.toUpperCase();
        if (this.orderContentType === 'EVENT' || this.orderContentType === 'MOVIE') {
          this.orderContentType = 'SPECIAL';
        }
      } else {
        this.orderContentType = 'BRAND';
      }
    }
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

}
