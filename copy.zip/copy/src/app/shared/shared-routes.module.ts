import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const SharedRoutes: Routes = [
  // { path: 'user-guide', component: SharedBaseComponent, data: {title: 'User Guide'}, canActivate: [ RouteGuard ],
  //   children: [
  //     { path: '', component: UserGuideComponent },
  //     { path: '', component: SiteHeaderComponent, outlet: 'header' }
  //   ]
  // }
];

@NgModule({
  imports: [ RouterModule.forChild(SharedRoutes) ],
  exports: [ RouterModule ]
})

export class SharedRoutesModule {}
