import { Component, OnInit, Input, TemplateRef, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-inline-editor',
  templateUrl: './inline-editor.component.html',
  styleUrls: ['./inline-editor.component.scss']
})
export class InlineEditorComponent implements OnInit {
  @Input() text;
  @Output() onSubmitChange = new EventEmitter<string>();
  textValue = '';
  constructor(
    private dialog: MatDialog
  ) { }

  openDialog(ref: TemplateRef<any>, width, height) {
    this.dialog.open(ref, {
      width: width + 'px',
      height: height + 'px'
    });
    this.textValue = this.text;
  }

  submitChange() {
    if (this.textValue !== this.text) {
      this.onSubmitChange.emit(this.textValue);
    }
  }

  ngOnInit() {
  }
}
