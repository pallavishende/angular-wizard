import { TestBed, inject } from '@angular/core/testing';

import { ContentPanelService } from './content-panel.service';

describe('ContentPanelService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ContentPanelService]
    });
  });

  it('should be created', inject([ContentPanelService], (service: ContentPanelService) => {
    expect(service).toBeTruthy();
  }));
});
