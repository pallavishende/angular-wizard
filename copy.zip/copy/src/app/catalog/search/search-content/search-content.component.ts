import { Component, OnInit, OnChanges, Input,  Output, EventEmitter, SimpleChanges, ViewChild, ElementRef, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { orderBy } from 'lodash';

import { CatalogService } from '../../catalog.service';

@Component({
  selector: 'app-search-content',
  templateUrl: './search-content.component.html',
  styleUrls: [ '../../catalog-base/catalog-base.component.scss', '../search.component.scss', './search-content.component.scss']
})
export class SearchContentComponent implements OnInit, OnChanges {

  @Input() searchContent: any;
  @Input() contentType: string;
  @Output() seriesContent = new EventEmitter<any>();
  @Output() createNewOrder = new EventEmitter<any>();
  @Output() clearSearch = new EventEmitter<any>();
  @ViewChild('orderTitle') input: ElementRef;

  searchResults: Array<any> = [];
  hasContent: boolean;
  sortObj = {
    sortParamsObj: {},
    currentSortSelection: ''
  };

  constructor(
    private router: Router,
    private ngZone: NgZone,
    private catalogService: CatalogService
  ) { }

  ngOnInit() {}

  sortBy(sortProperty) {
    this.sortObj.currentSortSelection = sortProperty;
    if (this.sortObj.sortParamsObj[sortProperty] === undefined) {
      this.sortObj.sortParamsObj[sortProperty] = 'asc';
    } else {
      this.sortObj.sortParamsObj[sortProperty] = (this.sortObj.sortParamsObj[sortProperty] === 'desc') ? 'asc' : 'desc';
    }
    let tmpObj = this.sortObj.sortParamsObj;    // scoping
    if (this.searchResults[this.getActiveContentIndex()] !== undefined) {
      if (sortProperty === 'episodeNumber' || sortProperty === 'totalNumberOfSeasons') {
        this.searchResults[this.getActiveContentIndex()] =
        this.sortDataNumber(this.searchResults[this.getActiveContentIndex()],
        sortProperty, this.sortObj.sortParamsObj[sortProperty]);
      } else {
        this.searchResults[this.getActiveContentIndex()] =
        this.sortData(this.searchResults[this.getActiveContentIndex()],
        sortProperty, this.sortObj.sortParamsObj[sortProperty]);
      }
      // this.setPersistSearchResponse();
    }
  };

  emitSeriesContent(seriesVmid: string) {
    this.seriesContent.emit(seriesVmid);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (typeof changes.contentType !== 'undefined' && !changes.contentType.firstChange) {
      this.searchContent = [];
      this.sortObj.currentSortSelection = '';
      this.sortObj.sortParamsObj = {};
    }
    if (typeof changes.searchContent !== 'undefined' && typeof changes.searchContent.currentValue !== 'undefined') {
      for (let i = 0; i < 3; i++) {
        if (this.searchContent[i] && this.searchContent[i].contentResult) {
          this.searchResults[i] = (this.searchContent[i].contentResult);
        }
      }
      if (this.searchContent[3] && this.searchContent[3].brandsResult) {
        this.searchResults[3] = (this.searchContent[3].brandsResult);
      }
    }
    if (this.searchResults[this.getActiveContentIndex()].length === 0) {
      this.hasContent = false;
    } else {
      this.hasContent = true;
    }
  }

  sortDataNumber(data, sortProperty, sortDirection) {
    if (data !== undefined) {
      return orderBy(data, (obj) => {
        if (obj[sortProperty]) {
          obj[sortProperty] = obj[sortProperty].toString();
          return obj[sortProperty].replace(/\d+/g, (m) => {
            return '000000'.substr(m.length - 1) + m;
          }).toLowerCase();
        }
      }, sortDirection);
    }
  }

  sortData(data, sortProperty, sortDirection) {
    if (data !== undefined) {
      return orderBy(data, (obj) => { if (obj[sortProperty]) { return obj[sortProperty].toLowerCase(); } }, sortDirection);
    }
  }

  goToDetail(episode, event, route): void {
    event.preventDefault();
    // this.setPersistSearchResponse();
    if (episode.hasVersions) {
      this.catalogService.selectedVersion = {'name': episode.versions[0].name, 'dsid': episode.versions[0].dsid};
    }
    this.ngZone.run(() => {
      this.router.navigateByUrl(route);
    });
  }

  getActiveContentIndex() {
    return this.catalogService.getCatalogContentIndex(this.contentType);
  }

  clearSearchAndFilters() {
    this.clearSearch.emit();
  }

  isValidColumn(column: string): boolean {
    switch (column) {
      case 'title':
      if (this.contentType !== 'BRAND') {
        return true;
      }
      return false;
      case 'series':
      if (this.contentType === 'EPISODE') {
        return true;
      }
      return false;
      case 'brand':
      if (this.contentType === 'SERIES' || this.contentType === 'EVENT') {
        return true;
      }
      return false;
      case 'season':
      if (this.contentType === 'SERIES') {
        return true;
      }
      return false;
      case 'episode':
      if (this.contentType === 'EPISODE') {
        return true;
      }
      return false;
      case 'info':
      if (this.contentType !== 'BRAND') {
        return true;
      }
      return false;
      case 'newOrder':
      if (this.contentType !== 'BRAND') {
        return true;
      }
      return false;
    }
  }

  emitOrderPayload(contentType, orderType, lineItem) {
    let payload = {};
    payload['orderVmid'] = lineItem.vmid;
    payload['orderType'] = orderType;
    payload['orderContentType'] = contentType;
    if (contentType === 'BRAND') {
      payload['brandTitle'] = lineItem.name;
    } else if (contentType === 'SERIES') {
      payload['brandTitle'] = lineItem.originBrandName;
      payload['seriesTitle'] = lineItem.title;
    } else if (contentType === 'EPISODE') {
      payload['brandTitle'] = lineItem.originBrandName;
      payload['seriesTitle'] = lineItem.seriesTitle;
      payload['seasonNumber'] = lineItem.seasonNumber;
      payload['episodeNumber'] = lineItem.episodeNumber;
      payload['episodeTitle'] = lineItem.title;
    } else if (contentType === 'EVENT') {
      payload['eventTitle'] = lineItem.title;
      payload['brandTitle'] = lineItem.originBrandName;
    }
    this.createNewOrder.emit(payload);
  }
}
