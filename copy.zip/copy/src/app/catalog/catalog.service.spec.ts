/* tslint:disable:no-unused-variable */
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod, Headers } from '@angular/http';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TestBed, async, inject } from '@angular/core/testing';
import { CatalogService } from './catalog.service';
import { OrdersService } from '../orders/orders/orders.service';
import { ConfigService } from '../services/config.service';
import { UserService } from '../services/user.service';
import { UtilityService } from '../services/utility.service';
import { LoginService } from '../login/login.service';
import { AdalService } from '../shared/auth/adal.service';
import { SecretService } from '../services/secret.service';
import { StorageService } from '../services/storage.service';
import { LoadingMaskService } from '../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../services/system-alerts.service';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../services/environment.service';
import { NavigationService } from '../services/navigation.service';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('CatalogService', () => {

  let catalogValues = new FormGroup({
    searchTerm: new FormControl(),
    searchResponse: new FormControl()
  })


  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        CatalogService,
        OrdersService,
        ConfigService,
        UserService,
        UtilityService,
        LoginService,
        AdalService,
        SecretService,
        StorageService,
        LoadingMaskService,
        SystemAlertsService,
        NavigationService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
            provide: HttpClient,
            useFactory: (http: Http) => http,
            deps: [Http]
        },
        EnvironmentService,
        ConfigurationManagerService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  });

  it('should call the service', inject([CatalogService], (service: CatalogService) => {
    expect(service).toBeTruthy();
  }));

 // it('#getItems should accept a searchObj', inject([CatalogService], (service: CatalogService) => {
  //  expect(service.getItems(catalogValues, 1)).toBeTruthy();
  //}));

  // fit('#getItems should call endpoint and return success response', inject([CatalogService, MockBackend], (service: CatalogService, mockBackend: MockBackend) => {
  //
  //   mockBackend.connections.subscribe((connection: MockConnection) => {
  //       let options = new ResponseOptions({
  //         body: JSON.stringify({ search_term: catalogValues.searchTerm }),
  //       });
  //
  //       let header = new Headers();
  //       header.append('Content-Type', 'application/json');
  //       header.append('Accept', 'application/json');
  //       var body = {
  //         search_term: catalogValues.searchTerm
  //       };
  //       connection.mockRespond(new Response(options));
  //     });
  //
  //     let subject = service;
  //
  //     subject
  //       .getItems(catalogValues.searchTerm)
  //       .subscribe((data) => {
  //         expect(data.json()).toEqual({ response: catalogValues.searchResponse });
  //       });
  //
  // }));


});
