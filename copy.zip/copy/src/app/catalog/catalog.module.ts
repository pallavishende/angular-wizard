import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';
import { CatalogRoutesModule } from './catalog-routes.module';

import { SearchComponent } from './search/search.component';
import { CatalogBaseComponent } from './catalog-base/catalog-base.component';
import { SearchDetailsComponent } from './search-details/search-details.component';
import { OnboardingModule } from '../onboarding/onboarding.module';
import { ModalModule } from 'app/shared/ng-modal';
import { CatalogService } from './catalog.service';
import { ContentPanelService } from './search/content-panel/content-panel.service';
import { ConfigService } from '../services/config.service';
import { OrdersService } from '../orders/orders/orders.service';
import { UtilityService } from '../services/utility.service';
import { VideoPlayerComponent } from '../shared/video-player/video-player.component';
import { SearchContentComponent } from './search/search-content/search-content.component';
import { ContentPanelComponent } from './search/content-panel/content-panel.component';

@NgModule({
  declarations: [
    SearchComponent,
    CatalogBaseComponent,
    SearchDetailsComponent,
    VideoPlayerComponent,
    SearchContentComponent,
    ContentPanelComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    CatalogRoutesModule,
    OnboardingModule,
    ModalModule
  ],
  providers: [ CatalogService, ConfigService, OrdersService, UtilityService, ContentPanelService ]
})

export class CatalogModule { }