import { Component, OnInit, OnDestroy, ElementRef, ViewChild, ViewChildren, QueryList, NgZone } from '@angular/core';
import { CatalogService } from '../catalog.service';
import { Router, ActivatedRoute } from '@angular/router';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { Activity } from '../../models/activity';
import { UtilityService } from '../../services/utility.service';
import { OrderTypes } from '../../models/constants/order-types';
import { Subscription } from 'rxjs/Subscription';
import { map, uniqBy, orderBy } from 'lodash';
import { Location } from '@angular/common';
import { OrderRequestTypes } from 'app/models/bridge-order/shared.model';
import { StorageService } from '../../services/storage.service';
import { BridgeUI } from 'app/models/bridge-order/bridge-ui.model';
import { OrdersService } from 'app/orders/orders/orders.service';
import { UserService } from 'app/services/user.service';
import { VideoOrderModel } from 'app/models/bridge-order/order-models/video-order.model';
import { PressOrderModel } from 'app/models/bridge-order/order-models/press-order.model';

@Component({
  selector: 'app-search-details',
  templateUrl: './search-details.component.html',
  styleUrls: ['../catalog-base/catalog-base.component.scss', './search-details.component.scss']
})
export class SearchDetailsComponent implements OnInit, OnDestroy {

  @ViewChild('orderTitle') input: ElementRef;
  @ViewChild('createOrderDropdown') createOrderDropdown: ElementRef;
  @ViewChildren('assetClips') assetClips: QueryList<ElementRef>;

  subscriptions = new Subscription();
  orderType: string = '';
  isFullEpisode = false;
  ordersObj;
  sessionsList = [];
  selectedSession = 'All Sessions';
  orderName: string;
  selectedRow;
  currentTime: any;
  videoDuration;
  showCCIcon = false;
  showCCtext = true;
  ccTrack;
  selectedClip;
  sortingOrder: 'asc' | 'desc' = 'desc';
  sortColumn;
  dataLoaded = false;

  searchDetailId;
  searchDetailsObj;
  searchVersionDetailsObj;
  selectedVersionDsid: any;
  hasVersions: boolean;
  hasVersionInfo: boolean;
  isVersionContentRestricted: boolean;
  versionContentRestrictionId: number;
  videOrderRequestTypeList;
  videoOrderRequestType;
  brandList;
  brand;
  brandTitle = '';
  OrderRequestTypes = OrderRequestTypes;

  /* adding temporary variable for constructing VMS link. The link will come from the back-end in the suture */
  materialId;
  headerInfoObj = {
    seriesTitle: '',
    episode: ''
  };

  constructor(
    private catalogService: CatalogService,
    private utilityService: UtilityService,
    private router: Router,
    private ngZone: NgZone,
    private activeRoute: ActivatedRoute,
    private alerts: SystemAlertsService,
    private loadingMask: LoadingMaskService,
    private location: Location,
    private storageService: StorageService,
    private userService: UserService,
    private ordersService: OrdersService,
  ) { }

  ngOnInit() {
    this.catalogService.setCatalogPageTitle('Content Details - Viacom Bridge');
    this.catalogService.catalogOrderClipsArr = [];
    this.activeRoute.params.subscribe((params) => {
      this.searchDetailId = params['id'];
      this.selectedVersionDsid = params['dsid'];
      this.catalogService.selectedVersion.dsid = params['dsid'];
      this.videOrderRequestTypeList = Object.keys(OrderRequestTypes);
      const requestTypeFromLocalStorage = this.storageService.getVideoRequestTypeFromLocal();
      this.videoOrderRequestType = requestTypeFromLocalStorage && requestTypeFromLocalStorage.requestType ? requestTypeFromLocalStorage.requestType : this.videOrderRequestTypeList[0];
      this.getItemDetails();
    });
  }

  getHeaderInfo() {
    this.headerInfoObj.seriesTitle = this.searchDetailsObj['seriesTitle'];
    this.headerInfoObj.episode = this.searchDetailsObj['episodeNumber'] ? ' #' + this.searchDetailsObj['episodeNumber'] : '';
    return this.headerInfoObj;
  }

  getNextClip(clip: string) {
    let selectedClipIndex = this.searchVersionDetailsObj.clips.indexOf(this.selectedClip);
    let nextClip;
    if (clip === 'next') {
      if (selectedClipIndex === this.searchVersionDetailsObj.clips.length - 1) {
        this.selectedRow = 0;
        nextClip = this.searchVersionDetailsObj.clips[this.selectedRow];
      } else {
        this.selectedRow = selectedClipIndex + 1;
        nextClip = this.searchVersionDetailsObj.clips[this.selectedRow];
      }
    } else {
      if (selectedClipIndex === 0) {
        this.selectedRow = this.searchVersionDetailsObj.clips.length - 1;
        nextClip = this.searchVersionDetailsObj.clips[this.selectedRow];
      } else {
        this.selectedRow = selectedClipIndex - 1;
        nextClip = this.searchVersionDetailsObj.clips[this.selectedRow];
      }
    }
    this.selectClip(this.selectedRow, nextClip);
  }

  selectClip(selectedClipIndex: number, clip: any) {
    const clipIdentifier = {
      clipId: clip.id,
      materialId: clip.materialId
    };
    this.loadingMask.enableLoadingMask();
    this.subscriptions.add(this.catalogService.getAssetRestrictionType(clipIdentifier.clipId).subscribe(
      (restrictionIdData) => {
        if (restrictionIdData < 3) {
          this.subscriptions.add(this.catalogService.getClipDetails(clipIdentifier).subscribe(
            data => {
              this.loadingMask.disableLoadingMask();
              clip['clipDetails'] = data[0];
              this.selectedClip = clip;
              this.selectedRow = selectedClipIndex;
            },
            error => {
              this.loadingMask.disableLoadingMask();
              this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
              console.log('Error: couldn\'t fetch clip details');
            }
          ));
        } else {
          this.loadingMask.disableLoadingMask();
          this.alerts.addErrorAlerts(`Sorry, the video couldn't be played - this content may have restricted access.`);
        }
      },
      (error) => {
        console.log(`Error occured while getting Alias content restriction id.`, error);
        this.loadingMask.disableLoadingMask();
        // if user don't have access to vms, this error will happen
        this.alerts.addErrorAlerts(`Sorry, the video couldn't be played - this content may have restricted access.`);
      }
    ));
  }

  addToPreorder(event) {
    event.stopPropagation();
    let isChecked = event.target.checked;
    let itemId = event.target.attributes['data-id'].value;
    let itemsArray = this.searchVersionDetailsObj.clips;
    let index = this.findWithAttr(this.catalogService.catalogOrderClipsArr, 'id', itemId);
    let item = itemsArray.find((obj) => {
      return obj.id.toString() === itemId;
    });
    item.dsid = this.searchVersionDetailsObj.dsid;
    isChecked ? this.catalogService.catalogOrderClipsArr.push(item) : this.catalogService.catalogOrderClipsArr.splice(index, 1);
  }

  isClipAlreadyAddedtoOrder(clip) {
    if (map(this.catalogService.catalogOrderClipsArr, 'id').indexOf(clip.id) > -1) {
      return true;
    } else {
      return false;
    }
  }

  showPreorderDialog() {
    if (this.catalogService.catalogOrderClipsArr.length === 0) {
      return false;
    }
  }

  clearModal() {
    this.orderName = '';
  }

  actionOnOpen() {
    let elem = this.input.nativeElement;
    setTimeout(() => {
      elem.focus();
    }, 250);
  }

  createNewOrderPayload() {
    let contentType = this.searchDetailsObj.contentType.toUpperCase();
    if (contentType === 'EVENT' || contentType === 'MOVIE') {
      contentType = 'SPECIAL';
    }

    const userLoginInfo = this.userService.getUserLoginInfo();

    const uiOrder = BridgeUI.Order.createNewOrder(
      this.orderName,
      {
          vmId: this.searchDetailsObj.vmid,
          contentType: contentType,
          orderType: this.orderType.toUpperCase() as any,
          isFullEpisode: this.isFullEpisode,
          isNewOrder: true,
          brand: this.brand ? this.brand.name : '',
          requestType: null,
          orderInstruction: this.ordersService.createOrderInstructions()
      },
      userLoginInfo['firstName'] + ' ' + userLoginInfo['familyName'],
      userLoginInfo['email']
    );

    if ((uiOrder.isPressOrder() || uiOrder.isVideoOrder())) {
      const orderModel = <VideoOrderModel|PressOrderModel>uiOrder.orderModel;
      if (this.catalogService.catalogOrderClipsArr.length > 0) {
        for (let i = 0; i < this.catalogService.catalogOrderClipsArr.length; i++) {
          orderModel.addAsset({
              clipTitle: this.catalogService.catalogOrderClipsArr[i].title,
              clipId: this.catalogService.catalogOrderClipsArr[i].id,
              dsId: this.catalogService.selectedVersion.dsid,
              clipDSId: this.catalogService.catalogOrderClipsArr[i].clipDSID,
              clipSource: null,
              duration: null,
              inOutPoint: null
          });
        }
      } else {
        // start with blank asset
        orderModel.addAsset({
          clipTitle: '',
          clipId: null,
          dsId: null,
          clipDSId: null,
          clipSource: '',
          duration: null,
          inOutPoint: null
        });
      }
    }

    if (uiOrder.isVideoOrder()) {
      uiOrder.metadata.requestType = this.videoOrderRequestType ? OrderRequestTypes[this.videoOrderRequestType] as any : null;
      uiOrder.videoModel.requestType = uiOrder.metadata.requestType;
      this.storageService.setVideoRequestTypeToLocal(this.videoOrderRequestType);
    }
    this.uncheckClips();

    this.catalogService.createOrder(uiOrder.generateDSOrder(), this.orderType);
    this.orderType = '';
  }

  findWithAttr(array, attr, value) {
    for (let i = 0; i < array.length; i += 1) {
      if (value === array[i][attr].toString()) {
        return i;
      }
    }
    return -1;
  }

  getUserInitial(name: string) {
    return name.charAt(0);
  }

  uncheckClips() {
    this.assetClips.forEach((element) => {
      element.nativeElement.checked = false;
    });
  }

  loadItemVersion(version: any) {
    this.catalogService.selectedVersion = version;
    const url = this
        .router
        .createUrlTree(['/catalog/content-details', this.searchDetailId, this.catalogService.selectedVersion.dsid])
        .toString();

    // change url in browser without triggering angular router
    this.location.go(url);

    // get details for new item version
    this.searchDetailId = this.searchDetailId;
    this.selectedVersionDsid = this.catalogService.selectedVersion.dsid;
    this.getItemDetails();
  }

  resetVideoClips() {
    this.selectedRow = null;
    delete this.selectedClip;
  }

  getItemDetails() {
    this.loadingMask.enableLoadingMask('itemDetails');
    if (!this.searchDetailsObj) {
      this.subscriptions.add(this.catalogService.getItemDetails(this.searchDetailId).subscribe(
        data => {
          this.searchDetailsObj = data.contentDetails;
          this.getAllBrands();
          this.catalogService.setCatalogPageTitle(this.searchDetailsObj.title + ' - Content Details - Viacom Bridge');
          this.getItemVersionDetails();
        },
        error => {
          this.loadingMask.disableLoadingMask();
          if (error.status === 404) {
            console.log('Content Details Not Existing');
            this.alerts.redirectTo404Page();
          } else {
            this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
            console.log('Error occurred while getting the content details..');
          }
        }
      ));
    } else {
      // call getItemVersionDetails if episode details are already present
      this.getItemVersionDetails();
    }
  }

  getItemVersionDetails() {
    this.resetVideoClips();
    if (this.searchDetailsObj.hasVersions) {
      this.hasVersions = true;

      if (!this.catalogService.selectedVersion.dsid) {
        this.catalogService.selectedVersion = this.searchDetailsObj.versions[0];
        this.router.navigate(['/catalog/content-details', this.searchDetailId, this.catalogService.selectedVersion.dsid]);
      }

      if (!this.catalogService.selectedVersion.name) {
        for (const version of this.searchDetailsObj.versions) {
          if (version.dsid === this.catalogService.selectedVersion.dsid) {
            this.catalogService.selectedVersion.name = version.name;
            break;
          }
        }
      }
      this.subscriptions.add(this.catalogService.getVersionDetails(this.searchDetailId, this.catalogService.selectedVersion.dsid)
        .subscribe(
        (data) => {
          this.loadingMask.disableLoadingMask();
          this.dataLoaded = true;
          this.hasVersionInfo = true;
          this.resetVersionRestrictionsObject();
          this.searchVersionDetailsObj = data.assetMaterial;
          this.searchVersionDetailsObj.clips.forEach((item) => item.clipDSID = item.dsid);
          this.materialId = this.searchVersionDetailsObj.materialId;
          this.sessionsList = map(uniqBy(this.searchVersionDetailsObj.clips, 'sessionTitle'), 'sessionTitle');
        },
        (errorData) => {
          this.loadingMask.disableLoadingMask();
          console.log('Error occurred while getting the version details..', errorData);
          if (errorData.error.status === `FORBIDDEN`) {
            this.isVersionContentRestricted = true;
            if (errorData.error.message === `Unable to open content for version with VMID [${this.searchDetailsObj.vmid}] and DSID [${this.catalogService.selectedVersion.dsid}]`) {
              this.versionContentRestrictionId = 4;
            } else if (errorData.error.message === `Unable to preview proxy for version with VMID [${this.searchDetailsObj.vmid}] and DSID [${this.catalogService.selectedVersion.dsid}]`) {
              this.versionContentRestrictionId = 3;
            }
          } else {
            if (this.isVersionContentRestricted) {
              this.resetVersionRestrictionsObject();
            }
          }
          this.hasVersionInfo = false;
          this.dataLoaded = true;
        }
        ));
    } else {
      this.loadingMask.disableLoadingMask();
      this.hasVersions = false;
      this.dataLoaded = true;
    }
  }

  getVersionName() {
    if (this.searchVersionDetailsObj) {
      return this.searchVersionDetailsObj.versionName;
    } else {
      return this.searchDetailsObj.versions[0].name;
    }
  }

  getSelectedVersion() {
    return this.catalogService.selectedVersion;
  }

  getCatalogOrderClipsArr() {
    return this.catalogService.catalogOrderClipsArr;
  }

  resetCatalogOrderClipsArr() {
    this.catalogService.catalogOrderClipsArr = [];
  }

  sortBy(property: string) {
    this.sortColumn = property;
    this.searchVersionDetailsObj.clips = orderBy(this.searchVersionDetailsObj.clips, (clip) => {
      return clip[property] ? clip[property].toLowerCase() : clip[property];
    }, [this.sortingOrder]);
    if (this.sortingOrder === 'asc') {
      this.sortingOrder = 'desc';
    } else {
      this.sortingOrder = 'asc';
    }
  }

  navigateToRoute(route: string) {
    this.ngZone.run(() => {
      this.router.navigateByUrl(route);
    });
  }

  resetVersionRestrictionsObject(): void {
    this.isVersionContentRestricted = false;
    this.versionContentRestrictionId = 0;
  }

  getVideoRequestType() {
    return this.videoOrderRequestType;
  }

  setVideoOrderRequestType(requestType) {
    this.videoOrderRequestType = requestType;
  }

  getVideoOrderBrand() {
    return this.brand;
  }

  setVideoOrderBrand(brand) {
    this.brand = brand;
  }

  getAllBrands() {
    this.subscriptions.add(this.catalogService.getAllBrands().subscribe(
      data => {
        this.brandList = data['brandsResult'];
        const brandTitle = this.searchDetailsObj && this.searchDetailsObj.originBrandName !== 'n/a' ? this.searchDetailsObj.originBrandName : this.brandList[0].name;
        this.brand = this.brandList.filter(brand => brand.name === brandTitle)[0];
      }));
  }

  getVideoType(requestType) {
    switch (requestType) {
      case OrderRequestTypes.TRANSCRIPTS: {
        return this.utilityService.activityTypes.VIDEO_TRANSCRIPT.type;
      }
      case OrderRequestTypes.CAPTIONS: {
        return this.utilityService.activityTypes.VIDEO_CAPTIONS.type;
      }
      case OrderRequestTypes.STILL_FRAMES: {
        return this.utilityService.activityTypes.VIDEO_STILLFRAMES.type;
      }
    }
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
