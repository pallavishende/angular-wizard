import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { Order } from '../models/order';
import { Activity } from '../models/activity';
import { SubActivity } from '../models/sub-activity';
import { OrderInstruction } from 'app/models/bridge-order/shared.model';
import { LoadingMaskService } from '../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../services/system-alerts.service';
import { UserService } from '../services/user.service';
import { OrdersService } from '../orders/orders/orders.service';
import { UtilityService } from '../services/utility.service';
import { NavigationService } from '../services/navigation.service';
import { EnvironmentService } from '../services/environment.service';
import { ConfigService } from '../services/config.service';
import { OrderTypes } from '../models/constants/order-types';
import { ALIAS_ASSET_DETAILS_API_KEY } from '../models/constants/keys';
import { OrderRequestTypes } from 'app/models/bridge-order/shared.model';

@Injectable()
export class CatalogService {
  private itemDetailSubject = new BehaviorSubject(null);
  itemDetailStream = this.itemDetailSubject.asObservable();
  itemDetailsCache = {};
  headers = new Headers();
  body = {
    searchTerm: null,
    size: null,
    offset: 0,
    searchType: '',
    seriesTitleFilters: [],
    seasonNumberFilters: [],
    brandNameFilters: []
  };
  selectedVersion = {
    dsid: '',
    name: ''
  };
  catalogOrderClipsArr = [];
  OrderRequestTypes = OrderRequestTypes;

  constructor(
    private title: Title,
    private authHttp: HttpClient,
    private router: Router,
    private configService: ConfigService,
    private userService: UserService,
    private ordersService: OrdersService,
    private utilityService: UtilityService,
    private loadingMask: LoadingMaskService,
    private alerts: SystemAlertsService,
    private navigationService: NavigationService,
    private environmentService: EnvironmentService
  ) { }

  getItems(searchObj: any, pageCount: number, contentType) {
    this.headers.append('Content-Type', 'application/json');
    this.headers.append('Accept', 'application/json');
    this.body = {
      searchTerm: searchObj.searchTerm.value,
      size: 25,
      offset: 50 + 25 * (pageCount - 2),
      searchType: contentType,
      seriesTitleFilters: searchObj.seriesTitleFilters,
      seasonNumberFilters: searchObj.seasonNumberFilters,
      brandNameFilters: searchObj.brandNameFilters
    };
    if (pageCount === 1) {
      this.body.offset = 0;
      this.body.size = 50;
    }
    if (this.body.searchType === 'brands') {
      return this.getBrandsContent();
    } else {
      return this.authHttp.post(this.configService.searchUrl, this.body);
    }
  }

  getBrandsContent() {
    return this.authHttp.get(
      `${this.configService.searchUrl}/brands?name=${encodeURIComponent(
        this.body.searchTerm
      )}`
    );
  }

  getSeriesContent() {
    this.headers.append('Content-Type', 'application/json');
    this.headers.append('Accept', 'application/json');
  }

  getItemDetails(vmid: string, contentType?: string) {
    if (contentType === 'BRAND') {
      return this.authHttp
        .get(this.configService.searchUrl + '/brands-by-ids/' + vmid)
        .map((response: any) => response);
    }
    return this.authHttp
      .get(this.configService.searchDetailsUrl + vmid)
      .map((response: any) => response);
  }

  getItemDetailsCached(vmid: string) {
    if (typeof this.itemDetailsCache[vmid] === 'undefined') {
      // fetch data and set up streem
      this.getItemDetails(vmid).subscribe(data => {
        console.log('getItemDetailsCached > empty > data: ', data);
        this.itemDetailsCache[vmid] = data;
        this.itemDetailSubject.next(data);
      });
    } else {
      console.log(
        'getItemDetailsCached > NOT empty > data: ',
        this.itemDetailStream
      );
    }
    return this.itemDetailStream;
  }

  getVersionDetails(vmid: string, dsid: string) {
    return this.authHttp
      .get(this.configService.searchDetailsUrl + vmid + '/' + dsid)
      .map((response: any) => response);
  }

  getClipDetails(clipIdentifier: any) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        ApiKey: ALIAS_ASSET_DETAILS_API_KEY
      })
    };
    const payload = [
      {
        ItemId: clipIdentifier.clipId,
        ItemType: 'Clip',
        MaterialId: clipIdentifier.materialId
      }
    ];
    const aliasAssetDetailsEndpoint = this.environmentService.isRuntimeEnvironmentGreaterThan(
      4
    )
      ? this.configService.aliasAssetDetailsUrl
      : this.configService.aliasStgAssetDetailsUrl;
    return this.authHttp.post(aliasAssetDetailsEndpoint, payload, httpOptions);
  }

  getAssetRestrictionType(clipId: string): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        ApiKey: ALIAS_ASSET_DETAILS_API_KEY
      })
    };
    const aliasAssetRestrictionEndpoint = this.environmentService.isRuntimeEnvironmentGreaterThan(
      4
    )
      ? this.configService.aliasAssetRestrictionUrl
      : this.configService.aliasStgAssetRestrictionUrl;
    return this.authHttp.get(
      `${aliasAssetRestrictionEndpoint}?contentId=${clipId}`,
      httpOptions
    );
  }

  getClips(vmId: string, dsId: string, clipId: Array<number>) {
    return this.authHttp
      .get(
        this.configService.clipDetailsUrl +
        '/' +
        vmId +
        '/' +
        dsId +
        '/' +
        clipId.toString(),
        { observe: 'response', responseType: 'text' }
      )
      .map(response => JSON.parse(response.body));
  }

  setCatalogPageTitle(title: string) {
    this.title.setTitle(title);
  }

  getCatalogContentIndex(contentType: string): CatalogContent {
    switch (contentType) {
      case 'EPISODE':
        return CatalogContent.Episode;
      case 'SERIES':
        return CatalogContent.Series;
      case 'EVENT':
        return CatalogContent.Event;
      case 'BRAND':
        return CatalogContent.Brand;
    }
  }

  getSeriesDetails(seriesVmid: string) {
    return this.authHttp.get(
      `${this.configService.searchUrl}/content/${seriesVmid}`
    );
  }

  getSeasonDetails(seriesVmid: string, seasonVmid: string) {
    return this.authHttp.get(
      `${this.configService.searchUrl}/content/${seasonVmid}`
    );
  }

  /**
   *  Create new order methods start here
   */
  createNewOrder(payload, orderType: string, linkOrderId?: Array<any>) {
    this.loadingMask.enableLoadingMask();
    this.ordersService.createOrder(payload).subscribe(
      data => {
        this.catalogOrderClipsArr.length = 0;
        if (linkOrderId) {
          // if order is created as a mirror order, no navigation happens and is linked to original order
          this.ordersService
            .linkOrders(data.id, linkOrderId)
            .subscribe(data => {
              this.loadingMask.disableLoadingMask();
              this.alerts.addSuccessAlerts(
                'Your order <strong>' +
                payload.name +
                '</strong> was created successfully!'
              );
              this.ordersService.notifyLinkOrderUpdate(linkOrderId);
            });
        } else {
          this.navigationService.disableRouteGuard();
          this.navigateToOrderDraft(orderType, data.id);
        }
      },
      error => {
        console.log('error');
        this.alerts.addErrorAlerts(
          'Sorry, it looks like there was an error. Try again, or refresh the page.'
        );
      }
    );
  }

  createOrder(orderPayload, orderType, linkedOrders = []) {
    this.loadingMask.enableLoadingMask();
    if (linkedOrders && linkedOrders.length > 0) {
      this.createNewOrder(orderPayload, orderType, linkedOrders);
    } else {
      this.createNewOrder(orderPayload, orderType);
    }
  }

  createAssetOrder(orderName: string, vmId, contentType: string, orderType: string, isFullEpisode: boolean, lineItems,
    requestType, brand, linkOrderId?: Array<any>) {
    this.loadingMask.enableLoadingMask();
    const userLoginInfo = this.userService.getUserLoginInfo();
    contentType = contentType.toUpperCase();
    if (contentType === 'EVENT' || contentType === 'MOVIE') {
      contentType = 'SPECIAL';
    }
    const orderInstruction: OrderInstruction = this.ordersService.createOrderInstructions();
    let activityObj = new Activity();
    if (lineItems.length <= 0) {
      if (orderType === 'press') {
        activityObj.quantity = 1;
        activityObj.typeId = this.utilityService.activityTypes.PRESS.type;
        activityObj.input = {};
        activityObj.subActivities = [];
      } else {
        activityObj = undefined;
      }
      const emptyLineItemObj = this.ordersService.generatePressOrderEmptyLineItem(activityObj, orderType);
      emptyLineItemObj.metadata[0].clipDSId = orderType === 'press' ? null : '';
      lineItems.push(emptyLineItemObj);
    }
    const payload: Order = {
      name: orderName,
      creator: userLoginInfo['firstName'] + ' ' + userLoginInfo['familyName'],
      createdBy: userLoginInfo['email'],
      assigneeEmail: userLoginInfo['email'],
      metadata: {
        vmId: vmId,
        contentType: contentType,
        orderType: orderType.toUpperCase(),
        isFullEpisode: isFullEpisode,
        // TO BE REMOVED temporary flag for combined approval and publish
        isNewOrder: true,
        brand: brand ? brand.name : null,
        requestType: requestType ? OrderRequestTypes[requestType] : null,
        orderInstruction: orderInstruction
      },
      lineItems: lineItems,
      orderFor: 2222,
      to: 'bridge'
    };
    if (linkOrderId) {
      this.createNewOrder(payload, orderType, linkOrderId);
    } else {
      this.createNewOrder(payload, orderType);
    }
  }

  createNonAssetOrder(
    orderName,
    vmId,
    contentType,
    orderType,
    linkOrderId?: Array<any>
  ) {
    this.loadingMask.enableLoadingMask();
    const activityObj = new Activity();
    const subActivityObj = new SubActivity();
    const userLoginInfo = this.userService.getUserLoginInfo();
    contentType = contentType.toUpperCase();
    if (contentType === 'EVENT' || contentType === 'MOVIE') {
      contentType = 'SPECIAL';
    }
    const payload: Order = {
      name: orderName,
      creator: userLoginInfo['firstName'] + ' ' + userLoginInfo['familyName'],
      createdBy: userLoginInfo['email'],
      assigneeEmail: userLoginInfo['email'],
      metadata: {
        vmId: vmId,
        contentType: contentType,
        orderType: orderType.toUpperCase(),
        isFullEpisode: false,
        // TO BE REMOVED temporary flag for combined approval and publish
        isNewOrder: true
      },
      lineItems: [],
      orderFor: 2222,
      to: 'bridge'
    };

    activityObj.quantity = 1;
    subActivityObj.generationMode = this.utilityService.activityGenerationMode.Automatic;
    activityObj.subActivities = [];
    switch (orderType) {
      case OrderTypes.Copy:
        activityObj.typeId = this.utilityService.activityTypes.COPYWRITE.type; // 3;
        activityObj.input = {};
        break;

      case OrderTypes.Graphics:
        activityObj.typeId = this.utilityService.activityTypes.GRAPHICS.type; // 5;
        activityObj.input = {};
        subActivityObj.typeId = this.utilityService.activityTypes.APPROVE_GRAPHICS.type; // 11
        subActivityObj.description = this.utilityService.activityTypes.APPROVE_GRAPHICS.description;
        activityObj.subActivities.push(subActivityObj);
        break;

      case OrderTypes.SiteAndAppUpdates:
        activityObj.typeId = this.utilityService.activityTypes.SITE_APP_UPDATES.type; // 14;
        activityObj.input = {};
        subActivityObj.typeId = this.utilityService.activityTypes.QA.type; // 15
        subActivityObj.description = this.utilityService.activityTypes.QA.description;
        activityObj.subActivities.push(subActivityObj);
        payload.metadata.orderType = 'SITE_APP_UPDATES';
        break;
    }

    payload.lineItems['activities'] = [];
    payload.lineItems.push({ activities: [activityObj] });
    if (linkOrderId) {
      this.createNewOrder(payload, 'copy', linkOrderId);
    } else {
      this.createNewOrder(payload, 'copy');
    }
  }

  navigateToOrderDraft(orderType: string, orderId: number): void {
    switch (orderType.toLowerCase()) {
      case OrderTypes.Video: {
        this.router.navigate(['orders/' + orderId + '/draft/assets']);
        break;
      }
      case OrderTypes.Press: {
        this.router.navigate(['orders/' + orderId + '/draft/assets']);
        break;
      }
      default: {
        this.router.navigate(['orders/' + orderId + '/draft/instructions']);
        break;
      }
    }
  }

  getAllBrands() {
    return this.authHttp.get(
      `${this.configService.searchUrl}/brands?name=*`
    );
  }

  getVideoType(requestType) {
    switch (requestType) {
      case OrderRequestTypes.TRANSCRIPTS: {
        return this.utilityService.activityTypes.VIDEO_TRANSCRIPT.type;
      }
      case OrderRequestTypes.CAPTIONS: {
        return this.utilityService.activityTypes.VIDEO_CAPTIONS.type;
      }
      case OrderRequestTypes.STILL_FRAMES: {
        return this.utilityService.activityTypes.VIDEO_STILLFRAMES.type;
      }
      case OrderRequestTypes.SAA: {
        return this.utilityService.activityTypes.CREATE_VIDEO.type;
      }
    }
  }

}

export enum CatalogContent {
  Episode = 0,
  Series = 1,
  Event = 2,
  Brand = 3
}