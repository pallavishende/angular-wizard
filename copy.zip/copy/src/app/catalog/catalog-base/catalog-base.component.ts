import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalog-base',
  templateUrl: './catalog-base.component.html',
  styleUrls: ['./catalog-base.component.scss']
})
export class CatalogBaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
