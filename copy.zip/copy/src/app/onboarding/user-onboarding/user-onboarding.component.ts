import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

import { UserService } from '../../services/user.service';
import { UserPreferencesService } from '../../user-preferences/user-preferences.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { LoginService } from '../../login/login.service';
import { AzureUser } from '../../models/user';
import { UPDUser } from '../../models/user';

@Component({
  selector: 'app-user-onboarding',
  templateUrl: './user-onboarding.component.html',
  styleUrls: ['./user-onboarding.component.scss'],
  providers: [ UserPreferencesService ]
})
export class UserOnboardingComponent implements OnInit, OnDestroy {

  subscriptions = new Subscription();
  userLoginInfo: AzureUser;
  userInitial: string;
  photoLoaded: boolean;

  constructor(
    private userService: UserService,
    private userPreferencesService: UserPreferencesService,
    private loadingMaskService: LoadingMaskService,
    private alerts: SystemAlertsService,
    private loginService: LoginService,
    private router: Router) { }

  ngOnInit() {
    this.getUserInfo();
  }

  getUserInfo() {
    this.userLoginInfo = this.userService.getUserLoginInfo();
    this.userInitial = this.userLoginInfo.firstName.charAt(0) || "";
    this.userService.getUserPhoto(this.photoLoadHandler, this);
    this.loadingMaskService.disableLoadingMask();
  }

  private photoLoadHandler(result: string, callerComponent: any) {
    const image = document.getElementById('userPhoto');
    if (result !== null) {
      image.setAttribute('src', result);
      callerComponent.photoLoaded = true;
    } else {
      callerComponent.photoLoaded = false;
    }
  }

  finishUserProfileSetup(): void {
    const newUserPayload: UPDUser = {
      login: this.userLoginInfo.email,
      adIdentity: this.userLoginInfo.id,
      firstName: this.userLoginInfo.firstName,
      lastName: this.userLoginInfo.familyName,
      displayName: this.userLoginInfo.displayName
    };
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.userService.createNewUser(newUserPayload).subscribe((data) => {
      console.log('Success: User successfully created:', data);
      this.userService.isNewUser = true;
      this.subscriptions.add(this.userPreferencesService.updateAllUserNotificationPreferences(data['id']).subscribe(
        (userPreferencesData) => {
          console.log('All user preferences have created and checked');
          this.router.navigateByUrl('/catalog');
        },
        (error) => {
          console.log('Issue while creating user preferences');
          this.router.navigateByUrl('/catalog');
        }));
    },
      (error) => {
        console.log('Error: user creation task failed');
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  logout(event) {
    event.preventDefault();
    if (this.loginService.logout()) {
      this.router.navigate(['login']);
    }
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
