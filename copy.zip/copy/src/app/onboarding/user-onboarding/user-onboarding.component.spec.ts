import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AdalService } from '../../shared/auth/adal.service';

import { UserOnboardingComponent } from './user-onboarding.component';
import { UserService } from '../../services/user.service';
import { LoginService } from '../../login/login.service';
import { SecretService } from '../../services/secret.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';

xdescribe('UserOnboardingComponent', () => {
  let component: UserOnboardingComponent;
  let fixture: ComponentFixture<UserOnboardingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      declarations: [ UserOnboardingComponent ],
      providers: [ UserService, LoginService, AdalService, SecretService, ConfigurationManagerService ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserOnboardingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
