import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OnboardingRoutesModule } from './onboarding-routes.module';
import { ModalModule } from 'app/shared/ng-modal';
import { OnboardingBaseComponent } from './onboarding-base/onboarding-base.component';
import { UserOnboardingComponent } from './user-onboarding/user-onboarding.component';
import { SharedModule } from '../shared/shared.module';
import { CompleteSetupModalComponent } from './complete-setup-modal/complete-setup-modal.component';

@NgModule({
  imports: [
    CommonModule,
    OnboardingRoutesModule,
    SharedModule,
    ModalModule
  ],
  exports: [ CompleteSetupModalComponent ],
  declarations: [UserOnboardingComponent, OnboardingBaseComponent, CompleteSetupModalComponent]
})
export class OnboardingModule { }
