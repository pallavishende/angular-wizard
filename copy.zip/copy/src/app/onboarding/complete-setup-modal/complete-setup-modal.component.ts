import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';

import { UserService } from '../../services/user.service';
import { ConfigService } from '../../services/config.service';

@Component({
  selector: 'complete-setup-modal',
  templateUrl: './complete-setup-modal.component.html',
  styleUrls: ['./complete-setup-modal.component.scss']
})
export class CompleteSetupModalComponent implements OnInit {

  @ViewChild('newUserModal') newUserModal;
  userGuideUrl: string;

  constructor(private userService: UserService, private configService: ConfigService) { }

  ngOnInit() {
    this.userGuideUrl = this.configService.userGuideUrl;
    if (this.userService.isNewUser) {
      this.newUserModal.open();
    }
  }

  onModalClose(): void {
    this.userService.isNewUser = false;
  }

}