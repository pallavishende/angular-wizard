import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompleteSetupModalComponent } from './complete-setup-modal.component';

xdescribe('CompleteSetupModalComponent', () => {
  let component: CompleteSetupModalComponent;
  let fixture: ComponentFixture<CompleteSetupModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompleteSetupModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompleteSetupModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
