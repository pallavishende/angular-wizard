import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardingBaseComponent } from './onboarding-base.component';

xdescribe('OnboardingBaseComponent', () => {
  let component: OnboardingBaseComponent;
  let fixture: ComponentFixture<OnboardingBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardingBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardingBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
