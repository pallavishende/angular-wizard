import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';

import { OnboardingBaseComponent } from './onboarding-base/onboarding-base.component';
import { UserOnboardingComponent } from './user-onboarding/user-onboarding.component';
import { SiteHeaderComponent } from '../shared/site-header/site-header.component';


const OnboardingRoutes: Routes = [
  { path: '', component: OnboardingBaseComponent, data: {title: 'Get Started'},
    children: [
      { path: '', component: SiteHeaderComponent, outlet: 'header' },
      { path: '', component: UserOnboardingComponent
      }
    ]
  }
];

@NgModule({
  imports: [ RouterModule.forChild(OnboardingRoutes) ],
  exports: [ RouterModule ]
})

export class OnboardingRoutesModule {}