import { Component, OnInit, OnDestroy, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import 'rxjs/add/operator/toPromise';
import { ActivitiesService } from '../activities.service';
import { LineItem } from '../../models/line-item';
import { ActivitiesCommentsService } from '../../shared/activities-comments/activities-comments.service';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { UserService } from '../../services/user.service';
import { OrdersService } from '../../orders/orders/orders.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { remove, orderBy, clone, cloneDeep, find, forEach } from 'lodash';
import { Observable } from 'rxjs';


const orderPressFormFields = require('../../models/mock-payloads/order-press-form-instructions.json');

@Component({
  selector: 'app-activities-create-press',
  templateUrl: './activities-create-press.component.html',
  providers: [CustomEditorService],
  styleUrls: ['../activities.scss']
})
export class ActivitiesCreatePressComponent implements OnInit, OnDestroy {

  @ViewChildren('versions') versions: QueryList<any>;
  @ViewChild('submitForApprovalModal') submitForApprovalModal;
  @ViewChild('submitForApprovalModalSummary') submitForApprovalModalSummary;
  orderStatus;
  activityStatus = '';
  activityBundleId: string;
  detailsObj;
  loggedInUser;
  subscriptions = new Subscription();
  dataSubscription: Subscription;
  updatedObj;
  submissionComment;
  attachmentsStatus: any = {};
  activitySubmissionObj = {};
  commentServiceInstance: ActivitiesCommentsService;
  initializeEditor: boolean;
  initializeEditorSummary: boolean;
  oldSubmissionMsg = '';
  isValidDescription: boolean;
  disableDataPolling = false;
  pressInstructionsList;
  pressInstrFormFields;
  pressOrderClipsArr = [];
  activityEventsMap = {};
  submittedActivityStatus = false;
  assetListModal = [];
  composeStatusFromEvents = 'Updating';
  commentsCountStream: Observable<any>;
  orderName = '';
  selectAllCheckbox = false;
  hideBackToSelection = false;
  updatingSubmitButton = '';
  submittedActivity = {};

  constructor(
    private ordersService: OrdersService,
    private activitiesService: ActivitiesService,
    private activeRoute: ActivatedRoute,
    private alerts: SystemAlertsService,
    private loadingMaskService: LoadingMaskService,
    private userService: UserService,
    public customEditorService: CustomEditorService
  ) { }


  ngOnInit() {
    this.activitiesService.setActivitiesPageTitle('Create Video - Press & Media - Viacom Bridge');
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.activityBundleId = this.activeRoute.snapshot.params['id'];
    this.pressInstrFormFields = orderPressFormFields;
    this.getActivityInfo();
    this.pollingFunction();
  }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        this.pollCurrentTaskStatus();
      }
    ));
  }

  pollCurrentTaskStatus() {
    if (this.disableDataPolling) {
      return;
    }
    const self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(self.activityBundleId)
      .subscribe(data => {
          self.updatedObj = data;
          this.detailsObj.composeStatus = data.activityBundle.status;
          this.setActivityStatus(self.updatedObj);
          this.activityStatus = data.activityBundle.status;
          self.getOrderStatus();
      });
  }

  setActivityStatus(updatedObj) {
    updatedObj.lineItems.forEach(item => {
      const lineItemIndex = this.detailsObj.lineItems.findIndex(i => i.id === item.id);
      if (lineItemIndex >= 0) {
        this.detailsObj.lineItems[lineItemIndex].activities[0].currentState.status = item.activities[0].currentState.status;
        if (this.activityEventsMap[item.activities[0].id]) {
          this.activityEventsMap[item.activities[0].id].status = item.activities[0].currentState.status;
        }
      }
    });
    this.createAssetListForModal();
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
        this.loadingMaskService.disableLoadingMask();
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.dataSubscription = this.activitiesService.getActivityDetail(this.activityBundleId)
      .subscribe(
        data => {
          this.detailsObj = data;
          this.detailsObj.lineItems = this.sortAssetsByNumber(this.detailsObj.lineItems);
          this.updatedObj = data;
          this.detailsObj.composeStatus = data.activityBundle.status;
          this.getOrderStatus();
          this.orderName = this.detailsObj.orderName;
          if (this.detailsObj.activityBundle.orderClipName) {
            this.activitiesService
              .setActivitiesPageTitle('Create Video - Press & Media ' + this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
          }
          const self = this;
          // sorting lineItems by endpoints in ascending order
          this.activityStatus = this.detailsObj.activityBundle.status;
          this.pressInstructionsList = this.activitiesService.getPressOrderSummary(this.pressInstrFormFields, this.detailsObj.lineItems[0].activities[0].instructions);
          this.createAssetListForModal();
        },
        error => {
          this.loadingMaskService.disableLoadingMask();
          if (error.status === 404) {
            this.alerts.redirectTo404Page();
          } else {
            this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
          }
          console.log('all activities error', error);
        }
      );
  }

  createAssetListForModal() {
    this.assetListModal = [];
    this.detailsObj.lineItems.forEach(item => {
      let title = item.metadata[0].assetInputs[0].assetNumber + ' (' + item.metadata[0].assetInputs[0].assetName + ' (' + item.metadata[0].assetInputs[0].assetSource + '))';
      const lineItemObj = { assetNumber: item.metadata[0].assetInputs[0].assetNumber, title: title, activityId: item.activities[0].id, status: item.activities[0].currentState.status };
      this.assetListModal.push(lineItemObj);
      if (item.activities[0].currentState.status === 'COMPLETED') {
        this.submittedActivity[item.activities.id] = lineItemObj;
      }
    });
  }

  onSubmitForApproval(lineItem: any) {
    const activities = [];
    this.selectAllCheckbox = false;
    // extracting the ids from activities
    for (let i = 0; i < lineItem.length; i++) {
      activities[i] = lineItem[i].activityId;
    }
    const mentionsEmails = [];
    this.activitySubmissionObj['mentionedUsers'].forEach((element) => {
      mentionsEmails.push(element.email);
    });
    const submissionPayload = {
      activityIds: activities,
      orderId: this.detailsObj.activityBundle.orderId,
      message: this.submissionComment || '',
      mentionedUserEmails: mentionsEmails,
      createdByEmail: this.userService.getUserLoginInfo().email,
      attachments: this.attachmentsStatus['uploadedFileQueue']
    };
    this.disableDataPolling = true;
    this.detailsObj.composeStatus = 'Updating';
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.submitActivityForApproval(submissionPayload).subscribe(
      data => {
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addSuccessAlerts('Success! Your work was submitted for approval.');
        this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
        this.disableDataPolling = false;
        this.submissionComment = '';
        this.oldSubmissionMsg = '';
        this.pressOrderClipsArr = [];
        this.hideBackToSelection = false;
        this.attachmentsStatus = [];
        Observable.of(submissionPayload).mergeMap((dataRespMerge: any) => {
          // Press only needs to retry because  there are multiple lineitems
          this.pollCurrentTaskStatus();
          return Observable.throw('Retrying status');
        }).retryWhen(errors => errors.delay(3000).take(5))
        .finally(() => {
          this.pollCurrentTaskStatus();
        })
        .subscribe((dataResp: any) => {
          console.log('subscribe');
          // TODO: tie the activity status to lineItem and update
        });
      },
      error => {
        this.disableDataPolling = false;
        this.pollCurrentTaskStatus();
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        this.loadingMaskService.disableLoadingMask();
      }
    ));
  }

  contentChanged(event) {
    this.activitySubmissionObj = event;
    if (event.isValidContent) {
      // this.renderer.addClass(this.submitDescriptionBtn.nativeElement, 'ready');
      this.isValidDescription = true;
      this.submissionComment = event.content;
      this.oldSubmissionMsg = event.content;
    } else {
      if (this.submissionComment) {
        this.submissionComment = event.content;
        this.oldSubmissionMsg = event.content;
      }
      // this.renderer.removeClass(this.submitDescriptionBtn.nativeElement, 'ready');
      this.isValidDescription = false;
    }
    if (event.readyToPostComment) {
      this.onSubmitForApproval(this.pressOrderClipsArr);
    }
  }

  updateAttachmentsMetadata(event, lineItems?, activityType?) {
    if (activityType === 'PRESS_ACTIVITY') {
      for (let item of this.detailsObj.lineItems) {
        let uploadLineItem = clone(item);
        this.updateFilesMetadata(event, uploadLineItem);
      }
    } else {
      this.attachmentsStatus = event;
    }
  }

  updateFilesMetadata(event, lineItem?) {
    let eventClone = cloneDeep(event);
    if (!eventClone.uploadingInProgressQueue.length) {
      forEach(eventClone.uploadedFileQueue, (uploadedFile) => {
        uploadedFile.source = 'S3';
        uploadedFile.activityId = this.getPressActivity(lineItem)['id'];
      });
      this.subscriptions.add(this.activitiesService.updateFilesMetadata(eventClone.uploadedFileQueue).subscribe(
        (data) => {
          console.log('Successfully updated the metadata.');
          const lineItemIndex = this.detailsObj.lineItems.findIndex(line => line.id === lineItem.id);
          if (lineItemIndex > 0) {
            if (this.detailsObj.lineItems[lineItemIndex].activities[0].input) {
              this.detailsObj.lineItems[lineItemIndex].activities[0].input.attachments = data;
            } else {
              this.detailsObj.lineItems[lineItemIndex].activities[0].input = { attachments: data };
            }
          }
        },
        error => {
          console.log('Error in updating the metadata');
        }));
    }
  }

  addToPreorder($event) {
    $event.stopPropagation();
    const isChecked = $event.target.checked;
    const itemId = $event.target.attributes['data-id'].value;
    const itemsArray = this.assetListModal;
    const item = itemsArray.filter(function (obj) {
      return obj.activityId.toString() === itemId;
    });
    if (isChecked) {
      this.pressOrderClipsArr.push(item[0]);
      this.submittedActivity[itemId] = item[0];
    } else {
      this.selectAllCheckbox = false;
      delete this.submittedActivity[itemId];
      remove(this.pressOrderClipsArr, (clip) => {
        return item[0].activityId === clip.activityId;
      });
    }

    const orderedLineItems = orderBy(this.pressOrderClipsArr, (lineItem: any) => {
      return Number(lineItem.assetNumber.split(' ')[1]);
    }, 'asc');
    this.pressOrderClipsArr = orderedLineItems;
  }

  addAllToPreorder(event) {
    const isChecked = event.target.checked;
    this.selectAllCheckbox = isChecked;
    if (isChecked) {
      this.assetListModal.forEach(item => {
        if (item.status === 'TO_DO') {
          this.submittedActivity[item.activityId] = item;
          this.pressOrderClipsArr.push(item);
          this.submittedActivity[item.activityId] = item;
        }
      });
    } else {
      remove(this.pressOrderClipsArr, (clip) => {
        delete this.submittedActivity[clip.activityId];
        return true;
      });
    }
  }

  openSummaryModal() {
    if (this.getToDoTasksList().length > 1) {
      this.submitForApprovalModal.open();
    } else {
      const itemsArray = this.assetListModal;
      const item = this.getToDoTasksList();
      this.pressOrderClipsArr.push(item[0]);
      this.submitForApprovalModalSummary.open();
      this.hideBackToSelection = true;
    }
  }

  isAssetSubmitted(asset) {
    return (asset.status === 'COMPLETED') ||
      (asset.status === 'TO_DO' && this.activityEventsMap[asset.activityId]);
  }

  clearSelectedAssets() {
    this.pressOrderClipsArr = [];
    this.attachmentsStatus = {};
    this.submissionComment = '';
    this.oldSubmissionMsg = '';
    this.submittedActivity = {};
    this.createAssetListForModal();
  }

  eventForId(event) {
    if (event && event.length > 0) {
      event.forEach(element => {
        const submittedEvent = element.type === 'CONTENT_SUBMITTED' ? element : undefined;
        if (submittedEvent) {
          const lineItemIndex = this.detailsObj.lineItems.findIndex(item => item.activities[0].id === submittedEvent.activityId);
          if (lineItemIndex >= 0) {
            this.activityEventsMap[submittedEvent.activityId] = { message: submittedEvent.comment && submittedEvent.comment.message ? submittedEvent.comment.message : '', status: this.detailsObj.lineItems[lineItemIndex].activities[0].currentState.status, createdDate: submittedEvent.createdDate };
          }
        }
      });
    }
  }

  getSubmittedDate(activityId) {
    return this.activityEventsMap[activityId] && this.activityEventsMap[activityId].status === 'COMPLETED'
      ? this.activityEventsMap[activityId].createdDate :
      (this.activityEventsMap[activityId] && this.activityEventsMap[activityId].status === 'TO_DO' ? 'Updating' : '');
  }

  setCommentsServiceInstanceObj(serviceInstance) {
    this.commentServiceInstance = serviceInstance;
  }

  updateComments() {
    this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
  }

  getPressActivity(item?: LineItem) {
    let lineItem: LineItem;
    if (item) {
      lineItem = item;
    }
    return find(lineItem.activities, { 'typeId': 17 });
  }

  onOpenSubmissionModal() {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  onCloseSubmissionModal() {
    this.closeModal();
  }

  submitForApprovalModalCancel() {
    this.pressOrderClipsArr = [];
  }

  onOpenSubmissionModalSummary() {
    setTimeout(() => {
      this.initializeEditorSummary = true;
    });
  }

  onCloseSubmissionModalSummary() {
    this.closeModal();
  }

  closeModal() {
    this.initializeEditorSummary = false;
    this.pressOrderClipsArr = [];
    this.selectAllCheckbox = false;
  }

  openApprovalSummaryModal() {
    const pressArray = this.pressOrderClipsArr;
    this.submitForApprovalModal.close();
    this.pressOrderClipsArr = pressArray;
    this.submitForApprovalModalSummary.open();
  }

  backToAssetSlectionModal() {
    const pressArray = this.pressOrderClipsArr;
    this.submitForApprovalModalSummary.close();
    this.pressOrderClipsArr = pressArray;
    this.submitForApprovalModal.open();
  }

  isAssetSelected() {
    return this.pressOrderClipsArr.length > 0;
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    console.log('fetching comment..:');
  }

  setTaskCommentsCountStream(event): void {
    this.commentsCountStream = event;
  }

  isAssetAlreadyAddedtoOrder(activityId) {
    if (this.pressOrderClipsArr && (this.pressOrderClipsArr.findIndex(order => order.activityId === activityId)) > -1) {
      return true;
    } else {
      return false;
    }
  }

  getToDoTasksList() {
    return this.assetListModal.filter(asset => asset.status === 'TO_DO');
  }

  typeofValue(value) {
    return typeof value;
  }

  checkComment(content) {
    if (content) {
      const filtered = content.toString().replace(/&nbsp;|\s\n/g, '');
      const removeBr = filtered.toString().replace(/[<]br[^>]*[>]/gi, '');
      return removeBr.trim() !== '';
    }
  }

  sortAssetsByNumber(assets: Array<LineItem>): Array<LineItem> {
    const sortedAssets = orderBy(assets, (asset: LineItem) => {
      return Number(asset.metadata[0].assetInputs[0].assetNumber.split(' ')[1]);
    }, 'asc');
    return sortedAssets;
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }
}
