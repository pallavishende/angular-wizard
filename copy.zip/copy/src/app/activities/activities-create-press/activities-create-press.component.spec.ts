import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesCreatePressComponent } from './activities-create-press.component';

xdescribe('ActivitiesComposeContentComponent', () => {
  let component: ActivitiesCreatePressComponent;
  let fixture: ComponentFixture<ActivitiesCreatePressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesCreatePressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesCreatePressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should be created', () => {
    expect(component).toBeTruthy();
  });
});