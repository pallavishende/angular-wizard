import {
  Component,
  OnInit,
  OnDestroy,
  NgZone,
  HostListener,
  ApplicationRef
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder } from '@angular/forms';
import * as moment from 'moment/moment';
import { forEach, sortBy, forEachRight, orderBy, remove, includes } from 'lodash';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';

import { ActivitiesService } from '../activities.service';
import { UserService } from '../../services/user.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { StorageService } from '../../services/storage.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { Subscription } from 'rxjs';
import {IntervalObservable} from 'rxjs/observable/IntervalObservable';
import { UtilityService } from '../../services/utility.service';

const statusFilter = [
  {id: "IN_PROGRESS", label: "IN_PROGRESS", count: 0},
  {id: "WAITING", label: "WAITING", count: 0},
  {id: "TO_DO", label: "TO_DO", count: 0},
  {id: "REJECTED", label: "REJECTED", count: 0},
  {id: "REOPENED", label: "REOPENED", count: 0}
];

@Component({
  selector: 'app-activities',
  templateUrl: './activities.component.html',
  styleUrls: ['../activities.scss'],
})

export class ActivitiesComponent implements OnInit, OnDestroy {
  pageType;
  pageTypeQuery = '';
  activitiesObj;
  activities;
  users;
  teamInfo;
  teamId;
  activityFilters;
  persistedActivitiesObj = {
    selectedFilters: [],
    searchTerm: ''
  };
  displayNames = [];
  assignedUser;
  hideResults = false;
  bulkArr = [];
  showOptions = false;
  searchObj: FormGroup;
  subscriptions = new Subscription();
  userNameSubscription;
  selectRow;
  queryString = '';
  userNameQuery = '';
  showNoSuggestion = false;
  showCalendars = false;
  customStartDate = '';
  customEndDate = '';
  validSearchInput: boolean;
  userEmail: string;
  dateArr = [];
  queryArr = [];
  showEmpty = false;
  dateQuery = '';
  filteredList = [];
  userInputValue = '';
  userInputEmail = '';
  activeBulkButton = false;
  pageNumber = 0;
  pageCount = 0;
  isLoadingData: boolean;
  filteredActivities;
  uncheckAssignBoxes = false;
  uncheckSelectAllBox = false;
  noEmptyMessage = true;
  loadingUsers: Array<number> = [];
  filterConfig: Array<any> = [];
  filterIndices;

  // table component config
  configObj = {
    objPropNames: [], // gets populated in data subscription of getActivities() method below
    emptyColumnsInLeft: [''], // entered as empty strings because *ngFor does not use numbers to iterate by
    objPropNamesForUI: ['Assigned to', 'Type', 'Order Name', 'Content', 'Due By', 'Status'],
    reorderedObjProps: ['activityTypeId', 'orderName', 'contentType', 'dueDate', 'status'],
    specialContentCols: [] // columns that get special treatment e.g. transclusion
  };

  constructor(
    private activitiesService: ActivitiesService,
    private utilityService: UtilityService,
    private searchFormBuilder: FormBuilder,
    public loadingMask: LoadingMaskService,
    private userService: UserService,
    private storageService: StorageService,
    private alerts: SystemAlertsService,
    private activatedRoute: ActivatedRoute,
    private ngZone: NgZone,
    private appRef: ApplicationRef) {
    this.createSearchForm();
    this.subscriptions.add(this.searchObj.get('searchTerm').valueChanges.debounceTime(500).distinctUntilChanged().subscribe(() => this.searchActivities()));
  }

  ngOnInit() {
    this.userEmail = this.userService.getUserLoginInfo().email;
    this.pageType = this.activatedRoute.snapshot.url[0].path;
    this.persistedActivitiesObj['activeTab'] = this.pageType;
    this.userService.getMyTeams().subscribe((teamsData) => {
      this.teamInfo = teamsData;
      this.initialize();
    });
    this.pollingFunction();
  }

  initialize() {
    switch (this.pageType) {
      case 'my-tasks':
        this.pageTypeQuery = '&userEmail=' + this.userEmail + '&excludeStatuses=COMPLETED';
        this.activitiesService.setActivitiesPageTitle('My Tasks - Viacom Bridge');
        break;
      case 'my-teams-tasks':
        if (this.teamInfo && this.teamInfo[0]) {
          this.teamId = this.teamInfo[0].id;
          this.pageTypeQuery = '&teams=' + this.teamId + '&excludeStatuses=COMPLETED';
          this.activitiesService.setActivitiesPageTitle('My Team\'s Tasks - Viacom Bridge');
        }
        break;
      case 'all-tasks':
        this.activitiesService.setActivitiesPageTitle('All Tasks - Viacom Bridge');
        break;
    }
    if (this.storageService.getActivitesObjFromLocal() === null) {
      this.setActivitiesToLocalStorage();
    }
    this.configFilters();
    this.getActivitiesObjFromLocalStorage();
    this.getFilters();
    if (this.persistedActivitiesObj) {
      this.filterActivities(this.queryString);
    } else {
      this.getActivities();
    }
  }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(60000).subscribe(
      interval => {
        if (this.bulkArr.length === 0) {
          this.getActivities(0, true);
          this.getFilters(true);
        }
      }
    ));
  }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const scrollPercentage = (((window.scrollY + window.innerHeight) / document.scrollingElement.scrollHeight)) * 100;
    if (scrollPercentage >= 98 && this.activities && !this.isLoadingData) {
      if (this.activities.length < this.activitiesObj.totalElements) {
        this.isLoadingData = true;
        this.pageNumber = this.pageCount + 2;
        this.pageCount++;
        this.getActivities();
      }
    }
  }

  createSearchForm() {
    this.searchObj = this.searchFormBuilder.group({
      searchTerm: ''
    });
  }

  getActivities(pageNumber?: number, isPolling?: boolean) {
    let pageSize;
    if (isPolling) {
      pageSize = this.pageNumber === 0 ? 50 : 50 + (this.pageNumber - 1) * 25;
    } else {
      if (pageNumber === undefined) {
        pageNumber = this.pageNumber;
      } else {
        pageSize = this.activities.length;
      }
    }
    let activityObservable;
    if (this.pageType === 'all-tasks') {
      activityObservable = this.activitiesService.getActivities(pageNumber, this.queryString, pageSize);
    } else {
      activityObservable = this.activitiesService.getActivities(pageNumber, this.queryString + this.pageTypeQuery, pageSize);
    }
    this.subscriptions.add(activityObservable.subscribe(
      data => {
        this.loadingMask.disableLoadingMask();
        this.activitiesObj = data;

        // this.activitiesObj.content = _.sortBy(this.activitiesObj.content, 'id');

        if (pageNumber === 0) {
          this.activities = this.activitiesObj.content;
        } else {
          this.activities.push(...data.content);
        }
        if (isPolling) {
          this.activities.length === 0 ? this.showEmpty = true : this.showEmpty = false;
        }
        this.isLoadingData = false;

        // get property names
        if (this.activities && this.activities.length > 0) {
          if (data.content.length) {
            this.configObj.objPropNames = Object.keys(data.content[0]); // actual data obj property names, replaced in UI by those below
          }
        }
      },
      error => {
        this.loadingMask.disableLoadingMask();
        if (!isPolling) {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
        console.log('all activities error');
      }
    ));
  }

  configFilters() {
    this.filterIndices = {
      activityTypeNames: 0,
      statuses: 1,
      users: 2,
      teamsIdAndTitles: 3,
      brandIdAndTitles: 4,
      seriesIdAndTitles: 5,
      moviesAndSpecials: 6
    };
    this.filterConfig = [
      {
        name: 'activityTypeNames',
        displayName: 'Type',
        queryKey: 'typeId=',
        queryValue: 'typeId',
        optionKey: 'typeId',
        displayCount: 5,
        selectionArr: []
      },
      {
        name: 'statuses',
        displayName: 'Status',
        queryKey: 'statuses=',
        queryValue: 'label',
        optionKey: 'label',
        displayCount: 5,
        selectionArr: []
      },
      {
        name: 'users', // name for identifing filter type
        displayName: 'Assigned To', // name to display on UI
        queryKey: 'userEmail=', // mapping for api call query type
        queryValue: 'login', // mapping for api call query content
        optionKey: 'displayName', // mapping for filter option names shown in UI
        displayCount: 5, // toggles between show 5 and show all
        selectionArr: [] // array to store checked options
      },
      {
        name: 'teamsIdAndTitles',
        displayName: 'Assigned To (Team)',
        queryKey: 'assignedTeams=',
        queryValue: 'id',
        optionKey: 'label',
        displayCount: 5,
        selectionArr: []
      },
      {
        name: 'brandIdAndTitles',
        displayName: 'Brand',
        queryKey: 'brands=',
        queryValue: 'id',
        optionKey: 'label',
        displayCount: 5,
        selectionArr: []
      },
      {
        name: 'seriesIdAndTitles',
        displayName: 'Series',
        queryKey: 'series=',
        queryValue: 'id',
        optionKey: 'title',
        displayCount: 5,
        selectionArr: []
      },
      {
        name: 'moviesAndSpecials',
        displayName: 'Movies and Specials',
        queryKey: 'moviesAndSpecials=',
        queryValue: 'id',
        optionKey: 'label',
        displayCount: 5,
        selectionArr: []
      }
    ];
    if (this.pageType !== 'all-tasks' && this.pageType !== 'my-teams-tasks') {
      this.filterConfig.splice(3, 1);
      this.filterIndices = {
        activityTypeNames: 0,
        statuses: 1,
        users: 2,
        brandIdAndTitles: 3,
        seriesIdAndTitles: 4,
        moviesAndSpecials: 5
      };
    }
  }

  getFilters(isPolling?: boolean) {
    let filterObservable;
    if (this.pageType === 'my-tasks') {
      filterObservable = this.activitiesService.getFilters('?assignedUserEmail=' + this.userEmail + '&excludeStatuses=COMPLETED');
    } else if (this.pageType === 'my-teams-tasks') {
      filterObservable = this.activitiesService.getFilters('?assignedTeams=' + this.teamId + '&excludeStatuses=COMPLETED');
    } else {
      filterObservable = this.activitiesService.getFilters();
    }
    this.subscriptions.add(filterObservable.subscribe(
      data => {
        this.activityFilters = data;
        if (this.activityFilters.users) {
          this.activityFilters.users = sortBy(this.activityFilters.users, 'displayName');
        }
        if (this.activityFilters.teamsIdAndTitles) {
          this.activityFilters.teamsIdAndTitles = sortBy(this.activityFilters.teamsIdAndTitles, 'label');
        }
        if (this.pageType !== 'all-tasks') {
          this.setStatusFilter();
        }
      },
      error => {
        console.log('all get filters error');
        if (!isPolling) {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
      }
    ));
  }

  setStatusFilter() {
    let statusBackup = this.activityFilters.statuses;
    this.activityFilters.statuses = statusFilter;
    this.activityFilters.statuses.forEach(s => {
      s.count = 0;
    });
    if(statusBackup && statusBackup.length > 0) {
      statusBackup.forEach(status => {
        let index = this.activityFilters.statuses.findIndex(sts => sts.id === status.id);
        if(index >= 0) {
          this.activityFilters.statuses[index].count = status.count;
        }
      });
    }
  }

  searchActivities() {
    if ((this.searchObj.get('searchTerm').value).trim() === '') {
      this.validSearchInput = false;

      // depopulate query array
      forEachRight(this.queryArr, (item, index) => {
        if (item.substring(0, 2) === 'q=') {
          this.queryArr.splice(index, 1);
        }
      });

      // construct query string from query array
      this.queryString = this.queryArr.join('&');
      this.filterActivities(this.queryString);
    } else {
      this.validSearchInput = true;
    }

    if (this.validSearchInput) {
      this.resetPage();
      this.loadingMask.enableLoadingMask();

      forEachRight(this.queryArr, (item, index) => {
        if (item.substring(0, 2) === 'q=') {
          this.queryArr.splice(index, 1);
        }
      });

      // populate query array
      this.queryArr.push('q=' + encodeURIComponent(this.searchObj.get('searchTerm').value));
      this.persistedActivitiesObj['searchTerm'] = this.searchObj.get('searchTerm').value;

      // construct query string from query array
      this.queryString = this.queryArr.join('&');

      this.setActivitiesToLocalStorage();
      let filterActivitiesObservable;
      if (this.pageType === 'all-tasks') {
        filterActivitiesObservable = this.activitiesService.filterActivities(this.queryString, this.pageNumber);
      } else {
        filterActivitiesObservable = this.activitiesService.filterActivities(this.queryString + this.pageTypeQuery, this.pageNumber);
      }
      this.subscriptions.add(filterActivitiesObservable.subscribe(
        data => {
          this.loadingMask.disableLoadingMask();
          this.activitiesObj = data;
          this.activities = this.activitiesObj.content;
          this.activities.length === 0 ? this.showEmpty = true : this.showEmpty = false;
        },
        error => {
          this.loadingMask.disableLoadingMask();
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
          console.log('search all activities error');
        }
      ));
      this.bulkArr.length = 0;
    }
  }

  clearTerm() {
    this.searchObj.get('searchTerm').setValue('');
    this.resetPage();
    this.bulkArr.length = 0;
    this.persistedActivitiesObj.searchTerm = '';
    forEachRight(this.queryArr, (item, index) => {
      if (item.substring(0, 2) === 'q=') {
        this.queryArr.splice(index, 1);
      }
    });
  }

  onSelectContentNotify(payload: any) {
    payload.event.target.select();
  }

  onSelectNameNotify(payload: any) {
    this.assignActivity(payload);
  }

  /*onRemoveNameNotify(payload: any) {
    this.unassignActivity(payload, 'single');
  }*/

  onLoadingUsersNotify(payload: Array<number>) {
    this.loadingUsers = this.loadingUsers.concat(payload);
  }

  assignActivity(payload) {
    this.subscriptions.add(this.activitiesService.assignActivity(payload)
      .subscribe(
        data => {
          this.loadingMask.disableLoadingMask();
          this.ngZone.run(() => {
            if ((this.pageType === 'my-tasks' && data[0].assignedUserEmail !== this.userEmail)
            || (this.pageType === 'my-teams-tasks' && data[0].teamId !== this.teamInfo[0].id)) {
              this.activities.splice(this.activities.indexOf(payload.item), 1);
              if (this.bulkArr.indexOf(payload.item) !== -1) {
                this.bulkArr.splice(this.bulkArr.indexOf(payload.item), 1);
              }
            } else {
              this.activities[payload.index].assignedUserName = data[0].assignedUserName;
              this.activities[payload.index].assignedUserEmail = data[0].assignedUserEmail;
              this.activities[payload.index].teamName = data[0].teamName;
              this.activities[payload.index].teamId = data[0].teamId;
              if (payload && this.filterConfig[this.filterIndices.users].selectionArr.length > 0
                && this.queryArr.indexOf('userEmail=' + this.activities[payload.index].assignedUserEmail) === -1) {
                this.activities.splice(payload.index, 1);
                if (this.bulkArr.length) {
                  this.bulkArr.length--;
                }
                if (this.activities.length === 0) {
                  this.showEmpty = true;
                  this.bulkArr.length = 0;
                }
              }
            }
          });
          this.loadingUsers.splice(this.loadingUsers.indexOf(payload.index), 1);
          this.getFilters();
        },
        error => {
          this.loadingMask.disableLoadingMask();
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
          console.log('assing all activity error');
        }
      ));
  }

  /*unassignActivity(item, quantity) {
    const self = this;
    this.subscriptions.add(this.activitiesService.unassignActivity(item, quantity)
    .subscribe(
      data => {
        this.loadingMask.disableLoadingMask();
        this.ngZone.run(() => {
          _.forEachRight(self.activities, (activitiesItem) => {
            _.forEachRight(data, (dataItem) => {
              if (activitiesItem && (activitiesItem.id === dataItem.id)) {
                const nameBefore = activitiesItem.assignedUserEmail;
                activitiesItem.assignedUserEmail = dataItem.assignedUserEmail;
                activitiesItem.assignedUserName = dataItem.assignedUserName;
                activitiesItem.teamName = dataItem.teamName;
                activitiesItem.teamId = dataItem.teamId;
                // if user email matches email in filters or is in MY-tasks queue, delete the activity
                if (this.queryArr.indexOf('userEmail=' + nameBefore) !== -1 || this.pageType === 'my-tasks') {
                  self.activities.splice(self.activities.indexOf(activitiesItem), 1);
                  if (this.activities.length === 0 && this.queryArr.length > 0) {
                    this.showEmpty = true;
                    return false;
                  }
                }
              }
            });
          });
        });
        this.bulkArr.length = 0;
        if (self.activities.length > 0) {
          this.uncheckAssignBoxes = true;
        }
        this.getFilters();
      },
      error => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        console.log('assing all activity error');
      }
    ));
  }*/

  assignTaskToMyTeam(): void {
    this.loadingMask.enableLoadingMask();
    this.subscriptions.add(this.userService.getUserTeamsInfo(this.userEmail).subscribe((data) => {
      if (data.length > 0) {
        this.bulkAssign(data[0].id, this.bulkArr, true);
      } else {
        this.alerts.addErrorAlerts(`Oops, looks like you don't belong to a team. Please create your team and try again.`);
        this.loadingMask.disableLoadingMask();
      }
    },
      (error) => {
        this.alerts.addErrorAlerts(`Tasks assignment Failed. Please try again.`);
        this.loadingMask.disableLoadingMask();
      }));
  }

  bulkAssign(assignee, bulkArr, isTeamAssignment?: boolean) {
    if (assignee === 'me') {
      assignee = this.userEmail;
    }
    this.loadingMask.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.bulkAssignActivity(assignee, bulkArr, this.userEmail, isTeamAssignment)
      .subscribe(
        data => {
          this.loadingMask.disableLoadingMask();
          this.ngZone.run(() => {
            forEachRight(this.activities, (activitiesItem) => {
              forEachRight(data, (dataItem) => {
                if (activitiesItem.id === dataItem.id) {
                  if (this.pageType === 'my-tasks' && dataItem.assignedUserEmail !== this.userEmail
                  || (this.pageType === 'my-teams-tasks' && dataItem.teamId !== this.teamInfo[0].id)) {
                    this.activities.splice(this.activities.indexOf(activitiesItem), 1);
                    if (this.activities.length === 0) {
                      this.showEmpty = true;
                    }
                  } else {
                    activitiesItem.assignedUserEmail = dataItem.assignedUserEmail;
                    activitiesItem.assignedUserName = dataItem.assignedUserName;
                    activitiesItem.teamId = dataItem.teamId;
                    activitiesItem.teamName = dataItem.teamName;
                    console.log('this activities:', this.activities);
                    /* if user email matches email in filters, delete the activity */
                    if ((this.filterConfig[this.filterIndices.users].selectionArr.length > 0 && this.queryArr.indexOf('userEmail=' + activitiesItem.assignedUserEmail) === -1)) {
                      this.activities.splice(this.activities.indexOf(activitiesItem), 1);
                      if (this.activities.length === 0) {
                        this.showEmpty = true;
                      }
                    }
                  }
                }
              });
            });
          });
          this.bulkArr.length = 0;
          this.activeBulkButton = false;
          this.uncheckAssignBoxes = true;
          this.uncheckSelectAllBox = true;
          this.getFilters();
        },
        error => {
          this.loadingMask.disableLoadingMask();
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
          console.log('bulk assign all activity error');
        }
      ));
  }

  onCheckChangeNotify(payload: any) {
    payload.event.stopPropagation();
    this.showOptions = false;
    const isChecked = payload.event.target.checked;
    if (payload.index === 'all') {
      this.bulkArr.length = 0;
      if (isChecked) {
        this.bulkArr.push(...this.activities);
      };
    } else {
      const removalIndex: number = this.bulkArr.indexOf(payload.item);
      isChecked ? this.bulkArr.push(payload.item) : this.bulkArr.splice(removalIndex, 1);
    }
    this.uncheckAssignBoxes = false;
    this.uncheckSelectAllBox = false;
  }

  onClickSortNotify(sortingObj: any) {
    if (sortingObj.sortByProp === 'contentType') {
      if (sortingObj.sortAsc) {
        this.activities = orderBy(this.activities, [activity => this.activitiesService.getContentDetails(activity).toLowerCase()], 'asc');
      } else {
        this.activities = orderBy(this.activities, [activity => this.activitiesService.getContentDetails(activity).toLowerCase()], 'desc');
      }
    } else if (sortingObj.sortByProp === 'assignedUserName') {
      if (sortingObj.sortAsc) {
        this.activities = orderBy(this.activities, [activity => {
          if (activity['assignedUserName'] && activity['assignedUserName'] !== 'UNASSIGNED') {
            return activity['assignedUserName'];
          } else if (activity['teamName']) {
            return activity['teamName'];
          } else { return ''; }
        }], 'asc');
      } else {
        this.activities = orderBy(this.activities, [activity => {
          if (activity['assignedUserName'] && activity['assignedUserName'] !== 'UNASSIGNED') {
            return activity['assignedUserName'];
          } else if (activity['teamName']) {
            return activity['teamName'];
          } else { return ''; }
        }], 'desc');
      }
    } else {
      const targetProp = sortingObj.sortByProp;
      if (sortingObj.sortAsc) {
        this.activities = orderBy(this.activities,
          activity => {
            if (!activity[targetProp]) {
              return '';
            } else {
              return activity[targetProp].toString().toLowerCase();
            }
          }, 'asc');
      } else {
        this.activities = orderBy(this.activities, activity => {
          if (!activity[targetProp]) {
            return '';
          } else {
            return activity[targetProp].toString().toLowerCase();
          }
        }, 'desc');
      }
    }
  }

  onChangeFilter(e, query, filterType) {
    let filterString = '';
    e.target.value !== 'unassigned' ? filterString = query + e.target.value : filterString = query + '%20';

    if (e.target.checked) {
      this.filterConfig[this.filterIndices[filterType]].selectionArr.push(e.target.value);
      this.queryArr.push(filterString);
      this.persistedActivitiesObj.selectedFilters.push({ value: e.target.value, type: filterType });
      this.queryString = this.queryArr.join('&');
      this.filterActivities(this.queryString);
    } else {
      this.filterConfig[this.filterIndices[filterType]].selectionArr
        .splice(this.filterConfig[this.filterIndices[filterType]].selectionArr.indexOf(e.target.value), 1);
      this.queryArr.splice(this.queryArr.indexOf(filterString), 1);
      if (this.persistedActivitiesObj.selectedFilters.filter(item => item.value === e.target.value && item.type === filterType).length > 0) {
        this.persistedActivitiesObj.selectedFilters.splice(this.persistedActivitiesObj.selectedFilters
          .findIndex(j => j.value === e.target.value && j.type === filterType), 1);
      }
      this.queryString = this.queryArr.join('&');
      this.filterActivities(this.queryString);
    }
    this.bulkArr.length = 0;
  }

  clearFilterChecks(filterType, queryType) {
    if (filterType === 'date') {
      this.dateArr = [];
      this.showCalendars = false;
    } else {
      this.filterConfig[this.filterIndices[filterType]].selectionArr = [];
    }

    // depopulate query array
    forEachRight(this.queryArr, (item) => {
      if (item && item.indexOf(queryType) !== -1) {
        this.queryArr.splice(this.queryArr.indexOf(item), 1);
      }
    });

    forEachRight(this.persistedActivitiesObj.selectedFilters, (item) => {
      if (item.type === filterType) {
        this.persistedActivitiesObj.selectedFilters.splice(this.persistedActivitiesObj.selectedFilters.indexOf(item), 1);
      }
    });

    // construct query string from query array
    this.queryString = this.queryArr.join('&');
    this.filterActivities(this.queryString);
    this.bulkArr.length = 0;
  }

  filterActivities(filterString) {
    this.uncheckSelectAllBox = true;
    this.resetPage();
    this.loadingMask.enableLoadingMask();
    this.setActivitiesToLocalStorage();
    let filterActivitiesObservable;
    if (this.pageType === 'all-tasks') {
      filterActivitiesObservable = this.activitiesService.filterActivities(filterString, this.pageNumber);
    } else {
      filterActivitiesObservable = this.activitiesService.filterActivities(filterString + this.pageTypeQuery, this.pageNumber);
    }
    this.subscriptions.add(filterActivitiesObservable.subscribe(
      data => {
        this.loadingMask.disableLoadingMask();
        // get data object
        this.activitiesObj = data;
        this.activities = this.activitiesObj.content;
        if (this.activities.length === 0 && this.persistedActivitiesObj['queryString'].length) {
          this.showEmpty = true;
        } else {
          this.showEmpty = false;
        }
        this.appRef.tick();
      },
      error => {
        this.loadingMask.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        console.log('error on all filter activity');
      }
    ));
  }

  getActivityNameByType(item) {
    return this.utilityService.getActivityNameByTypeId(item);
  }

  renderFilterOptions(str, filterName) {
    if (filterName === 'statuses') {
      return str.toLowerCase().replace(/_/g, ' ').replace(/(^| )(\w)/g, (char) => {
        return char.toUpperCase();
      });
    } else if (filterName === 'brandIdAndTitles') {
      if (str.toLowerCase() === 'na') {
        return 'No Brand / Acquired';
      }
    } else if (filterName === 'users') {
      if (!str) {
        return 'Unassigned';
      }
    } else if (filterName === 'activityTypeNames') {
      return this.getActivityNameByType(str);
    }
    return str;
  }

  getResultsByDate(period, e) {
    let startDate;
    let endDate;
    if (e.target.checked) {
      if (this.dateArr.length === 1) {
        this.dateArr.length = 0;
        remove(this.queryArr, query => includes(query, 'fromDate='));
        if (this.persistedActivitiesObj.selectedFilters.filter(item => item.type === 'date').length > 0) {
          this.persistedActivitiesObj.selectedFilters.splice(this.persistedActivitiesObj.selectedFilters
            .findIndex(j => j.type === 'date'), 1);
        }
        this.showCalendars = false;
      }
      switch (period) {
        case 'today':
          startDate = moment().utc().startOf('day').format('YYYY-MM-DD');
          endDate = moment().utc().endOf('day').format('YYYY-MM-DD');
          this.dateQuery = 'fromDate=' + startDate + '&toDate=' + endDate;
          break;
        case 'sevenDays':
          startDate = moment().utc().startOf('day').add(1, 'days').format('YYYY-MM-DD');
          endDate = moment().utc().endOf('day').add(7, 'days').format('YYYY-MM-DD');
          this.dateQuery = 'fromDate=' + startDate + '&toDate=' + endDate;
          break;
        case 'fourteenDays':
          startDate = moment().utc().startOf('day').add(1, 'days').format('YYYY-MM-DD');
          endDate = moment().utc().endOf('day').add(14, 'days').format('YYYY-MM-DD');
          this.dateQuery = 'fromDate=' + startDate + '&toDate=' + endDate;
          break;
      }
      this.dateArr.push(period);
      this.queryArr.push(this.dateQuery);
      // construct query string from query array
      this.queryString = this.queryArr.join('&');
      this.persistedActivitiesObj.selectedFilters.push({ value: period, type: 'date' });
      this.filterActivities(this.queryString);
    } else {
      this.dateArr.splice(this.dateArr.indexOf(period), 1);
      remove(this.queryArr, query => includes(query, 'fromDate='));
      // construct query string from query array
      this.queryString = this.queryArr.join('&');
      if (this.persistedActivitiesObj.selectedFilters.filter(item => item.value === period && item.type === 'date').length > 0) {
        this.persistedActivitiesObj.selectedFilters.splice(this.persistedActivitiesObj.selectedFilters
          .findIndex(j => j.value === period && j.type === 'date'), 1);
      }
      this.filterActivities(this.queryString);
    }
  }

  getResultsByCustomDate(date, end) {
    if (end === 'from') {
      if (this.customStartDate === moment.utc(date).format('YYYY-MM-DD')) {
        return;
      }
      this.customStartDate = date;
      this.customStartDate = moment.utc(this.customStartDate).format('YYYY-MM-DD');
    }
    if (end === 'to') {
      if (this.customEndDate === moment.utc(date).endOf('day').format('YYYY-MM-DD')) {
        return;
      }
      this.customEndDate = date;
      this.customEndDate = moment.utc(this.customEndDate).endOf('day').format('YYYY-MM-DD');
    }
    this.persistedActivitiesObj['startDate'] = this.customStartDate;
    this.persistedActivitiesObj['endDate'] = this.customEndDate;
    this.dateQuery = 'fromDate=' + this.customStartDate + '&toDate=' + this.customEndDate;
    if (date) {
      if (this.customStartDate && this.customEndDate) {
        remove(this.queryArr, query => includes(query, 'fromDate='));
        this.queryArr.push(this.dateQuery);
        this.queryString = this.queryArr.join('&');
        this.filterActivities(this.queryString);
      }
    } else {
      if (this.customStartDate === 'Invalid date' && this.customEndDate === 'Invalid date') {
        remove(this.queryArr, query => includes(query, 'fromDate='));
        // construct query string from query array
        this.queryString = this.queryArr.join('&');
        this.customStartDate = '';
        this.customEndDate = '';
        this.filterActivities(this.queryString);
      } else {
        return false;
      }
    }
  }

  getFilterDateCount(period) {
    let dateArr = [];
    let dateRangeArr = [];
    let sevenDays = moment().utc().add(7, 'days');
    let fourteenDays = moment().utc().add(14, 'days');

    forEach(this.activities, (item) => {
      dateArr.push(item.dueDate);
    });

    forEach(dateArr, (date) => {
      if ((moment().utc().startOf('day').isBefore(date) && moment().utc().endOf('day').isAfter(date)) && period === 'today') {
        dateRangeArr.push(date);
      }
      if ((moment().utc().endOf('day').isBefore(date) && sevenDays.isAfter(date)) && period === 'sevenDays') {
        dateRangeArr.push(date);
      }
      if ((moment().utc().endOf('day').isBefore(date) && fourteenDays.isAfter(date)) && period === 'fourteenDays') {
        dateRangeArr.push(date);
      }
    });
    return dateRangeArr.length;
  }

  clearAllFilters() {
    this.filterConfig = this.filterConfig.map(config => { config.selectionArr = []; return config; });
    this.queryArr.length = 0;
    this.dateArr.length = 0;
  }

  clearSearchAndFilters(e, keepSearchTerm?: boolean) {
    e.preventDefault();
    this.filterConfig = this.filterConfig.map(config => { config.displayCount = 5; return config; });
    this.customStartDate = '';
    this.customEndDate = '';
    this.showCalendars = false;
    this.clearAllFilters();
    this.queryArr = [];
    this.queryString = '';
    if (keepSearchTerm && this.persistedActivitiesObj.searchTerm) {
      this.queryString = 'q=' + encodeURIComponent(this.persistedActivitiesObj.searchTerm);
      this.queryArr.push('q=' + encodeURIComponent(this.persistedActivitiesObj.searchTerm));
    }
    if (!keepSearchTerm) {
      this.clearTerm();
      this.persistedActivitiesObj.searchTerm = '';
    }
    this.persistedActivitiesObj.selectedFilters = [];
    this.filterActivities(this.queryString);
    this.getFilters();
  }

  customChange(e) {
    this.showCalendars = !this.showCalendars;
    if (this.dateArr.length === 1) { // change to custom filter from other date filter
      remove(this.queryArr, query => includes(query, 'fromDate='));
      if (this.persistedActivitiesObj.selectedFilters.filter(item => item.type === 'date').length > 0) {
        this.persistedActivitiesObj.selectedFilters.splice(this.persistedActivitiesObj.selectedFilters
          .findIndex(i => i.type === 'date'), 1);
      }
      this.dateArr.length = 0;
    }

    if (e.target.checked) { // check custom date
      this.dateArr.push('custom');
      this.persistedActivitiesObj.selectedFilters.push({ value: 'custom', type: 'date' });
    } else { // uncheck custom date
      if (this.dateArr.indexOf('custom') !== -1) {
        this.dateArr.splice(this.dateArr.indexOf('custom'), 1);
      }
      if (this.queryArr.indexOf('startDate=') !== -1) {
        this.queryArr.splice(this.queryArr.indexOf('startDate='), 1);
      }
      this.queryString = this.queryArr.join('&');
      if (this.customStartDate && this.customEndDate) {
        this.filterActivities(this.queryString);
      }
      this.customStartDate = '';
      this.customEndDate = '';
    }
    this.setActivitiesToLocalStorage();
    if (this.dateArr[0] !== 'custom' && (this.customStartDate && this.customEndDate)) {
      this.filterActivities(this.queryString);
    }
    this.customStartDate = '';
    this.customEndDate = '';
    this.persistedActivitiesObj['startDate'] = '';
    this.persistedActivitiesObj['endDate'] = '';
  }

  // auto-complete methods
  filter(e) {
    this.activeBulkButton = false;
    // if old search doesn't have any suggestion, don't update no-suggestion holder
    if (this.filteredList.length > 0) {
      this.showNoSuggestion = false;
    }
    this.userNameQuery = e.target.value;
    if (!e.target.value) {
      this.displayNames = [];
      this.filteredList = this.displayNames;
    } else {
      if (this.userNameSubscription) {
        this.userNameSubscription.unsubscribe();
      }
      this.userNameSubscription = this.userService.getUsersAndTeams(e.target.value, 5)
        .subscribe(
          data => {
            this.users = data;
            this.displayNames = [];
            if (this.users) {
              forEach(this.users, (item) => {
                let name = item.name;
                let email = item.id;
                this.displayNames.push({'name': name, 'email': email});
              });
              this.filteredList = orderBy(this.displayNames, [user => user.name.toLowerCase()], ['asc']);
            }
            this.showNoSuggestion = true;
          },
          error => {
            this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
            console.log('get users error');
          }
        );
    }
  }

  isTeamId(email: string) {
    return !includes(email, '@');
  }

  getIcon(email, name?) {
    if (this.isTeamId(email) && name) {
      return name.charAt(0).toUpperCase();
    } else {
      return email.charAt(0).toUpperCase();
    }
  }

  selectNameFromModal(filteredName, e) {
    e.preventDefault();
    e.stopPropagation();
    this.userInputValue = filteredName.name;
    this.userInputEmail = filteredName.email;
    this.activeBulkButton = true;
    this.filteredList = [];
    this.userNameQuery = '';
  }

  submitModalValue(e) {
    e.preventDefault();
    if (this.isTeamId(this.userInputEmail)) {
      this.bulkAssign(this.userInputEmail, this.bulkArr, true);
    } else {
      this.bulkAssign(this.userInputEmail, this.bulkArr);
    }
    this.userInputValue = '';
  }

  onBlur(e) {
    e.preventDefault();
    e.stopPropagation();
    e.target.value = '';
    this.showNoSuggestion = false;
  }

  onFocus(e) {
    e.target.select();
  }

  onModalClick(e) {
    e.stopPropagation();
    this.filteredList = [];
  }

  /*clearEnteredName(e, i) {
    this.filteredList = [];
    this.activeBulkButton = false;
    this.showNoSuggestion = false;
  }*/

  clearModal() {
    this.userInputValue = '';
    this.activeBulkButton = false;
  }

  resetPage() {
    this.pageCount = 0;
    this.pageNumber = 0;
  }

  jumpToTop() {
    window.scroll({
      top: 0,
      behavior: 'smooth'
    });
  }

  getActivitiesObjFromLocalStorage() {
    this.persistedActivitiesObj = JSON.parse(this.storageService.getActivitesObjFromLocal());
    if (this.persistedActivitiesObj) {
      this.queryString = this.persistedActivitiesObj['queryString'];
      this.queryArr = this.persistedActivitiesObj['queryArr'];
      this.setPersistedFilters();
      this.setSearchTerm();
    }
  }

  setActivitiesToLocalStorage() {
    this.persistedActivitiesObj['queryString'] = this.queryString;
    this.persistedActivitiesObj['queryArr'] = this.queryArr;
    this.storageService.setActivitiesObjToLocal(this.persistedActivitiesObj);
  }

  setPersistedFilters() {
    if (this.persistedActivitiesObj['selectedFilters']) {
      forEach(this.persistedActivitiesObj['selectedFilters'], (item) => {
        if (item.type === 'date') {
          this.dateArr.push(item.value);
        } else {
          if (this.filterIndices[item.type] || this.filterIndices[item.type] === 0) {
            this.filterConfig[this.filterIndices[item.type]].selectionArr.push(item.value);
          }
        }
      });

      if (this.dateArr.length && this.dateArr.indexOf('custom') !== -1) {
        this.showCalendars = true;
        this.customStartDate = this.persistedActivitiesObj['startDate'];
        this.customEndDate = this.persistedActivitiesObj['endDate'];
      }
    }
  }

  setSearchTerm() {
    if (this.persistedActivitiesObj['searchTerm']) {
      this.searchObj.get('searchTerm').setValue(this.persistedActivitiesObj['searchTerm']);
    }
  }

  ngOnDestroy() {
    if (this.userNameSubscription) {
      this.userNameSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
    this.loadingMask.disableLoadingMask();
  }
}
