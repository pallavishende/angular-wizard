import { TestBed, inject } from '@angular/core/testing';

import { ActivityHelperService } from './activity-helper.service';

xdescribe('ActivityHelperService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ActivityHelperService]
    });
  });

  it('should be created', inject([ActivityHelperService], (service: ActivityHelperService) => {
    expect(service).toBeTruthy();
  }));
});
