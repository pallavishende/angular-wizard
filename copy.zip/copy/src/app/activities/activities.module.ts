import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, FormControl, ReactiveFormsModule } from '@angular/forms';

import { SharedModule } from '../shared/shared.module';
import { ActivitiesRoutesModule } from './activities-routes.module';

import { ActivitiesBaseComponent } from './activities-base/activities-base.component';
import { ActivitiesViewComponent } from './activities-view/activities-view.component';
import { ActivitiesComponent } from './activities/activities.component';
import { TableComponent } from '../shared/table/table.component';
import { ActivitiesComposeContentComponent } from './activities-compose-content/activities-compose-content.component';
import { ActivitiesApproveContentComponent } from './activities-approve-content/activities-approve-content.component';
import { ModalModule } from 'app/shared/ng-modal';
import { ActivitiesComposeCopyComponent } from './activities-compose-copy/activities-compose-copy.component';
import { ActivitiesApproveCopyComponent } from './activities-approve-copy/activities-approve-copy.component';
import { ActivitiesService } from './activities.service';
import { ActivityHelperService } from './activity-helper.service';
import { ApproverTogglesComponent } from './approver-toggles/approver-toggles.component';
import { ConfigService } from '../services/config.service';
import { UtilityService } from '../services/utility.service';
import { ActivitiesCommentsService } from '../shared/activities-comments/activities-comments.service';
import { ActivitiesPublishComponent } from './activities-publish/activities-publish.component';
import { CatalogService } from '../catalog/catalog.service';
import { OrdersService } from '../orders/orders/orders.service';
import { ActivitiesCreateGraphicsComponent } from './activities-create-graphics/activities-create-graphics.component';
import { ActivitiesApproveGraphicsComponent } from './activities-approve-graphics/activities-approve-graphics.component';
import { ActivitiesSiteAndAppUpdatesComponent } from './activities-site-and-app-updates/activities-site-and-app-updates.component';
import { ActivitiesQaComponent } from './activities-qa/activities-qa.component';
import { ActivitiesVideoQaComponent } from './activities-video-qa/activities-video-qa.component';
import { ActivitiesCreatePressComponent } from './activities-create-press/activities-create-press.component';
import { AssetRestorationComponent } from './asset-restoration/asset-restoration.component';
import { ActivityListRouteGuard } from './route-guard/activity-list-route-guard';
import { ActivitiesHeaderComponent } from './activities-header/activities-header.component';
import { ActivitiesHeaderVideoSourceComponent } from './activities-header-video-source/activities-header-video-source.component';
import { ActivitiesCreateTranscriptComponent } from './activities-create-transcript/activities-create-transcript.component';


@NgModule({
  declarations: [
    ActivitiesViewComponent,
    ActivitiesComponent,
    ActivitiesBaseComponent,
    TableComponent,
    ActivitiesComposeContentComponent,
    ActivitiesApproveContentComponent,
    ActivitiesComposeCopyComponent,
    ActivitiesApproveCopyComponent,
    ApproverTogglesComponent,
    ActivitiesPublishComponent,
    ActivitiesCreateGraphicsComponent,
    ActivitiesApproveGraphicsComponent,
    ActivitiesSiteAndAppUpdatesComponent,
    ActivitiesQaComponent,
    ActivitiesVideoQaComponent,
    AssetRestorationComponent,
    ActivitiesCreatePressComponent,
    ActivitiesHeaderComponent,
    ActivitiesHeaderVideoSourceComponent,
    ActivitiesCreateTranscriptComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    ActivitiesRoutesModule,
    FormsModule,
    ReactiveFormsModule,
    ModalModule
  ],
  providers: [
    ActivitiesService,
    ConfigService,
    UtilityService,
    ActivityHelperService,
    ActivitiesCommentsService,
    CatalogService,
    OrdersService,
    ActivityListRouteGuard
    ]
})
export class ActivitiesModule { }
