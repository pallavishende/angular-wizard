import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesApproveGraphicsComponent } from './activities-approve-graphics.component';

xdescribe('ActivitiesApproveGraphicsComponent', () => {
  let component: ActivitiesApproveGraphicsComponent;
  let fixture: ComponentFixture<ActivitiesApproveGraphicsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesApproveGraphicsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesApproveGraphicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
