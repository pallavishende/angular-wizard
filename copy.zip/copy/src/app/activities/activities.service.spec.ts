/* tslint:disable:no-unused-variable */
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod, Headers } from '@angular/http';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TestBed, async, inject } from '@angular/core/testing';
import { MockBackend, MockConnection } from '@angular/http/testing';

import { ActivitiesService } from './activities.service';
import { ConfigService } from '../services/config.service';

import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../services/environment.service';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';
import { AdalService } from '../shared/auth/adal.service';

xdescribe('ActivitiesService', () => {

  let activitiesValues = {
    username: "john",
    getActivitiesResponse: [
      {
        "activities": [
          { "id": 1,
            "assigned_to": "Patricia Henry",
            "items": "3",
            "type": "compose video",
            "clip": "Highlight",
            "series": "The Half Hour",
            "episode": 503
          },
          { "id": 2,
            "assigned_to": "Shakespeare",
            "items": "3",
            "type": "compose video",
            "clip": "Highlight",
            "series": "The Half Hour",
            "episode": 503
          }
        ]
      }
    ]
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ActivitiesService,
        ConfigService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        AdalService,
        {
            provide: HttpClient,
            useFactory: (http: Http) => http,
            deps: [Http]
        },
        EnvironmentService,
        ConfigurationManagerService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  });

  it('should inject the service', inject([ActivitiesService], (service: ActivitiesService) => {
    expect(service).toBeTruthy();
  }));

  it('#getActivities should send the activities request to the server', (done) => {
    done();
  });

  it('#getActivities should call endpoint and return success response', inject([ActivitiesService, MockBackend], (service: ActivitiesService, mockBackend: MockBackend) => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
        let options = new ResponseOptions({
          body: JSON.stringify(activitiesValues.getActivitiesResponse)
        });

        let header = new Headers();
        header.append('Content-Type', 'application/json');
        connection.mockRespond(new Response(options));
      });

      let subject = service;
      subject
        .getActivities(0)
        .subscribe((data) => {
          expect(data).toEqual(activitiesValues.getActivitiesResponse);
        });
  }));

});
