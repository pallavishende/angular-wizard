import { Component, OnInit, OnDestroy, AfterViewInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitiesService } from '../activities.service';
import { Subscription } from 'rxjs/Subscription';
import { forEach, assign, orderBy, find, get, indexOf } from 'lodash';
import 'rxjs/add/operator/toPromise';
import { LineItem } from '../../models/line-item';
import { OrdersService } from '../../orders/orders/orders.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { ActivityHelperService } from '../activity-helper.service';
import { ActivitiesCommentsService } from '../../shared/activities-comments/activities-comments.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { UserService } from '../../services/user.service';
import { UtilityService } from '../../services/utility.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-activities-video-qa',
  templateUrl: './activities-video-qa.component.html',
  styleUrls: ['./activities-video-qa.component.scss', '../activities.scss']
})

export class ActivitiesVideoQaComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChildren('versions') versions: QueryList<any>;

  activityBundleId: string;
  detailsObj;
  orderStatus;
  copyObj;
  endpointObj = [];
  endpointNames: Array<any> = [];
  submitComment: string;
  publishActivityObj;
  loggedInUser;
  submitAllowed = {};
  assetOptions = {
    lineItemId: 0
  };
  isFullEpisode = false;
  dataSubscription: Subscription;
  subscriptions = new Subscription();
  updatedObj;
  allowSubmission = {};
  activeActivitiesTab;
  initializePublishEditor: boolean;
  initializeRejectEditor: boolean;
  commentServiceInstance: ActivitiesCommentsService;
  pageFragment: string;
  selectedLineItem;
  disableDataPolling = false;
  publishingInstructions = {};
  versionTypes = {};
  attachmentsStatus: Array<any> = [];
  commentsCountStream: Observable<any>;

  constructor(
    private ordersService: OrdersService,
    private activitiesService: ActivitiesService,
    private activeRoute: ActivatedRoute,
    private alerts: SystemAlertsService,
    private activityHelperService: ActivityHelperService,
    private activitiesCommentsService: ActivitiesCommentsService,
    private loadingMaskService: LoadingMaskService,
    private userService: UserService,
    private utilityService: UtilityService
  ) { }

  ngOnInit() {
    this.activitiesService.setActivitiesPageTitle('QA - Video - Viacom Bridge');
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.activityBundleId = this.activeRoute.snapshot.params['id'];
    this.getActivityInfo();
    this.pollingFunction();
    this.activeRoute.fragment.subscribe((fragment) => {
      this.pageFragment = fragment;
    });
  }

  ngAfterViewInit(): void {
    // converting queryList observable to promise to trigger a callback when the versions are loaded in the DOM
    this.versions.changes.take(1).toPromise().then(data => {
      if (this.pageFragment) {
        this.versions.forEach((version) => {
        if (version.nativeElement.id === this.pageFragment) {
          document.querySelector('#' + this.pageFragment).scrollIntoView(true);
          let scrolledY = window.scrollY;
          // checking if this is not the last version on the page to substract the header height
          if (scrolledY && ('version' + (this.endpointObj[this.endpointNames[this.endpointNames.length - 1]]
          [this.endpointObj[this.endpointNames[this.endpointNames.length - 1]].length - 1].id)) !== this.pageFragment) {
            window.scroll(0, scrolledY - 200);
          }
          return;
        }
      });
    }
    });
  }

  setTaskCommentsCountStream(event): void {
    this.commentsCountStream = event;
  }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        this.pollCurrentTaskStatus();
      }
    ));
  }

  pollCurrentTaskStatus() {
    let self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(self.activityBundleId)
    .subscribe( data => {
      if (!this.disableDataPolling) {
        self.updatedObj = data;
        // 1. loop through all the end points
        forEach(Object.keys(self.endpointObj), (endpoint) => {
          // 2. loop through all line items
          forEach(self.endpointObj[endpoint], (lineItem) => {
            // 4. get line item id
            let lineItemId = lineItem['id'];
            // 5. find the corresponding line item in updatedObj
            let updatedData = find(self.updatedObj.lineItems, (item) => {
              return item['id'] === lineItemId; // failing on type for id
            });
            let updatedLineItem: LineItem = assign(new LineItem(), updatedData);
            // 6. update the status of endpoint.lineitem with updated.lineItem.status
            let calculatedStatus = self.activityHelperService.getVideoQaStatus(updatedLineItem);
            lineItem['publishStatus'] = calculatedStatus;
          });
        });
        self.getOrderStatus();
      }
    });
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        this.loadingMaskService.disableLoadingMask();
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.getActivityDetail(this.activityBundleId)
    .subscribe(
      data => {
        this.loadingMaskService.disableLoadingMask();
        this.detailsObj = data;
        this.updatedObj = data;
        this.getOrderStatus();
        if (this.detailsObj.activityBundle.isFullEpisode) {
          this.isFullEpisode = this.detailsObj.activityBundle.isFullEpisode;
        }
        if (this.detailsObj.activityBundle.orderClipName) {
          this.activitiesService.setActivitiesPageTitle('QA Video - ' +
          this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
        }
        this.getVideoContentEvents();
        let self = this;
        // sorting lineItems by endpoints in ascending order
        this.detailsObj.lineItems = orderBy(this.detailsObj.lineItems, 'endpoint', 'asc');
        // create array out of line items only
        let lineItems = this.detailsObj.lineItems;
        this.assetOptions.lineItemId = lineItems[0]['id'];

        // create object with endpoint names as keys and set up empty arrays as values
        this.detailsObj.lineItems.forEach((lineItem) => {
          self.endpointObj[lineItem.endpoint] = [];
          lineItem.videoInstructionsMetadata = {};
          const videoActivity = find(lineItem.activities, { 'typeId': 1 });
          forEach(videoActivity['instructions'], (instruction) => {
            lineItem.videoInstructionsMetadata[instruction.label] = instruction.label === 'captions' ? instruction.values : instruction.values.join('\r\n');
          });
        });

        // create object with endpoint names as keys and set up empty arrays as values
        lineItems.forEach((lineItem) => {
          self.endpointObj[lineItem.endpoint] = [];
          if (lineItem.endpoint === 'Viacom Sites & Apps') {
            const publishActivity = find(lineItem.activities, { 'typeId': 13 });
            forEach(publishActivity['instructions'], (instruction) => {
              this.publishingInstructions[instruction.label] = instruction;
            });
          }
          this.versionTypes[lineItem.id] = this.getVersionType(lineItem);
        });

        // push corresponding line items into appropriate endpoint array in new object
        lineItems.forEach((item) => {
          for (const k in self.endpointObj) {
            if (item.endpoint === k) {
              item.publishStatus = self.activityHelperService.getVideoQaStatus(item);
              // item.isDisabled = true;
              self.endpointObj[k].push(item);
              self.endpointObj[k] = orderBy(self.endpointObj[k], [(activity) => {
                return activity['version'].toLowerCase();
              }], 'asc');
            }
          }
        });

        // create array containing only endpoint names
        self.endpointNames = Object.keys(self.endpointObj);
        this.getCopyOrderInfo(this.detailsObj.metadata.vmid);
        console.log('endpointObj', this.endpointObj);
      },
      error => {
        console.log('all activities error', error);
        this.loadingMaskService.disableLoadingMask();
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
      }
    ));
  }

  updateComments() {
    this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
  }

  updateFilesMetadata(event, lineItem?, activityType?) {
    if (activityType === 'VIDEO_ACTIVITY') {
      if (!event.uploadingInProgressQueue.length) {
        forEach(event.uploadedFileQueue, (uploadedFile) => {
          uploadedFile.source = 'S3';
          uploadedFile.activityId = this.getVideoActivity(lineItem)['id'];
        });
        this.subscriptions.add(this.activitiesService.updateFilesMetadata(event.uploadedFileQueue).subscribe(
        (data) => {
          console.log('Successfully updated the metadata.');
          const lineItemIndex = indexOf(this.detailsObj.lineItems, lineItem);
          const videoActivityIndex = indexOf(this.detailsObj.lineItems[lineItemIndex].activities, this.getVideoActivity(lineItem));
          if (this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input) {
            this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input.attachments = data;
          } else {
            this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input = { attachments: data };
          }
        },
        error => {
          console.log('Error in updating the metadata');
        }));
      }
    } else {
      this.attachmentsStatus = event;
    }
  }

  getCopyOrderInfo(vmid: string) {
    this.subscriptions.add(this.activitiesService.getCopyOrderInfo(vmid)
    .subscribe(
      data => {
        // NOTE: not displaying submissionMessage from this payload, deprecated
        this.copyObj = data;
      },
      error => {
        console.log('get copy order error', error);
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  getVideoContentEvents() {
    forEach(this.detailsObj.lineItems, (lineItem) => {
      const currentLineItemVideoActivity = this.getVideoActivity(lineItem);
      this.subscriptions.add(this.activitiesService.getActivityEvents(this.getVideoActivity(lineItem)['id'])
      .subscribe(
        (data) => {
          const currentLineItemVideoActivityIndex = indexOf(lineItem.activities, currentLineItemVideoActivity);
          lineItem.activities[currentLineItemVideoActivityIndex].events = data;
          // initializing empty object for consolidating submit for approval attachments
          lineItem.activities[currentLineItemVideoActivityIndex].events.consolidatedAttachments = [];
          forEach(lineItem.activities[currentLineItemVideoActivityIndex].events, (event) => {
            if (event.type === 'CONTENT_SUBMITTED') {
              lineItem.activities[currentLineItemVideoActivityIndex].events.consolidatedAttachments.push.
              apply(lineItem.activities[currentLineItemVideoActivityIndex].events.consolidatedAttachments, event.attachments);
            }
          });
        }));
    });
  }

  getCopyOrderUrl(copy): string {
    return '/orders/' + copy['id'] + '/order-detail';
  }

  getQaActivity(lineItem: LineItem) {
    return find(lineItem.activities, {'typeId': 16 });
  }

  setAddingCommentEvent(value: any) {
    const activityId = value['activityId'];
    const isAddingComment = value['isAddingComment'];
    this.allowSubmission[activityId] = !isAddingComment;
  }

  setCommentsServiceInstanceObj(serviceInstance) {
   this.commentServiceInstance = serviceInstance;
  }

  onOpen(type?: string) {
    setTimeout(() => {
      if (type === 'publish') {
        this.initializePublishEditor = true;
      } else if (type === 'reject') {
        this.initializeRejectEditor = true;
      }
    });
  }

  onClose() {
    this.initializePublishEditor = false;
    this.initializeRejectEditor = false;
    this.submitComment = '';
  }

  getVideoActivity(lineItem: LineItem) {
    return find(lineItem.activities, { 'typeId': 1 });
  }

  getCopyDetails(copy: any): void {
    if (!copy.showDetails || copy.status !== 'COMPLETED') {
      return;
    }
    copy.isLoadingEvents = true;
    this.subscriptions.add(this.activitiesService.getActivityEvents(copy.activityId).subscribe((data) => {
      copy.isLoadingEvents = false;
      copy.approvedEvent = this.activitiesCommentsService.getLatestCommentEvent(data, 'APPROVED');
      if (copy.approvedEvent && copy.approvedEvent.attachments) {
        copy.approvedAttachments = copy.approvedEvent.attachments;
      } else {
        copy.approvedAttachments = [];
      }
    }));
  }

  getEndpointIconName(endpoint) {
    return '/assets/images/' + endpoint.replace(/ /g, '_').replace(/&/g, 'and').toLowerCase() + '.logo.png';
  }

  getVersionType(lineItem: LineItem): string {
    const videoActivity = this.getVideoActivity(lineItem);
    const versionType = find(videoActivity.instructions, (instruction) => {
      return instruction.label === 'versionType';
    });
    return (versionType && versionType.values) ? versionType.values[0] : '';
  }

  getToggleOptions(item) {
    let lineItem = item;
    let activity = this.getVideoQaActivity(item);
    let copyActivityId = this.getVideoQaActivity(item)['id'];
    let correspondingApprovalTypeObj = find(this.utilityService.getActivityTypesList(), function(item) {
      return item.map === activity.typeId && item.type !== activity.typeId;
    });
    //let correspondingApprovalActivity = true;
    let correspondingApprovalActivity = activity;

    if ( correspondingApprovalActivity ) {
      return {
        activity: activity,
        subActivity: activity,
        commentActivityId: copyActivityId,
        lineItem: lineItem,
        episode: this.detailsObj.metadata.title,
        isOrderComplete: this.orderIsCompleted(),
        isVersionPublished: this.versionIsPublished(lineItem)
      };
    } else {
      return {};
    }
  }

  onStatusChange(e) {
    this.disableDataPolling = true;
    let lineItem = e.lineItem;
    const activityId = this.getVideoQaActivity(lineItem)['id'];
    delete e.lineItem;
    delete e.subActivityId;
    delete e.activityIdForEvent;
    delete e.activityId;
    e['activityIds'] = [activityId];
    e['orderId'] = this.detailsObj.activityBundle.orderId;
    if (e.status === 'APPROVED') {
      this.onActionTaken(lineItem);
      this.handleSubmission('submitting');
      this.subscriptions.add(this.activitiesService.submitApprovalQAActivity('mark-as-content-qa-completed',  e)
      .subscribe(
        data => {
          console.log('APPROVALS: Approved Successfully', e);
          this.retrySubmission(lineItem, 1, 'COMPLETED');
          this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
        },
        error => {
          console.log('APPROVALS: Status not updated');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
    } else if (e.status === 'REJECTED') {
      this.onActionTaken(lineItem);
      this.handleSubmission('submitting');
      this.subscriptions.add(this.activitiesService.submitApprovalQAActivity('mark-as-content-qa-completed', e)
      .subscribe(
        data => {
          console.log('APPROVALS: Rejected Successfully', e);
          this.retrySubmission(lineItem, 1, 'WAITING');
          this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
        },
        error => {
          console.log('APPROVALS: Status not updated');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
    }
}

  getVideoQaActivity(lineItem: LineItem) {
    return find(lineItem.activities, {'typeId': 16 });
  }

  orderIsCompleted() {
    if (get(this.detailsObj, 'orderInfo.currentMilestone.status')) {
      return get(this.detailsObj, 'orderInfo.currentMilestone.status').toString() === 'COMPLETED';
    } else {
      return '';
    }
  }

  versionIsPublished(version) {
    let currentVersion;
    let publishActivity;
    let status;
    if (this.detailsObj.orderInfo) {
      currentVersion = find(this.detailsObj.orderInfo.lineItems, {'id': version.id });
    }
    if (currentVersion) {
      publishActivity = find(currentVersion.activities, {'typeId': 13});
    }
    if (publishActivity) {
      status = publishActivity.currentState.status === 'COMPLETED';
    }
    return status;
  }

  onActionTaken(lineItem) {
    lineItem['publishStatus'] = 'Updating';
  }

  retrySubmission(lineItem, retry, targetStatus) {
    setTimeout(() => {
      if (lineItem.publishStatus === targetStatus || retry > 3) {
        /*if (this.toggleOptions.lineItem.approveStatus !== targetStatus) {
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error updating task status. Try again, or refresh the page.');
        }*/
        this.handleSubmission('submitted');
        return;
      }
      lineItem['publishStatus'] = 'Updating';
      // this.toggleOptions.commentsServiceInstance.getActivityEvents(this.toggleOptions.commentActivityId);
      this.handleSubmission({targetStatus: targetStatus, id: lineItem.id});
      this.retrySubmission(lineItem, retry + 1, targetStatus);
    }, 2000);
  }

  handleSubmission(e) {
    if (e === 'submitting') { // when user hit approve toggle
      this.disableDataPolling = true;
    } else if (e === 'submitted') { // when lineitem polled correct status or when 3 retries failed
      this.disableDataPolling = false;
    } else { // event to poll status of a target lineitem
      this.pollCurrentTaskStatus();
    }
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }
}
