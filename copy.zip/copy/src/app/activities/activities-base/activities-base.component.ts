import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activities-base',
  templateUrl: './activities-base.component.html',
  styleUrls: ['./activities-base.component.scss']
})
export class ActivitiesBaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
