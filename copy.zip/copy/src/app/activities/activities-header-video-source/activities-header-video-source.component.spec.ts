import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesHeaderVideoSourceComponent } from './activities-header-video-source.component';

xdescribe('ActivitiesHeaderComponent', () => {
  let component: ActivitiesHeaderVideoSourceComponent;
  let fixture: ComponentFixture<ActivitiesHeaderVideoSourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesHeaderVideoSourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesHeaderVideoSourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
