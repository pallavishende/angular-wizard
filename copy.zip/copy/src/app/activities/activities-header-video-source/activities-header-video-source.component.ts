import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-activities-header-video-source',
  templateUrl: './activities-header-video-source.component.html',
  styleUrls: ['../activities-header/activities-header.component.scss', './activities-header-video-source.component.scss']
})
export class ActivitiesHeaderVideoSourceComponent implements OnInit {
  @Input() detailsObj;
  isFullEpisode = false;
  showAssets = false;
  assetOptions: any = {};

  constructor() {}

  ngOnInit() {
    if (this.detailsObj.activityBundle.isFullEpisode) {
      this.isFullEpisode = this.detailsObj.activityBundle.isFullEpisode;
    }
  }

}
