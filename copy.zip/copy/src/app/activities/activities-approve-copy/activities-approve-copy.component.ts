import { Component, OnInit, OnDestroy, AfterViewInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitiesService } from '../activities.service';
import { Subscription } from 'rxjs/Subscription';
import { forEach, find } from 'lodash';
import 'rxjs/add/operator/toPromise';
import { LineItem } from '../../models/line-item';
import { ActivityHelperService } from '../activity-helper.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { OrdersService } from '../../orders/orders/orders.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';
import { ActivitiesCommentsService } from '../../shared/activities-comments/activities-comments.service';
import { UserService } from '../../services/user.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-activities-approve-copy',
  templateUrl: './activities-approve-copy.component.html',
  providers: [CustomEditorService],
  styleUrls: ['./activities-approve-copy.component.scss', '../activities.scss'],
})

export class ActivitiesApproveCopyComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChildren('versions') versions: QueryList<any>;
  activityId;
  detailsObj;
  lineItem;
  endpointObj = [];
  endpointNames: Array<any> = [];
  approvalSubmitted = false;
  submitForApproval = false;
  commentsCount = {};
  dataSubscription: Subscription;
  subscriptions = new Subscription();
  updatedObj;
  orderStatus;
  commentServiceInstance: ActivitiesCommentsService;
  activeActivitiesTab;
  pageFragment: string;
  disableDataPolling = false;
  attachmentsStatus: any = {};
  initializeSubmitEditor: boolean;
  initializeRejectEditor: boolean;
  submitComment: string;
  publishActivityObj;
  commentsCountStream: Observable<any>;

  constructor(
    private activitiesService: ActivitiesService,
    private activeRoute: ActivatedRoute,
    public activityHelperService: ActivityHelperService,
    private loadingMaskService: LoadingMaskService,
    private ordersService: OrdersService,
    private alerts: SystemAlertsService,
    public customEditorService: CustomEditorService,
    private userService: UserService
  ) { }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        this.pollCurrentTaskStatus();
      }
    ));
  }

  setTaskCommentsCountStream(event): void {
    this.commentsCountStream = event;
  }

  pollCurrentTaskStatus(targetLineItem?) {
    const self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(this.activityId)
      .subscribe(data => {
        if (!this.disableDataPolling || targetLineItem) {
          this.updatedObj = data;
          if (targetLineItem) {
            if (this.activityHelperService.getApproveActivityStatus(data.lineItems[0]).status !== targetLineItem.targetStatus
              && this.lineItem.approveStatus === 'Updating') {
              return; // keep state as updating while retrying
            }
          }
          this.lineItem.approveStatus = this.activityHelperService.getApproveActivityStatus(data.lineItems[0]).status;
          self.getOrderStatus();
        }
      });
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.getActivityDetail(this.activityId)
      .flatMap(
        data => {
          this.loadingMaskService.disableLoadingMask();
          console.log('....: ', data);
          this.detailsObj = data;
          this.updatedObj = data;
          this.getOrderStatus();
          if (this.detailsObj.activityBundle.orderClipName) {
            this.activitiesService
              .setActivitiesPageTitle('Edit Copy - ' + this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
          }
          const self = this;
          this.lineItem = this.detailsObj.lineItems[0];
          this.lineItem.approveStatus = self.activityHelperService.getApproveActivityStatus(this.lineItem).status;
          // getting the order info for status
          return this.ordersService.getOrder(this.detailsObj.activityBundle.orderId);
        }
      )
      .subscribe(
        data => {
          this.detailsObj.orderInfo = data;
          console.log('Edit Copy > orders data: ', this.detailsObj);
        },
        error => {
          this.loadingMaskService.disableLoadingMask();
          if (error.status === 404) {
            this.alerts.redirectTo404Page();
          } else {
            this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
          }
        }
      ));
  }

  updateComments() {
    this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
  }

  contentChanged(event, type?: string) {
    this.publishActivityObj = event;
    this.submitComment = event.content;
    if (!event.isValidContent) {
      this.submitComment = '';
    }
    if (event.readyToPostComment) {
      if (type && type === 'reject') {
        if (event.isValidContent) {
          this.submitApprovalActivity(event, 'reject');
        }
      } else {
        this.submitApprovalActivity(event, 'submit');
      }
    }
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
  }

  submitApprovalActivity(event, actionType: string) {
    const copyActivityId = Number(this.detailsObj.activityBundle.activityIds[0]);
    const parentActivityId = this.getCopyActivity(this.lineItem)['id'];
    const mentionedUserEmails = [];
    this.publishActivityObj.mentionedUsers.forEach((element) => {
      mentionedUserEmails.push(element.email);
    });

    this.onActionTaken(this.lineItem);
    if (actionType === 'submit') {
      this.handleSubmission('submitting');
      const submissionPayload = {
        activityIdForEvent: parentActivityId,
        message: event.content,
        attachments: this.attachmentsStatus['uploadedFileQueue'],
        mentionedUserEmails: mentionedUserEmails,
        createdByEmail: this.userService.getUserLoginInfo().email
      };
      this.subscriptions.add(this.activitiesService.submitApprovalActivity('/edit-copy-approval', copyActivityId, submissionPayload)
        .subscribe(
          data => {
            this.retrySubmission(this.lineItem, 1, 'COMPLETED');
            this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
          },
          error => {
            this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
          }
        ));
    } else if (actionType === 'reject') {
      this.handleSubmission('submitting');
      const rejectPayload = {
        activityId: copyActivityId,
        activityIdForEvent: parentActivityId,
        message: event.content,
        mentionedUserEmails: mentionedUserEmails,
        createdByEmail: this.userService.getUserLoginInfo().email
      };
      this.subscriptions.add(this.activitiesService.submitApprovalActivity('/reject', copyActivityId, rejectPayload)
        .subscribe(
          data => {
            this.retrySubmission(this.lineItem, 1, 'WAITING');
            this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
          },
          error => {
            this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
          }
        ));
    }
  }

  handleSubmission(e) {
    if (e === 'submitting') {
      this.disableDataPolling = true;
    } else if (e === 'submitted') { // when lineitem polled correct status or when 3 retries failed
      this.disableDataPolling = false;
    } else { // event to poll status of a target lineitem
      this.pollCurrentTaskStatus(e);
    }
  }

  onActionTaken(lineItem) {
    lineItem['approveStatus'] = 'Updating';
  }

  retrySubmission(lineItem, retry, targetStatus) {
    setTimeout(() => {
      if (lineItem.approveStatus === targetStatus || retry > 3) {
        this.handleSubmission('submitted');
        return;
      }
      lineItem['approveStatus'] = 'Updating';
      this.handleSubmission({ targetStatus: targetStatus, id: lineItem.id });
      this.retrySubmission(lineItem, retry + 1, targetStatus);
    }, 2000);
  }

  getCopyActivity(lineItem: LineItem) {
    return find(lineItem.activities, { 'typeId': 3 });
  }

  updateFilesMetadata(event, lineItem, activityType) {
    this.attachmentsStatus = event;
    if (activityType === 'COPY_ACTIVITY' && !event.uploadingInProgressQueue.length) {
      forEach(event.uploadedFileQueue, (uploadedFile) => {
        uploadedFile.source = 'S3';
        uploadedFile.activityId = this.getCopyActivity(lineItem)['id'];
      });
      this.subscriptions.add(this.activitiesService.updateFilesMetadata(event.uploadedFileQueue).subscribe(
        (data) => {
          console.log('Successfully updated the metadata.');
          this.attachmentsStatus = {};
          if (this.detailsObj.lineItems[0].activities[0].input) {
            this.detailsObj.lineItems[0].activities[0].input.attachments = data;
          } else {
            this.detailsObj.lineItems[0].activities[0].input = { attachments: data };
          }
        }
      ));
    }
  }

  setCommentsServiceInstanceObj(serviceInstance: any) {
    this.commentServiceInstance = serviceInstance;
  }

  onOpen(type?: string) {
    setTimeout(() => {
      if (type === 'complete') {
        this.initializeSubmitEditor = true;
      } else if (type === 'reject') {
        this.initializeRejectEditor = true;
      }
    });
  }

  onClose() {
    this.initializeSubmitEditor = false;
    this.initializeRejectEditor = false;
    this.submitComment = '';
    this.attachmentsStatus = {};
  }

  ngOnInit() {
    this.activitiesService.setActivitiesPageTitle('Edit Copy - Viacom Bridge');
    this.activityId = this.activeRoute.snapshot.params['id'];
    this.getActivityInfo();
    this.pollingFunction();
    this.activeRoute.fragment.subscribe((fragment) => {
      this.pageFragment = fragment;
    });
  }

  ngAfterViewInit(): void {
    // converting queryList observable to promise to trigger a callback when the versions are loaded in the DOM
    this.versions.changes.take(1).toPromise().then(data => {
      if (this.pageFragment) {
        this.versions.forEach((version) => {
          if (version.nativeElement.id === this.pageFragment) {
            document.querySelector('#' + this.pageFragment).scrollIntoView(true);
            let scrolledY = window.scrollY;
            // checking if this is not the last version on the page to substract the header height
            if (scrolledY && ('version' + (this.endpointObj[this.endpointNames[this.endpointNames.length - 1]]
            [this.endpointObj[this.endpointNames[this.endpointNames.length - 1]].length - 1].id)) !== this.pageFragment) {
              window.scroll(0, scrolledY - 200);
            }
            return;
          }
        });
      }
    });
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }
}
