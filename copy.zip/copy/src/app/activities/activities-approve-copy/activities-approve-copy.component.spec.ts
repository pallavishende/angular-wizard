import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesApproveCopyComponent } from './activities-approve-copy.component';

xdescribe('ActivitiesApproveCopyComponent', () => {
  let component: ActivitiesApproveCopyComponent;
  let fixture: ComponentFixture<ActivitiesApproveCopyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesApproveCopyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesApproveCopyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
