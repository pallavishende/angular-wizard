import { Component, OnInit, OnDestroy, QueryList, ViewChildren, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitiesService } from '../activities.service';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/mergeMap';
import { UtilityService } from '../../services/utility.service';
import { LineItem } from '../../models/line-item';
import { ActivityHelperService } from '../activity-helper.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { OrdersService } from '../../orders/orders/orders.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { UserService } from '../../services/user.service';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';
import { ActivitiesCommentsService } from '../../shared/activities-comments/activities-comments.service';
import { Observable } from 'rxjs';
import {clone, cloneDeep, forEach, find } from 'lodash';

@Component({
  selector: 'app-activities-create-transcript',
  templateUrl: './activities-create-transcript.component.html',
  providers: [CustomEditorService],
  styleUrls: ['../activities.scss']
})
export class ActivitiesCreateTranscriptComponent implements OnInit, OnDestroy {

  @ViewChildren('versions') versions: QueryList<any>;
  @ViewChild('submitForApprovalModalSummary') submitForApprovalModalSummary;

  activityBundleId: string;
  allowSubmission = {};
  status: string;
  isFullEpisode = false;
  disableDataPolling = false;
  dataSubscription: Subscription;
  subscriptions = new Subscription();
  updatedObj;
  commentsCountStream: Observable<any>;
  lineItem;
  detailsObj;
  orderStatus;
  bundleIdStatus;
  commentServiceInstance: ActivitiesCommentsService;
  commentsCount = {};
  pageFragment: string;
  assetOptions = {
    lineItemId: 0
  };
  commentServiceInstances = {};
  currentRenderedTask;
  assetListModal = [];
  submittedActivity = {};
  videoTypesOrderClipsArr = [];
  updatingSubmitButton = '';
  loggedInUser;
  hideBackToSelection = false;
  initializeEditor: boolean;
  initializeEditorSummary: boolean;
  activitySubmissionObj = {};
  isValidDescription: boolean;
  attachmentsStatus: any = {};
  submissionComment;
  oldSubmissionMsg = '';
  selectAllCheckbox = false;

  constructor(
    private activitiesService: ActivitiesService,
    private utilityService: UtilityService,
    private activeRoute: ActivatedRoute,
    public activityHelperService: ActivityHelperService,
    private loadingMaskService: LoadingMaskService,
    private ordersService: OrdersService,
    private alerts: SystemAlertsService,
    private userService: UserService,
    public customEditorService: CustomEditorService
  ) { }

  ngOnInit() {
    this.status = 'PLACED';
    this.activityBundleId = this.activeRoute.snapshot.params['id'];
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.getActivityInfo();
    this.pollingFunction();
    this.activeRoute.fragment.subscribe((fragment) => {
      this.pageFragment = fragment;
    });

  }

  getOrderStatus() {
    if(this.detailsObj) {
      this.bundleIdStatus = this.detailsObj.activityBundle.status;
    }
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.dataSubscription = this.activitiesService.getActivityDetail(this.activityBundleId)
    .flatMap(
      data => {
        this.loadingMaskService.disableLoadingMask();
        this.detailsObj = data;
        this.updatedObj = data;
        this.detailsObj.composeStatus = data.activityBundle.status;
        this.getOrderStatus();
        if (this.detailsObj.activityBundle.isFullEpisode) {
          this.isFullEpisode = this.detailsObj.activityBundle.isFullEpisode;
        }
        const lineItems = this.detailsObj.lineItems;
        this.assetOptions.lineItemId = lineItems[0]['id'];
        this.currentRenderedTask = this.detailsObj.activityBundle.activityTypeId;
        if (this.currentRenderedTask === this.utilityService.activityTypes.VIDEO_TRANSCRIPT.type && this.detailsObj.activityBundle.orderClipName) {
          this.activitiesService.setActivitiesPageTitle('Create Transcripts - ' + this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
        } else if (this.currentRenderedTask === this.utilityService.activityTypes.VIDEO_TRANSCRIPT.type) {
          this.activitiesService.setActivitiesPageTitle('Create Transcripts - Viacom Bridge');
        } else if (this.currentRenderedTask === this.utilityService.activityTypes.VIDEO_CAPTIONS.type && this.detailsObj.activityBundle.orderClipName) {
          this.activitiesService.setActivitiesPageTitle('Create Captions - ' + this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
        } else if (this.currentRenderedTask === this.utilityService.activityTypes.VIDEO_CAPTIONS.type) {
          this.activitiesService.setActivitiesPageTitle('Create Captions - Viacom Bridge');
        } else if (this.currentRenderedTask === this.utilityService.activityTypes.VIDEO_STILLFRAMES.type && this.detailsObj.activityBundle.orderClipName) {
          this.activitiesService.setActivitiesPageTitle('Create Still Frames - ' + this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
        } else if (this.currentRenderedTask === this.utilityService.activityTypes.VIDEO_STILLFRAMES.type) {
          this.activitiesService.setActivitiesPageTitle('Create Still Frames - Viacom Bridge');
        }
        this.createAssetListForModal();
        return this.ordersService.getOrder(this.detailsObj.activityBundle.orderId);
      }).subscribe(data => {
        this.detailsObj.orderInfo = data;
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
      });
  }

  setCommentsServiceInstanceObj(serviceInstance: any) {
    this.commentServiceInstance = serviceInstance;
  }

  createAssetListForModal() {
    this.assetListModal = [];
    this.detailsObj.lineItems.forEach(item => {
      if (item.metadata[0].assetInputs.length !== 0) {
      const title = item.metadata[0].assetInputs[0].assetNumber + ' (' + item.metadata[0].assetInputs[0].assetName + ' (' + item.metadata[0].assetInputs[0].assetSource + '))';
      const lineItemObj = { assetNumber: item.metadata[0].assetInputs[0].assetNumber, title: title, activityId: item.activities[0].id, status: item.activities[0].currentState.status };
      this.assetListModal.push(lineItemObj);
      if (item.activities[0].currentState.status === 'COMPLETED') {
        this.submittedActivity[item.activities.id] = lineItemObj;
      }
    }
    });
  }

  isAssetSelected() {
    return this.videoTypesOrderClipsArr.length > 0;
  }


  clearSelectedAssets() {
    this.videoTypesOrderClipsArr = [];
    this.attachmentsStatus = {};
    this.submissionComment = '';
    this.oldSubmissionMsg = '';
    this.submittedActivity = {};
    this.createAssetListForModal();
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    console.log('fetching comment..:');
  }

  setPreSubmitMsg(activityId) {
    this.oldSubmissionMsg = this.commentServiceInstance.getReSubmitMessage(activityId);
  }

  getToDoTasksList() {
    return this.assetListModal.filter(asset => asset.status === 'TO_DO');
  }

  isAssetAlreadyAddedtoOrder(activityId) {
    if (this.videoTypesOrderClipsArr && (this.videoTypesOrderClipsArr.findIndex(order => order.activityId === activityId)) > -1) {
      return true;
    } else {
      return false;
    }
  }

  checkComment(content) {
    if (content) {
      const filtered = content.toString().replace(/&nbsp;|\s\n/g, '');
      const removeBr = filtered.toString().replace(/[<]br[^>]*[>]/gi, '');
      return removeBr.trim() !== '';
    }
  }

  onOpenSubmissionModal() {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  onCloseSubmissionModal() {
    this.closeModal();
  }

  submitForApprovalModalCancel() {
    this.videoTypesOrderClipsArr = [];
  }

  onOpenSubmissionModalSummary() {
    setTimeout(() => {
      this.initializeEditorSummary = true;
    });
  }

  onCloseSubmissionModalSummary() {
    this.closeModal();
  }

  openApprovalSummaryModal() {
    const pressArray = this.videoTypesOrderClipsArr;
    this.videoTypesOrderClipsArr = pressArray;
    this.submitForApprovalModalSummary.open();
  }

  closeModal() {
    this.initializeEditorSummary = false;
    this.videoTypesOrderClipsArr = [];
    this.selectAllCheckbox = false;
  }

  openSummaryModal() {
      const itemsArray = this.assetListModal;
      const item = this.getToDoTasksList();
      this.videoTypesOrderClipsArr.push(item[0]);
      this.submitForApprovalModalSummary.open();
      this.hideBackToSelection = true;
  }

  backToAssetSlectionModal() {
    const pressArray = this.videoTypesOrderClipsArr;
    this.submitForApprovalModalSummary.close();
    this.videoTypesOrderClipsArr = pressArray;
  }

  updateComments() {
    this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
  }

  getVideoTaskActivity(item?: LineItem) {
    let lineItem: LineItem;
    if (item) {
      lineItem = item;
    }
    return find(lineItem.activities, { 'typeId': this.currentRenderedTask });
  }

  setTaskCommentsCountStream(event): void {
    this.commentsCountStream = event;
  }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        this.pollCurrentTaskStatus();
      }
    ));
  }

  pollCurrentTaskStatus() {
    const self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(this.activityBundleId)
      .subscribe(data => {
        this.updatedObj = data;
        if (!this.disableDataPolling) {
          this.detailsObj.composeStatus = data.activityBundle.status;
          self.getOrderStatus();
          this.setActivityStatus(self.updatedObj);
        }
      });
  }

  setActivityStatus(updatedObj) {
    updatedObj.lineItems.forEach(item => {
      const lineItemIndex = this.detailsObj.lineItems.findIndex(i => i.id === item.id);
      if (lineItemIndex >= 0) {
        this.detailsObj.lineItems[lineItemIndex].activities[0].currentState.status = item.activities[0].currentState.status;
      }
    });
    this.createAssetListForModal();
  }

  setAddingCommentEvent(value: any) {
    const activityId = value['activityId'];
    const isAddingComment = value['isAddingComment'];
    this.allowSubmission[activityId] = isAddingComment;
  }

  onSubmitForApproval(lineItem: any) {
    const activities = [];
    this.selectAllCheckbox = false;
    // extracting the ids from activities
    for (let i = 0; i < lineItem.length; i++) {
      activities[i] = lineItem[i].activityId;
    }
    const mentionsEmails = [];
    this.activitySubmissionObj['mentionedUsers'].forEach((element) => {
      mentionsEmails.push(element.email);
    });
    const submissionPayload = {
      activityIds: activities,
      orderId: this.detailsObj.activityBundle.orderId,
      message: this.submissionComment || '',
      mentionedUserEmails: mentionsEmails,
      createdByEmail: this.userService.getUserLoginInfo().email,
      attachments: this.attachmentsStatus['uploadedFileQueue']
    };
    this.disableDataPolling = true;
    this.detailsObj.composeStatus = 'Updating';
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.submitActivityForApproval(submissionPayload).subscribe(
      data => {
        this.loadingMaskService.disableLoadingMask();
        this.submissionComment = '';
        this.oldSubmissionMsg = '';
        this.videoTypesOrderClipsArr = [];
        this.hideBackToSelection = false;
        this.attachmentsStatus = [];
        this.pollCurrentTaskStatus();
        this.alerts.addSuccessAlerts('Success! Your work was submitted for approval.');
        this.activitiesService.getActivityDetail(this.activityBundleId).mergeMap((dataRespMerge: any) => {
          // Press only needs to retry because  there are multiple lineitems
          activities.forEach(activityId => {
            this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
          });
          return Observable.throw('Retrying status');
        }).retryWhen(errors => errors.delay(3000).take(5)).subscribe((dataResp: any) => {
          this.disableDataPolling = false;
          this.pollCurrentTaskStatus();
          // TODO: tie the activity status to lineItem and update
        }, error => {
          this.disableDataPolling = false;
          this.pollCurrentTaskStatus();
        }, () => {
          this.disableDataPolling = false;
          this.pollCurrentTaskStatus();
        });
      },
      error => {
        this.disableDataPolling = false;
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        this.loadingMaskService.disableLoadingMask();
      }
    ));
  }

  contentChanged(event) {
    this.activitySubmissionObj = event;
    if (event.isValidContent) {
      this.isValidDescription = true;
      this.submissionComment = event.content;
      this.oldSubmissionMsg = event.content;
    } else {
      if (this.submissionComment) {
        this.submissionComment = event.content;
        this.oldSubmissionMsg = event.content;
      }
      this.isValidDescription = false;
    }
    if (event.readyToPostComment) {
        this.onSubmitForApproval(this.videoTypesOrderClipsArr);
    }
  }

  updateAttachmentsMetadata(event, lineItems?, activityType?) {
    if (activityType === this.utilityService.activityTypes.VIDEO_TRANSCRIPT.type || activityType === this.utilityService.activityTypes.VIDEO_CAPTIONS.type) {
      for (const item of this.detailsObj.lineItems) {
        const uploadLineItem = clone(item);
        this.updateFilesMetadata(event, uploadLineItem);
      }
    } else {
      this.attachmentsStatus = event;
    }
  }

  updateFilesMetadata(event, lineItem?) {
    const eventClone = cloneDeep(event);
    if (!eventClone.uploadingInProgressQueue.length) {
      forEach(eventClone.uploadedFileQueue, (uploadedFile) => {
        uploadedFile.source = 'S3';
        uploadedFile.activityId = this.getVideoTaskActivity(lineItem)['id'];
      });
      this.subscriptions.add(this.activitiesService.updateFilesMetadata(eventClone.uploadedFileQueue).subscribe(
        (data) => {
          console.log('Successfully updated the metadata.');
          const lineItemIndex = this.detailsObj.lineItems.findIndex(line => line.id === lineItem.id);
          if (lineItemIndex > 0) {
            if (this.detailsObj.lineItems[lineItemIndex].activities[0].input) {
              this.detailsObj.lineItems[lineItemIndex].activities[0].input.attachments = data;
            } else {
              this.detailsObj.lineItems[lineItemIndex].activities[0].input = { attachments: data };
            }
          }
        },
        error => {
          console.log('Error in updating the metadata');
        }));
    }
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }
}
