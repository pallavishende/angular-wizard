import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetRestorationComponent } from './asset-restoration.component';

xdescribe('AssetRestorationComponent', () => {
  let component: AssetRestorationComponent;
  let fixture: ComponentFixture<AssetRestorationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetRestorationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetRestorationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});