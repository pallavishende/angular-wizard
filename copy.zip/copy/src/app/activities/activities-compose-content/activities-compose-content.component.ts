import { Component, OnInit, OnDestroy, AfterViewInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import 'rxjs/add/operator/toPromise';
import { forEach, find, orderBy, assign, filter, get, indexOf } from 'lodash';
import { ActivitiesService } from '../activities.service';
import { LineItem } from '../../models/line-item';
import { ActivityHelperService } from '../activity-helper.service';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';
import { ActivitiesCommentsService } from '../../shared/activities-comments/activities-comments.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { UserService } from '../../services/user.service';
import { OrdersService } from '../../orders/orders/orders.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-activities-compose-content',
  templateUrl: './activities-compose-content.component.html',
  providers: [CustomEditorService],
  styleUrls: ['../activities.scss']
})
export class ActivitiesComposeContentComponent implements OnInit, OnDestroy, AfterViewInit {

  @ViewChildren('versions') versions: QueryList<any>;
  @ViewChild('submitForApprovalModal') submitForApprovalModal;
  orderStatus;
  activityBundleId;
  detailsObj;
  endpointObj = [];
  endpointNames = [];
  parentStatus = '';
  loggedInUser;
  submitAllowed = {};
  assetOptions = {
    lineItemId: 0
  };
  isFullEpisode = false;
  subscriptions = new Subscription();
  dataSubscription: Subscription;
  pollingInterval = new Subscription();
  updatedObj;
  selectedLineItem;
  submissionComment;
  attachmentsStatus: any = {};
  activitySubmissionObj = {};
  allowSubmission = {};
  commentServiceInstance: ActivitiesCommentsService;
  initializeEditor: boolean;
  isValidDescription: boolean;
  activeActivitiesTab;
  pageFragment: string;
  oldSubmissionMsg = '';
  disableDataPolling = false;
  versionTypes = {};
  commentsCountStream: Observable<any>;
  retryCounter = 0;
  pollingUnsubscribed = false;

  constructor(
    private ordersService: OrdersService,
    private activitiesService: ActivitiesService,
    private activeRoute: ActivatedRoute,
    private activityHelperService: ActivityHelperService,
    private alerts: SystemAlertsService,
    private loadingMaskService: LoadingMaskService,
    private userService: UserService,
    public customEditorService: CustomEditorService
  ) { }


  ngOnInit() {
    this.activeRoute.fragment.subscribe((fragment) => {
      this.pageFragment = fragment;
    });
    this.activitiesService.setActivitiesPageTitle('Create Video - Viacom Bridge');
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.activityBundleId = this.activeRoute.snapshot.params['id'];
    this.getActivityInfo();
    this.pollingFunction();
  }

  setTaskCommentsCountStream(event): void {
    this.commentsCountStream = event;
  }

  ngAfterViewInit(): void {
    // converting queryList observable to promise to trigger a callback when the versions are loaded in the DOM
    this.versions.changes.take(1).toPromise().then(data => {
      if (this.pageFragment) {
        this.versions.forEach((version) => {
          if (version.nativeElement.id === this.pageFragment) {
            document.querySelector('#' + this.pageFragment).scrollIntoView(true);
            const scrolledY = window.scrollY;
            // checking if this is not the last version on the page to substract the header height
            if (scrolledY && ('version' + (this.endpointObj[this.endpointNames[this.endpointNames.length - 1]]
            [this.endpointObj[this.endpointNames[this.endpointNames.length - 1]].length - 1].id)) !== this.pageFragment) {
              window.scroll(0, scrolledY - 200);
            }
            return;
          }
        });
      }
    });
  }

  pollingFunction() {
    this.pollingInterval = IntervalObservable.create(20000).subscribe(
      interval => {
          this.pollCurrentTaskStatus();
      }
    );
    this.subscriptions.add(this.pollingInterval);
  }

  pollCurrentTaskStatus() {
    if (this.disableDataPolling) {
      return;
    }
    const self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(self.activityBundleId)
      .subscribe(data => {
          self.updatedObj = data;
          // 1. loop through all the end points
          forEach(Object.keys(self.endpointObj), function (endpoint) {
            // 2. loop through all line items
            forEach(self.endpointObj[endpoint], function (lineItem) {
              // 4. get line item id
              let lineItemId = lineItem['id'];
              // 5. find the corresponding line item in updatedObj
              let updatedData = find(self.updatedObj.lineItems, function (item) {
                return item['id'] === lineItemId; // failing on type for id
              });
              let updatedLineItem: LineItem = assign(new LineItem(), updatedData);
              // 6. update the status of endpoint.lineitem with updated.lineItem.status
              let calculatedStatus = self.activityHelperService.getComposeActivityStatus(updatedLineItem);
              lineItem['composeStatus'] = calculatedStatus;
            });
          });
          self.getOrderStatus();
      });
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.dataSubscription = this.activitiesService.getActivityDetail(this.activityBundleId)
    .subscribe(
      data => {
        this.loadingMaskService.disableLoadingMask();
        this.detailsObj = data;
        this.updatedObj = data;
        this.getOrderStatus();
        if (this.detailsObj.activityBundle.isFullEpisode) {
          this.isFullEpisode = this.detailsObj.activityBundle.isFullEpisode;
        }
        if (this.detailsObj.activityBundle.orderClipName) {
          this.activitiesService
            .setActivitiesPageTitle('Create Video - ' + this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
        }
        const self = this;
        // sorting lineItems by endpoints in ascending order
        this.detailsObj.lineItems = orderBy(this.detailsObj.lineItems, 'endpoint', 'asc');
        // create array out of line items only
        const lineItems = this.detailsObj.lineItems;
        this.assetOptions.lineItemId = lineItems[0]['id'];

        // create object with endpoint names as keys and set up empty arrays as values
        this.detailsObj.lineItems.forEach((lineItem) => {
          self.endpointObj[lineItem.endpoint] = [];
          lineItem.videoInstructionsMetadata = {};
          const videoActivity = find(lineItem.activities, { 'typeId': 1 });
          forEach(videoActivity['instructions'], (instruction) => {
            lineItem.videoInstructionsMetadata[instruction.label] = instruction.values.join('\r\n');
          });
        });

        // push corresponding line items into appropriate endpoint array in new object
        lineItems.forEach((item) => {
          for (let k in self.endpointObj) {
            if (item.endpoint === k) {
              item.composeStatus = self.activityHelperService.getComposeActivityStatus(item);
              self.endpointObj[k].push(item);
              self.endpointObj[k] = orderBy(self.endpointObj[k], [(activity) => {
                return activity['version'].toLowerCase();
              }], 'asc');
            }
          }
          this.versionTypes[item.id] = this.getVersionType(item);
        });

        // create array containing only endpoint names
        self.endpointNames = Object.keys(self.endpointObj);
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
        console.log('all activities error', error);
      }
      );
  }

  updateComments() {
    this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
  }

  getVideoActivity(item?: LineItem) {
    let lineItem: LineItem;
    if (item) {
      lineItem = item;
    } else {
      lineItem = this.selectedLineItem;
    }
    return find(lineItem.activities, { 'typeId': 1 });
  }

  getActivitiesForApproval(lineItem: any) {
    let tmp = filter(lineItem.activities, function (activity) {
      return get(activity, 'currentState.status') === 'TO_DO' || 'WAITING';
    });
    return tmp;
  }

  onSubmitForApproval(lineItem: any) {
    const prevComposeStatus = lineItem.composeStatus;
    const lineItemId = lineItem.id;
    const activities = this.getActivitiesForApproval(lineItem);
    lineItem.composeStatus = 'Updating';
    // extracting the ids from activities
    for (let i = 0; i < activities.length; i++) {
      activities[i] = activities[i]['id'];
    }
    const videoActivityId = this.getVideoActivity(lineItem)['id'];
    const mentionsEmails = [];
    this.activitySubmissionObj['mentionedUsers'].forEach((element) => {
      mentionsEmails.push(element.email);
    });
    const submissionPayload = {
      activityIds: activities,
      activityIdForEvent: videoActivityId,
      orderId: this.detailsObj.activityBundle.orderId,
      message: this.submissionComment || '',
      mentionedUserEmails: mentionsEmails,
      createdByEmail: this.userService.getUserLoginInfo().email,
      attachments: this.attachmentsStatus['uploadedFileQueue']
    };
    this.loadingMaskService.enableLoadingMask();
    this.disableDataPolling = true;

    this.subscriptions.add(this.activitiesService.submitActivityForApproval(submissionPayload).subscribe(
      data => {
        this.submissionComment = '';
        lineItem.composeStatus = 'Updating';
        this.retryCounter++;
        if (this.retryCounter > 1) {
          this.pollingUnsubscribed = true;
          this.pollingInterval.unsubscribe();
        }
        this.loadingMaskService.disableLoadingMask();
        this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
        this.alerts.addSuccessAlerts('Success! Your work was submitted for approval.');
        // Retry Logic
        this.activitiesService.getActivityDetail(this.activityBundleId).mergeMap((dataRespMerge: any) => {
          const submittedLineItem = find(dataRespMerge.lineItems, function (item) {
            return item['id'] === lineItemId; // failing on type for id
          });
          if (submittedLineItem.activities.filter(selectedLineItem => selectedLineItem.currentState.status !== 'COMPLETED').length > 0) {
            return Observable.throw('Retrying status update');
          } else {
            return Observable.of(dataRespMerge);
          }
        })
        .retryWhen(errors => errors.delay(3000).take(5))
        .finally(() => {
          this.retryCounter--;
          if (this.retryCounter === 0) {
            this.disableDataPolling = false;
            this.pollCurrentTaskStatus();
            if (this.pollingUnsubscribed) {
              this.pollingFunction();
              this.pollingUnsubscribed = false;
            }
          }
        })
        .subscribe((dataResp: any) => {
        });

    }, error => {
      this.disableDataPolling = false;
      this.loadingMaskService.disableLoadingMask();
      this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
    }));
  }

  setAddingCommentEvent(value: any) {
    const activityId = value['activityId'];
    const isAddingComment = value['isAddingComment'];
    this.allowSubmission[activityId] = isAddingComment;
  }

  setCommentsServiceInstanceObj(serviceInstance: any) {
    this.commentServiceInstance = serviceInstance;
  }

  onOpenSubmissionModal() {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  onCloseSubmissionModal() {
    this.initializeEditor = false;
    this.attachmentsStatus = {};
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    console.log('fetching comment..:');
  }

  setPreSubmitMsg(activityId) {
    this.oldSubmissionMsg = this.commentServiceInstance.getReSubmitMessage(activityId);
  }

  contentChanged(event) {
    this.activitySubmissionObj = event;
    if (event.isValidContent) {
      // this.renderer.addClass(this.submitDescriptionBtn.nativeElement, 'ready');
      this.isValidDescription = true;
      this.submissionComment = event.content;
    } else {
      if (this.submissionComment) {
        this.submissionComment = event.content;
      }
      // this.renderer.removeClass(this.submitDescriptionBtn.nativeElement, 'ready');
      this.isValidDescription = false;
    }
    if (event.readyToPostComment) {
      this.onSubmitForApproval(this.selectedLineItem);
    }
  }

  updateFilesMetadata(event, lineItem?, activityType?) {
    if (activityType === 'VIDEO_ACTIVITY') {
      if (!event.uploadingInProgressQueue.length) {
        forEach(event.uploadedFileQueue, (uploadedFile) => {
          uploadedFile.source = 'S3';
          uploadedFile.activityId = this.getVideoActivity(lineItem)['id'];
        });
        this.subscriptions.add(this.activitiesService.updateFilesMetadata(event.uploadedFileQueue).subscribe(
          (data) => {
            console.log('Successfully updated the metadata.');
            const lineItemIndex = indexOf(this.detailsObj.lineItems, lineItem);
            const videoActivityIndex = indexOf(this.detailsObj.lineItems[lineItemIndex].activities, this.getVideoActivity(lineItem));
            if (this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input) {
              this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input.attachments = data;
            } else {
              this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input = { attachments: data };
            }
          },
          error => {
            console.log('Error in updating the metadata');
          }));
      }
    } else {
      this.attachmentsStatus = event;
    }
  }

  getEndpointIconName(endpoint) {
    return '/assets/images/' + endpoint.replace(/ /g, '_').replace(/&/g, 'and').toLowerCase() + '.logo.png';
  }

  getVersionType(lineItem: LineItem): string {
    console.log('This is the line item:', lineItem);
    const versionType = find(lineItem.activities[0].instructions, (instruction) => {
      return instruction.label === 'versionType';
    });
    return (versionType && versionType.values) ? versionType.values[0] : '';
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }
}