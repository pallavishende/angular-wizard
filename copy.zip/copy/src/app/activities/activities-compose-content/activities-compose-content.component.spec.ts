import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesComposeContentComponent } from './activities-compose-content.component';

xdescribe('ActivitiesComposeContentComponent', () => {
  let component: ActivitiesComposeContentComponent;
  let fixture: ComponentFixture<ActivitiesComposeContentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesComposeContentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesComposeContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should be created', () => {
    expect(component).toBeTruthy();
  });
});