import { Component, OnInit, OnDestroy, AfterViewInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitiesService } from '../activities.service';
import { Subscription } from 'rxjs/Subscription';
import { forEach, assign, find, orderBy, get, flatten, filter, indexOf } from 'lodash';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/mergeMap';
import { UtilityService } from '../../services/utility.service';
import { Activity } from '../../models/activity';
import { LineItem } from '../../models/line-item';
import { ActivityHelperService } from '../activity-helper.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { OrdersService } from '../../orders/orders/orders.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-activities-approve-content',
  templateUrl: './activities-approve-content.component.html',
  styleUrls: ['../activities.scss', './activities-approve-content.component.scss']
})
export class ActivitiesApproveContentComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChildren('versions') versions: QueryList<any>;
  status: string;
  isFullEpisode = false;
  dataSubscription: Subscription;
  subscriptions = new Subscription();
  updatedObj;
  bundleId: number;
  detailsObj;
  orderStatus;
  endpointObj = [];
  endpointNames: Array<any> = [];
  commentsCount = {};
  pageFragment: string;
  assetOptions = {
    lineItemId: 0
  };
  commentServiceInstance: any;
  pendingLineItemsCounter = 0;
  attachmentsStatus: Array<any> = [];
  showAssets = false;
  versionTypes = {};
  commentsCountStream: Observable<any>;

  constructor(
    private activitiesService: ActivitiesService,
    private utilityService: UtilityService,
    private activeRoute: ActivatedRoute,
    public activityHelperService: ActivityHelperService,
    private loadingMaskService: LoadingMaskService,
    private ordersService: OrdersService,
    private alerts: SystemAlertsService
  ) { }


  ngOnInit() {
    this.activitiesService.setActivitiesPageTitle('Approve Video - Viacom Bridge');
    this.status = 'PLACED';
    this.bundleId = this.activeRoute.snapshot.params['id'];
    this.getActivityInfo();
    this.pollingFunction();
    this.activeRoute.fragment.subscribe((fragment) => {
      this.pageFragment = fragment;
    });
  }

  ngAfterViewInit(): void {
    // converting queryList observable to promise to trigger a callback when the versions are loaded in the DOM
    this.versions.changes.take(1).toPromise().then(data => {
      if (this.pageFragment) {
        this.versions.forEach((version) => {
          if (version.nativeElement.id === this.pageFragment) {
            document.querySelector('#' + this.pageFragment).scrollIntoView(true);
            const scrolledY = window.scrollY;
            // checking if this is not the last version on the page to substract the header height
            if (scrolledY && ('version' + (this.endpointObj[this.endpointNames[this.endpointNames.length - 1]]
            [this.endpointObj[this.endpointNames[this.endpointNames.length - 1]].length - 1].id)) !== this.pageFragment) {
              window.scroll(0, scrolledY - 200);
            }
            return;
          }
        });
      }
    });
  }

  setTaskCommentsCountStream(event): void {
    this.commentsCountStream = event;
  }

  /*
    status update:
    * if ANY is rejected then show updating...
    * if ANY is accepted then do nothing
    * if ALL is accepted then show updating...
    * ALL OTHER CASES: do nothing
  */

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        this.pollCurrentTaskStatus();
      }
    ));
  }

  pollCurrentTaskStatus(targetLineItem?) {
    const self = this;
    // unsubscribing the last call before making another call
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(self.bundleId)
      .subscribe(data => {
        if (this.pendingLineItemsCounter <= 0 || targetLineItem) {
          self.updatedObj = data;
          // 1. loop through all the end points
          forEach(Object.keys(self.endpointObj), function (endpoint) {
            // 2. loop through all line items
            forEach(self.endpointObj[endpoint], function (lineItem) {
              // 4. get line item id
              let lineItemId = lineItem['id'];
              // 5. find the corresponding line item in updatedObj
              let updatedData = find(self.updatedObj.lineItems, function (item) {
                return item['id'] === lineItemId; // failing on type for id
              });
              let updatedLineItem: LineItem = assign(new LineItem(), updatedData);
              // 6. update the status of endpoint.lineitem with updated.lineItem.status
              const calculatedStatus = self.activityHelperService.getApproveActivityStatus(updatedLineItem).status;
              if (targetLineItem) {
                if (targetLineItem.id === lineItemId) {
                  if (calculatedStatus !== targetLineItem.targetStatus && lineItem['approveStatus'] === 'Updating') {
                    return; // keep state as updating while retrying
                  }
                } else {
                  if (lineItem['approveStatus'] === 'Updating') {
                    return;
                  }
                }
              }
              const prevStatus = lineItem['approveStatus'];
              lineItem['approveStatus'] = calculatedStatus;
              if (prevStatus !== calculatedStatus) {
                self.getActivityInfo();
              }
            });
          });
          self.getOrderStatus();
        }
      });
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.dataSubscription = this.activitiesService.getActivityDetail(this.bundleId)
    .flatMap(
      data => {
        this.loadingMaskService.disableLoadingMask();
        console.log('approve content > data: ', data);
        this.detailsObj = data;
        this.updatedObj = data;
        this.getOrderStatus();
        if (this.detailsObj.activityBundle.isFullEpisode) {
          this.isFullEpisode = this.detailsObj.activityBundle.isFullEpisode;
        }
        if (this.detailsObj.activityBundle.orderClipName) {
          this.activitiesService.setActivitiesPageTitle('Approve Video - '
            + this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
        }
        let self = this;
        // sorting lineItems by endpoints in ascending order
        this.detailsObj.lineItems = orderBy(this.detailsObj.lineItems, 'endpoint', 'asc');
        // create array out of line items only
        let lineItems = this.detailsObj.lineItems;
        this.assetOptions.lineItemId = lineItems[0]['id'];

        // create object with endpoint names as keys and set up empty arrays as values
        this.detailsObj.lineItems.forEach((lineItem) => {
          self.endpointObj[lineItem.endpoint] = [];
          lineItem.videoInstructionsMetadata = {};
          const videoActivity = find(lineItem.activities, { 'typeId': 1 });
          forEach(videoActivity['instructions'], (instruction) => {
            lineItem.videoInstructionsMetadata[instruction.label] = instruction.values.join('\r\n');
          });
          this.versionTypes[lineItem.id] = this.getVersionType(lineItem);
        });

        // push corresponding line items into appropriate endpoint array in new object
        lineItems.forEach(function (item) {
          for (let k in self.endpointObj) {
            if (item.endpoint === k) {
              item.approveStatus = self.activityHelperService.getApproveActivityStatus(item).status;
              self.endpointObj[k].push(item);
              self.endpointObj[k] = orderBy(self.endpointObj[k], [(activity) => {
                return activity['version'].toLowerCase();
              }], 'asc');
            }
          }
        });
        // create array containing only endpoint names
        self.endpointNames = Object.keys(self.endpointObj);
        // getting the order info for status
        return this.ordersService.getOrder(this.detailsObj.activityBundle.orderId);
      }
    )
    .subscribe(
      data => {
        this.detailsObj.orderInfo = data;
        console.log('approve content > orders data: ', this.detailsObj);
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
      }
    );
  }

  updateComments() {
    // Object.keys(this.commentServiceInstances).forEach(key => {
    //   this.commentServiceInstances[key].getActivityEvents(key);
    // });
  }

  versionIsPublished(version) {
    let currentVersion;
    let publishActivity;
    let status;
    if (this.detailsObj.orderInfo) {
      currentVersion = find(this.detailsObj.orderInfo.lineItems, { 'id': version.id });
    }
    if (currentVersion) {
      publishActivity = find(currentVersion.activities, { 'typeId': 13 });
    }
    if (publishActivity) {
      status = publishActivity.currentState.status === 'COMPLETED';
    }
    return status;
  }

  orderIsCompleted() {
    if (get(this.detailsObj, 'orderInfo.currentMilestone.status')) {
      return get(this.detailsObj, 'orderInfo.currentMilestone.status').toString() === 'COMPLETED';
    } else {
      return '';
    }
  }

  getApprovableActivities(activities: Array<Activity>) {
    // return _.sortBy(activities, ['typeId']); // changed to one approval for all activities
    if (find(activities, {'typeId': 1})) {
      return [find(activities, {'typeId': 1})];
    } else {
      return [];
    }
  }

  getToggleOptions(activity: Activity, lineItem: LineItem) {
    let videoActivityId = this.getVideoActivity(lineItem)['id'];
    let correspondingApprovalTypeObj = find(this.utilityService.getActivityTypesList(), function (item) {
      return item.map === activity.typeId && item.type !== activity.typeId;
    });
    let correspondingApprovalActivity = find(activity.subActivities, function (subActivity) {
      return subActivity.typeId === correspondingApprovalTypeObj.type;
      // && subActivity.assignedUserEmail === userServiceRef.getUserLoginInfo().email;
    });
    if (correspondingApprovalActivity) {
      return {
        activity: activity,
        commentActivityId: videoActivityId,
        subActivity: correspondingApprovalActivity,
        lineItem: lineItem,
        episode: this.detailsObj.metadata.title,
        isOrderComplete: this.orderIsCompleted(),
        isVersionPublished: this.versionIsPublished(lineItem)
      };
    } else {
      return {};
    }
  }

  onStatusChange(e) {
    let videoActivityId = this.getVideoActivity(e.lineItem)['id'];
    let lineItem = e.lineItem;
    delete e.lineItem;
    //delete more params
    e['orderId'] = this.detailsObj.activityBundle.orderId;
    this.onActionTaken(lineItem);
    if(e.status === 'APPROVED') {
      this.handleSubmission('submitting');
      this.subscriptions.add(this.activitiesService.submitApprovalActivity('/approve', e.subActivityId, e)
      .subscribe(
        data => {
          console.log('APPROVALS: Approved Successfully', e);
          this.retrySubmission(lineItem, 1, 'COMPLETED');
          this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
        },
        error => {
          console.log('APPROVALS: Status not updated');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
    } else if (e.status === 'REJECTED') {
      this.handleSubmission('submitting');
      this.subscriptions.add(this.activitiesService.submitApprovalActivity('/reject',e.subActivityId, e)
      .subscribe(
        data => {
          console.log('APPROVALS: Rejected Successfully', e);
          this.retrySubmission(lineItem, 1, 'WAITING');
          this.commentServiceInstance.getOrderCommentsAndEvents(videoActivityId);
        },
        error => {
          console.log('APPROVALS: Status not updated');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
    }
  }

  onActionTaken(lineItem, activity?) {
    lineItem['approveStatus'] = 'Updating';
  }

  retrySubmission(lineItem, retry, targetStatus) {
    setTimeout(() => {
      if (lineItem.approveStatus === targetStatus || retry > 3) {
        /*if (this.toggleOptions.lineItem.approveStatus !== targetStatus) {
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error updating task status. Try again, or refresh the page.');
        }*/
        this.handleSubmission('submitted');
        return;
      }
      lineItem['approveStatus'] = 'Updating';
      //this.toggleOptions.commentsServiceInstance.getActivityEvents(this.toggleOptions.commentActivityId);
      this.handleSubmission({targetStatus: targetStatus, id: lineItem.id});
      this.retrySubmission(lineItem, retry + 1, targetStatus);
    }, 2000);
  }

  handleSubmission(e) {
    if (e === 'submitting') { // when user hit approve toggle
      this.pendingLineItemsCounter ++;
    } else if (e === 'submitted') { // when lineitem polled correct status or when 3 retries failed
      this.pendingLineItemsCounter --;
    } else { // event to poll status of a target lineitem
      this.pollCurrentTaskStatus(e);
    }
  }

  aggregatedStatus(lineItem: LineItem) {
    // 1. pull out all the sub activities
    const tmp = [];
    let status = 'WAITING';

    forEach(lineItem.activities, function (activity) {
      tmp.push(activity.subActivities);
    });
    let subActivities = flatten(tmp);

    // 2. filter by completed
    let completedSubActivities = filter(subActivities, function (subActivity) {
      return get(subActivity, 'currentState.status') === 'COMPLETED';
    });
    let notStartedSubActivities = filter(subActivities, function (subActivity) {
      return get(subActivity, 'currentState.status') === 'TO_DO';
    });

    // -- if completed count = subactivities count --> COMPLETED
    if (completedSubActivities.length === subActivities.length) {
      status = 'COMPLETED';
    }
    // -- if nothing has started then --> TO_DO
    if (notStartedSubActivities.length === subActivities.length) {
      status = 'TO_DO';
    }
    // -- else --> WAITING

    return status;
  }
  // needed for comments
  getVideoActivity(lineItem: LineItem) {
    return find(lineItem.activities, { 'typeId': 1 });
  }

  setCommentsServiceInstanceObj(serviceInstance: any) {
    this.commentServiceInstance = serviceInstance;
  }

  updateFilesMetadata(event, lineItem, activityType) {
    this.attachmentsStatus = event;
    if (activityType === 'VIDEO_ACTIVITY' && !event.uploadingInProgressQueue.length) {
      forEach(event.uploadedFileQueue, (uploadedFile) => {
        uploadedFile.source = 'S3';
        uploadedFile.activityId = this.getVideoActivity(lineItem)['id'];
      });
      this.subscriptions.add(this.activitiesService.updateFilesMetadata(event.uploadedFileQueue).subscribe(
        (data) => {
          console.log('Successfully updated the metadata.');
          this.attachmentsStatus = [];
          const lineItemIndex = indexOf(this.detailsObj.lineItems, lineItem);
          const videoActivityIndex = indexOf(this.detailsObj.lineItems[lineItemIndex].activities, this.getVideoActivity(lineItem));
          if (this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input) {
            this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input.attachments = data;
          } else {
            this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input = { attachments: data};
          }
        }
      ));
    }
  }

  getEndpointIconName(endpoint) {
    return '/assets/images/' + endpoint.replace(/ /g, '_').replace(/&/g, 'and').toLowerCase() + '.logo.png';
  }

  getVersionType(lineItem: LineItem): string {
    console.log('This is the line item:', lineItem);
    const versionType = find(lineItem.activities[0].instructions, (instruction) => {
      return instruction.label === 'versionType';
    });
    return versionType.values[0] || '';
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }
}
