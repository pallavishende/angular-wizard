import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesComposeCopyComponent } from './activities-compose-copy.component';

xdescribe('ActivitiesComposeCopyComponent', () => {
  let component: ActivitiesComposeCopyComponent;
  let fixture: ComponentFixture<ActivitiesComposeCopyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesComposeCopyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesComposeCopyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should be created', () => {
    expect(component).toBeTruthy();
  });
});
