import { Component, OnInit, OnDestroy, AfterViewInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitiesService } from '../activities.service';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/toPromise';
import { forEach, find, filter, get } from 'lodash';
import { LineItem } from '../../models/line-item';
import { OrdersService } from '../../orders/orders/orders.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { ActivityHelperService } from '../activity-helper.service';
import { ActivitiesCommentsService } from '../../shared/activities-comments/activities-comments.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { UserService } from '../../services/user.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-activities-compose-copy',
  templateUrl: './activities-compose-copy.component.html',
  styleUrls: ['./activities-compose-copy.component.scss', '../activities.scss'],
  providers: [ActivitiesCommentsService, CustomEditorService]
})

export class ActivitiesComposeCopyComponent implements OnInit, OnDestroy, AfterViewInit {

  @ViewChildren('versions') versions: QueryList<any>;
  activityBundleId: string;
  detailsObj;
  orderStatus;
  lineItem;
  endpointObj = [];
  endpointNames: Array<any> = [];
  attachmentsStatus: any = {};
  loggedInUser;
  subscriptions = new Subscription();
  dataSubscription: Subscription;
  updatedObj;
  selectedLineItem;
  submissionComment: string;
  activitySubmissionObj;
  allowSubmission = {};
  commentServiceInstance: ActivitiesCommentsService;
  initializeEditor: boolean;
  isValidDescription: boolean;
  activeActivitiesTab;
  fragment: string;
  oldSubmissionMsg = '';
  disableDataPolling = false;
  commentsCountStream: Observable<any>;

  constructor(
    private ordersService: OrdersService,
    private activitiesService: ActivitiesService,
    private activeRoute: ActivatedRoute,
    private alerts: SystemAlertsService,
    private activityHelperService: ActivityHelperService,
    private loadingMaskService: LoadingMaskService,
    private userService: UserService,
    public customEditorService: CustomEditorService
  ) { }

  pollingFunction() {
    this.subscriptions.add(IntervalObservable.create(20000).subscribe(
      interval => {
        this.pollCurrentTaskStatus();
      }
    ));
  }

  setTaskCommentsCountStream(event): void {
    this.commentsCountStream = event;
  }

  pollCurrentTaskStatus() {
    if (this.disableDataPolling) {
      return;
    }
    const self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(this.activityBundleId)
      .subscribe(data => {
          this.updatedObj = data;
          this.lineItem.composeStatus = this.activityHelperService.getComposeActivityStatus(data.lineItems[0]);
          self.getOrderStatus();
      });
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }));
  }

  updateComments() {
    this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.getActivityDetail(this.activityBundleId)
    .subscribe(
      data => {
        this.loadingMaskService.disableLoadingMask();
        console.log('....: ', data);
        this.detailsObj = data;
        this.updatedObj = data;
        this.getOrderStatus();
        if (this.detailsObj.activityBundle.orderClipName) {
          this.activitiesService
          .setActivitiesPageTitle('Write Copy - ' + this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
        }
        const self = this;
        this.lineItem = this.detailsObj.lineItems[0];
        this.lineItem.composeStatus = self.activityHelperService.getComposeActivityStatus(this.lineItem);
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
        console.log('all activities error', error);
      }
    ));
  }

  getCopyActivity(item?: LineItem) {
    let lineItem: LineItem;
    if (item) {
      lineItem = item;
    } else {
      lineItem = this.selectedLineItem;
    }
    return find(lineItem.activities, { 'typeId': 3 });
  }

  updateFilesMetadata(event, lineItem?, activityType?) {
    if (activityType === 'COPY_ACTIVITY') {
      if (!event.uploadingInProgressQueue.length) {
        forEach(event.uploadedFileQueue, (uploadedFile) => {
          uploadedFile.source = 'S3';
          uploadedFile.activityId = this.getCopyActivity(lineItem)['id'];
        });
        this.subscriptions.add(this.activitiesService.updateFilesMetadata(event.uploadedFileQueue).subscribe(
          (data) => {
            console.log('Successfully updated the metadata.');
            if (this.detailsObj.lineItems[0].activities[0].input) {
              this.detailsObj.lineItems[0].activities[0].input.attachments = data;
            } else {
              this.detailsObj.lineItems[0].activities[0].input = { attachments: data };
            }
          }));
      }
    } else {
      this.attachmentsStatus = event;
    }
  }

  getActivitiesForApproval(lineItem: any) {
    let tmp = filter(lineItem.activities, function (activity) {
      return get(activity, 'currentState.status') === 'TO_DO' || 'WAITING';
    });
    return tmp;
  }

  onSubmitForApproval(lineItem: any) {
    const prevComposeStatus = lineItem.composeStatus;
    const prevLineItemId = lineItem.id;
    const activities = this.getActivitiesForApproval(lineItem);
    lineItem.composeStatus = 'Updating';
    // extracting the ids from activities
    for (let i = 0; i < activities.length; i++) {
      activities[i] = activities[i]['id'];
    }
    const copyActivityId = this.getCopyActivity(lineItem)['id'];
    const mentionsEmails = [];
    this.activitySubmissionObj !== undefined && Array.isArray(this.activitySubmissionObj) ? this.activitySubmissionObj['mentionedUsers'].forEach((element) => {
      mentionsEmails.push(element.email);
    }) : [];
    const submissionPayload = {
      activityIds: activities,
      activityIdForEvent: copyActivityId,
      orderId: this.detailsObj.activityBundle.orderId,
      message: this.submissionComment || '',
      mentionedUserEmails: mentionsEmails,
      createdByEmail: this.userService.getUserLoginInfo().email,
      attachments: this.attachmentsStatus['uploadedFileQueue']
    };
    this.loadingMaskService.enableLoadingMask();
    this.disableDataPolling = true;
    this.subscriptions.add(this.activitiesService.submitActivityForApproval(submissionPayload).subscribe(
      data => {

        lineItem.composeStatus = 'Updating';
        this.submissionComment = '';

        this.loadingMaskService.disableLoadingMask();
        this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
        this.alerts.addSuccessAlerts('Success! Your work was marked as completed.');

        this.activitiesService.getActivityDetail(this.activityBundleId).mergeMap((dataRespMerge: any) => {
          if (dataRespMerge.lineItems[0].activities[0].currentState.status === prevComposeStatus) {
            return Observable.throw('Retrying status update');
          } else {
            return Observable.of(dataRespMerge);
          }
        }).retryWhen(errors => errors.delay(3000).take(5))
        .finally(() => {
          this.disableDataPolling = false;
          this.pollCurrentTaskStatus();
        })
        .subscribe((dataResp: any) => {

        });
      },
      error => {
        this.disableDataPolling = false;
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  setAddingCommentEvent(value: any) {
    const activityId = value['activityId'];
    const isAddingComment = value['isAddingComment'];
    this.allowSubmission[activityId] = isAddingComment;
  }

  setCommentsServiceInstanceObj(serviceInstance) {
    this.commentServiceInstance = serviceInstance;
  }

  onOpen() {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  onClose() {
    this.initializeEditor = false;
    this.attachmentsStatus = {};
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    console.log('fetching comment..:');
  }

  setPreSubmitMsg(activityId: number) {
    this.oldSubmissionMsg = this.commentServiceInstance.getReSubmitMessage(activityId);
  }

  contentChanged(event) {
    this.activitySubmissionObj = event;
    if (event.isValidContent) {
      // this.renderer.addClass(this.submitDescriptionBtn.nativeElement, 'ready');
      this.isValidDescription = true;
      this.submissionComment = event.content;
    } else {
      if (this.submissionComment) {
        this.submissionComment = event.content;
      }
      // this.renderer.removeClass(this.submitDescriptionBtn.nativeElement, 'ready');
      this.isValidDescription = false;
    }
    if (event.readyToPostComment) {
      this.onSubmitForApproval(this.selectedLineItem);
    }
  }

  ngOnInit() {
    this.activitiesService.setActivitiesPageTitle('Write Copy - Viacom Bridge');
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.activityBundleId = this.activeRoute.snapshot.params['id'];
    this.getActivityInfo();
    // this.pollingFunction();
    this.activeRoute.fragment.subscribe((fragment) => {
      this.fragment = fragment;
    });
  }

  ngAfterViewInit(): void {
    // converting queryList observable to promise to trigger a callback when the versions are loaded in the DOM
    this.versions.changes.take(1).toPromise().then(data => {
      if (this.fragment) {
        this.versions.forEach((version) => {
          if (version.nativeElement.id === this.fragment) {
            document.querySelector('#' + this.fragment).scrollIntoView(true);
            let scrolledY = window.scrollY;
            // checking if this is not the last version on the page to substract the header height
            if (scrolledY && ('version' + (this.endpointObj[this.endpointNames[this.endpointNames.length - 1]]
            [this.endpointObj[this.endpointNames[this.endpointNames.length - 1]].length - 1].id)) !== this.fragment) {
              window.scroll(0, scrolledY - 200);
            }
            return;
          }
        });
      }
    });
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }

}
