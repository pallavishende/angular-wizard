import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { HttpHeaders } from '@angular/common/http';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { ConfigService } from '../services/config.service';
import { HttpClient } from '@angular/common/http';
import { UtilityService } from '../services/utility.service';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import { map } from 'lodash';

@Injectable()
export class ActivitiesService {

  constructor(
    private title: Title,
    private configService: ConfigService,
    private authHttp: HttpClient,
    private utilityService: UtilityService
  ) { }

  submitApprovalActivity(subUrl, activityId, approvePayload) {
    return this.authHttp.put(this.configService.activityUrl + activityId + subUrl, approvePayload)
      .map((response: any) => response);
  }

  submitApprovalQAActivity(subUrl, approvePayload) {
    return this.authHttp.put(this.configService.activityUrl + subUrl, approvePayload)
      .map((response: any) => response);
  }

  getFilters(query?: string) {
    if (query) {
      return this.authHttp.get(this.configService.activitiesFiltersUrl + query)
        .map((response: any) => response);
    } else {
      return this.authHttp.get(this.configService.activitiesFiltersUrl)
        .map((response: any) => response);
    }
  }

  getActivities(page, filterString?, pageSize?) {
    let size: number;
    if (!pageSize) {
      if (page === 0) {
        size = 50;
      } else {
        size = 25;
      }
    } else {
      page = 0;
      size = pageSize;
    }

    if (filterString) {
      return this.authHttp.get(this.configService.activitiesUrl + '?' + filterString + '&size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc')
        .map((response: any) => response);
    } else {
      return this.authHttp.get(this.configService.activitiesUrl + '?size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc')
        .map((response: any) => response);
    }
  }

  getActivityDetail(id) {
    return this.authHttp.get(this.configService.activityDetailUrl + id)
      .map((response: any) => response);
  }

  getCopyOrderInfo(vmid: string) {
    return this.authHttp.get(this.configService.publishCopyOrdersUrl + vmid)
      .map((response: any) => response);
  }


  getActivityEvents(activityId: string) {
    return this.authHttp.get(this.configService.activityUrl + activityId + '/events')
      .map((response: any) => response);
  }

  getOrderCommentsAndEvents(orderId: number) {
    return this.authHttp.get(`${this.configService.allCommentsAndEventsUrl}?orderId=${orderId}`)
      .map((response: any) => response);
  }

  filterActivities(filterString, page) {
    let size: number;
    if (page === 0) {
      size = 50;
    } else {
      size = 25;
    }
    if (filterString) {
      return this.authHttp.get(this.configService.activitiesUrl + '?' + filterString + '&size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc')
        .map((response: any) => response);
    } else {
      return this.authHttp.get(this.configService.activitiesUrl + '?size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc')
        .map((response: any) => response);
    }
  }

  bulkAssignActivity(assigneeId, bulkArr, assignedByEmail, isTeamAssignment?: boolean) {
    const header = new Headers();
    const activityIds = map(bulkArr, 'id');
    const payload = {
      'groupedActivityIds': activityIds,
      'assignedByEmail': assignedByEmail,
      ...!isTeamAssignment && { 'userEmail': assigneeId },
      ...isTeamAssignment && { 'teamId': assigneeId }
    };
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.assignActivitiesUrl, payload)
      .map((response: any) => response);
  }

  getActivityBundles(bundleIds: string[]) {
    const payload = {
      'bundleIds': bundleIds,
    };
    return this.authHttp.get(`${this.configService.activitiesUrl}/search`, {
      params: payload
    })
      .map((response: any) => response);
  }

  startWork(payload) {
    const header = new Headers();
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.startWorkUrl, payload)
      .map((response: any) => response);
  }

  toggleTask(payload) {
    return this.authHttp.put(this.configService.reopenTaskUrl + payload.orderId, payload)
      .map((response: any) => response);
  }

  assignActivity(payload) {
    const header = new Headers();
    const newPayload = {
      'groupedActivityIds': [payload.id],
      'userEmail': payload.assigneeEmail,
      'teamId': payload.teamId,
      'assignedByEmail': payload.assignedByEmail
    };
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.assignActivitiesUrl, newPayload)
      .map((response: any) => response);
  }

  unassignActivity(payload, unassignQty) {
    const header = new Headers();
    let newPayload = {};
    if (unassignQty === 'bulk') {
      const activityIds = map(payload, 'id');
      newPayload = {
        'groupedActivityIds': activityIds,
        'userEmail': '',
        'teamId': ''
      };
    } else {
      newPayload = {
        'groupedActivityIds': [payload.id],
        'userEmail': '',
        'teamId': ''
      };
    }

    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.unassignActivitiesUrl, newPayload)
      .map((response: any) => response);
  }

  postOrderComment(commentObj, orderId: number) {
    return this.authHttp.post(`${this.configService.orderDetailsUrl}${orderId}/comment`, commentObj);
  }

  postActivityComment(commentObj: any, currentBundleId: string, isChildEvent?: boolean) {
    if (typeof commentObj.orderId !== 'undefined') {
      delete commentObj.orderId;
    }
    commentObj.isChildEvent = isChildEvent;
    return this.authHttp.post(this.configService.activityUrl + currentBundleId + '/comments', commentObj);
  }

  updateComment(commentObj: any) {
    return this.authHttp.put(`${this.configService.editAllCommentsUrl}/${commentObj.id}`, commentObj);
  }

  deleteComment(eventId: string, isActivityEvent: boolean) {
    if (isActivityEvent) {
      return this.authHttp.delete(`${this.configService.activityUrl}${eventId}/comments`);
    } else {
      return this.authHttp.delete(`${this.configService.orderDetailsUrl}${eventId}/event`);
    }
  }

  submitActivityForApproval(submissionPayload) {
    const header = new Headers();
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.activityUrl + 'submit_for_approval', submissionPayload);
  }

  markAsPublished(publishActivityPayload) {
    const activityId = publishActivityPayload.activityId;
    const header = new Headers();
    delete publishActivityPayload.activityId;
    delete publishActivityPayload.activityIdForEvent;
    header.append(`Content-type`, `application/json`);
    return this.authHttp.put(this.configService.activityUrl + 'mark-as-published', publishActivityPayload);
  }

  updateFilesMetadata(filesMetadata) {
    const headers = new HttpHeaders();
    const payload = filesMetadata;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    };
    headers.append('Content-type', 'application/json');
    return this.authHttp.post(`${this.configService.fileHandlerUrl}-metadata`, payload).retryWhen(error => {
      return error.flatMap((error) => {
        return Observable.of(error.status).delay(200);
      }).take(5).concat(Observable.throw({ error: 'Couldn\'t update the metadata' }));
    });
  }

  getAssetRestorationInfo(lineItemId: number) {
    return this.authHttp.get(this.configService.assetRestorationUrl + lineItemId + '/asset-restoration-progress')
      .map((response: any) => response);
  }

  setActivitiesPageTitle(title: string) {
    this.title.setTitle(title);
  }

  getContentDetails(metadata) {
    const contentMetadata = {};
    contentMetadata['originBrandName'] = metadata['brandTitle'];
    contentMetadata['seriesTitle'] = metadata['orderSeries'];
    contentMetadata['seasonTitle'] = metadata['seasonTitle'];
    contentMetadata['episodeNumber'] = metadata['orderEpisode'];
    contentMetadata['title'] = metadata['episodeTitle'];
    contentMetadata['movieAndSpecial'] = metadata['movieAndSpecialTitle'];
    return this.utilityService.getHeaderForContentType(contentMetadata, metadata['contentType']);
  }

  getGraphicsOrderSummary(graphicsInstrFormFields, instructions) {
    const instructionMap = {};
    const platformList = [];
    let brandName;
    let platformNames = [];
    const orderGraphicsFormFields = graphicsInstrFormFields;
    if (instructions && instructions.length > 0) {
      const requestIndex = this.getInstructionsIndex(instructions, 'requestType');
      if (requestIndex >= 0) {
        const requestType = instructions[requestIndex].values[0];
        if (requestType === 'VMN') {
          const resultForm = instructions.filter(inst => inst.type === '');
          if (resultForm.length > 0) {
            resultForm.map(f => {
              if (f.label !== 'platformList') {
                instructionMap[f.label] = f.values[0];
              }
            });
          }

          const brandIndex = this.getInstructionsIndex(instructions, 'brand');
          if (brandIndex >= 0) {
            const brandCode = instructions[brandIndex].values[0];
            brandName = orderGraphicsFormFields.BrandDropDown.filter(b => b.id === brandCode)[0];
            instructionMap['brand'] = brandName['value'];
            platformNames = brandName['options'];
          }

          const inx = this.getInstructionsIndex(instructions, 'platformList');
          const platformLst = [];
          if (inx >= 0) {

            const platformLstBkp = instructions[inx].values;
            platformNames.forEach(pltName => {
              if (platformLstBkp.findIndex(plt => plt === pltName.id) >= 0) {
                platformLst.push(pltName.id);
              }
            });

            if (platformLst && platformLst.length >= 0) {
              platformLst.forEach(platform => {
                const specification = orderGraphicsFormFields.RequestType[platform][1].options;
                const specificationMap = {};
                if (specification) {
                  specification.map(spe => {
                    specificationMap[spe.key] = spe.label;
                  });
                }
                const result = instructions.filter(inst => inst.type === platform);
                if (result && result.length >= 0) {
                  const options = [];
                  const specsList = [];
                  let cta = undefined;
                  result.forEach(res => {
                    if (res.label === 'CTA') {
                      const label = 'Copy or Special Instructions';
                      cta = { label: label, value: res.values[0] };
                    } else if (res.label === 'dimensions') {
                      const label = 'Custom Dimensions';
                      options.push({ label: label, value: res.values[0] });
                    } else if (res.label === 'Description') {
                      const label = 'Description';
                      options.push({ label: label, value: res.values[0] });
                    } else {
                      specsList.push(specificationMap[res.label]);
                    }
                  });

                  const platFormName = brandName['options'].filter(opt => opt.id === platform)[0].value;
                  if (specsList.length > 0) {
                    options.unshift({ label: 'Specs', value: specsList });
                  }
                  if (cta) {
                    options.push(cta);
                  }
                  platformList.push({ platformName: platFormName, options });
                }
              });
            }
          }
        }
      }
    }
    return { instructionMap: instructionMap, platformList: platformList };
  }

  getPressOrderSummary(pressInstrFormFields, instructions) {
    const instructionsList = [];
    if (typeof instructions !== 'undefined' && instructions.length > 0) {
      const requestIndex = this.getInstructionsIndex(instructions, 'requestType');
      if (requestIndex >= 0) {
        const requestType = instructions[requestIndex].values[0];
        if (typeof requestType !== 'undefined' && typeof pressInstrFormFields !== 'undefined') {
          let options = [];
          const requestLabel = pressInstrFormFields.RequestTypeDropDown.filter(request => request.id === requestType)[0];
          if (requestLabel) {
            instructionsList.push({ SpecificationName: 'Request Type', value: requestLabel.value });
          }
          pressInstrFormFields.RequestType[requestType].forEach(request => {
            const specification = request.options;
            const specificationMap = {};
            if (specification) {
              specification.map(spec => {
                specificationMap[spec.key] = spec.label;
              });
            }
            const result = instructions.filter(inst => inst.label === request.key);
            if (result && result.length >= 0) {

              result.forEach(res => {
                instructionsList.push({ SpecificationName: request.label, value: specificationMap[res.values[0]] ? specificationMap[res.values[0]] : res.values[0] });
              });
            }
            options = [];
            if (request.key === 'VideoOptions') {
              specification.forEach(spec => {
                const specOptions = instructions.filter(inst => inst.label === spec.key);
                if (specOptions && specOptions[0] && specOptions[0].values) {
                  options.push(spec.label);
                }
              });
              if (options.length > 0) {
                instructionsList.push({ SpecificationName: request.label, value: options });
              }
            }
            options = [];
            if (request.key === 'deliveryOptions') {
              specification.forEach(spec => {
                const specOptions = instructions.filter(inst => inst.label === spec.key);
                if (specOptions && specOptions[0] && specOptions[0].values) {
                  options.push(spec.label);
                }
              });
              if (options.length > 0) {
                instructionsList.push({ SpecificationName: request.label, value: options });
              }
            }
          });
        }
      }

    }

    return instructionsList;
  }

  getInstructionsIndex(instructions, label) {
    return instructions.findIndex(inst => inst.label === label);
  }
}
