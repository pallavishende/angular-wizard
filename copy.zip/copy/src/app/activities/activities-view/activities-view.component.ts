import { Component, OnInit } from '@angular/core';
import { StorageService } from '../../services/storage.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-activities-view',
  templateUrl: './activities-view.component.html',
  styleUrls: ['./activities-view.component.scss']
})

export class ActivitiesViewComponent implements OnInit {
  teamName = '';

  constructor(private storageService: StorageService, private userService: UserService) { }

  clearActivitiesObjFromlocal() {
    this.storageService.resetActivitiesObjInLocal();
  }

  ngOnInit() {
    this.userService.getMyTeamsInfo().subscribe((data) => {
      if (data.length > 0) {
        this.teamName = data[0].name;
      }
    });
  }

}
