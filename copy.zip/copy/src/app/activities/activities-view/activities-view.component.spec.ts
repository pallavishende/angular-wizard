import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { ActivitiesService } from '../../activities/activities.service';
import { HttpClientModule } from '@angular/common/http';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ActivitiesViewComponent } from './activities-view.component';

describe('ActivitiesViewComponent', () => {
  let component: ActivitiesViewComponent;
  let fixture: ComponentFixture<ActivitiesViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule ],
      declarations: [ ActivitiesViewComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      providers: [ {provide: ActivitiesService, useValue: ActivitiesService} ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create the component', () => {
    expect(component).toBeTruthy();
  });
});
