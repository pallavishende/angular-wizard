import { Component, OnInit, Input, Output, EventEmitter, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
import { ActivityHelperService } from '../activity-helper.service';
import { Subscription , Observable} from 'rxjs';
import { ActivitiesService } from '../activities.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { forEach, find, remove, orderBy } from 'lodash';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';

@Component({
  selector: 'app-activities-header',
  templateUrl: './activities-header.component.html',
  styleUrls: ['./activities-header.component.scss'],
  providers: [ CustomEditorService ]
})
export class ActivitiesHeaderComponent implements OnInit , OnChanges, OnDestroy {
  @Input() detailsObj;
  @Input() orderStatus;
  @Input() commentsCountStream: Observable<any>;

  @Output() updateActivity = new EventEmitter<any>();
  @Output() updateComments = new EventEmitter<any>();

  subscriptions = new Subscription();
  previousPage: { url: string, name: string; };
  pageSubheader = '';
  loggedInUser;
  clipInfo;
  workflowRouteObj;
  isFullEpisode = false;
  isVideoPublishingActivity: boolean;
  showAssets = false;
  startWorkFlag = false;
  reOpenTaskComment: boolean;
  submissionComment: string;
  pageTitle: string;
  commentsCount = 0;
  activityBundleId; // For press order
  assetOptions: any = {};

  constructor(
    private userService: UserService,
    private activitiesService: ActivitiesService,
    private activityHelperService: ActivityHelperService,
    private utilityService: UtilityService,
    private alerts: SystemAlertsService,
    private router: Router,
    public customEditorService: CustomEditorService,
    private activatedRoute: ActivatedRoute
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }

  onOpen(event: any = '') {
    setTimeout(() => {
      this.reOpenTaskComment = true;
    });
  }

  onClose() {
    this.reOpenTaskComment = false;
    this.submissionComment = '';
  }

  getActivityClipInfo() {
    const bundleId = this.detailsObj.activityBundle.id;
    const clipsInfo = this.detailsObj.orderClipsInfo;
    if (clipsInfo) {
      forEach(clipsInfo, clipInfo => {
        if (clipInfo.activityBundles) {
          if (find(clipInfo.activityBundles, bundle => bundle['bundleId'] === bundleId)) {
            this.clipInfo = clipInfo;
            return;
          }
        }
      });
    } else {
      this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page.');
      return;
    }
  }

  constructActivitiesWorkflowRoutes() {
    this.workflowRouteObj = [];
    if (this.isVideoPublishingActivity) {
      this.workflowRouteObj = this.clipInfo.activityBundles;
      this.workflowRouteObj = orderBy(this.workflowRouteObj, ['activityTypeId'], ['asc']);
      forEach(this.workflowRouteObj, workflow => {
        workflow['activityName'] = this.utilityService.getActivityNameByTypeId(workflow['activityTypeId']);
        workflow['activityRoute'] = this.utilityService.getActivityRouteByTypeId(workflow['activityTypeId']);
      });
      // change for combined approve and publish
      remove(this.workflowRouteObj, route => route['activityTypeId'] === 7 || route['activityTypeId'] === 18 || route['activityTypeId'] === 19 || route['activityTypeId'] === 20 );
    } else {
      if (this.detailsObj.lineItems[0] && this.detailsObj.lineItems[0].activities && this.detailsObj.lineItems[0].activities[0]) {
        const composeActivity = this.detailsObj.lineItems[0].activities[0];
        if (composeActivity.subActivities && composeActivity.subActivities[0]) {
          const approveActivity = composeActivity.subActivities[0];
          this.workflowRouteObj.push({
            'activityTypeId': composeActivity.typeId,
            'activityName': this.utilityService.getActivityNameByTypeId(composeActivity.typeId),
            'activityRoute': this.utilityService.getActivityRouteByTypeId(composeActivity.typeId),
            'bundleId': composeActivity.activityBundleId
          });
          this.workflowRouteObj.push({
            'activityTypeId': approveActivity.typeId,
            'activityName': this.utilityService.getActivityNameByTypeId(approveActivity.typeId),
            'activityRoute': this.utilityService.getActivityRouteByTypeId(approveActivity.typeId),
            'bundleId': approveActivity.activityBundleId
          });
        } else {
          this.activityBundleId = this.detailsObj.lineItems[0].activities[0].activityBundleId;
        }
      }
    }
  }

  getClipRoute(clipInfo) {
    if (clipInfo.activityBundles) {
      let targetActivity = find(clipInfo.activityBundles, activity => activity['activityTypeId'] === this.detailsObj.activityBundle.activityTypeId);
      if (!targetActivity) {
        targetActivity = find(clipInfo.activityBundles, activity => activity['activityTypeId'] === 1); // if same type of activity is not found, route to compose video
      }
      if (targetActivity) {
        this.router.navigateByUrl('/tasks/' + targetActivity['bundleId'] + '/' + this.utilityService.getActivityRouteByTypeId(targetActivity['activityTypeId']));
      }
    }
  }

  getOrderOwner() {
    if (this.detailsObj.assigneeName && this.detailsObj.assigneeName !== 'UNASSIGNED') {
      return this.detailsObj.assigneeName;
    } else if (this.detailsObj.teamName) {
      return this.detailsObj.teamName;
    } else {
      return 'UNASSIGNED';
    }
  }

  onSelectNameNotify(payload: any) {
    this.subscriptions.add(this.activitiesService.assignActivity(payload)
      .subscribe(
        data => {
          this.updateActivity.emit();
        },
        error => {
          console.log('assing all activity error');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
  }

  startWork() {
    this.startWorkFlag = true;
    const payload = {
      'groupedActivityIds': [this.detailsObj.activityBundle.id],
      'startWorkBy': this.loggedInUser.email
    }
    this.subscriptions.add(this.activitiesService.startWork(payload)
      .subscribe(
        data => {
          this.detailsObj.activityBundle.status = 'IN_PROGRESS';
          this.updateComments.emit();
        },
        error => {
          console.log('start work error');
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
        }
      ));
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
    this.toggleTask(true);
  }

  contentChanged(event, type?: string) {
    this.submissionComment = event.content;
    if (!event.isValidContent) {
      this.submissionComment = '';
    }
  }

  toggleTask(isReopen: boolean) {
    const activityBundleIds = [];
    if (this.detailsObj.orderClipsInfo.length !== 0) {
      this.detailsObj.orderClipsInfo.forEach((element) => {
        element.activityBundles.forEach((item) => {
          if (item.activityTypeId !== 7) {
            activityBundleIds.push(item.bundleId);
          }
        });
      });
    } else {
      this.workflowRouteObj.forEach((element) => {
        activityBundleIds.push(element.bundleId);
      });
      if (activityBundleIds.length <= 0) {
        activityBundleIds.push(this.activityBundleId);
      }
    }
   const payload =  {
      'orderId':  this.detailsObj.activityBundle.orderId,
      'activityIdForEvent': this.detailsObj.activityBundle.activityIds[0],
      'reOpenedActivityBundleId': this.detailsObj.activityBundle.id,
      'message': this.submissionComment,
      'activityBundleIds': activityBundleIds,
      'createdBy': this.loggedInUser.email,
      'activityStatus': isReopen ? 'REOPENED' : 'COMPLETED'
  };

    this.subscriptions.add(this.activitiesService.toggleTask(payload)
      .subscribe(
        data => {
          this.updateActivity.emit();
          const successMessage = isReopen ? 'Success! Your order has been Reopened.' : 'Success! Your order has been Closed.';
          this.alerts.addSuccessAlerts(successMessage);
        },
        error => {
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page!');
        }
      ));
  }

  ngOnInit() {
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.previousPage = this.activityHelperService.setActivityDetailsBackToNavigationRoute();
    if (this.detailsObj.activityBundle.isFullEpisode) {
      this.isFullEpisode = this.detailsObj.activityBundle.isFullEpisode;
    }
    this.pageSubheader = this.activityHelperService.getHeaderBundleInfo(this.detailsObj.metadata);
    this.pageTitle = this.activatedRoute.data["_value"].title;
    this.isVideoPublishingActivity = this.detailsObj.activityBundle.activityTypeId === 1
      || this.detailsObj.activityBundle.activityTypeId === 7
      || this.detailsObj.activityBundle.activityTypeId === 13
      || this.detailsObj.activityBundle.activityTypeId === 16
      || this.detailsObj.activityBundle.activityTypeId === 18
      || this.detailsObj.activityBundle.activityTypeId === 19
      || this.detailsObj.activityBundle.activityTypeId === 20;
    this.getActivityClipInfo();
    this.constructActivitiesWorkflowRoutes();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (typeof changes.commentsCountStream !== 'undefined' &&
        typeof changes.commentsCountStream.currentValue !== 'undefined' &&
        typeof changes.commentsCountStream.previousValue === 'undefined') {
      this.setCommentsCount();
    }
  }

 setCommentsCount(): void {
    this.commentsCountStream.subscribe(
      (data) => {
        this.commentsCount = data;
      },
      (error) => {
        console.error('Failed to fetch comments count.');
      }
    );
 }
  scrollToBottom() {
    window.scrollTo(0, document.body.scrollHeight);
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscriptions.unsubscribe();
  }


}
