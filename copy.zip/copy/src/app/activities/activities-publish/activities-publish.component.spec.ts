import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitiesPublishComponent } from './activities-publish.component';

describe('ActivitiesPublishComponent', () => {
  let component: ActivitiesPublishComponent;
  let fixture: ComponentFixture<ActivitiesPublishComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitiesPublishComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitiesPublishComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should be created', () => {
    expect(component).toBeTruthy();
  });
});
