import { Component, OnInit, OnDestroy, AfterViewInit, QueryList, ViewChildren } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ActivitiesService } from '../activities.service';
import { Subscription } from 'rxjs/Subscription';
import { forEach, find, assign, orderBy, indexOf } from 'lodash';
import 'rxjs/add/operator/toPromise';
import { LineItem } from '../../models/line-item';
import { OrdersService } from '../../orders/orders/orders.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { CustomEditorService } from '../../shared/custom-editor/custom-editor.service';
import { ActivityHelperService } from '../activity-helper.service';
import { ActivitiesCommentsService } from '../../shared/activities-comments/activities-comments.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { UserService } from '../../services/user.service';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-activities-publish',
  templateUrl: './activities-publish.component.html',
  providers: [ CustomEditorService ],
  styleUrls: ['./activities-publish.component.scss', '../activities.scss']
})

export class ActivitiesPublishComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChildren('versions') versions: QueryList<any>;

  activityBundleId: string;
  detailsObj;
  copyObj;
  orderStatus;
  endpointObj = [];
  endpointNames: Array<any> = [];
  submitComment: string;
  publishActivityObj;
  loggedInUser;
  submitAllowed = {};
  assetOptions = {
    lineItemId: 0
  };
  isFullEpisode = false;
  dataSubscription: Subscription;
  subscriptions = new Subscription();
  pollingInterval = new Subscription();
  updatedObj;
  allowSubmission = {};
  activeActivitiesTab;
  initializePublishEditor: boolean;
  initializeRejectEditor: boolean;
  commentServiceInstance: ActivitiesCommentsService;
  pageFragment: string;
  selectedLineItem;
  disableDataPolling = false;
  publishingInstructions = {};
  versionTypes = {};
  attachmentsStatus: Array<any> = [];
  commentsCountStream: Observable<any>;
  retryCounter = 0;
  pollingUnsubscribed = false;

  constructor(
    private ordersService: OrdersService,
    private activitiesService: ActivitiesService,
    private activeRoute: ActivatedRoute,
    private alerts: SystemAlertsService,
    private activityHelperService: ActivityHelperService,
    private activitiesCommentsService: ActivitiesCommentsService,
    private loadingMaskService: LoadingMaskService,
    private userService: UserService,
    private customEditorService: CustomEditorService
  ) { }

  ngOnInit() {
    this.activitiesService.setActivitiesPageTitle('Publish Video - Viacom Bridge');
    this.loggedInUser = this.userService.getUserLoginInfo();
    this.activityBundleId = this.activeRoute.snapshot.params['id'];
    this.getActivityInfo();
    this.pollingFunction();
    this.activeRoute.fragment.subscribe((fragment) => {
      this.pageFragment = fragment;
    });
  }

  ngAfterViewInit(): void {
    // converting queryList observable to promise to trigger a callback when the versions are loaded in the DOM
    this.versions.changes.take(1).toPromise().then(data => {
      if (this.pageFragment) {
        this.versions.forEach((version) => {
        if (version.nativeElement.id === this.pageFragment) {
          document.querySelector('#' + this.pageFragment).scrollIntoView(true);
          let scrolledY = window.scrollY;
          // checking if this is not the last version on the page to substract the header height
          if (scrolledY && ('version' + (this.endpointObj[this.endpointNames[this.endpointNames.length - 1]]
          [this.endpointObj[this.endpointNames[this.endpointNames.length - 1]].length - 1].id)) !== this.pageFragment) {
            window.scroll(0, scrolledY - 200);
          }
          return;
        }
      });
    }
    });
  }

  setTaskCommentsCountStream(event): void {
    this.commentsCountStream = event;
  }

  pollingFunction() {
    this.pollingInterval = IntervalObservable.create(20000).subscribe(
      interval => {
          this.pollCurrentTaskStatus();
      }
    );
    this.subscriptions.add(this.pollingInterval);
  }

  pollCurrentTaskStatus() {
    if (this.disableDataPolling) {
      return;
    }
    const self = this;
    if (typeof this.dataSubscription !== 'undefined') {
      this.dataSubscription.unsubscribe();
    }
    this.dataSubscription = this.activitiesService.getActivityDetail(self.activityBundleId)
    .subscribe( data => {
        self.updatedObj = data;
        // 1. loop through all the end points
        forEach(Object.keys(self.endpointObj), (endpoint) => {
          // 2. loop through all line items
          forEach(self.endpointObj[endpoint], (lineItem) => {
            // 4. get line item id
            let lineItemId = lineItem['id'];
            // 5. find the corresponding line item in updatedObj
            let updatedData = find(self.updatedObj.lineItems, (item) => {
              return item['id'] === lineItemId; // failing on type for id
            });
            let updatedLineItem: LineItem = assign(new LineItem(), updatedData);
            // 6. update the status of endpoint.lineitem with updated.lineItem.status
            let calculatedStatus = self.activityHelperService.getPublishStatus(updatedLineItem);
            lineItem['publishStatus'] = calculatedStatus;
          });
        });
        self.getOrderStatus();
    });
  }

  getOrderStatus() {
    this.subscriptions.add(this.ordersService.getOrderDetails(this.detailsObj.activityBundle.orderId).subscribe(
      data => {
        this.orderStatus = data.currentMilestone.status;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        this.loadingMaskService.disableLoadingMask();
      }));
  }

  getActivityInfo() {
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.activitiesService.getActivityDetail(this.activityBundleId)
    .subscribe(
      data => {
        this.loadingMaskService.disableLoadingMask();
        this.detailsObj = data;
        this.updatedObj = data;
        this.getOrderStatus();
        if (this.detailsObj.activityBundle.isFullEpisode) {
          this.isFullEpisode = this.detailsObj.activityBundle.isFullEpisode;
        }
        if (this.detailsObj.activityBundle.orderClipName) {
          this.activitiesService.setActivitiesPageTitle('Publish Video - ' +
          this.detailsObj.activityBundle.orderClipName + ' - Viacom Bridge');
        }
        let self = this;
        // sorting lineItems by endpoints in ascending order
        this.detailsObj.lineItems = orderBy(this.detailsObj.lineItems, 'endpoint', 'asc');
        // create array out of line items only
        let lineItems = this.detailsObj.lineItems;
        this.assetOptions.lineItemId = lineItems[0]['id'];

        // construct videoInstructionsMetadata
        this.detailsObj.lineItems.forEach((lineItem) => {
          self.endpointObj[lineItem.endpoint] = [];
          lineItem.videoInstructionsMetadata = {};
          const videoActivity = find(lineItem.activities, { 'typeId': 1 });
          forEach(videoActivity['instructions'], (instruction) => {
            lineItem.videoInstructionsMetadata[instruction.label] = (instruction.label === 'captions' ? instruction.values : instruction.values.join('\r\n'));
          });
        });

        // construct publishingInstructions
        lineItems.forEach((lineItem) => {
          self.endpointObj[lineItem.endpoint] = [];
          if (lineItem.endpoint === 'Viacom Sites & Apps') {
            const publishActivity = find(lineItem.activities, { 'typeId': 13 });
            forEach(publishActivity['instructions'], (instruction) => {
              this.publishingInstructions[instruction.label] = instruction;
            });
          }
          this.versionTypes[lineItem.id] = this.getVersionType(lineItem);
        });

        // push corresponding line items into appropriate endpoint array in new object
        lineItems.forEach((item) => {
          for (const k in self.endpointObj) {
            if (item.endpoint === k) {
              item.publishStatus = self.activityHelperService.getPublishStatus(item);
              // item.isDisabled = true;
              self.endpointObj[k].push(item);
              self.endpointObj[k] = orderBy(self.endpointObj[k], [(activity) => {
                return activity['version'].toLowerCase();
              }], 'asc');
            }
          }
        });
        console.log('detialsObj -> ', this.detailsObj);

        // create array containing only endpoint names
        self.endpointNames = Object.keys(self.endpointObj);
        this.getCopyOrderInfo(this.detailsObj.metadata.vmid);
      },
      error => {
        console.log('all activities error', error);
        this.loadingMaskService.disableLoadingMask();
        if (error.status === 404) {
          this.alerts.redirectTo404Page();
        } else {
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
      }
    ));
  }

  updateComments() {
    this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
  }

  updateFilesMetadata(event, lineItem?, activityType?) {
    if (activityType === 'VIDEO_ACTIVITY') {
      if (!event.uploadingInProgressQueue.length) {
        forEach(event.uploadedFileQueue, (uploadedFile) => {
          uploadedFile.source = 'S3';
          uploadedFile.activityId = this.getVideoActivity(lineItem)['id'];
        });
        this.subscriptions.add(this.activitiesService.updateFilesMetadata(event.uploadedFileQueue).subscribe(
        (data) => {
          console.log('Successfully updated the metadata.');
          const lineItemIndex = indexOf(this.detailsObj.lineItems, lineItem);
          const videoActivityIndex = indexOf(this.detailsObj.lineItems[lineItemIndex].activities, this.getVideoActivity(lineItem));
          if (this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input) {
            this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input.attachments = data;
          } else {
            this.detailsObj.lineItems[lineItemIndex].activities[videoActivityIndex].input = { attachments: data };
          }
        },
        error => {
          console.log('Error in updating the metadata');
        }));
      }
    } else {
      this.attachmentsStatus = event;
    }
  }

  getCopyOrderInfo(vmid: string) {
    this.subscriptions.add(this.activitiesService.getCopyOrderInfo(vmid)
    .subscribe(
      data => {
        // NOTE: not displaying submissionMessage from this payload, deprecated
        this.copyObj = data;
      },
      error => {
        console.log('get copy order error', error);
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  getCopyOrderUrl(copy): string {
    return '/orders/' + copy['id'] + '/order-detail';
  }

  getVideoActivity(lineItem: LineItem) {
    return find(lineItem.activities, { 'typeId': 1 });
  }

  getPublishActivity(lineItem: LineItem) {
    return find(lineItem.activities, {'typeId': 13 });
  }

  contentChanged(event, type?: string) {
    this.publishActivityObj = event;
    this.submitComment = event.content;
    if (!event.isValidContent) {
      this.submitComment = '';
    }
    if (event.readyToPostComment) {
      if (type && type === 'reject') {
        if (event.isValidContent) {
          this.markAsPublished(this.selectedLineItem, 'REJECTED');
        }
      } else {
        this.markAsPublished(this.selectedLineItem, 'COMPLETED');
      }
    }
  }

  markAsPublished(lineItem: LineItem, status: string) {
    const prevComposeStatus = lineItem['publishStatus'];
    lineItem['publishStatus'] = 'Updating';
    lineItem['isDisabled'] = true;
    const lineItemId = lineItem.id;
    const publishActivityId = this.getPublishActivity(lineItem)['id'];
    const mentionsEmails = [];
    this.publishActivityObj.mentionedUsers.forEach((element) => {
      mentionsEmails.push(element.email);
    });
    const publishActivityPayload = {
      activityIds: [publishActivityId],
      orderId: this.detailsObj.activityBundle.orderId,
      status: status,
      message: this.submitComment,
      mentionedUserEmails: mentionsEmails,
      createdByEmail: this.userService.getUserLoginInfo().email
    };
    this.loadingMaskService.enableLoadingMask();
    this.disableDataPolling = true;
    this.subscriptions.add(this.activitiesService.markAsPublished(publishActivityPayload).subscribe(
      data => {
        this.retryCounter++;
        if (this.retryCounter > 1) {
          this.pollingInterval.unsubscribe();
          this.pollingUnsubscribed = true;
        }
        lineItem['publishStatus'] = 'Updating';
        this.submitComment = '';
        this.loadingMaskService.disableLoadingMask();
        this.commentServiceInstance.getOrderCommentsAndEvents(this.detailsObj.activityBundle.orderId);
        if (status === 'COMPLETED') {
          this.alerts.addSuccessAlerts('Success! The work for ' + lineItem['version'] + ' was marked as published.');
        } else if (status === 'REJECTED') {
          this.alerts.addSuccessAlerts('Success! The work for ' + lineItem['version'] + ' was marked as rejected.');
        }
        this.activitiesService.getActivityDetail(this.activityBundleId).mergeMap((dataRespMerge: any) => {
          const submittedLineItem = find(dataRespMerge.lineItems, function (item) {
            return item['id'] === lineItemId; // failing on type for id
          });
          if (submittedLineItem.activities.filter(selectedLineItem => (selectedLineItem.typeId === 13 && selectedLineItem.currentState.status === prevComposeStatus)).length > 0) {
            return Observable.throw('Retrying status update');
          } else {
            return Observable.of(dataRespMerge);
          }
        }).retryWhen(errors => errors.delay(3000).take(5))
        .finally(() => {
          this.retryCounter--;
          if (this.retryCounter === 0 ) {
            this.disableDataPolling = false;
            this.pollCurrentTaskStatus();
            if (this.pollingUnsubscribed) {
              this.pollingFunction();
              this.pollingUnsubscribed = false;
            }
          }
        })
        .subscribe((dataResp: any) => {
        });
    }));
  }

  setAddingCommentEvent(value: any) {
    const activityId = value['activityId'];
    const isAddingComment = value['isAddingComment'];
    this.allowSubmission[activityId] = !isAddingComment;
  }

  setCommentsServiceInstanceObj(serviceInstance: any) {
   this.commentServiceInstance = serviceInstance;
  }

  onOpen(type?: string) {
    setTimeout(() => {
      if (type === 'publish') {
        this.initializePublishEditor = true;
      } else if (type === 'reject') {
        this.initializeRejectEditor = true;
      }
    });
  }

  onClose() {
    this.initializePublishEditor = false;
    this.initializeRejectEditor = false;
    this.submitComment = '';
  }

  getCommentFromEditor() {
    this.customEditorService.getCommentFromEditor.emit();
  }

  getCopyDetails(copy: any): void {
    if (!copy.showDetails || copy.status !== 'COMPLETED') {
      return;
    }
    copy.isLoadingEvents = true;
    this.subscriptions.add(this.activitiesService.getActivityEvents(copy.activityId).subscribe((data) => {
      copy.isLoadingEvents = false;
      copy.approvedEvent = this.activitiesCommentsService.getLatestCommentEvent(data, 'APPROVED');
      if (copy.approvedEvent && copy.approvedEvent.attachments) {
        copy.approvedAttachments = copy.approvedEvent.attachments;
      } else {
        copy.approvedAttachments = [];
      }
    }));
  }

  getEndpointIconName(endpoint) {
    return '/assets/images/' + endpoint.replace(/ /g, '_').replace(/&/g, 'and').toLowerCase() + '.logo.png';
  }

  getVersionType(lineItem: LineItem): string {
    const videoActivity = this.getVideoActivity(lineItem);
    const versionType = find(videoActivity.instructions, (instruction) => {
      return instruction.label === 'versionType';
    });
    return versionType.values[0] || '';
  }

  ngOnDestroy() {
    if (this.dataSubscription) {
      this.dataSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }
}
