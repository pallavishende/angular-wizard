import { Injectable, Inject } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AdalService } from '../shared/auth/adal.service';
import { Observable } from 'rxjs/Rx';
import { DOCUMENT } from '@angular/platform-browser';
import 'rxjs/add/observable/of';
import { UserService } from '../services/user.service';

@Injectable()
export class RouteGuard implements CanActivate {

  constructor(
    @Inject(DOCUMENT)
    private document: Element,
    private router: Router,
    private adalService: AdalService,
    private userService: UserService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    let loggedInUser;
    if (this.adalService.isUserAuthenticated()) {
      this.adalService.getUser().subscribe((userInfo) => {
        loggedInUser = userInfo.userName;
      });
      if (!this.userService.isActiveUser && route.routeConfig.path !== 'get-started') {
        return this.userService.getUserInfo(loggedInUser).map(
          (userData) => {
            console.log('Existing User, redirecting to the requested page:', userData);
            this.userService.isActiveUser = true;
            return true;
          })
          .catch(error => {
            if (error.status === 404) {
              console.log('User not found in the system. Redirecting to setup user profile.');
              this.router.navigateByUrl('get-started');
            }
            return Observable.of(false);
          });
      } else {
        console.log('Existing User, redirecting to the requested page');
        return true;
      }
    } else {
      return this.adalService.acquireToken(this.adalService.config.clientId).do(() => {
         this.removeAdalFrame();
         // update the User model and isAuthenticated in AdalService
         this.adalService.refreshDataFromCache();
      }).mergeMap((data) => {
        console.log('Refreshing the token:', data);
        return Observable.of(true);
      })
        .catch(() => {
          this.router.navigateByUrl('/login');
          return Observable.of(false);
        });
    }
  }

  private removeAdalFrame() {
    // removing only the idToken frame
    const iFrames = this.document.getElementsByTagName('iframe');
    for (let i = 0; i < iFrames.length; i++) {
      if (iFrames[i].id.startsWith('adalIdTokenFrame')) {
        iFrames[i].remove();
      }
    }
  }
}
