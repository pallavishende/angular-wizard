export interface BulkSubmissionItem {
  activityId: number;
  status: string;
  title: string;
}
