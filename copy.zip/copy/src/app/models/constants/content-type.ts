export enum ContentTypes {
    Episode = "EPISODE",
    Movie = "MOVIE",
    Special = "SPECIAL",
    Brand = "BRAND",
    Series = "SERIES",
    Season = "SEASON"
}