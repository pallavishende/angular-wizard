export enum OrderTypes {
    Video = 'video',
    Copy = 'copy',
    Graphics = 'graphics',
    SiteAndAppUpdates = 'site_app_updates',
    Press = 'press'
};
