export enum DefaultTeams {
    VmnMmops = 'vmn mmops',
    VmnDesign = 'vmn design',
    VmnSitesAndApps = 'vmn sites & apps'
};
