export interface OrderInstruction {
    instructions: string;
    siteAndAppPresets?: string;
    dropoffLocation?: string;
    captions?: string;
    captionsBillingGroup?: string;
    deliveryFormat?: string;
    budgetCode?: string;
    deliveryLocation?: string;
    dueDate?: string;
    publishDate?: string;
    rollingDueDate?: string;
  }
