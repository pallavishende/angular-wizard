import { OrderInstruction } from '../../app/models/bridge-order/shared.model';

export interface Metadata {
  contentType: string;
  orderType: string;
  isFullEpisode?: boolean;
  episode?: string;
  series?: string;
  vmId?: string;
  isNewOrder?: boolean;
  brand?: string;
  requestType?: string;
  orderInstruction?: OrderInstruction;
}
export interface OrderInstruction {
  instructions?:   string;
  dueDateTime?:    String;
  deliveryFormat?: string;
  budgetCode?:     string;
  rollingDueDate?: string;
  siteAndAppPresets?: string;
  dropOffLocation?: string;
  captions?: string;
  captionsBillingGroup?: string;
  publishDateTime?: string;
  launchDateTime?: string;
  deliveryLocation?: string;
}
