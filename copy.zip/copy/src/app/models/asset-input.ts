export class AssetInput {
    assetNumber: string;
    assetName: string;
    assetSource: string;
    inOutPoint: string;
    clipId?: number;

    constructor() { }
}