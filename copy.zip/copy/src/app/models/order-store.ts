import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { includes, orderBy, sortBy, forEach, filter, get, uniqBy, keys, indexOf, remove, union, findIndex, assignIn, flatten, map } from 'lodash';
import { EndpointProfileService } from '../services/endpoint-profile.service';
import { Order } from './order';
import { LineItem } from './line-item';
import { Activity } from './activity';
import { OrderTypes } from './constants/order-types';
import { UtilityService } from '../services/utility.service';
import * as moment from 'moment/moment';

const orderPublishingFormFields = require('./mock-payloads/order-publishing-form-fields.json');
const orderVideoCopyFormFields = require('./mock-payloads/order-video-copy-form-fields.json');
const orderGraphicsFormFields = require('./mock-payloads/order-graphic-request-instructions.json');

@Injectable()
export class OrderStore {
  private order: BehaviorSubject<Order> = new BehaviorSubject(<Order>{});
  orderStream = this.order.asObservable();
  orderObject;

  constructor(
    private endpointProfileService: EndpointProfileService,
    private utilityService: UtilityService) {}

  setTotalsForEndpoints(orderData) {
    const FilterFn = this.utilityService.propertyFilter;  // maintain reference
    let epdData;
    this.endpointProfileService.getEndpointProfiles().subscribe(
      data => {
        // storing the alphabetically sorted response from epd service to a local object
        epdData = orderBy(data, 'name', 'asc');
        forEach(orderData.lineItemsClipId, (lineItemClipId) => {
          lineItemClipId['endpoint_info'] = {};
          const clipIdentifier = lineItemClipId['metadata'][0]['clipId'] ? 'clipId' : 'clipTitle';
          const isArchive = clipIdentifier === 'clipId';
          forEach(epdData, (epd) => {
            lineItemClipId.endpoint_info[epd['name']] = orderBy(filter(orderData.lineItems, (lineItem) => {
              return FilterFn(lineItem, 'customConfig.endpoint', epd['name']) &&
                lineItem['metadata'][0][clipIdentifier] === lineItemClipId['metadata'][0][clipIdentifier] &&
                (isArchive || !lineItem['metadata'][0]['clipId']);
            }), [(epdLineItem) => {
              return epdLineItem['customConfig']['version'].toLowerCase();
            }],
              'asc');
          });
        });
      }
    );
  }

  loadInitialModel(orderData: any, orderType?: string) {
    const orderObject = orderData;
    if (typeof orderType !== 'undefined') {
      switch (orderType.toLowerCase()) {
        case OrderTypes.Video: {
          const lineItemsUniqueClipId = this.getUniqueLineItemsByClipIds(orderObject.lineItems);
          const sortedLineItems = sortBy(orderObject.lineItems, [(o) => { return get(o, 'customConfig.version'); }]);
          orderData.groupedLineItemsByClipId = {};
          forEach(sortedLineItems, (item: LineItem) => {
            const clipIdentifier = item.metadata[0]['clipId'] || item.metadata[0]['clipTitle'];
            orderData.groupedLineItemsByClipId[clipIdentifier] = filter(orderData.lineItems, (lineItem: LineItem) => {
            if (lineItem.metadata[0]['clipId'] === clipIdentifier || (!lineItem.metadata[0]['clipId'] &&
              lineItem.metadata[0]['clipTitle'] === clipIdentifier)) {
                return lineItem;
              }
            });
          });

          // sorting lineItems by clip titles
          const sortedlineItemsClipId = orderBy(lineItemsUniqueClipId, [(lineItem) => {
            return lineItem['metadata'][0]['clipTitle'] ? lineItem['metadata'][0]['clipTitle'].toLowerCase() : lineItem['metadata'][0]['clipTitle'];
          }], 'asc');
          orderObject.lineItems = sortedLineItems;
          orderObject.lineItemsClipId = sortedlineItemsClipId;
          this.setTotalsForEndpoints(orderObject);
          this.setInstructionsMetadata(orderObject);
          this.setOrderInstructions(orderObject);
          break;
        }

        case OrderTypes.Press: {
          const orderedLineItems = orderBy(orderObject.lineItems, (lineItem: any) => {
            return Number(lineItem.metadata[0].assetInputs[0].assetNumber.split(' ')[1]);
          }, 'asc');
          orderObject.lineItems = orderedLineItems;
          orderObject.lineItemsClipId = orderedLineItems;
          this.setTotalsForEndpoints(orderObject);
          this.setInstructionsMetadata(orderObject);
          break;
        }

        case OrderTypes.Graphics: {
          this.setGraphicsInstructionsMetadata(orderObject);
          break;
        }
      }
    }
    this.order.next(orderObject);
  }

  setInstructionsMetadata(orderObject: Order) {
    this.setVideoInstructionsMetadata(orderObject);
    this.setPublishInstructionsMetadata(orderObject);
  }

  setVideoInstructionsMetadata(orderObject: Order) {
    let videoActivity: Activity;
    let videoInstructionsMetadata = {};
    forEach(orderObject.lineItems, (lineItem: LineItem) => {
      lineItem['videoInstructionsMetadata'] = {};
      videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
      if (videoActivity && videoActivity.instructions) {
        forEach(videoActivity.instructions, (metadata) => {
          videoInstructionsMetadata[metadata.label] = metadata.values;
        });
        lineItem['videoInstructionsMetadata'] = videoInstructionsMetadata;
        videoInstructionsMetadata = {};
      }
    });
  }

  setPublishInstructionsMetadata(orderObject: Order) {
    let publishActivity: Activity;
    forEach(orderObject.lineItems, (lineItem: LineItem) => {
      const publishInstructionsMetadata = {};
      const videoCopyInstructionsMetadata = {};
      publishActivity = this.utilityService.getLineItemActivity(13, lineItem);
      if (publishActivity && publishActivity.instructions) {
        if (!this.instructionBelongsToFormField(publishActivity.instructions, orderPublishingFormFields)
        && typeof lineItem['publishInstructionsMetadata'] !== 'undefined') {
          delete lineItem['publishInstructionsMetadata'];
        }
        if (!this.instructionBelongsToFormField(publishActivity.instructions, orderVideoCopyFormFields)
        && typeof lineItem['videoCopyInstructionsMetadata'] !== 'undefined') {
          delete lineItem['videoCopyInstructionsMetadata'];
        }
        forEach(publishActivity.instructions, (metadata) => {
          if (includes(keys(orderPublishingFormFields), metadata['label'])) {
            publishInstructionsMetadata[metadata.label] = metadata.values;
            lineItem['publishInstructionsMetadata'] = publishInstructionsMetadata;
          } else if (includes(keys(orderVideoCopyFormFields), metadata['label'])) {
            videoCopyInstructionsMetadata[metadata.label] = metadata.values;
            lineItem['videoCopyInstructionsMetadata'] = videoCopyInstructionsMetadata;
          }
        });
      }
    });
  }

  setOrderInstructions(orderObject: Order) {
    const currentOrderDueDateTime = orderObject.lineItems[0] && orderObject.lineItems[0].dueDateTime;
    if (currentOrderDueDateTime) {
      if (!orderObject.lineItems[0].dueByDate) {
        orderObject.lineItems[0].dueByDate = moment(currentOrderDueDateTime).format('YYYY-MM-DD');
      }
      if (!orderObject.lineItems[0].dueByTime) {
        orderObject.lineItems[0].dueByTime = moment(currentOrderDueDateTime).format('hh:mm A');
      }
    }
  }

  setGraphicsInstructionsMetadata(orderObject: Order) {
    let graphicsActivity: Activity;
    let graphicsFormFields = orderGraphicsFormFields.graphicsDetailForm;
    forEach(orderObject.lineItems, (lineItem: LineItem) => {
      const graphicsInstructionsMetadata = {};
      graphicsActivity = this.utilityService.getLineItemActivity(5, lineItem);
      delete lineItem['graphicsInstructionsMetadata'];
      if (graphicsActivity && graphicsActivity.instructions) {
        forEach(graphicsActivity.instructions, (metadata) => {
          if (includes(keys(graphicsFormFields), metadata['label'])) {
            graphicsInstructionsMetadata[metadata.label] = metadata.values;
            lineItem['graphicsInstructionsMetadata'] = graphicsInstructionsMetadata;
          }
        });
      }
    });
  }

  // return true when at least one property in instructions belongs to certain form field
  instructionBelongsToFormField(instructions, formField): boolean {
    if (instructions.length === 0) {
      return false;
    }
    let result = false;
    forEach(instructions, metadata => {
      if (includes(keys(formField), metadata['label'])) {
        result = true;
      }
    });
    return result;
  }

  getUniqueLineItemsByClipIds(lineItems) {
    let arrByClipId = lineItems.filter(lineItem => {
      if (lineItem['metadata'] && lineItem['metadata'][0] && lineItem['metadata'][0]['clipId']) {
        return true;
      } else {
        return false;
      }
    });
    arrByClipId = uniqBy(lineItems, 'metadata[0].clipId');
    let arrByClipTitle = lineItems.filter(lineItem => {
      if (lineItem['metadata'] && lineItem['metadata'][0] && lineItem['metadata'][0]['clipId']) {
        return false;
      } else {
        return true;
      }
    });
    arrByClipTitle = uniqBy(lineItems, 'metadata[0].clipTitle');
    return union(arrByClipId, arrByClipTitle);
  }

  getCorrespondingLineItemsFromClipIdentifier(lineItem, orderPayload) {
    return filter(orderPayload.lineItems, (item: LineItem) => {
      if (item.metadata[0]['clipId'] && lineItem.metadata[0]['clipId']) {
        if (item.metadata[0]['clipId'] === lineItem.metadata[0]['clipId']) {
          return item;
        }
      } else {
        if (!item.metadata[0]['clipId'] && !lineItem.metadata[0]['clipId'] && item.metadata[0]['clipTitle'] === lineItem.metadata[0]['clipTitle']) {
          return item;
        }
      }
    });
  }

  updateExistingLineItem(updatedlineItem: Object) {
    const orderData = this.order['_value'];
    const lineItemIndex = findIndex(orderData.lineItems, (item) => {
      if (typeof updatedlineItem['id'] !== 'undefined') {
        return item['id'] === updatedlineItem['id'];
      } else {
        return item['lineItemId'] === updatedlineItem['lineItemId'];
      }
    });
    assignIn(orderData.lineItems[lineItemIndex], updatedlineItem);
    this.setTotalsForEndpoints(orderData);
    this.order.next(orderData);
  }

  addNewLineItem(newLineItem: Object) {
    const orderData = this.order['_value'];
    newLineItem['lineItemId'] = this.utilityService.generateGuid();
    orderData.lineItems.push(newLineItem);
    this.setTotalsForEndpoints(orderData);
    this.order.next(orderData);
  }

  addNewAssetToFullEpisode(clipMetadata) {
    const orderData = this.order['_value'];
    forEach(orderData['lineItems'], (lineItem: LineItem) => {
      const newMetadataIndex = indexOf(lineItem.metadata, clipMetadata);
      if (newMetadataIndex < 0) {
        lineItem.metadata.push(clipMetadata);
      }
    });
    this.setTotalsForEndpoints(orderData);
    this.order.next(orderData);
  }

  removeLineItem(lineItem: Object) {
    var orderData = this.order['_value'];

    if (lineItem['id']) {
      remove(orderData.lineItems, {
        id: lineItem['id']
      });
    } else if (lineItem['lineItemId']) {
      remove(orderData.lineItems, {
        lineItemId: lineItem['lineItemId']
      });
    }
    this.setTotalsForEndpoints(orderData);
    this.order.next(orderData);
  }

  addActivity(activityObj, lineItem) {
    var orderData = this.order['_value'];

    let idFieldToUse = lineItem.id ? 'id' : 'lineItemId';

    forEach(orderData.lineItems, (item) => {
      if (item[idFieldToUse] === lineItem[idFieldToUse]) {
        if (item['activities'] !== undefined && item['activities'].length) {
          item['activities'].push(activityObj);
        } else {
          item['activities'] = [];
          item['activities'].push(activityObj);
        }
      }
    });
    // commenting the syncActivities method because this will be called for each lineItem on the Approval step
    // so as to make an optional but required step (for navigation) to proceed.
    // this.syncActivities(lineItem);

    this.order.next(orderData);
  }

  removeActivity(activityObj, lineItem) {
    var orderData = this.order['_value'];
    remove(lineItem.activities, {
      typeId: activityObj['typeId']
    });
    // commenting the syncActivities method because this will be called for each lineItem on the Approval step
    // so as to make an optional but required step (for navigation) to proceed.
    // this.syncActivities(lineItem);

    this.order.next(orderData);
  }

  syncActivities(lineItem) {
    const utilityServiceRef = this.utilityService;
    // get all the approvals for the line items in step 1
    const subActivities = [];
    forEach(lineItem['activities'], (activity) => {
      let s = activity['subActivities'];
      if (s !== undefined) {
        subActivities.push(s);
      }
    });
    const tmp = flatten(subActivities);
    const approvals = map(tmp, (approval) => {
      let a = {
        typeId: approval.typeId,
        description: approval.description,
        generationMode: approval.generationMode,
        assignedUserEmail: approval.assignedUserEmail || '',
        previousTypeId: approval.typeId,     // used for lookup
        previousUserEmail: approval.assignedUserEmail || '',    // used for lookup
        activityId: utilityServiceRef.generateGuid()
        // activity_ref: approval.activity_ref
      };
      return a;
    });
    lineItem.customConfig.approvals = sortBy(flatten(approvals), ['generationMode', 'typeId']);
  }

  removeLineItemsByProperty(removeBy, removeByValue) {
    const orderData = this.order['_value'];
    if (orderData.metadata.isFullEpisode) {
      forEach(orderData.lineItems, (lineItem: LineItem) => {
        remove(lineItem.metadata, (metadata) => {
          if (removeBy === 'clipTitle') {
            return metadata['clipTitle'] === removeByValue && !metadata['clipId'];
          } else {
            return metadata[removeBy] === removeByValue;
          }
        });
      });
      if (orderData.lineItems[0] && orderData.lineItems[0].metadata.length === 0) {
        orderData.lineItems.length = 0;
      }
    } else {
      remove(orderData.lineItems, (item) => {
        if (removeBy === 'clipTitle') {
          return item['metadata'][0]['clipTitle'] === removeByValue && !item['metadata'][0]['clipId'];
        } else {
          return item['metadata'][0][removeBy] === removeByValue;
        }
      });
    }
    let lineItemsUniqueClipId: any[] = uniqBy(orderData.lineItems, 'vmid');
    let sortedLineItems = sortBy(orderData.lineItems, [(o) => { return get(o, 'customConfig.version'); }]);
    let sortedlineItemsClipId = sortBy(lineItemsUniqueClipId, [(o) => { return o.vmid; }]);
    orderData.lineItems = sortedLineItems;
    orderData.lineItemsClipId = sortedlineItemsClipId;
    this.order.next(orderData);
  }

  updateCurrentOrder(orderData) {
    this.order.next(orderData);
  }

  // other methods working on the model
  notify() {
    const orderData = this.order['_value'];
    this.order.next(orderData);
  }
}
