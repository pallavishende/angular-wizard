export interface AzureUser {
    displayName: string;
    email: string;
    familyName: string;
    firstName: string;
    id: string;
    uniqueName: string;
}

export interface UPDUser {
    login: string,
    adIdentity: string,
    firstName: string,
    lastName: string,
    displayName: string,
    selectedNotifications?: Array<any>,
    id?: number,
    jobTitle?: string,
    imageUrl?: string,
    primaryWorkLocation?: string,
    workForBrands?: Array<any>,
    termsOfUse?: Array<any>
}
