export class Approval {
  type: string;
  user: string;
}
