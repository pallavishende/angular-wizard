import { DateTimeObject } from './order-models/date-time.model';
import { BridgeUI } from './bridge-ui.model';

export interface Milestone {
    id?: number;
    status?: Status;
    createdDate?: string;
    lastModifiedDate?: string;
    note?: null;
}

export interface State {
    id?: number;
    status?: Status;
    createdDate?: string;
    lastModifiedDate?: string;
    note?: null;
}

export enum StatusEnum {
    APPROVED = 'APPROVED',
    CANCELLED = 'CANCELLED',
    COMPLETED = 'COMPLETED',
    DRAFT = 'DRAFT',
    IN_PROGRESS = 'IN_PROGRESS',
    REJECTED = 'REJECTED',
    REOPENED = 'REOPENED',
    SUBMITTED = 'SUBMITTED',
    TO_DO = 'TO_DO',
    WAITING = 'WAITING',
}

export type Status = keyof typeof StatusEnum;

export interface LineItem {
    id?: number;
    currentState?: State;
    metadata?: LineItemMetadata[] | null;
    dueDateTime?: string | null;
    publishDateTime?: string | null;
    endpointId?: null;
    lastModifiedDate?: string;
    activities?: Activity[];
    states?: State[];
    customConfig?: CustomConfig | null;
    attachments?: null;
    launchDateTime?: string | null;
    version?: null;
    endpoint?: null;
    approvals?: null;
    createdDate?: string;
    composeContentEvent?: null;
    writeCopyEvent?: null;
    assetRestorationProgress?: null;
}

export interface Activity {
    id?: number;
    name?: null;
    description?: null | string;
    quantity?: number | null;
    typeId?: number;
    activityBundleId?: null | string;
    activityBundleStatus?: Status | null;
    assignedUserEmail?: null | string;
    states?: State[];
    currentState?: State;
    subActivities?: Activity[] | null;
    isSubActivity?: boolean;
    subActivity?: boolean;
    generationMode?: string | null;
    commentIds?: null | string[];
    createdDate?: string;
    lastModifiedDate?: string;
    assignedByEmail?: null | string;
    instructions?: Instruction[];
    input?: Input | null;
    startWorkBy?: null | string;
    startWorkStatusValue?: string | null;
    teamId?: null | string;
    teamName?: null | string;
    assignedUserName?: null | string;
}

export interface Input {
    attachments?: Attachment[];
    isUploading?: boolean;
}

export interface Attachment {
    id?: string;
    originalName?: string;
    name?: string;
    type?: string;
    contentLength?: number;
    createdBy?: string;
    activityId?: number;
    source?: string;
    createdDate?: string;
    lastModifiedDate?: null;
}

export interface Instruction {
    id?: number;
    label: string;
    values: string[];
    type?: string;
}

export interface CustomConfig {
    version?: string;
    endpoint?: string;
    dueByDate?: string;
    dueByTime?: string;
    publishOnDate?: string;
    publishOnTime?: string;
}

export interface LineItemMetadata {
    dsId?: string | null;
    clipTitle?: string | null;
    clipId?: number | null;
    clip?: Clip | null;
    series?: string | null;
    episode?: null | string;
    clipDSId?: null | string;
    clipSource?: null | string;
    assetInputs?: AssetInput[] | null;
    inOutPoint?: string | null;
    duration?: string | null;
    customClipId?: number | null;
}

export interface AssetInput {
    assetName: string | null;
    assetNumber: string | null;
    assetSource: string | null;
    inOutPoint: string | null;
    clipId: number | null;
}

export interface Clip {
    id?: number;
    materialId?: number;
    barcode?: string;
    dsid?: null | string;
    title?: string;
    sessionTitle?: string;
    sessionType?: SessionType;
    duration?: string;
    enteredDate?: string;
    createdBy?: string;
    createdDate?: string;
    updatedBy?: string;
    updatedDate?: string;
    showId?: number;
    loggerUrl?: string;
}

export enum SessionType {
    Clip = 'Clip',
    Segment = 'Segment',
}

export interface OrderMetadata {
    orderType?: OrderType;
    vmId?: string;
    contentType?: ContentType;
    brand?: string | null;
    series?: null | string;
    movieAndSpecial?: null | string;
    episode?: null | string;
    episodeTitle?: null | string;
    season?: null;
    isFullEpisode?: boolean;
    isNewOrder?: boolean;
    requestType?: null | OrderRequestType;
    orderInstruction?: OrderInstruction;
}

export enum OrderRequestTypes {
    SOCIAL = 'Social Video',
    SAA = 'Site & App Publishing',
    CAPTIONS = 'Captions Only',
    TRANSCRIPTS = 'Transcripts Only',
    STILL_FRAMES = 'Still Frames Only'
}

export type OrderRequestType = 'Social Video' | 'Site & App Publishing' | 'Captions Only' | 'Transcripts Only' | 'Still Frames Only';

export enum ContentTypes {
    BRAND = 'BRAND',
    EPISODE = 'EPISODE',
    SERIES = 'SERIES',
    SPECIAL = 'SPECIAL',
}

export type ContentType = keyof typeof ContentTypes;

export enum OrderTypes {
    COPY = 'COPY',
    GRAPHICS = 'GRAPHICS',
    PRESS = 'PRESS',
    SITE_APP_UPDATES = 'SITE_APP_UPDATES',
    VIDEO = 'VIDEO',
}

export type OrderType = keyof typeof OrderTypes;

export interface UserWatcher {
    id?: number;
    login?: string;
    firstName?: string;
    lastName?: string;
    displayName?: string;
    jobTitle?: null;
    imageUrl?: null;
    primaryWorkLocation?: null;
    workForBrands?: any[];
    count?: null;
}
export interface OrderInstruction {
    siteAndAppPresets?: string | null;
    dropOffLocation?: string | null;
    captions?: string | null;
    captionsBillingGroup?: string | null;
    instructions?: string | null;
    dueDateTime?: string | null;
    publishDateTime?: string | null;
    launchDateTime?: string | null;
    deliveryFormat?: string | null;
    budgetCode?: string | null;
    rollingDueDate?: string | null;
    deliveryLocation?: string | null;
}

export interface OrderAsset {
    customClipId?: number | null;
    inOutPoint?: string | null;
    clipTitle: string | null;
    clipId: number | null;
    dsId: string | null;
    clipDSId: string | null;
    clipSource?: string | null;
    duration?: string | null;
    assetNumber?: string | null;
}
// interface with essential structure for all models for different ordertypes
export interface IOrderModel {
    description: string;
    dueDateTime?: DateTimeObject;
    launchDateTime?: DateTimeObject;
    publishDateTime?: DateTimeObject;

    /**
     * Reference to original lineItems from the order data
     *
     * @type {LineItem[]}
     * @memberof IOrderModel
     */
    lineItems: LineItem[];
    /**
     * Update Class properties from LineItems and instructions
     *
     * @param {BridgeUI.Order} [uiOrder] - the full order object
     * @memberof IOrderModel
     */
    updateProperties(uiOrder?: BridgeUI.Order): void;
    /**
     * Update LineItems from class properties
     *
     * @param {BridgeUI.Order} [uiOrder] - the full order object
     * @returns {LineItem[]} lineItems - array of lineItems
     * @memberof IOrderModel
     */
    updateLineItems(uiOrder?: BridgeUI.Order): LineItem[];

    // TODO: add Validator methods
}
