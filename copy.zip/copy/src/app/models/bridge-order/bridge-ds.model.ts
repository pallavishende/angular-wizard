import { LineItem, OrderMetadata, Milestone, UserWatcher } from './shared.model';

export namespace BridgeDS {
    export class Order {
        id?: number;
        name?: string;
        orderNumber?: string;
        to?: string;
        orderFor?: string | number;
        lineItems?: LineItem[] | null;
        assigneeEmail?: string;
        assignedByEmail?: null | string;
        assigneeName?: string;
        teamId?: null | string;
        teamName?: null | string;
        createdDate?: string;
        creator?: string;
        createdBy?: string;
        createdByUserName?: string;
        metadata?: OrderMetadata;
        milestones?: Milestone[];
        currentMilestone?: Milestone;
        watcherEmails?: string[];
        userWatchers?: UserWatcher[];
        relatedOrders?: any[];
        lastModifiedBy?: null | string;
        lastModifiedDate?: string;
        children?: null | [];
    }
}
