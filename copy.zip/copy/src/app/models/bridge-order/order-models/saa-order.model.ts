import { BridgeUI } from '../bridge-ui.model';
import { Attachment, Activity, LineItem, IOrderModel } from '../shared.model';
import { get } from 'lodash';
import { DateTimeObject } from './date-time.model';

/** Model for Site And App Orders */
export class SiteAndAppOrderModel implements IOrderModel {

    description = '';
    dueDateTime?: DateTimeObject;
    launchDateTime?: DateTimeObject;

    attachments: Attachment[] = [];
    isUploading = false;

    lineItems: LineItem[] = [];
    activity: Activity;
    constructor(lineItems?: LineItem[]) {

        this.activity = {
            instructions: [],
            quantity: 1,
            subActivities: [
                {
                    generationMode: 'AUTOMATIC',
                    typeId: 15,
                    description: 'QA - Site & App Updates'
                }
            ],
            typeId: 14,
            input: {}
        };

        if (lineItems && lineItems.length > 0) {
            this.lineItems = lineItems;
            const activity = get(lineItems, ['0', 'activities', '0'], null);
            if (activity) {
                this.activity = activity;
            }
        } else {
            this.lineItems = [{
                activities: [this.activity]
            }];
        }
    }

    updateProperties() {
        const activity = this.activity;
        const lineItem = this.lineItems[0];

        /** Update due dateTime */
        if (lineItem && lineItem.dueDateTime) {
            this.dueDateTime = new DateTimeObject(lineItem.dueDateTime);
        }

        /** Update launch dateTime */
        if (lineItem && lineItem.launchDateTime) {
            this.launchDateTime = new DateTimeObject(lineItem.launchDateTime);
        }

        if (activity) {
            this.description = activity.description || '';

            if (activity.input) {
                if (activity.input.attachments) {
                    this.attachments = activity.input.attachments || [];
                }
                if (activity.input.isUploading === true) {
                    this.isUploading = true;
                }
            }
        }
    }

    updateLineItems(): LineItem[] {
        const activity = this.activity;
        const lineItem = this.lineItems[0];

        /** Update lineItem */
        if (lineItem) {
            if (this.dueDateTime && this.dueDateTime.iso) {
                lineItem.dueDateTime = this.dueDateTime.iso || null;
            }

            if (this.launchDateTime && this.launchDateTime.iso) {
                lineItem.launchDateTime = this.launchDateTime.iso || null;
            }
        }


        /** Update activity */
        if (activity) {
            activity.instructions = activity.instructions || [];

            if (this.attachments && this.attachments.length > 0) {
                activity.input = {
                    attachments: this.attachments
                };
            } else {
                activity.input = {
                    attachments: []
                };
            }

            if (this.isUploading === true) {
                activity.input.isUploading = true;
            }

            activity.description = this.description;
        }

        return this.lineItems;
    }
}
