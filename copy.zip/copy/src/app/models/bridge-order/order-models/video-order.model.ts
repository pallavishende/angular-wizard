import { Attachment, Activity, LineItem, IOrderModel, OrderRequestType, OrderRequestTypes, OrderInstruction, OrderAsset } from '../shared.model';
import { DateTimeObject } from './date-time.model';
import { BridgeUI } from '../bridge-ui.model';
import { remove, sortBy, get, isEmpty, findIndex, cloneDeep } from 'lodash';
import { AssetInput } from 'app/models/asset-input';
import { isArray } from 'util';
import { ValueProvider } from '@angular/core';

/*

    transcript order: 1114463
    captions order: 1117302
    orderInstruction: {
        siteAndAppPresets: "",
        dropOffLocation: "",
        captions:"",
        captionsBillingGroup:"",
        instructions:"",
        dueDateTime:"",
        publishDateTime:"",
        launchDateTime:"",
        deliveryFormat:"",
        budgetCode:"",
        rollingDueDate:"",
        deliveryLocation:""
    }

*/

abstract class A {
    abstract m(): void;
	otherM() {
		console.log("otherm");
	}
}

interface D  {
    m() : void;
}

class B  {
    m(): void { }
}

class C extends A implements B  {
    m(): void { }
}

const some = new B();
//some.otherM();




export interface VideoAsset extends OrderAsset {
    clipTitle: string | null;
    clipId: number | null;
    dsId: string | null;
    clipDSId: string | null;
    clipSource?: string | null;
    duration?: string | null;
    inOutPoint?: string | null;
    assetNumber?: string | null;
    endpoints?: VideoEndpoint[];
    customClipId?: number | null;
}

export interface VideoEndpoint {
    endpoint: string;
    version?: string;
    instructions: {
        [key: string]: string | boolean | string[];
    };
    metadata?: {
        [key: string]: string | boolean | string[];
    };
}

const blankCreateVideoActivity = {
    'quantity': 1,
    'typeId': 1,
    'subActivities': [],
    'input': {}
};

const blankCreateCaptionActivity = {
    'quantity': 1,
    'typeId': 18,
    'subActivities': [],
    'input': {}
};

const blankCreateTranscriptActivity = {
    'quantity': 1,
    'typeId': 19,
    'subActivities': [],
    'input': {}
};

const blankCreateStillFrameActivity = {
    'quantity': 1,
    'typeId': 20,
    'subActivities': [],
    'input': {}
};

const blankPublishActivity = {
    'description': 'Publish Video',
    'typeId': 13,
    'quantity': 1,
    'generationMode': 'AUTOMATIC'
};

const blankQAActivity = {
    'description': 'QA - Video',
    'typeId': 16,
    'quantity': 1,
    'generationMode': 'AUTOMATIC'
};

/** Model for Video Orders */
export class VideoOrderModel implements IOrderModel {

    description = '';
    dueDateTime?: DateTimeObject;
    publishDateTime?: DateTimeObject;
    launchDateTime?: DateTimeObject;
    attachments: Attachment[] = [];
    isUploading = false;

    assets: VideoAsset[] = [];

    lineItems: LineItem[] = [];

    requestType?: OrderRequestType;

    orderInstruction: OrderInstruction = {};

    constructor(lineItems?: LineItem[], requestType?: OrderRequestType | null) {
        this.lineItems = lineItems || [];
        if (requestType) {
            this.requestType = requestType;
        }
    }

    supportsEndpoints(): boolean {
        return !isEmpty(this.requestType) && (this.requestType === OrderRequestTypes.SOCIAL || this.requestType === OrderRequestTypes.SAA);
    }

    addAsset(asset: OrderAsset) {
        if (this.requestType && (this.requestType === OrderRequestTypes.SOCIAL || this.requestType === OrderRequestTypes.SAA)) {
            (asset as VideoAsset).endpoints = [];
        }
        if (!asset.clipId && !asset.customClipId) {
            // generate customClipId in case clipId is not available
            asset.customClipId = Date.now();
        }
        this.assets.push(asset);
    }

    removeAsset(assetIndex: number) {
        if (this.assets[assetIndex]) {
            this.assets.splice(assetIndex, 1);
        }
    }

    addEndpointToAsset(endpoint: string, asset: VideoAsset) {
        if (!asset.endpoints) {
            asset.endpoints = [];
        }
        asset.endpoints.push({
            endpoint: endpoint,
            instructions: {}
        });
    }

    removeEndpointfromAsset(endpoint: string, asset: VideoAsset) {
        if (asset.endpoints) {
            remove(asset.endpoints, (videoEndpoint) => {
                return videoEndpoint.endpoint === endpoint;
            });
        }
    }

    checkEndpointInAsset(endpoint: string, asset: VideoAsset) {
        if (asset.endpoints) {
            return findIndex(asset.endpoints, { endpoint: endpoint }) >= 0;
        }
        return false;
    }

    updateProperties(uiOrder: BridgeUI.Order) {

        let isAttachmentUpdated = false;
        // sort by assetNumber
        this.lineItems = sortBy(this.lineItems, [function (item) {
            const assetNumber = get(item, 'metadata.0.assetInputs.0.assetNumber', undefined);
            return assetNumber || '';
        }]);

        if (uiOrder.metadata && uiOrder.metadata.orderInstruction) {
            this.orderInstruction = {
                ...uiOrder.metadata.orderInstruction
            };
            if (this.orderInstruction.dueDateTime) {
                this.dueDateTime = new DateTimeObject(this.orderInstruction.dueDateTime);
            }
            if (this.orderInstruction.publishDateTime) {
                this.publishDateTime = new DateTimeObject(this.orderInstruction.publishDateTime);
            }
            if (this.orderInstruction.launchDateTime) {
                this.launchDateTime = new DateTimeObject(this.orderInstruction.launchDateTime);
            }
        }

        for (const lineItem of this.lineItems) {

            let uniqueAsset: VideoAsset | undefined;
            let uniqueEndpoint: VideoEndpoint | undefined;

            if (lineItem && lineItem.dueDateTime && !this.dueDateTime) {
                this.dueDateTime = new DateTimeObject(lineItem.dueDateTime);
            }

            if (lineItem && lineItem.publishDateTime && !this.publishDateTime) {
                this.publishDateTime = new DateTimeObject(lineItem.publishDateTime);
            }

            if (lineItem && lineItem.launchDateTime && !this.launchDateTime) {
                this.launchDateTime = new DateTimeObject(lineItem.launchDateTime);
            }

            if (lineItem.metadata && lineItem.metadata.length > 0) {
                const assetInfo = lineItem.metadata[0];
                const altAssetInfo: AssetInput = lineItem.metadata[0].assetInputs ? lineItem.metadata[0].assetInputs[0] : null;
                uniqueAsset = this.assets.find(asset => {

                    if (asset.customClipId && assetInfo.customClipId) {
                        return asset.customClipId === assetInfo.customClipId;
                    }
                    if (asset.clipId) {
                        return asset.clipId === assetInfo.clipId;
                    }
                    if (asset.clipTitle) {
                        return asset.clipTitle === assetInfo.clipTitle;
                    }
                    return false;
                });

                if (!uniqueAsset) {
                    uniqueAsset = {
                        customClipId: assetInfo.customClipId || null,
                        inOutPoint: assetInfo.inOutPoint || altAssetInfo ? altAssetInfo.inOutPoint : null,
                        clipTitle: assetInfo.clipTitle || null,
                        clipId: assetInfo.clipId || null,
                        dsId: assetInfo.dsId || null,
                        clipDSId: assetInfo.clipDSId || null,
                        clipSource: assetInfo.clipSource || altAssetInfo ? altAssetInfo.assetSource : null,
                        duration: assetInfo.duration || null,
                        assetNumber: altAssetInfo ? altAssetInfo.assetNumber : null
                    };
                    if (!assetInfo.clipId && !assetInfo.customClipId) {
                        // generate customClipId in case clipId is not available
                        uniqueAsset.customClipId = Date.now();
                    }
                    this.assets.push(uniqueAsset);
                }

                if (this.supportsEndpoints() && lineItem.customConfig) {
                    const customConfig = lineItem.customConfig;
                    if (!uniqueAsset.endpoints) {
                        uniqueAsset.endpoints = [];
                    }

                    uniqueEndpoint = uniqueAsset.endpoints.find(videoEndpoint => {
                        const isVersionMatching = (customConfig.version) ? customConfig.version === videoEndpoint.version : true;
                        return videoEndpoint.endpoint === customConfig.endpoint && isVersionMatching;
                    });

                    if (!uniqueEndpoint) {
                        uniqueEndpoint = {
                            endpoint: customConfig.endpoint || '',
                            version: customConfig.version || '',
                            instructions: {}
                        };
                        uniqueAsset.endpoints.push(uniqueEndpoint);
                    }
                }

            }

            if (lineItem.activities && lineItem.activities.length > 0) {
                const createActivity = this.getCreateActivity(lineItem.activities);
                if (createActivity) {
                    this.orderInstruction.instructions = createActivity.description || '';
                    this.description = createActivity.description || '';

                    if (!isAttachmentUpdated && createActivity.input) {
                        if (createActivity.input.attachments) {
                            this.attachments = createActivity.input.attachments || [];
                            isAttachmentUpdated = true;
                        }
                        if (createActivity.input.isUploading === true) {
                            this.isUploading = true;
                        }
                    }

                    // look for instructions if requestType supports Endpoints
                    if (this.supportsEndpoints() && uniqueEndpoint && createActivity.instructions) {
                        uniqueEndpoint.instructions = {};
                        uniqueEndpoint.metadata = {};
                        for (const instruction of createActivity.instructions) {
                            let val;
                            if (isArray(instruction.values) && instruction.values.length > 1) {
                                val = instruction.values;
                            } else {
                                val = instruction.values[0] === 'true' ? true : instruction.values[0];
                            }

                            if (instruction.type === 'metadata') {
                                uniqueEndpoint.metadata[instruction.label] = val;
                            } else {
                                uniqueEndpoint.instructions[instruction.label] = val;
                            }
                        }
                    }
                }
            }
        }
    }

    updateLineItems(uiOrder: BridgeUI.Order): LineItem[] {
        const newLineItems: LineItem[] = [];

        if (!isEmpty(this.description)) {
            this.orderInstruction.instructions = this.description;
        }

        if (this.dueDateTime && this.dueDateTime.isValid) {
            this.orderInstruction.dueDateTime = this.dueDateTime.iso;
        }

        if (this.launchDateTime && this.launchDateTime.isValid) {
            this.orderInstruction.launchDateTime = this.launchDateTime.iso;
        }

        if (this.publishDateTime && this.publishDateTime.isValid) {
            this.orderInstruction.publishDateTime = this.publishDateTime.iso;
        }

        // update orderInstruction at order level
        if (uiOrder.metadata && !isEmpty(this.orderInstruction)) {
            uiOrder.metadata.orderInstruction = {
                ...this.orderInstruction
            };
        }

        if (this.assets.length > 0) {
            for (let assetIndex = 0; assetIndex < this.assets.length; assetIndex++) {
                const asset = this.assets[assetIndex];

                if (!asset.clipId && !asset.customClipId) {
                    // generate customClipId in case clipId is not available
                    asset.customClipId = Date.now();
                }

                const lineItemMetadata = [{
                    customClipId: asset.customClipId,
                    clipTitle: asset.clipTitle,
                    clipId: asset.clipId,
                    dsId: asset.dsId,
                    clipDSId: asset.clipDSId,
                    clipSource: asset.clipSource,
                    inOutPoint: asset.inOutPoint,
                    duration: asset.duration !== null ? asset.duration : '',
                    assetInputs: [
                        {
                            assetName: asset.clipTitle,
                            assetNumber: `Asset ${assetIndex + 1}`,
                            assetSource: asset.clipSource ? asset.clipSource : (asset.clipDSId !== null ? asset.clipDSId : '' || asset.dsId !== null ? asset.dsId : ''),
                            inOutPoint: asset.inOutPoint || null,
                            clipId: asset.clipId
                        }
                    ]
                }];
                if (this.supportsEndpoints()) {
                    if (!asset.endpoints || asset.endpoints.length === 0) {
                        this.addEndpointToAsset('', asset);
                    }
                    for (const endpoint of asset.endpoints) {
                        const lineItemCustomConfig = {
                            endpoint: endpoint.endpoint,
                            version: endpoint.version || endpoint.endpoint || '',
                            dueByDate: (this.dueDateTime && this.dueDateTime.date) ? this.dueDateTime.date : '',
                            dueByTime:  (this.dueDateTime && this.dueDateTime.time) ? this.dueDateTime.time : '',
                            publishOnDate: (this.publishDateTime && this.publishDateTime.date) ? this.publishDateTime.date : '',
                            publishOnTime: (this.publishDateTime && this.publishDateTime.time) ? this.publishDateTime.time : '',
                        };
                        let lineItemForAssetAndEndpoint = this.getLineItemForAssetAndEndpoint(this.lineItems, asset, endpoint);
                        if (lineItemForAssetAndEndpoint) {
                            lineItemForAssetAndEndpoint.metadata = lineItemMetadata;
                            lineItemForAssetAndEndpoint.customConfig = lineItemCustomConfig;
                        } else {
                            const activities = this.getBlankActivities();
                            lineItemForAssetAndEndpoint = {
                                activities: activities,
                                metadata: lineItemMetadata,
                                customConfig: lineItemCustomConfig
                            };
                        }
                        newLineItems.push(lineItemForAssetAndEndpoint);
                    }
                } else {
                    let lineItemForAsset = this.getLineItemForAsset(this.lineItems, asset);
                    if (lineItemForAsset) {
                        lineItemForAsset.metadata = lineItemMetadata;
                    } else {
                        lineItemForAsset = {
                            metadata: lineItemMetadata
                        };
                    }
                    if (!lineItemForAsset.activities || lineItemForAsset.activities.length === 0) {
                        const activities = this.getBlankActivities();
                        lineItemForAsset.activities = activities;
                    }
                    newLineItems.push(lineItemForAsset);
                }
            }

            // loop through line items and update instructions
            for (const lineItem of newLineItems) {
                if (this.dueDateTime && this.dueDateTime.isValid) {
                    lineItem.dueDateTime = this.dueDateTime.iso;
                }

                if (this.launchDateTime && this.launchDateTime.isValid) {
                    lineItem.launchDateTime = this.launchDateTime.iso;
                }

                if (this.publishDateTime && this.publishDateTime.isValid) {
                    lineItem.publishDateTime = this.publishDateTime.iso;
                }

                if (lineItem.activities) {
                    const createActivity = this.getCreateActivity(lineItem.activities);
                    if (createActivity) {
                        createActivity.description = this.description || '';
                        if (!createActivity.instructions) {
                            createActivity.instructions = [];
                        }
                        if (this.attachments && this.attachments.length > 0) {
                            createActivity.input = {
                                attachments: this.attachments
                            };
                        } else {
                            createActivity.input = {
                                attachments: []
                            };
                        }

                        if (this.isUploading === true && createActivity.input) {
                            createActivity.input.isUploading = true;
                        }

                        const endpointForLineItem = this.getEndpointForLineItem(lineItem);
                        if (endpointForLineItem) {
                            const endpointInstructionValidKeys: string[] = [];

                            for (const key in endpointForLineItem.instructions) {
                                if (endpointForLineItem.instructions.hasOwnProperty(key) && endpointForLineItem.instructions[key] !== false) {
                                    endpointInstructionValidKeys.push(key);
                                }
                            }

                            // remove changed instructions that are falsey are not there anymore
                            remove(createActivity.instructions, (instruction) => {
                                return instruction.type !== 'metadata' && !endpointInstructionValidKeys.includes(instruction.label);
                            });

                            for (const endpointInstructionKey of endpointInstructionValidKeys) {
                                const val = endpointForLineItem.instructions[endpointInstructionKey];
                                let endpointInstructionObject = createActivity.instructions.find((instruction) => instruction.label === endpointInstructionKey);
                                if (!endpointInstructionObject) {
                                    endpointInstructionObject = {
                                        label: endpointInstructionKey,
                                        values: [
                                        ]
                                    };
                                    createActivity.instructions.push(endpointInstructionObject);
                                }
                                endpointInstructionObject.values = isArray(val) ? val as string[] : [val.toString()];
                            }

                            if (endpointForLineItem.metadata) {
                                const endpointMetadataValidKeys: string[] = [];

                                for (const key in endpointForLineItem.metadata) {
                                    if (endpointForLineItem.metadata.hasOwnProperty(key) && endpointForLineItem.metadata[key] !== false) {
                                        endpointMetadataValidKeys.push(key);
                                    }
                                }

                                // remove changed instructions that are falsey are not there anymore
                                remove(createActivity.instructions, (instruction) => {
                                    return instruction.type === 'metadata' && !endpointMetadataValidKeys.includes(instruction.label);
                                });

                                for (const endpointMetadataKey of endpointMetadataValidKeys) {
                                    const val = endpointForLineItem.metadata[endpointMetadataKey];
                                    let endpointMetadataObject = createActivity.instructions.find((instruction) => instruction.type === 'metadata' && instruction.label === endpointMetadataKey);
                                    if (!endpointMetadataObject) {
                                        endpointMetadataObject = {
                                            label: endpointMetadataKey,
                                            values: [
                                            ],
                                            type: 'metadata'
                                        };
                                        createActivity.instructions.push(endpointMetadataObject);
                                    }
                                    endpointMetadataObject.values = isArray(val) ? val as string[] : [val.toString()];
                                }
                            }
                        }
                    }
                }
            }
        }
        return newLineItems;
    }

    getFirstCreateActivity(): Activity {
        if (this.lineItems && this.lineItems.length > 0) {
            const activities = this.lineItems[0].activities;
            return this.getCreateActivity(activities);
        }
        return null;
    }

    private getCreateActivity(activities: Activity[]): Activity {
        return activities.find(activity => {
            return activity.typeId === 1 || activity.typeId === 18 || activity.typeId === 19 || activity.typeId === 20;
        });
    }
    private getBlankActivities(): Activity[] {
        const activities: Activity[] = [];
        switch (this.requestType) {
            case OrderRequestTypes.TRANSCRIPTS:
                activities.push(
                    blankCreateTranscriptActivity
                );
                break;
            case OrderRequestTypes.CAPTIONS:
                activities.push(
                    blankCreateCaptionActivity
                );
                break;
            case OrderRequestTypes.STILL_FRAMES:
                activities.push(
                    blankCreateStillFrameActivity
                );
                break;
            case OrderRequestTypes.SOCIAL:
                activities.push(
                    blankCreateVideoActivity,
                    blankPublishActivity
                );
                break;
            case OrderRequestTypes.SAA:
                activities.push(
                    blankCreateVideoActivity,
                    blankPublishActivity,
                    blankQAActivity
                );
                break;
            default:
                break;
        }
        return activities;
    }
    private getLineItemForAsset(lineItems: LineItem[], asset: VideoAsset) {
        const lineItemForAsset = lineItems.find(item => {
            const assetTitle = get(item, 'metadata.0.clipTitle', undefined);
            const assetClipId = get(item, 'metadata.0.clipId', undefined);
            const assetCustomClipId = get(item, 'metadata.0.customClipId', undefined);

            if (assetClipId && asset.clipId) {
                return asset.clipId === assetClipId;
            }
            if (assetCustomClipId && asset.customClipId) {
                return asset.customClipId === assetCustomClipId;
            }
            if (assetTitle && asset.clipTitle) {
                return asset.clipTitle === assetTitle;
            }
            return false;
        });
        return lineItemForAsset ? (lineItemForAsset) : null;
    }

    private getLineItemForAssetAndEndpoint(lineItems: LineItem[], asset: VideoAsset, endpoint: VideoEndpoint) {
        const lineItemForAssetAndEndpoint = lineItems.find(item => {
            let isAssetMatching = false;
            let isEndpointMatching = false;
            const assetTitle = get(item, 'metadata.0.clipTitle', undefined);
            const assetCustomClipId = get(item, 'metadata.0.customClipId', undefined);
            const assetClipId = get(item, 'metadata.0.clipId', undefined);

            if (assetCustomClipId && asset.customClipId) {
                isAssetMatching = asset.customClipId === assetCustomClipId;
            } else if (assetClipId) {
                isAssetMatching = asset.clipId === assetClipId;
            } else if (assetTitle) {
                isAssetMatching = asset.clipTitle === assetTitle;
            }

            if (isAssetMatching) {
                const endpointVersion = get(item, 'customConfig.version', undefined);
                const endpointName = get(item, 'customConfig.endpoint', undefined);
                if (endpointVersion && endpointName) {
                    isEndpointMatching = (endpoint.version === endpointVersion) && (endpoint.endpoint && endpointName);
                } else if (endpointName) {
                    isEndpointMatching = endpoint.endpoint && endpointName;
                }
            }

            return isAssetMatching && isEndpointMatching;
        });
        return lineItemForAssetAndEndpoint;
    }

    getEndpointForLineItem(lineItem: LineItem) {
        const assetForLineItem = this.assets.find(asset => {
            let isAssetMatching = false;
            const assetTitle = get(lineItem, 'metadata.0.clipTitle', undefined);
            const assetCustomClipId = get(lineItem, 'metadata.0.customClipId', undefined);
            const assetClipId = get(lineItem, 'metadata.0.clipId', undefined);

            if (assetCustomClipId && asset.customClipId) {
                isAssetMatching = asset.customClipId === assetCustomClipId;
            } else if (assetClipId) {
                isAssetMatching = asset.clipId === assetClipId;
            } else if (assetTitle) {
                isAssetMatching = asset.clipTitle === assetTitle;
            }

            return isAssetMatching;
        });

        if (assetForLineItem && assetForLineItem.endpoints) {
            const endpointForLineItem = assetForLineItem.endpoints.find(videoEndpoint => {
                let isEndpointMatching = false;
                const endpointVersion = get(lineItem, 'customConfig.version', undefined);
                const endpointName = get(lineItem, 'customConfig.endpoint', undefined);
                if (endpointVersion && videoEndpoint) {
                    isEndpointMatching = (videoEndpoint.version === endpointVersion) && (videoEndpoint.endpoint && endpointName);
                } else if (endpointName) {
                    isEndpointMatching = videoEndpoint.endpoint && endpointName;
                }
                return isEndpointMatching;
            });

            return endpointForLineItem || null;
        }

        return null;
    }

}
