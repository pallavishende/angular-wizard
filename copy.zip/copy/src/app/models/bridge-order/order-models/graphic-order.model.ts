import { Attachment, Activity, LineItem, IOrderModel, Instruction } from '../shared.model';
import { get, isEmpty, remove, isArray } from 'lodash';
import { DateTimeObject } from './date-time.model';

enum GraphicPlatforms {
    BRANDWEBSITE = 'BRANDWEBSITE',
    BRANDWEBSITECC = 'BRANDWEBSITECC',
    BRANDWEBSITECMT = 'BRANDWEBSITECMT',
    BRANDWEBSITELOGO = 'BRANDWEBSITELOGO',
    BRANDWEBSITEMTV = 'BRANDWEBSITEMTV',
    BRANDWEBSITEPN = 'BRANDWEBSITEPN',
    CUSTOM = 'CUSTOM',
    PLAYPLEX = 'PLAYPLEX',
    PLAYPLEXNOATV = 'PLAYPLEXNOATV',
    SPONSORSHIP = 'SPONSORSHIP',
    WEB20 = 'WEB20',
    WEB20EXTENDED = 'WEB20EXTENDED',
    WEBPLEX = 'WEBPLEX',
    WEBPLEXEXTENDED = 'WEBPLEXEXTENDED'
}

export type GraphicPlatformTypes = keyof typeof GraphicPlatforms;

/** Model for Graphic Orders */
export class GraphicOrderModel implements IOrderModel {

    description = '';
    dueDateTime?: DateTimeObject;
    launchDateTime?: DateTimeObject;

    // instructions
    brand = '';
    noOfDelivarables = '';
    assetLocation = '';
    fileDropOffLocation = '';
    dueDateReason = '';

    requestType: 'VMN' | 'GENERAL' | null = null;

    attachments: Attachment[] = [];
    isUploading = false;

    private propertiesMap: (keyof GraphicOrderModel)[] = ['brand', 'noOfDelivarables', 'assetLocation', 'fileDropOffLocation', 'dueDateReason', 'requestType', 'platformList'];

    platformList: GraphicPlatformTypes[] = [];

    platformInstructions: {
        [key in GraphicPlatformTypes]?: {
            [key: string]: any
        }
    } = {};

    lineItems: LineItem[] = [];
    activity: Activity;

    constructor(lineItems?: LineItem[]) {

        this.activity = {
            instructions: [],
            quantity: 1,
            subActivities: [
                {
                    generationMode: 'AUTOMATIC',
                    typeId: 11,
                    description: 'Approve Graphics'
                }
            ],
            typeId: 5,
            input: {}
        };

        if (lineItems && lineItems.length > 0) {
            this.lineItems = lineItems;
            const activity: Activity = get(lineItems, ['0', 'activities', '0'], null);
            if (activity) {
                this.activity = activity;
            }
        } else {
            this.lineItems = [{
                activities: [this.activity]
            }];
        }
    }

    addPlatform(platformType: GraphicPlatformTypes) {
        if (!this.platformList.includes(platformType)) {
            this.platformList.push(platformType);
        }
        if (!this.platformInstructions[platformType]) {
            this.platformInstructions[platformType] = {};
        }
    }

    removePlatform(platformType: GraphicPlatformTypes) {
        if (this.platformList.includes(platformType)) {
            remove(this.platformList, (pType) => pType === platformType);
        }
        if (this.platformInstructions[platformType]) {
            delete this.platformInstructions[platformType];
        }
    }

    updateProperties() {
        const activity = this.activity;
        const lineItem = this.lineItems[0];

        /** Update dateTime */
        if (lineItem && lineItem.dueDateTime) {
            this.dueDateTime = new DateTimeObject(lineItem.dueDateTime);
        }

        if (lineItem && lineItem.launchDateTime) {
            this.launchDateTime = new DateTimeObject(lineItem.launchDateTime);
        }

        if (activity) {
            if (activity.description) {
                this.description = activity.description;
            }

            if (activity.input) {
                if (activity.input.attachments) {
                    this.attachments = activity.input.attachments || [];
                }
                if (activity.input.isUploading === true) {
                    this.isUploading = true;
                }
            }

            this.propertiesMap.forEach(prop => {
                this.updatePropertyFromInstruction(activity.instructions, prop);
            });

            for (const platformType of this.platformList) {
                this.updatePlatformsFromInstruction(activity.instructions, platformType);
            }
        }
    }
    updateLineItems(): LineItem[] {
        const activity = this.activity;
        const lineItem = this.lineItems[0];

        /** Update lineItem */
        if (lineItem && this.dueDateTime && this.dueDateTime.iso) {
            lineItem.dueDateTime = this.dueDateTime.iso || null;
        }

        if (lineItem && this.launchDateTime && this.launchDateTime.iso) {
            lineItem.launchDateTime = this.launchDateTime.iso || null;
        }

        /** Update activity */
        if (activity) {
            if (!activity.instructions) {
                activity.instructions = [];
            }

            if (this.attachments && this.attachments.length > 0) {
                activity.input = {
                    attachments: this.attachments
                };
            } else {
                activity.input = {
                    attachments: []
                };
            }
            if (this.isUploading === true) {
                activity.input.isUploading = true;
            }

            this.propertiesMap.forEach(prop => {
                this.updateInstructionByProperty(activity.instructions, prop);
            });

            // remove platform instructions for removed platforms
            remove(activity.instructions, (instruction) => {
                if (!isEmpty(instruction.type)) {
                    return !this.platformList.includes(instruction.type as any);
                }
                return false;
            });

            for (const platformType of this.platformList) {
                if (this.platformInstructions && this.platformInstructions[platformType]) {
                    const platformInstruction = this.platformInstructions[platformType];
                    if (platformInstruction) {
                        for (const key in platformInstruction) {
                            if (platformInstruction.hasOwnProperty(key)) {
                                this.updateInstructionByProperty(activity.instructions, key, platformType);
                            }
                        }
                    }
                }
            }

            activity.description = this.description;
        }

        return this.lineItems;
    }

    /** Helper to create instructions and platform subinstructions */
    private updateInstructionByProperty(instructions: Instruction[] = [], propertyName: string, platformType?: GraphicPlatformTypes): void {
        if (!platformType && this.hasOwnProperty(propertyName)) {
            const prop = propertyName as keyof GraphicOrderModel;
            if (!isEmpty(this[prop])) {
                const val = this[prop] as any;
                let instructionObject = instructions.find((instruction) => instruction.label === prop);
                if (!instructionObject) {
                    instructionObject = {
                        label: prop,
                        values: [],
                        type: ''
                    };
                    instructions.push(instructionObject);
                }
                instructionObject.values = isArray(val) ? val : [val];
            }
        } else if (platformType) {
            const propVal = get(this.platformInstructions, [platformType, propertyName]);
            if (propVal) {
                let platformInstructionObject = instructions.find((instruction) => instruction.label === propertyName && instruction.type === platformType);
                if (!platformInstructionObject) {
                    platformInstructionObject = {
                        label: propertyName,
                        values: [],
                        type: platformType
                    };
                    instructions.push(platformInstructionObject);
                }
                platformInstructionObject.values = [propVal.toString()];
            }
        }

    }

    /** Helper to parse instructions */
    private updatePropertyFromInstruction(instructions: Instruction[] = [], propertyName: keyof GraphicOrderModel) {
        const instruction = instructions.find((_instruction) => _instruction.label === propertyName);
        if (instruction && instruction.values) {
            this[propertyName] = instruction.values.length > 1 ? instruction.values : instruction.values[0] as any;
        }
    }

    /** Helper to parse platform subinstructions */
    private updatePlatformsFromInstruction(instructions: Instruction[] = [], platformType: GraphicPlatformTypes) {
        const platformObject: {
            [key: string]: string
        } = {};
        const platformInstructions = instructions.filter((instruction) => instruction.type === platformType);
        for (const platformInstruction of platformInstructions) {
            platformObject[platformInstruction.label] = platformInstruction.values[0] as any;
        }
        this.platformInstructions[platformType] = platformObject;
    }
}
