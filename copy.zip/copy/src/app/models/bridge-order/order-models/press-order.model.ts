import { BridgeUI } from '../bridge-ui.model';
import { Attachment, Activity, LineItem, IOrderModel, OrderAsset } from '../shared.model';
import { get, remove, isEmpty, sortBy } from 'lodash';
import { DateTimeObject } from './date-time.model';


export interface PressAsset extends OrderAsset {
    inOutPoint: string | null;
    clipTitle: string | null;
    clipId: number | null;
    dsId: string | null;
    clipDSId: string | null;
    clipSource: string | null;
    customClipId?: number | null;
}

export enum PressRequestType {
    forEdit = 'forEdit',
    forYourConsideration = 'forYourConsideration',
    other = 'other',
    screener = 'screener',
    screeningRoom = 'screeningRoom',
    talentAppearance = 'talentAppearance',
    viewingLink = 'viewingLink'
}

// TODO: Can Review Information be generated from this model?
/** Model for Press Orders */
export class PressOrderModel implements IOrderModel {

    description = '';
    dueDateTime?: DateTimeObject;
    attachments: Attachment[] = [];
    isUploading = false;

    _requestType: PressRequestType | null = null;

    assets: PressAsset[] = [];

    activities: Activity[] = [];

    requestInstructions: {
        [key: string]: string | boolean
    } = {};

    lineItems: LineItem[] = [];

    private blankActivity = {
        'quantity': 1,
        'typeId': 17,
        'subActivities': [],
        'input': {}
    };

    constructor(lineItems?: LineItem[]) {
        this.lineItems = lineItems || [];
    }

    get requestType() {
        return this._requestType;
    }

    set requestType(requestType: PressRequestType | null) {
        this.setRequestType(requestType);
    }

    addAsset(asset: OrderAsset) {
        if (!asset.clipId && !asset.customClipId) {
            // generate customClipId in case clipId is not available
            asset.customClipId = Date.now();
        }
        this.assets.push(asset as PressAsset);
    }

    removeAsset(assetIndex: number) {
        if (this.assets[assetIndex]) {
            this.assets.splice(assetIndex, 1);
        }
    }

    // TODO:  can this be a private method or it can be useful?
    setRequestType(requestType: PressRequestType | null) {
        if (this._requestType !== requestType) {
            this._requestType = requestType;
            this.requestInstructions = {};
        }
    }

    updateProperties() {
        let isRequestTypeUpdated = false;
        let isAttachmentUpdated = false;

        // sort by assetNumber
        this.lineItems = sortBy(this.lineItems, [function (item) {
            const assetNumber = get(item, 'metadata.0.assetInputs.0.assetNumber', undefined);
            return assetNumber || '';
        }]);

        for (const lineItem of this.lineItems) {

            if (lineItem && lineItem.dueDateTime && !this.dueDateTime) {
                this.dueDateTime = new DateTimeObject(lineItem.dueDateTime);
            }

            if (lineItem.metadata && lineItem.metadata.length > 0 && lineItem.metadata[0].assetInputs) {
                const assetInput = lineItem.metadata[0].assetInputs[0];
                let customClipId = lineItem.metadata[0].customClipId || null;
                if (!assetInput.clipId && !customClipId) {
                    // generate customClipId in case clipId is not available
                    customClipId = Date.now();
                }
                this.assets.push({
                    customClipId: customClipId || null,
                    inOutPoint: assetInput.inOutPoint || null,
                    clipTitle: assetInput.assetName || null,
                    clipId: assetInput.clipId || null,
                    dsId: lineItem.metadata[0].dsId || null,
                    clipDSId: lineItem.metadata[0].clipDSId || null,
                    clipSource: assetInput.assetSource,
                    assetNumber: assetInput.assetNumber || null
                });
            }

            if (lineItem.activities) {
                const activity = lineItem.activities[0];
                this.description = activity.description || '';

                if (!isAttachmentUpdated && activity.input) {
                    if (activity.input.attachments) {
                        this.attachments = activity.input.attachments || [];
                        isAttachmentUpdated = true;
                    }
                    if (activity.input.isUploading === true) {
                        this.isUploading = true;
                    }
                }

                if (!isRequestTypeUpdated) {
                    this.requestInstructions = {};

                    if (activity.instructions) {
                        const requestTypeInstruction = activity.instructions.find(inst => inst.label === 'requestType');
                        this.requestType = requestTypeInstruction ? requestTypeInstruction.values[0] as PressRequestType : null;
                        if (this.requestType) {
                            for (const instruction of activity.instructions) {
                                if (instruction.type && instruction.type === this.requestType) {
                                    const val = instruction.values[0] === 'true' ? true : instruction.values[0];
                                    this.requestInstructions[instruction.label] = val;
                                }
                            }
                        }
                    }
                    // so we dont have to set the requestType again for every lineItem
                    isRequestTypeUpdated = true;
                }
            }
        }
    }
    updateLineItems(): LineItem[] {
        const newLineItems: LineItem[] = [];

        const requestInstructionValidKeys: string[] = [];

        for (const key in this.requestInstructions) {
            if (this.requestInstructions.hasOwnProperty(key) && this.requestInstructions[key] !== false) {
                requestInstructionValidKeys.push(key);
            }
        }

        if (this.assets.length > 0) {
            for (let assetIndex = 0; assetIndex < this.assets.length; assetIndex++) {
                const asset = this.assets[assetIndex];
                if (!asset.clipId && !asset.customClipId) {
                    // generate customClipId in case clipId is not available
                    asset.customClipId = Date.now();
                }
                const lineItemMetadata = [{
                    customClipId: asset.customClipId || null,
                    clipTitle: null,
                    clipId: null,
                    dsId: asset.dsId,
                    clipDSId: asset.clipDSId,
                    assetInputs: [
                        {
                            assetName: asset.clipTitle,
                            assetNumber: `Asset ${assetIndex + 1}`,
                            assetSource: asset.clipSource ? asset.clipSource : (asset.clipDSId !== null ? asset.clipDSId : '' || asset.dsId !== null ? asset.dsId : ''),
                            inOutPoint: asset.inOutPoint || null,
                            clipId: asset.clipId
                        }
                    ]
                }];
                let lineItemForAsset = this.lineItems.find(item => {
                    const assetNumber = get(item, 'metadata.0.assetInputs.0.assetNumber', undefined);
                    const assetCustomClipId = get(item, 'metadata.0.customClipId', undefined);
                    const assetClipId = get(item, 'metadata.0.assetInputs.0.clipId', undefined);

                    if (assetCustomClipId) {
                        return asset.customClipId === assetCustomClipId;
                    }
                    if (assetClipId) {
                        return asset.clipId === assetClipId;
                    }
                    if (assetNumber) {
                        return assetNumber === `Asset ${assetIndex + 1}`;
                    }
                    return false;
                });
                if (lineItemForAsset) {
                    lineItemForAsset.metadata = lineItemMetadata;
                } else {
                    lineItemForAsset = {
                        metadata: lineItemMetadata
                    };
                }
                if (!lineItemForAsset.activities || lineItemForAsset.activities.length === 0) {
                    lineItemForAsset.activities = [this.blankActivity];
                }
                newLineItems.push(lineItemForAsset);
            }
            for (const lineItem of newLineItems) {

                lineItem.dueDateTime = this.dueDateTime && this.dueDateTime.isValid ? this.dueDateTime.iso : null;

                if (lineItem.activities) {

                    const activity = lineItem.activities[0];
                    activity.description = this.description;
                    if (!activity.instructions) {
                        activity.instructions = [];
                    }

                    if (this.attachments && this.attachments.length > 0) {
                        activity.input = {
                            attachments: this.attachments
                        };
                    } else {
                        activity.input = {
                            attachments: []
                        };
                    }

                    if (this.isUploading === true && activity.input) {
                        activity.input.isUploading = true;
                    }

                    if (this.requestType) {
                        let requestTypeInstruction = activity.instructions.find((instruction) => instruction.label === 'requestType');

                        // remove old requestType specific instructions if requestType is changed
                        if (requestTypeInstruction && requestTypeInstruction.values[0] !== this.requestType) {
                            const oldRequestType = requestTypeInstruction.values[0];
                            remove(activity.instructions, (instruction) => {
                                return instruction.type === oldRequestType;
                            });
                        }

                        if (!requestTypeInstruction) {
                            requestTypeInstruction = {
                                label: 'requestType',
                                values: [],
                                type: ''
                            };
                            activity.instructions.push(requestTypeInstruction);
                        }
                        requestTypeInstruction.values = [this.requestType];

                        // remove requestType instructions that no longer exist/removed in the model
                        remove(activity.instructions, (instruction) => {
                            return instruction.type === this.requestType && !requestInstructionValidKeys.includes(instruction.label);
                        });

                        for (const requestInstructionKey of requestInstructionValidKeys) {
                            const val = this.requestInstructions[requestInstructionKey];
                            let requestInstructionObject = activity.instructions.find((instruction) => instruction.label === requestInstructionKey && instruction.type === this.requestType);
                            if (!requestInstructionObject) {
                                requestInstructionObject = {
                                    label: requestInstructionKey,
                                    values: [
                                    ],
                                    type: this.requestType
                                };
                                activity.instructions.push(requestInstructionObject);
                            }
                            requestInstructionObject.values = [val.toString()];
                        }
                    }
                }
            }
        }

        this.lineItems = newLineItems;

        return this.lineItems;
    }
}
