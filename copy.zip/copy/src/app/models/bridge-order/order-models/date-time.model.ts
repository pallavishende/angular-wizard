import * as moment from 'moment/moment';

export class DateTimeObject {

    private _date = '';
    private _time = '';
    private _isValid = false;
    private _dateTime: moment.Moment;

    constructor(iso: string = '') {

        this._dateTime = moment();

        if (iso === '') {
            this._date = '';
            this._time = '12:00 PM';
        } else {
            if (moment(iso).isValid()) {
                this._isValid = true;
                this._dateTime = moment(iso);
                this._date = this._dateTime.format('YYYY-MM-DD');
                this._time = this._dateTime.format('hh:mm A');
            }
        }
    }

    private update() {
        if (this.isValidDate(this._date) && this.isValidTime(this._time)) {
            this._isValid = true;
            const date = new Date(`${this._date} ${this._time}`);
            this._dateTime = moment.utc(date);
        } else {
            this._isValid = false;
        }
    }

    get iso(): string {
        return this._dateTime.toISOString();
    }

    get date(): string {
        return this._date;
    }

    get time(): string {
        return this._time;
    }

    get isValid(): boolean {
        return this._isValid;
    }

    get momentDate(): moment.Moment {
        return this._dateTime;
    }

    set date(dateStr: string) {
        this._date = dateStr;
        this.update();
    }

    set time(timeStr: string) {
        this._time = timeStr;
        this.update();
    }

    isValidDate(dateStr: string): boolean {
        return moment(dateStr, ['YYYY-MM-DD', 'MM/DD/YYYY']).isValid();
    }

    isValidTime(timeStr: string): boolean {
        if (!timeStr) {
            return false;
        }
        const parserColon = timeStr.indexOf(':');
        const parserSpace = timeStr.indexOf(' ');
        const hourStr = timeStr.substr(0, parserColon);
        const minuteStr = timeStr.substr(parserColon + 1, parserSpace - parserColon - 1);
        const periodStr = timeStr.substr(parserSpace + 1);
        const h = Number(hourStr);
        const m = Number(minuteStr);
        if (h > 0 && h <= 12) {
            if (m >= 0 && m < 60 && minuteStr.length === 2) {
                if (periodStr === 'AM' || periodStr === 'PM') {
                    return true;
                }
            }
        }
        return false;
    }

    isPast() {
        if (this._dateTime) {
            return this._dateTime.isSameOrBefore(Date.now());
        }
        return false;
    }

    isTooSoon() {
        if (this._dateTime) {
            return this._dateTime.isBetween(moment(), moment().add(2, 'h'));
        }
        return false;
    }

    isFiveDaysFurther() {
        if (this._dateTime) {
            return this._dateTime.isAfter(moment().add(5, 'd'));
        }
        return false;
    }
}
