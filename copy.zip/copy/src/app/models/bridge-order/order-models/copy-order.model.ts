import { Attachment, Activity, LineItem, IOrderModel } from '../shared.model';
import { get, isEmpty } from 'lodash';
import { DateTimeObject } from './date-time.model';

/** Model for Copy Orders */
export class CopyOrderModel implements IOrderModel {

    description = '';
    dueDateTime?: DateTimeObject;

    brandName = '';
    attachments: Attachment[] = [];
    isUploading = false;

    lineItems: LineItem[] = [];
    activity: Activity;

    constructor(lineItems?: LineItem[]) {

        this.activity = {
            quantity: 1,
            typeId: 3,
            instructions: [],
            input: {},
            subActivities: []
        };

        if (lineItems && lineItems.length > 0) {
            this.lineItems = lineItems;
            const activity: Activity = get(lineItems, ['0', 'activities', '0'], null);
            if (activity) {
                this.activity = activity;
            }
        } else {
            this.lineItems = [{
                activities: [this.activity]
            }];
        }
    }
    updateProperties() {
        const activity = this.activity;
        const lineItem = this.lineItems[0];

        /** Update dateTime */
        if (lineItem && lineItem.dueDateTime) {
            this.dueDateTime = new DateTimeObject(lineItem.dueDateTime);
        }

        if (activity) {
            this.description = activity.description || '';

            if (activity.input) {
                if (activity.input.attachments) {
                    this.attachments = activity.input.attachments || [];
                }
                if (activity.input.isUploading === true) {
                    this.isUploading = true;
                }
            }

            if (activity.instructions && activity.instructions.length > 0) {
                const instruction = activity.instructions.find((_instruction) => _instruction.label === 'brandName');
                if (instruction && instruction.values) {
                    this.brandName = instruction.values[0];
                }
            }

        }
    }
    updateLineItems(): LineItem[] {
        const activity = this.activity;
        const lineItem = this.lineItems[0];

        /** Update lineItem */
        if (lineItem && this.dueDateTime && this.dueDateTime.iso) {
            lineItem.dueDateTime = this.dueDateTime.iso || null;
        }

        /** Update activity */
        if (activity) {
            activity.instructions = activity.instructions || [];

            if (this.attachments && this.attachments.length > 0) {
                activity.input = {
                    attachments: this.attachments
                };
            } else {
                activity.input = {
                    attachments: []
                };
            }
            if (this.isUploading === true) {
                activity.input.isUploading = true;
            }

            if (!isEmpty(this.brandName)) {
                let instruction = activity.instructions.find((_instruction) => _instruction.label === 'brandName');
                if (!instruction) {
                    instruction = {
                        label: 'brandName',
                        values: []
                    };
                    activity.instructions.push(instruction);
                }
                instruction.values = [this.brandName];
            }
            activity.description = this.description;
        }

        return this.lineItems;
    }
}
