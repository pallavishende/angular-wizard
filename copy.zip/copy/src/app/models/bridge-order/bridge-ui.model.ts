import { BridgeDS } from './bridge-ds.model';
import { OrderMetadata, Milestone, UserWatcher, OrderTypes, IOrderModel, OrderType } from './shared.model';
import { CopyOrderModel } from './order-models/copy-order.model';
import { SiteAndAppOrderModel } from './order-models/saa-order.model';
import { PressOrderModel } from './order-models/press-order.model';
import { cloneDeep } from 'lodash';
import { GraphicOrderModel } from './order-models/graphic-order.model';
import { VideoOrderModel } from './order-models/video-order.model';
export namespace BridgeUI {
    export class Order {
        id?: number;
        name = '';
        metadata?: OrderMetadata;
        to = 'bridge';
        orderFor?: string | number = 2222;
        orderNumber?: string;
        createdBy?: string;
        createdByUserName?: string;
        createdDate?: string;
        creator?: string;
        assignedByEmail?: null | string;
        assigneeEmail?: string;
        assigneeName?: string;
        teamId?: null | string;
        teamName?: null | string;
        watcherEmails?: string[];
        milestones?: Milestone[];
        lastModifiedBy?: null | string;
        lastModifiedDate?: string;
        currentMilestone?: Milestone;
        userWatchers?: UserWatcher[];

        orderSource: BridgeDS.Order | null;

        /**
         * This will one of the OrderModel Classes based on the orderType
         * e.g SiteAndAppOrderModel or CopyOrderModel
         *
         * All properties and metadata specific to the orderTypes will be here.
         * This is a compact and ui friendly version of lineItems array
         *
         * @type {(IOrderModel | null)}
         * @memberof Order
         */
        orderModel: IOrderModel | null;

        orderType?: OrderType;

        private readonly ignoreKeysToImport: string[] = ['lineItems', 'relatedOrders'];
        private readonly ignoreKeysToExport: string[] = ['orderType', 'orderModel', 'orderSource', 'ignoreKeysToImport', 'ignoreKeysToExport'];

        // static helper to create new order from scratch
        static createNewOrder(name: string, metadata: OrderMetadata, userName?: string, userEmail?: string) {
            const order = new Order({
                name: name,
                metadata: metadata,
                creator: userName,
                createdBy: userEmail,
                assigneeEmail: userEmail
            });
            return order;
        }

        /**
        * Creates an instance of UI Order.
        * This is a class and will have methods to help with order editing and creating
        *
        * @param {BridgeDS.Order} [orderData]
        * @memberof Order
        */
        constructor(orderData?: BridgeDS.Order) {

            this.orderModel = null;

            if (orderData) {
                this.orderSource = cloneDeep(orderData);
                this.initializeFromDSOrder(this.orderSource);
            } else {
                this.orderSource = null;
            }
            this.initializeOrderModel();
        }

        update(orderData?: BridgeDS.Order) {
            if (orderData) {
                this.orderSource = cloneDeep(orderData);
                this.initializeFromDSOrder(this.orderSource);
                this.initializeOrderModel();
            }
        }

        initializeFromDSOrder(orderData: BridgeDS.Order) {
            for (const _key in orderData) {
                if (!this.ignoreKeysToImport.includes(_key)) {
                    (this as any)[_key] = orderData[_key as keyof BridgeDS.Order] as any;
                }
            }
        }

        initializeOrderModel() {
            if (this.metadata) {
                const lineItems = (this.orderSource && this.orderSource.lineItems) ? this.orderSource.lineItems : [];

                this.orderType = this.metadata.orderType;

                switch (this.metadata.orderType) {
                    case OrderTypes.COPY:
                        this.orderModel = new CopyOrderModel(lineItems);
                        break;
                    case OrderTypes.SITE_APP_UPDATES:
                        this.orderModel = new SiteAndAppOrderModel(lineItems);
                        break;
                    case OrderTypes.PRESS:
                        this.orderModel = new PressOrderModel(lineItems);
                        break;
                    case OrderTypes.GRAPHICS:
                        this.orderModel = new GraphicOrderModel(lineItems);
                        break;
                    case OrderTypes.VIDEO:
                        this.orderModel = new VideoOrderModel(lineItems, this.metadata.requestType);
                        break;
                    default:
                        break;
                }
                if (this.orderModel) {
                    // update local properties from lineItems
                    this.orderModel.updateProperties(this);
                }
            }
        }

        /**
         * Generates OMF Order format with lineitems and instructions, to POST or PUT
         *
         * @returns
         * @memberof Order
         */
        generateDSOrder(): BridgeDS.Order {
            const orderData: BridgeDS.Order = this.orderSource || new BridgeDS.Order();
            for (const _key in this) {
                if (this.hasOwnProperty(_key) && !this.ignoreKeysToExport.includes(_key)) {
                    (orderData as any)[_key] = this[_key as keyof Order] as any;
                }
            }

            if (this.orderModel) {
                // generate lineItems from model properties
                orderData.lineItems = this.orderModel.updateLineItems(this);
            }

            return orderData;
        }

        isCopyOrder() {
            return this.orderType === OrderTypes.COPY;
        }

        isVideoOrder() {
            return this.orderType === OrderTypes.VIDEO;
        }

        isGraphicsOrder() {
            return this.orderType === OrderTypes.GRAPHICS;
        }

        isPressOrder() {
            return this.orderType === OrderTypes.PRESS;
        }

        isSiteAndAppOrder() {
            return this.orderType === OrderTypes.SITE_APP_UPDATES;
        }

        get videoModel() {
            return this.orderModel as VideoOrderModel;
        }

        get pressModel() {
            return this.orderModel as PressOrderModel;
        }

        get graphicsModel() {
            return this.orderModel as GraphicOrderModel;
        }

        get copyModel() {
            return this.orderModel as CopyOrderModel;
        }

        get saaModel() {
            return this.orderModel as SiteAndAppOrderModel;
        }
    }

}
