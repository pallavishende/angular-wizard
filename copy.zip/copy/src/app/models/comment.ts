export class Comment {
  body: string;
  postedBy: string;
  activityId: any;
  bundleIds: Array<string>;
}