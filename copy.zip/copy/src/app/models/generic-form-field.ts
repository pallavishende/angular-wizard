export interface OrderInstructionFormFields {
    formFiels: Array<GenericFormField>;
    versionType?: any;
    subFranchise?: any;
    hideVideoPageToggle?: any;
    includeBetNowApp?: any;
    adTargeting?: any;
}

interface GenericFormField {
    label: string;
    key: string;
    value: Array<string>;
    defaultValue: string;
    multiSelection: boolean;
    isRequiredField: boolean;
    charLimit: number;
}