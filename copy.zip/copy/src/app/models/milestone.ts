export class Milestone {
  status: string;
  last_modified_date: string;
  last_modified_by: string;
  lastModifiedDate?: string;
}
