import { Metadata } from './metadata';
import { Milestone } from './milestone';

export interface Order {
    id?: number;
    orderFor: number;
    creator: string;
    createdBy: string;
    createdDate?: string;
    name: string;
    assigneeEmail: string;
    lineItems: any[];
    lineItemsClipId?: any[];
    metadata?: Metadata;
    dsid?: string;
    teamId?: string;
    currentMilestone?: Milestone;
    milestones?: Array<Milestone>;
    assignedByEmail?: string;
    orderNumber?: string;
    userWatchers?: any[];
    assigneeName?: string;
    teamName?: string;
    relatedOrders?: any[];
    to?: string;
}
