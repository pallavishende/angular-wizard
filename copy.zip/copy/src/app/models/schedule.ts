export class Schedule {
  due_date;
  publish_on;
}
