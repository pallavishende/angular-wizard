import { CustomConfig } from './custom-config';
import { AssetInput } from './asset-input';
import { Activity } from './activity';

export class LineItem {
  id: any;
  activities: Array<Activity>;
  customConfig: CustomConfig;
  currentState?: Object;
  metadata: Array<Metadata>;
  dueDateTime: string;
  launchDateTime: string;
  publishDateTime: string;
  videoInstructionsMetadata?: any;
}

interface Metadata {
  assetInputs?: Array<AssetInput>;
  clip?: any;
  clipDSId?: string;
  clipId?: number;
  clipSource?: string;
  clipTitle?: string;
  dsId?: string;
}
