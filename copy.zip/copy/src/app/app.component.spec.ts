/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER } from '@angular/core';
import { Subject, BehaviorSubject } from 'rxjs';
import { RouterTestingModule } from '@angular/router/testing';

import { ToasterModule, ToasterService } from 'angular2-toaster';

import { SystemAlertsService } from './services/system-alerts.service';
import { ToasterContainerComponent, ToasterConfig, BodyOutputType } from 'angular2-toaster';
import { LoginService } from './login/login.service';
import { AdalService } from './shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { SecretService } from './services/secret.service';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod, Headers} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { ConfigurationManagerService } from './configuration/configuration-manager.service';
import { configurationLoader } from './configuration/configurationLoader';
import { EnvironmentService } from './services/environment.service';
import { ConfigService } from './services/config.service';
import { StorageService } from './services/storage.service';
import { LoadingMaskService } from './shared/loading-mask/loading-mask.service';

describe('AppComponent', () => {
  beforeEach(() => {

    TestBed.configureTestingModule({
      imports: [
        ToasterModule, RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      providers: [
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
            provide: HttpClient,
            useFactory: (http: Http) => http,
            deps: [Http]
        },
        {provide: SystemAlertsService, useValue: SystemAlertsService },
        {provide: ToasterService, useValue: ToasterService},
        LoginService, AdalService, SecretService,
        ConfigurationManagerService,
        EnvironmentService,
        {
            provide: APP_INITIALIZER,
            useFactory: configurationLoader,
            deps: [ ConfigurationManagerService ],
            multi: true
        },
        ConfigService,
        StorageService,
        LoadingMaskService
      ]
    });
    TestBed.compileComponents();
  });

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));
});
