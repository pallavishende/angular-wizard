import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsApprovalService } from './order-details-approval.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { UtilityService } from '../../services/utility.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { Activity } from '../../models/activity';
import { SubActivity } from '../../models/sub-activity';
import { LineItem } from '../../models/line-item';
import { UserService } from '../../services/user.service';
import 'rxjs/add/operator/mergeMap';
import { filter, uniqBy, forEach, find } from 'lodash';

@Component({
  selector: 'app-order-details-approval',
  templateUrl: './order-details-approval.component.html',
  styleUrls: ['./order-details-approval.component.scss', '../order-customization-base/order-customization-base.component.scss'],
  providers: [OrderDetailsApprovalService],
  encapsulation: ViewEncapsulation.None
})
export class OrderDetailsApprovalComponent implements OnInit, OnDestroy {
  order;
  orderId;
  usersCount = 0;
  users;
  uniqueLineItems;
  dataObservable: Observable<{}>;
  usersObservable: Observable<{}>;
  dataSubscription: Subscription;
  usersSubscription: Subscription;
  endpointProfiles;
  activityTypesList = [];
  approvalActivityTypesList = [];
  subscriptions = new Subscription();

  constructor(
    private alerts: SystemAlertsService,
    private ordersService: OrdersService,
    private orderDetailsApprovalService: OrderDetailsApprovalService,
    private utilityService: UtilityService,
    private userService: UserService,
    private endpointProfileService: EndpointProfileService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private activatedRoute: ActivatedRoute) {
    this.alerts = alerts;
  }

  ngOnInit() {
    this.ordersService.setOrdersPageTitle('Draft - Viacom Bridge');
    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
    });
    const utilityServiceRef = this.utilityService;
    this.activityTypesList = this.utilityService.getActivityTypesList();
    this.approvalActivityTypesList = filter(this.activityTypesList, (activityType) => {
      return activityType.category === utilityServiceRef.activityCategory.APPROVAL;
    });
    this.initialize();
  }

  getActivityListForDisplay(existingActivities) {
    return uniqBy(existingActivities, 'description'); // this.approvalActivityTypesList;
  }

  initialize() {
    // this.loadingMask.enableLoadingMask();
    this.dataObservable = this.orderDetailsApprovalService.get();
    this.usersObservable = this.userService.getAllUsers();
    this.subscriptions.add(this.dataSubscription = this.dataObservable
      .subscribe(
        data => {
          this.order = data;
          this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          this.orderId = this.order.id;
          this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
            data => {
              this.endpointProfiles = data;
            }
          ));
          if (this.usersCount === 0) {
            this.subscriptions.add(this.usersSubscription = this.usersObservable.subscribe(
              data => {
                if (data) {
                  this.users = data['content'];
                  this.usersCount = this.users.length;
                }
              },
              error => {
                console.log('APPROVALS: Data not loaded');
                // this.loadingMask.disableLoadingMask();
                // this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
              }
            ));
          }
        },
        error => {
          console.log('APPROVALS: data not loaded');
          // this.loadingMask.disableLoadingMask();
          this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
        }
      ));
  }

  getParentActivityAssignee(lineItem: LineItem, isEmailRequired?: boolean) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    if (isEmailRequired) {
      return videoActivity.subActivities[0].assignedUserEmail;
    }
    else {
      return this.getDisplayNameFromEmail(videoActivity.subActivities[0].assignedUserEmail);
    }
  }

  getDisplayNameFromEmail(email: string) {
    let displayName = '';
    if (!email) {
      return displayName;
    }
    this.subscriptions.add(this.userService.getAllUsers().subscribe(
      data => {
        if (data) {
          this.users = data['content'];
          let tmp = find(this.users, { 'login': email });
          displayName = tmp ? tmp['displayName'] : '';
          return displayName;
        }
      },
      error => {
      }
    ));
    return displayName;
  }

  findCorrespondingApprovalActivity(approvalActivity: SubActivity, subActivities: Array<SubActivity>) {
    return find(subActivities, function (subActivity) {
      return subActivity.typeId === approvalActivity.previousTypeId
        && (subActivity.assignedUserEmail || '') === approvalActivity.previousUserEmail;
    });
  }

  onSelectNameNotify(payload, lineItem: LineItem) {
    if (this.order.metadata.orderType === 'VIDEO') {
      let videoActivity: Activity;
      let stillFramesActivity: Activity;
      let captionsActivity: Activity;
      const clipIdentifier = lineItem.metadata[0]['clipId'] || lineItem.metadata[0]['clipTitle'];
      forEach(this.order.lineItems, (item: LineItem) => {
        if (item.metadata[0]['clipId'] === clipIdentifier || (item.metadata[0]['clipId'] === null &&
          item.metadata[0]['clipTitle'] === clipIdentifier)) {
          videoActivity = this.utilityService.getLineItemActivity(1, item);
          stillFramesActivity = this.utilityService.getLineItemActivity(2, item);
          captionsActivity = this.utilityService.getLineItemActivity(4, item);
          videoActivity.subActivities[0].assignedUserEmail = payload.assigneeEmail;
          if (stillFramesActivity) { stillFramesActivity.subActivities[0].assignedUserEmail = payload.assigneeEmail; }
          if (captionsActivity) { captionsActivity.subActivities[0].assignedUserEmail = payload.assigneeEmail; }
        }
      });
    }
    this.saveToModel();
  }

  onRemoveNameNotify(lineItem: LineItem) {
    let videoActivity: Activity;
    let stillFramesActivity: Activity;
    let captionsActivity: Activity;
    const clipIdentifier = lineItem.metadata[0]['clipId'] || lineItem.metadata[0]['clipTitle'];
    forEach(this.order.lineItems, (item: LineItem) => {
      if (item.metadata[0]['clipId'] === clipIdentifier || (item.metadata[0]['clipId'] === null &&
        item.metadata[0]['clipTitle'] === clipIdentifier)) {
        videoActivity = this.utilityService.getLineItemActivity(1, item);
        stillFramesActivity = this.utilityService.getLineItemActivity(2, item);
        captionsActivity = this.utilityService.getLineItemActivity(4, item);
        videoActivity.subActivities[0].assignedUserEmail = '';
        if (stillFramesActivity) { stillFramesActivity.subActivities[0].assignedUserEmail = ''; }
        if (captionsActivity) { captionsActivity.subActivities[0].assignedUserEmail = ''; }
      }
    });
    this.saveToModel();
  }

  saveToModel() {
    const orderStore = this.orderDetailsApprovalService.getOrderStore();
    orderStore.notify();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
    // this.loadingMask.disableLoadingMask();
  }
}
