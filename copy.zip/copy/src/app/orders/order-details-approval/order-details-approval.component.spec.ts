/* tslint:disable:no-unused-variable */
import { TestBed, async, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsPackageService } from '../order-details-package/order-details-package.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { UserService } from '../../services/user.service';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import 'rxjs/add/observable/of';

import { OrderStore } from '../../models/order-store';
import { UtilityService } from '../../services/utility.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';

import { OrderDetailsApprovalComponent } from './order-details-approval.component';
import { OrderDetailsApprovalService } from './order-details-approval.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';

import { LoginService } from '../../login/login.service';
import { AdalService } from '../../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { SecretService } from '../../services/secret.service';
import { AppModule } from '../../app.module';
import { SharedModule } from '../../shared/shared.module';

describe('OrderDetailsApprovalComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;

  let users = {
    content: [
      {id: 2351, login: "Meghan.Besse@viacommix.com", firstName: "Meghan", lastName: "Besse", displayName: 'Meghan Besse'},
      {id: 1551, login: "Samir.Patel@viacomcontractor.com", firstName: "Samir", lastName: "Patel", displayName: 'Samir Patel'},
      {id: 1601, login: "Saransh.Ahlawat@viacomcontractor.com", firstName: "Saransh", lastName: "Ahlawat", displayName: 'Saransh Ahlawat'},
      {id: 1552, login: "Luis.Velez@viacommix.com", firstName: "Luis", lastName: "Velez", displayName: 'Luis Velez'}
    ]
  };
  let lineItem = {
    currentState: {
      'status': "TO_DO"
    },
    activities: [
      {
        'typeId': 1,
        'assignedUserEmail': '',
        'subActivities': [
          {
            'typeId': 7,
            'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
            'currentState': {
              'status': "WAITING"
            },
          }
        ],
        'currentState': {
          'status': "TO_DO"
        },
      },
      {
        'typeId': 3,
        'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
        'subActivities': [
          {
            'typeId': 7,
            'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
            'currentState': {
              'status': "WAITING"
            },
          }
        ],
        'currentState': {
          'status': "TO_DO"
        },
      },
      {
        'typeId': 13,
        'assignedUserEmail': '',
        'subActivities': [],
        'currentState': {
          'status': "TO_DO"
        },
      }
    ]
  };
  let order = {
    id: 1111,
    to: 1233,
    order_for: 12312,
    creator: 'J Unit',
    name: 'TEST ORDER FOR J UNIT',
    metadata: {
    },
    dsid: 'VBDSID',
    currentMilestone: {
      status: 'TO_DO',
      last_modified_date: '00000000',
      last_modified_by: 'J UNIT'
    },
    milestones: [{
      status: 'TO_DO',
      last_modified_date: '00000000',
      last_modified_by: 'J UNIT'
    }],
    lineItems: [lineItem],
    lineItemVmid: [lineItem]
  };

  let mockApprovalService = {
      get: () => {}
  };

  let MockUserService = {
    getAllUsers: function() {
      return Observable.of(users);
    }
  };


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, AppModule, SharedModule ],
      declarations: [ OrderDetailsApprovalComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        OrdersService,
        {provide: OrderDetailsApprovalService, useValue: mockApprovalService},
        {provide: OrderDetailsPackageService, useValue: mockApprovalService},
        {provide: OrderProgressTrackerService, useValue: mockApprovalService},
        OrderStore,
        { provide: UserService, useValue: MockUserService },
        {
          provide: ActivatedRoute, useValue: {
            params: Observable.of({ id: 'test' })
          }
        },
        UtilityService,
        LoginService,
        AdalService,
        SecretService,
        SystemAlertsService,
        EndpointProfileService,
        ConfigService,
        LoadingMaskService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        }
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OrderDetailsApprovalComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    //app = fixture.debugElement.componentInstance; // to access properties and methods
    app = fixture.componentInstance; // to access properties and methods
    //fixture.detectChanges();
  }));

  beforeEach(inject([OrderDetailsApprovalService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  it('should create approval component', async(() => {
    expect(app).toBeDefined();
  }));

  it('should have ngOnInit defined', () => {
    spyOn(mockApprovalService, 'get').and.returnValue(Observable.of(order));
    expect(app.ngOnInit).toBeDefined();
  });

  it('should have dataSubscription defined', async(() => {
    spyOn(mockApprovalService, 'get').and.returnValue(Observable.of(order));
    app.initialize();
    expect(app.dataSubscription).toBeDefined();
  }));

  it('should have usersSubscription defined', async(() => {
    spyOn(mockApprovalService, 'get').and.returnValue(Observable.of(order));
    app.initialize();
    expect(app.usersSubscription).toBeDefined();
  }));

  it('should have order defined', async(() => {
    spyOn(mockApprovalService, 'get').and.returnValue(Observable.of(order));
    app.initialize();
    expect(app.order).toBeDefined();
  }));

  it('#getDisplayNameFromEmail: Meghan.Besse@viacommix.com should return Meghan Besse', () => {
    let name = app.getDisplayNameFromEmail('Meghan.Besse@viacommix.com');
    expect(name).toEqual('Meghan Besse');
  });

  it('#getDisplayNameFromEmail: John.Doe@viacomm.com should return Unassigned', () => {
    let name = app.getDisplayNameFromEmail('John.Doe@viacomm.com');
    expect(name).toEqual('');
  });

  // it('should have addNewApprovalActivity defined', () => {
  //   spyOn(app, 'addNewApprovalActivity');
  //   expect(app.addNewApprovalActivity).toBeDefined();
  // });

  it('should have saveToModel defined', () => {
    expect(app.saveToModel).toBeDefined();
  });
});
