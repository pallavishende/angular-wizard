import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/map';
import { OrderStore } from '../../models/order-store';
import { OrderTypes } from '../../models/constants/order-types';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsScheduleService } from '../order-details-schedule/order-details-schedule.service';
import { LineItem } from '../../models/line-item';
import { UtilityService } from '../../services/utility.service';
import { Activity, Instructions } from '../../models/activity';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { find, forEach, hasIn, get, indexOf, cloneDeep, map, isEmpty } from 'lodash';
import { OrderRequestTypes } from 'app/models/bridge-order/shared.model';
import { BridgeDS } from 'app/models/bridge-order/bridge-ds.model';

const orderInstructionsFormFields = require('../../models/mock-payloads/order-instructions-form-fields.json');
const orderPublishingFormFields = require('../../models/mock-payloads/order-publishing-form-fields.json');
const orderVideoCopyFormFields = require('../../models/mock-payloads/order-video-copy-form-fields.json');
const orderGraphicsFormFields = require('../../models/mock-payloads/order-graphic-request-instructions.json');
const orderPressFormFields = require('../../models/mock-payloads/order-press-form-instructions.json');

@Injectable()
export class OrderProgressTrackerService {
  order;
  routeData;
  isSubmitReady = false;
  isPreviousCompleted = true;
  isNavigationDisabled = false;
  defaultOptions = [
    {
      step: 'endpoint', stepReady: false,
      section: 'platform-progress', stepCompleted: false,
      orderType: [OrderTypes.Video]
    },
    {
      step: 'assets', stepReady: false,
      section: 'assets-progress', stepCompleted: false,
      orderType: [OrderTypes.Press, OrderTypes.Video]
    },
    {
      step: 'instruction', stepReady: false,
      section: 'format-progress', stepCompleted: false,
      orderType: [OrderTypes.Video]
    },
    {
      step: 'metadata', stepReady: false,
      section: 'format-progress', stepCompleted: false,
      orderType: [OrderTypes.Video]
    },
    {
      step: 'instructions', stepReady: false,
      section: 'format-progress', stepCompleted: false,
      orderType: [OrderTypes.Video, OrderTypes.Copy, OrderTypes.Graphics, OrderTypes.SiteAndAppUpdates, OrderTypes.Press]
    },
    {
      step: 'schedule', stepReady: false,
      section: 'schedule-progress', stepCompleted: false,
      orderType: [OrderTypes.Video, OrderTypes.Copy, OrderTypes.Graphics, OrderTypes.SiteAndAppUpdates, OrderTypes.Press]
    },
    {
      step: 'review', stepReady: false,
      section: 'review-progress', stepCompleted: false,
      orderType: [OrderTypes.Video, OrderTypes.Copy, OrderTypes.Graphics, OrderTypes.SiteAndAppUpdates, OrderTypes.Press]
    },
    {
      step: 'submit', stepReady: false,
      section: 'NA', stepCompleted: false,
      orderType: [OrderTypes.Video, OrderTypes.Copy, OrderTypes.Graphics, OrderTypes.SiteAndAppUpdates, OrderTypes.Press]
    }
  ];

  constructor(
    private orderStore: OrderStore,
    private router: Router,
    private ordersService: OrdersService,
    private orderDetailsScheduleService: OrderDetailsScheduleService,
    private loadingMask: LoadingMaskService,
    private systemAlertsService: SystemAlertsService,
    private utilityService: UtilityService
  ) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  getDefaultOptions() {
    return this.defaultOptions;
  }

  isFound(list, toMatch) {
    return find(list, function (item) {
      return item === toMatch;
    });
  }

  getFormatActivity(item: LineItem) {
    return find(item.activities, { 'typeId': 1 });
  }

  validateLineItems(order, orderType: String) {
    const lineItems = order.lineItems;
    const customProgression = {
      platform: [],
      asset: [],
      format: [],
      approval: [],
      schedule: [],
      review: 0
    };
    const localIsFound = this.isFound;  // keep ref
    let isNavigationStatusModified = false;
    let orderValid = false;
    let orderDueDate = false;
    if (lineItems.length <= 0) {
      return customProgression;
    }
    if (order.metadata.requestType && orderType === OrderTypes.Video) {
      orderValid = this.validateNewVideoOrderInstructions(order);
      orderDueDate = this.validateDueDateTime(order);
    }

    forEach(lineItems, (lineItem) => {
      // endpoints validation
      if (hasIn(lineItem, 'customConfig.endpoint') && get(lineItem, 'customConfig.endpoint') !== '') {
        if (lineItem['metadata'][0]['clipId'] !== null && lineItem['metadata'][0]['clipId'] !== '') {
          if (!localIsFound(customProgression.platform, lineItem['metadata'][0]['clipId'])) {
            customProgression.platform.push(lineItem['metadata'][0]['clipId']);
          }
        } else {
          if (!localIsFound(customProgression.platform, lineItem['metadata'][0]['clipTitle'])) {
            customProgression.platform.push(lineItem['metadata'][0]['clipTitle']);
          }
        }
      }

      // asset validation
      if ((order.metadata.requestType && orderType === OrderTypes.Video) || orderType === OrderTypes.Press) {
        const assetInputs = lineItem.metadata[0].assetInputs[0];
        if ((
          (orderType === OrderTypes.Press && assetInputs.inOutPoint !== '') ||
          (orderType === OrderTypes.Video && order.metadata.requestType === OrderRequestTypes.TRANSCRIPTS && lineItem.metadata[0].duration !== '') ||
          (orderType === OrderTypes.Video && order.metadata.requestType === OrderRequestTypes.CAPTIONS) ||
          (orderType === OrderTypes.Video && order.metadata.requestType === OrderRequestTypes.STILL_FRAMES) ||
          (orderType === OrderTypes.Video && order.metadata.requestType === OrderRequestTypes.SAA) ||
          (orderType === OrderTypes.Video && order.metadata.requestType === OrderRequestTypes.SOCIAL)
          )
          &&
          (assetInputs.assetName && assetInputs.assetName !== '')
          &&
          (assetInputs.assetSource && assetInputs.assetSource !== '')) {
          customProgression.asset.push(assetInputs);
        }
      }

      // format validation
      let videoActivityObj: Activity;
      let hasAllRequiredFields = (order.metadata.requestType && orderType === OrderTypes.Video) ? orderValid : false;
      // let hasAllRequiredFields = true;

      if (order.metadata.requestType) {
        videoActivityObj = find(lineItem.activities, (activity) => {
          return (activity['typeId'] === 18 || activity['typeId'] === 19 || activity['typeId'] === 20 || activity['typeId'] === 1);
        });
        if (get(videoActivityObj, 'input.isUploading')) {
          this.isNavigationDisabled = true;
          isNavigationStatusModified = true;
        }
        if (hasAllRequiredFields) {
          if (lineItem['metadata'][0]['clipId'] !== null && lineItem['metadata'][0]['clipId'] !== '') {
            customProgression.format.push(lineItem['metadata'][0]['clipId']);
          } else {
            customProgression.format.push(lineItem['metadata'][0]['clipTitle']);
          }
        } else {
          customProgression.format = [];
        }
      } else {
        videoActivityObj = find(lineItem.activities, (activity) => {
          return activity['typeId'] === 1;
        });

        if (lineItem['publishInstructionsMetadata']) {
          for (const key in orderPublishingFormFields) {
            if (orderPublishingFormFields.hasOwnProperty(key)) {
              if (key === 'adTargeting' && lineItem['publishInstructionsMetadata'][key] && lineItem['publishInstructionsMetadata'][key][0].trim() === '') {
                hasAllRequiredFields = false;
              } else {
                if (orderPublishingFormFields[key].isRequiredField &&
                  (!lineItem['publishInstructionsMetadata'][key] || lineItem['publishInstructionsMetadata'][key].length === 0 || (lineItem['publishInstructionsMetadata'][key][0] && lineItem['publishInstructionsMetadata'][key][0].trim() === ''))) {
                  hasAllRequiredFields = false;
                  break;
                }
              }
            }
          }
        }

        if (lineItem['videoCopyInstructionsMetadata']) {
          for (const key in orderVideoCopyFormFields) {
            if (orderVideoCopyFormFields.hasOwnProperty(key)) {
              if (orderVideoCopyFormFields[key].isRequiredField) {
                if (!lineItem['videoCopyInstructionsMetadata'][key]) {
                  hasAllRequiredFields = false;
                  break;
                } else if (lineItem['videoCopyInstructionsMetadata'][key][0].trim() === '') {
                  hasAllRequiredFields = false;
                  break;
                }
              }
              if (orderVideoCopyFormFields[key].charLimit && lineItem['videoCopyInstructionsMetadata'][key]) {
                if (lineItem['videoCopyInstructionsMetadata'][key][0].length > orderVideoCopyFormFields[key].charLimit) {
                  hasAllRequiredFields = false;
                  break;
                }
              }
            }
          }
        }

        if (lineItem['videoInstructionsMetadata']) {
          // if current version type need caption field
          if (lineItem['videoInstructionsMetadata']['versionType'] && lineItem['videoInstructionsMetadata']['versionType'][0]
            && orderInstructionsFormFields['captions'].permittedVersionType.indexOf(lineItem['videoInstructionsMetadata']['versionType'][0]) > -1) {
            if (!lineItem['videoInstructionsMetadata']['captions'] || !lineItem['videoInstructionsMetadata']['captions'][0]) {
              hasAllRequiredFields = false;
            }
            if (lineItem['videoInstructionsMetadata']['captions'] && lineItem['videoInstructionsMetadata']['captions'].indexOf('Deliver/include transcript file') > -1) {
              if (!lineItem['videoInstructionsMetadata']['budgetCode']) {
                hasAllRequiredFields = false;
              } else if (!lineItem['videoInstructionsMetadata']['budgetCode'][0]) {
                hasAllRequiredFields = false;
              } else if (lineItem['videoInstructionsMetadata']['budgetCode'][0].trim() === '') {
                hasAllRequiredFields = false;
              }
            }
          }
          // if no file drop off location
          if (!lineItem['videoInstructionsMetadata']['fileDropOffLocation'] || !lineItem['videoInstructionsMetadata']['fileDropOffLocation'][0]) {
            hasAllRequiredFields = false;
          }
          // if selected slates and graphics, slates and graphics source info is thus neccessary
          if (lineItem['videoInstructionsMetadata']['slatesAndGraphics'] && lineItem['videoInstructionsMetadata']['slatesAndGraphics'].length > 0) {
            if (!lineItem['videoInstructionsMetadata']['slatesAndGraphicsSourceInfo']) {
              hasAllRequiredFields = false;
            }
          }
        } else {
          hasAllRequiredFields = false;
        }

        if (get(videoActivityObj, 'input.isUploading')) {
          this.isNavigationDisabled = true;
          isNavigationStatusModified = true;
        }
        if (hasIn(lineItem, 'customConfig.version')
          && (get(lineItem, 'customConfig.version')).toString().replace(/&nbsp;|\s/g, '') !== ''
          && hasAllRequiredFields && orderType === OrderTypes.Video
        ) {
          if (lineItem['metadata'][0]['clipId'] !== null &&  lineItem['metadata'][0]['clipId'] !== '') {
            customProgression.format.push(lineItem['metadata'][0]['clipId']);
          } else {
            customProgression.format.push(lineItem['metadata'][0]['clipTitle']);
          }
        } else {
          customProgression.format = [];
        }
      }

      // schedule validation
      let isScheduleValid: boolean;
      if (orderType === OrderTypes.Video) {
        if (order.metadata.requestType) {
          isScheduleValid = orderDueDate;
          if (order.metadata.requestType === OrderRequestTypes.SAA) {
            isScheduleValid = isScheduleValid && this.validatePublishDateTime(order) && this.orderDetailsScheduleService.isValidDate(get(order, 'metadata.orderInstruction.dueDateTime'), get(order, 'metadata.orderInstruction.publishDateTime'));
          }
        } else {
          isScheduleValid = hasIn(lineItem, 'publishDateTime') && get(lineItem, 'publishDateTime') !== ''
          && this.orderDetailsScheduleService.isValidDate(get(lineItem, 'dueDateTime'), get(lineItem, 'publishDateTime'))
          && !this.orderDetailsScheduleService.isPast(get(lineItem, 'dueDateTime'))
          && !this.orderDetailsScheduleService.isPast(get(lineItem, 'publishDateTime'));
        }
      } else if (orderType === OrderTypes.Press) {
        isScheduleValid = !this.orderDetailsScheduleService.isPast(get(lineItem, 'dueDateTime'));
      }
      if (isScheduleValid) {
        if (lineItem['metadata'][0]['clipId'] !== null && lineItem['metadata'][0]['clipId'] !== '') {
          customProgression.schedule.push(lineItem['metadata'][0]['clipId']);
        } else {
          customProgression.schedule.push(lineItem['metadata'][0]['clipTitle']);
        }
      } else {
        customProgression.schedule = [];
      }
    });

    if (!isNavigationStatusModified) {
      this.isNavigationDisabled = false;
    }
    return customProgression;
  }

  generateOrderProgress(order, lineItemsClipId, orderType?: string) {
    const lineItems = order.lineItems;
    if (orderType !== OrderTypes.Video && orderType !== OrderTypes.Press && typeof orderType !== 'undefined') {
      return this.getNonVideoOrderProgress(lineItems, orderType);
    } else {
      const customProgression = this.validateLineItems(order, orderType);
      const defOpt = this.defaultOptions; // maintain ref
      let isPreviousCompleted = true;

      // enpoint step for Video
      if (orderType === OrderTypes.Video && !order.metadata.requestType) {
        defOpt[0].stepReady = true;
        defOpt[0].stepCompleted = lineItemsClipId && lineItemsClipId.length > 0 && (customProgression.platform.length === lineItemsClipId.length);
        isPreviousCompleted = defOpt[0].stepCompleted;
      }

      // assets step for Video and press
      if ((orderType === OrderTypes.Video && order.metadata.requestType) || orderType === OrderTypes.Press) {
        defOpt[1].stepReady = true;
        defOpt[1].stepCompleted = lineItems && lineItems.length > 0 && (customProgression.asset.length === lineItems.length);
        //defOpt[1].stepCompleted = lineItemsClipId && lineItemsClipId.length > 0 && (customProgression.asset.length === lineItemsClipId.length);
        if (orderType === OrderTypes.Video && order.metadata.requestType && orderType === OrderTypes.Video && order.metadata.requestType === OrderRequestTypes.SAA) {
          defOpt[1].stepCompleted  = defOpt[1].stepCompleted && lineItemsClipId && lineItemsClipId.length > 0 && (customProgression.platform.length === lineItemsClipId.length);
        }
        isPreviousCompleted = defOpt[1].stepCompleted;
      }

      // instruction step for video
      if (orderType === OrderTypes.Video && order.metadata.requestType) {
        defOpt[2].stepReady = defOpt[1].stepCompleted;
        defOpt[2].stepCompleted = customProgression.format.length === lineItems.length && customProgression.schedule.length === lineItems.length && isPreviousCompleted;
        isPreviousCompleted = defOpt[2].stepCompleted;
      }

      // metadata step for video
      if (orderType === OrderTypes.Video && order.metadata.requestType === OrderRequestTypes.SAA) {
        defOpt[3].stepReady = defOpt[2].stepCompleted;
        defOpt[3].stepCompleted = isPreviousCompleted; // add metadata validation
        isPreviousCompleted = defOpt[3].stepCompleted;
      }

      // instructions step for Video and Press
      if (orderType === OrderTypes.Video && !order.metadata.requestType) {
        defOpt[4].stepReady = defOpt[0].stepCompleted;
        defOpt[4].stepCompleted = customProgression.format.length === lineItems.length && isPreviousCompleted;
        isPreviousCompleted = defOpt[4].stepCompleted;
      }
      if (orderType === OrderTypes.Press) {
        defOpt[4].stepReady = defOpt[1].stepCompleted;
        defOpt[4].stepCompleted = isPreviousCompleted && this.checkPressForm(lineItems[0]);
        isPreviousCompleted = defOpt[4].stepCompleted;
      }

      // schedule step for Video and Press
      if (orderType === OrderTypes.Press) {
        defOpt[5].stepReady = defOpt[4].stepCompleted;
        defOpt[5].stepCompleted = lineItems[0].dueDateTime && !this.orderDetailsScheduleService.isPast(get(lineItems[0], 'dueDateTime')) && isPreviousCompleted;
        isPreviousCompleted = defOpt[5].stepCompleted;
      } else if (orderType === OrderTypes.Video && !order.metadata.requestType) {
        defOpt[5].stepReady = defOpt[4].stepCompleted;
        defOpt[5].stepCompleted = customProgression.schedule.length === lineItems.length && isPreviousCompleted;
        isPreviousCompleted = defOpt[5].stepCompleted;
      }

      // review
      defOpt[6].stepReady = isPreviousCompleted;
      defOpt[6].stepCompleted = isPreviousCompleted;
      this.isSubmitReady = isPreviousCompleted;
      return this.defaultOptions;
    }
  }

  getNonVideoOrderProgress(lineItems, orderType) {
    const defOpt = this.defaultOptions; // maintain ref
    let isPreviousCompleted = true;
    // instructions page is optional for Copy Orders and required for Graphics Orders
    if (lineItems[0].activities[0] && lineItems[0].activities[0].input && lineItems[0].activities[0].input.isUploading) {
      this.isNavigationDisabled = true;
    } else {
      this.isNavigationDisabled = false;
    }
    if (orderType === OrderTypes.Graphics) {
      defOpt[4].stepReady = true;
      defOpt[4].stepCompleted = lineItems[0].activities[0].description !== null
        && lineItems[0].activities[0].description.trim() !== '' && this.checkGraphicsForm(lineItems) && isPreviousCompleted;
      isPreviousCompleted = defOpt[4].stepCompleted;
    } else {
      defOpt[4].stepReady = true;
      defOpt[4].stepCompleted = true;
      isPreviousCompleted = defOpt[4].stepCompleted;
    }
    // schedule
    defOpt[5].stepReady = isPreviousCompleted;
    defOpt[5].stepCompleted = lineItems[0].dueDateTime && !this.orderDetailsScheduleService.isPast(lineItems[0].dueDateTime) && isPreviousCompleted;
    if (orderType === OrderTypes.SiteAndAppUpdates) {
      if (lineItems[0].launchDateTime === 'notValid' || lineItems[0].launchDateError) {
        lineItems[0].launchDateTime = '';
        defOpt[5].stepCompleted = false;
      } else if (lineItems[0].launchDateTime && defOpt[5].stepCompleted) {
        defOpt[5].stepReady = isPreviousCompleted;
        defOpt[5].stepCompleted = !this.orderDetailsScheduleService.isPast(lineItems[0].launchDateTime) && isPreviousCompleted
          && this.orderDetailsScheduleService.isValidDate(lineItems[0].dueDateTime, lineItems[0].launchDateTime);
      }
    } else if (orderType === OrderTypes.Graphics) {
      const request = lineItems[0].activities[0].instructions.filter(item => item.label === 'requestType')[0];
      if (request && request.values[0] === 'VMN') {
        defOpt[5].stepCompleted = lineItems[0].dueDateTime && !this.orderDetailsScheduleService.isPast(lineItems[0].dueDateTime) &&
          !this.orderDetailsScheduleService.isPast(lineItems[0].launchDateTime) && isPreviousCompleted
          && this.orderDetailsScheduleService.isValidDate(lineItems[0].dueDateTime, lineItems[0].launchDateTime)
          && this.checkForDueDateReason(lineItems);
      }
    }
    isPreviousCompleted = defOpt[5].stepCompleted;

    // review
    defOpt[6].stepReady = isPreviousCompleted;
    defOpt[6].stepCompleted = isPreviousCompleted;
    this.isSubmitReady = isPreviousCompleted;
    return this.defaultOptions;
  }

  checkGraphicsForm(lineItems) {
    let hasAllRequiredFields = true;
    const brand = lineItems[0].activities[0].instructions.filter(item => item.label === 'brand')[0];
    const request = lineItems[0].activities[0].instructions.filter(item => item.label === 'requestType')[0];
    if (typeof request !== 'undefined') {
      if (request.values[0] === 'VMN') {
        if (typeof brand !== 'undefined') {
          const platformList = lineItems[0].activities[0].instructions.filter((inst) => inst['label'] === 'platformList');
          if (platformList[0] && platformList[0].values.length > 0) {
            platformList[0].values.forEach(res => {
              if (res === 'CUSTOM') {
                const resultCustom = lineItems[0].activities[0].instructions.findIndex((inst) => inst['type'] === res && inst['label'] === 'Description');
                hasAllRequiredFields = hasAllRequiredFields && resultCustom >= 0 ? true : false;
              } else {
                const result = lineItems[0].activities[0].instructions.filter((inst) => inst['type'] === res);
                const brandObj = orderGraphicsFormFields.RequestType[res];
                let count = 0;
                let isCustomChecked = false;

                brandObj[1].options.forEach(obj => {
                  const optionsObj = result.filter(resl => resl.label === obj.key);
                  if (optionsObj.length > 0) {
                    isCustomChecked = optionsObj[0].label === 'Custom' ? true : false;
                    count++;
                  }
                });

                if (count > 0 && hasAllRequiredFields) {
                  hasAllRequiredFields = true;
                } else {
                  hasAllRequiredFields = false;
                }
                if (isCustomChecked) {
                  const resultCustom = lineItems[0].activities[0].instructions.findIndex((inst) => inst['type'] === res && inst['label'] === 'dimensions');
                  hasAllRequiredFields = resultCustom >= 0 && hasAllRequiredFields ? true : false;
                }
              }
            });
          } else {
            hasAllRequiredFields = false;
          }
        }

        if (lineItems[0]['graphicsInstructionsMetadata']) {
          if (!lineItems[0]['graphicsInstructionsMetadata']['noOfDelivarables'] || !lineItems[0]['graphicsInstructionsMetadata']['noOfDelivarables'][0]) {
            hasAllRequiredFields = false;
          }
        } else {
          hasAllRequiredFields = false;
        }
      } else {
        hasAllRequiredFields = true;
      }
    }
    return hasAllRequiredFields;
  }

  checkForDueDateReason(lineItems) {
    const index = lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'dueDateReason');
    if (index >= 0) {
      if (lineItems[0].activities[0].instructions[index].values[0].length > 0) {
        return true;
      }
    }
    return false;
  }

  checkPressForm(lineItems) {
    let hasAllRequiredFields = false;
    const request = lineItems.activities[0].instructions.filter(item => item.label === 'requestType')[0];
    if (typeof request !== 'undefined') {
      const requestObj = orderPressFormFields.RequestType[request.values[0]];
      if (typeof requestObj !== 'undefined') {
        requestObj.forEach(obj => {
          switch (obj.key) {
            case 'DeliveryMethod':
              const deliverMethod = this.checkInstructionsArrayForKey(obj.key, lineItems.activities[0].instructions);
              if (deliverMethod && deliverMethod.values[0] === 'Other') {
                const deliveryLocation = this.checkInstructionsArrayForKey('deliveryLocation', lineItems.activities[0].instructions);
                hasAllRequiredFields = deliveryLocation;
              } else {
                hasAllRequiredFields = true;
              }
              break;
           /*  case 'VideoOptions':
              let count = 0;
              obj.options.forEach(o => {
                if (this.checkInstructionsArrayForKey(o.key, lineItems.activities[0].instructions)) {
                  count++;
                }
              });
              hasAllRequiredFields = hasAllRequiredFields && count > 0;
              break; */
          }
        });
      }
    }
    return hasAllRequiredFields;
  }

  validateNewVideoOrderInstructions(order: BridgeDS.Order) {
    switch (order.metadata.requestType) {
      case OrderRequestTypes.TRANSCRIPTS:
        return this.validateVideoTranscriptOrder(order);
      case OrderRequestTypes.CAPTIONS:
        return true;
      case OrderRequestTypes.STILL_FRAMES:
        return true;
      case OrderRequestTypes.SAA:
        return this.validateVideoSAAOrder(order);
      case OrderRequestTypes.SOCIAL:
        return true;
      default:
        break;
    }
    return false;
  }

  validateVideoTranscriptOrder(order: BridgeDS.Order) {
    let hasAllRequiredFields = false;
    if (order.metadata.orderInstruction) {
      if (!isEmpty(order.metadata.orderInstruction.budgetCode) && !isEmpty(order.metadata.orderInstruction.deliveryFormat) && !isEmpty(order.metadata.orderInstruction.dueDateTime)) {
        hasAllRequiredFields = true;
      } else {
        hasAllRequiredFields = false;
      }
    }
    return hasAllRequiredFields;
  }

  validateVideoSAAOrder(order: BridgeDS.Order) {
    let hasAllRequiredFields = false;
    if (order.metadata.orderInstruction) {
      if (!isEmpty(order.metadata.orderInstruction.dropOffLocation) && !isEmpty(order.metadata.orderInstruction.captionsBillingGroup) && !isEmpty(order.metadata.orderInstruction.dueDateTime) && !isEmpty(order.metadata.orderInstruction.publishDateTime)) {
        hasAllRequiredFields = true;
      } else {
        hasAllRequiredFields = false;
      }
    }
    return hasAllRequiredFields;
  }

  validateDueDateTime(order: BridgeDS.Order) {
    return !isEmpty(order.metadata.orderInstruction.dueDateTime) && !this.orderDetailsScheduleService.isPast(order.metadata.orderInstruction.dueDateTime);
  }

  validatePublishDateTime(order: BridgeDS.Order) {
    return !isEmpty(order.metadata.orderInstruction.publishDateTime) && !this.orderDetailsScheduleService.isPast(order.metadata.orderInstruction.publishDateTime);
  }

  checkInstructionsArrayForKey(label, instructions) {
    const reqIndex = instructions.findIndex(inst => inst.label === label);
    if (reqIndex >= 0) {
      return instructions[reqIndex];
    } else {
      return undefined;
    }
  }

  getLastCompletedOrderStep(orderData) {
    let route;
    const status = this.generateOrderProgress(orderData, orderData.lineItemsClipId);
    for (let i = 0; i < status.length - 1; i++) {
      if (!status[i].stepCompleted && indexOf(status[i].orderType, orderData.metadata.orderType.toLowerCase()) >= 0 && this.getVideoOrderStep(orderData, status[i].step)) {
        route = status[i];
        break;
      }
    }
    if (typeof route === 'undefined' && orderData.metadata.orderType.toLowerCase() === OrderTypes.Press ) {
      return status[5];
    }
    if (typeof route === 'undefined' && (orderData.metadata.orderType.toLowerCase() === OrderTypes.Video && orderData.metadata.requestType && orderData.metadata.requestType === OrderRequestTypes.SAA)) {
      return status[3];
    }
    if (typeof route === 'undefined' && (orderData.metadata.orderType.toLowerCase() === OrderTypes.Video && orderData.metadata.requestType)) {
      return status[2];
    }
    return route || status[5];
  }

  getVideoOrderStep(orderData, step) {
    if (orderData.metadata.orderType.toLowerCase() === OrderTypes.Video) {
      if (!orderData.metadata.requestType) {
          return step === 'endpoint' || step === 'schedule' || step === 'instructions' || step === 'review' || step === 'submit';
      }
      if (orderData.metadata.requestType) {
        return (orderData.metadata.requestType === OrderRequestTypes.SAA && step === 'metadata') || step === 'instruction' || step === 'assets' || step === 'review' || step === 'submit';
      }
    } else {
      return true;
    }
  }

  getLastCompletedNonVideoOrderStep(orderPayload) {
    let route;
    const status = this.generateOrderProgress(orderPayload, orderPayload.lineItems, orderPayload.metadata.orderType.toLowerCase());
    for (let i = 0; i < status.length - 1; i++) {
      if (status[i].orderType.indexOf(OrderTypes.Graphics) > -1 || status[i].orderType.indexOf(OrderTypes.Copy) > -1) {
        if (!this.defaultOptions[i].stepCompleted) {
          if (i === 3 && orderPayload.metadata.orderType.toLowerCase() === OrderTypes.Copy) { // approvals page
            route = this.defaultOptions[2];  // if approvals step is not completed, route to the instructions page because its optional
          } else {
            route = this.defaultOptions[i];
          }
          break;
        }
      }
    }
    return route || this.defaultOptions[5];
  }

  isSubmitEnabled() {
    return this.isSubmitReady;
  }

  resetDefaultOptions() {
    forEach(this.defaultOptions, function (option) {
      option.stepReady = false;
      option.stepCompleted = false;
    });
    return this.defaultOptions;
  }

  updateOrder(orderData) {
    const tmp = cloneDeep(orderData);
    delete tmp.lineItemsClipId;
    delete tmp.groupedLineItemsByClipId;
    if (orderData.metadata.orderType.toLowerCase() === OrderTypes.Video) {
      this.loadingMask.enableLoadingMask();
      this.initOrderActivities(tmp);
    }
    map(tmp.lineItems, (item) => {
      delete item['videoInstructionsMetadata'];
      delete item['publishInstructionsMetadata'];
      delete item['graphicsInstructionsMetadata'];
      delete item['endpoint_info'];
      delete item['lineItemId'];
      delete item['format_description'];
      delete item['opened'];
      delete item['dateError'];
      delete item['n'];
      /**
       * setting inputs array from lineitem => activities of typeId 1 to an empty object
       */
      if (item['activities'] && item['activities'].length) {
        if (orderData.metadata.orderType.toLowerCase() === OrderTypes.Video) {
          const videoActivityIndex =
            indexOf(item['activities'], find(item['activities'], (activity) => {
              if (activity['typeId'] === 1) {
                return activity;
              }
            }));
          if (videoActivityIndex >= 0) {
            item['activities'][videoActivityIndex].input = {};
          }
        } else {
          if (item['activities'][0] && orderData.metadata.orderType.toLowerCase() !== OrderTypes.Press) {
            item['activities'][0].input = {};
          }
        }
      }
    });
    return this.ordersService.modifyOrder(tmp.id, tmp);
  }

  saveOrder(order, alertMsg?: string, onComplete?) {
    this.loadingMask.enableLoadingMask();
    this.updateOrder(order)
      .subscribe(
        data => {
          this.getOrderStore().loadInitialModel(data);
          if (alertMsg && alertMsg.length > 0) {
            this.systemAlertsService.addSuccessAlerts(alertMsg);
          }
          if (order['lineItems'].length === 0) {
            // this.initOrderActivities();
            this.router.navigate(['/orders/' + order.id + '/draft/assets']);
          }
          this.ordersService.getOrder(order.id).subscribe(
            updatedData => {
              this.loadingMask.disableLoadingMask();
              this.orderStore.loadInitialModel(updatedData, updatedData.metadata.orderType);
              if (onComplete) {
                onComplete();
              }
            },
            error => {
              console.log('Order could not be updated. error: ', error);
              this.loadingMask.disableLoadingMask();
              this.systemAlertsService.addErrorAlerts(
                'Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
              if (onComplete) {
                onComplete();
              }
            }
          );
        },
        error => {
          console.log('Order could not be submitted. error: ', error);
          this.loadingMask.disableLoadingMask();
          this.systemAlertsService.addErrorAlerts(
            'Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
          if (onComplete) {
            onComplete();
          }
        }
      );
  }

  initOrderActivities(orderData) {
    // init activities on page loads and on adding versions, to obtain activity id for uploading attachment metadata
    // only called by Video & Captions orders
    let modified = false;
    const composeActivity = this.generateNewActivity(1, '');
    const publishActivity = this.generateNewActivity(13);
    const qaActivity = this.generateNewActivity(16, this.utilityService.activityTypes.QA_VIDEO.description);
    forEach(orderData.lineItems, (item) => {
      if ((item['activities'] === undefined || !item['activities'].length) && item.customConfig) {
        item['activities'] = [];
        item['activities'].push(composeActivity);
        item['activities'].push(publishActivity);
        if (item.customConfig && item.customConfig.endpoint === 'Viacom Sites & Apps' && this.isVideoWithCaptioning(item)) {
          item.activities.push(qaActivity);
        }
        modified = true;
      }
    });
  }

  isVideoWithCaptioning(lineItem: LineItem) {
    const composeActivity = this.utilityService.getLineItemActivity(1, lineItem);
    if (composeActivity && composeActivity.instructions) {
      const versionType = find(composeActivity.instructions, instruction => instruction['label'] === 'versionType');
      if (versionType && versionType['values'][0] === 'Video with captioning') {
        return true;
      }
    }
    return false;
  }

  generateNewActivity(type: number, description?: string) {
    const activity = new Activity();
    activity.description = description ? description : '';
    if (type === this.utilityService.activityTypes.CREATE_VIDEO.type) {
      activity.typeId = type;
      activity.input = { attachments: [] };
      activity.instructions = this.setDefaultActivityInstructions('videoInstructions');
      activity.subActivities = [];
    }
    if (type === this.utilityService.activityTypes.PUBLISH_VIDEO.type) {
      activity.typeId = type;
      activity.quantity = 1;
      activity.description = this.utilityService.activityTypes.PUBLISH_VIDEO.description;
      activity.generationMode = this.utilityService.activityGenerationMode.Automatic;
    }
    if (type === this.utilityService.activityTypes.QA_VIDEO.type) {
      activity.typeId = type;
    }
    return activity;
  }

  setDefaultActivityInstructions(formField: string, versionType: string = 'Video with captioning'): Array<Instructions> {
    const defaultMetadata = [];
    if (formField === 'videoInstructions') {
      defaultMetadata.push({
        label: 'versionType',
        values: [versionType]
      },
      {
        label: 'aspectRatio',
        values: ['16 : 9']
      },
      {
        label: 'fileDropOffLocation',
        values: ['']
      });
      switch (versionType) {
        case 'Video with captioning':
        case 'Caption file only':
          defaultMetadata.push({
            label: 'captions',
            values: ['Deliver a closed caption file (SRT, SCC, etc.)']
          });
          break;
        case 'Still frames only':
          defaultMetadata.push({
            label: 'stillFrames',
            values: [1]
          });
          break;
      }
    } else if (formField === 'publishInstructions') {
      defaultMetadata.push(
        {
          label: 'subFranchise',
          values: ['Acceptance Speech']
        },
        {
          label: 'primarySiteCategory',
          values: ['Shows']
        }
      );
    } else if (formField === 'videoCopyInstructions') {
      // as for now, this act like placeholder to keep some property living so videoCopyInstructionsMetadata won't be deleted when update form
      defaultMetadata.push(
        {
          label: 'videoTitle',
          values: ['']
        }
      );
    }
    return defaultMetadata;
  }

  updateOrderName(order, name) {
    this.ordersService.updateOrderName(order.id, name).subscribe(
      data => {
        this.systemAlertsService.addSuccessAlerts('Order name has been updated successfully.');
        order.name = data.name;
      },
      error => {
        this.systemAlertsService.addErrorAlerts('Error: Order name could not be updated. Please try again');
      }
    );
  }

  submitOrder(orderId) {
    return this.ordersService.placeOrder(orderId);
  }

  saveRouteData(routeData) {
    this.routeData = routeData;
  }

  getRouteData() {
    return this.routeData;
  }

}
