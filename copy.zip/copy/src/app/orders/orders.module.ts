import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { OrdersRoutesModule } from './orders-routes.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { OrdersComponent } from './orders/orders.component';
import { OrdersService } from './orders/orders.service';
import { OrderDetailsPlatformComponent } from './order-details-platform/order-details-platform.component';
import { OrderDetailsFormatComponent } from './order-details-format/order-details-format.component';
import { OrderDetailsInstructionsComponent } from './order-details-instructions/order-details-instructions.component';
import { OrderDetailsApprovalComponent } from './order-details-approval/order-details-approval.component';
import { OrderDetailsScheduleComponent } from './order-details-schedule/order-details-schedule.component';
import { OrderDetailsReviewComponent } from './order-details-review/order-details-review.component';
import { OrderProgressTrackerComponent } from './order-progress-tracker/order-progress-tracker.component';
import { OrderProgressTrackerService } from './order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsScheduleService } from './order-details-schedule/order-details-schedule.service';
import { OrderDetailsFormatService } from './order-details-format/order-details-format.service';
import { OrderDetailsPackageService } from './order-details-package/order-details-package.service';
import { OrderDetailsSideBarComponent } from './order-details-side-bar/order-details-side-bar.component';
import { OrderCustomizationBaseComponent } from './order-customization-base/order-customization-base.component';
import { OrderCustomizationBaseService } from './order-customization-base/order-customization-base.service';
import { OrdersBaseComponent } from './orders-base/orders-base.component';
import { OrderDetailsHeaderComponent } from './order-details-header/order-details-header.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { UtilityService } from '../services/utility.service';
import { ModalModule } from 'app/shared/ng-modal';
import { OrdersViewComponent } from './orders-view/orders-view.component';
import { CatalogService } from '../catalog/catalog.service';
import { EndpointProfileService } from '../services/endpoint-profile.service';
import { OrderStore } from '../models/order-store';
import { OrderDraftRouteGuard } from './route-guard/order-draft-route-guard';
import { OrderSubmittedRouteGuard } from './route-guard/order-submitted-route-guard';
import { OrderLinkingComponent } from './order-links/order-links.component';
import { OrderInstructionsFormComponent } from './order-details-format/instructions-forms/order-instructions-form/order-instructions-form.component';
import { PublishInstructionsFormComponent } from './order-details-format/instructions-forms/publish-instructions-form/publish-instructions-form.component';
import { CopyInstructionsFormComponent } from './order-details-format/instructions-forms/copy-instructions-form/copy-instructions-form.component';
import { OrderListRouteGuard } from './route-guard/order-list-route-guard';
import { OrderDetailsAssetComponent } from './order-details-asset/order-details-asset.component';
import { OrderDetailsAssetService } from './order-details-asset/order-details-asset.service';
import { OrderDraftNavigatorComponent } from './order-draft-navigator/order-draft-navigator.component';
import { OrderDetailsAssetFormComponent } from './order-details-asset/order-details-asset-form/order-details-asset-form.component';
import { OrderDetailsMetadataComponent } from './order-details-metadata/order-details-metadata.component';


@NgModule({
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    CommonModule,
    FormsModule,
    OrdersRoutesModule,
    SharedModule,
    ModalModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    OrdersComponent,
    OrderDetailsPlatformComponent,
    OrderDetailsFormatComponent,
    OrderDetailsInstructionsComponent,
    OrderDetailsApprovalComponent,
    OrderDetailsScheduleComponent,
    OrderDetailsReviewComponent,
    OrderProgressTrackerComponent,
    OrderDetailsSideBarComponent,
    OrderCustomizationBaseComponent,
    OrdersBaseComponent,
    OrderDetailsHeaderComponent,
    OrderDetailsComponent,
    OrdersViewComponent,
    OrderLinkingComponent,
    OrderInstructionsFormComponent,
    PublishInstructionsFormComponent,
    CopyInstructionsFormComponent,
    OrderDetailsAssetComponent,
    OrderDraftNavigatorComponent,
    OrderDetailsAssetFormComponent,
    OrderDetailsMetadataComponent
  ],
  providers: [
    CatalogService,
    EndpointProfileService,
    UtilityService,
    OrdersService,
    OrderProgressTrackerService,
    OrderDetailsScheduleService,
    OrderCustomizationBaseService,
    OrderDetailsFormatService,
    OrderDetailsPackageService,
    OrderDetailsAssetService,
    OrderStore,
    OrderDraftRouteGuard,
    OrderSubmittedRouteGuard,
    OrderListRouteGuard
  ]
})
export class OrdersModule { }
