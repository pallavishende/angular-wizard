/* tslint:disable:no-unused-variable */
import { TestBed, async, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ModalModule } from "app/shared/ng-modal";
import { HttpClientModule } from '@angular/common/http';
import { Http, Response, ResponseOptions, BaseRequestOptions, } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/of';

import { OrderStore } from '../../models/order-store';
import { UtilityService } from '../../services/utility.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UserService } from '../../services/user.service';
import { StorageService } from '../../services/storage.service';

import { OrdersService } from '../orders/orders.service';
import { OrderCustomizationBaseService } from '../order-customization-base/order-customization-base.service';
import { OrderDetailsFormatComponent } from './order-details-format.component';
import { OrderDetailsFormatService } from './order-details-format.service';
import { OrderDetailsPackageService } from '../order-details-package/order-details-package.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { AdalService } from '../../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { LoginService } from "../../login/login.service";
import { RouterTestingModule } from '@angular/router/testing';
import { SecretService } from "../../services/secret.service";
import { ConfigurationManagerService} from '../../configuration/configuration-manager.service';
import { EnvironmentService } from '../../services/environment.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { LineItem } from '../../models/line-item';

xdescribe('OrderDetailsFormatComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  let lineItem = {
    id: 1112312,
    vmid: 'abcd-efgh-ijkl-mnop',
    currentState: {
      'status': "TO_DO"
    },
    activities: [
      {
        'typeId': 1,
        'assignedUserEmail': '',
        'quantity': 3,
        'subActivities': [
          {
            'typeId': 7,
            'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
            'currentState': {
              'status': "WAITING"
            },
          }
        ],
        'currentState': {
          'status': "TO_DO"
        },
      },
      {
        'typeId': 3,
        'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
        'quantity': 1,
        'subActivities': [
          {
            'typeId': 7,
            'assignedUserEmail': 'Samir.Patel@viacomcontractor.com',
            'currentState': {
              'status': "WAITING"
            },
          }
        ],
        'currentState': {
          'status': "TO_DO"
        },
      },
      {
        'typeId': 13,
        'assignedUserEmail': '',
        'quantity': 1,
        'subActivities': [],
        'currentState': {
          'status': "TO_DO"
        },
      }
    ]
  };
  let order = {
    id: 1111,
    to: 1233,
    order_for: 12312,
    creator: 'J Unit',
    name: 'TEST ORDER FOR J UNIT',
    metadata: {
    },
    dsid: 'VBDSID',
    currentMilestone: {
      status: 'TO_DO',
      last_modified_date: '00000000',
      last_modified_by: 'J UNIT'
    },
    milestones: [{
      status: 'TO_DO',
      last_modified_date: '00000000',
      last_modified_by: 'J UNIT'
    }],
    lineItems: [lineItem],
    lineItemVmid: [lineItem]
  };

  let mockFormatService = {
      get: () => {}
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, ModalModule, RouterTestingModule ],
      declarations: [ OrderDetailsFormatComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { OrderCustomizationBaseService },
        {provide: OrderDetailsFormatService, useValue: mockFormatService},
        {provide: OrderDetailsPackageService, useValue: mockFormatService},
        {provide: OrderProgressTrackerService, useValue: mockFormatService},
        OrderStore,
        OrdersService,
        UtilityService,
        StorageService,
        {
          provide: ActivatedRoute, useValue: {
            params: Observable.of({ id: 'test' })
          }
        },
        SystemAlertsService,
        EndpointProfileService,
        ConfigService,
        LoadingMaskService,
        MockBackend,
        UserService,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http)=> http,
          deps: [Http]
        },
        LoginService,
        AdalService,
        SecretService,
        ConfigurationManagerService,
        EnvironmentService
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OrderDetailsFormatComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    //app = fixture.debugElement.componentInstance; // to access properties and methods
    app = fixture.componentInstance; // to access properties and methods
    //fixture.detectChanges();
  }));

  beforeEach(inject([OrderDetailsFormatService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  it('should create format component', async(() => {
    expect(app).toBeDefined();
  }));

  it('should have ngOnInit defined', () => {
    spyOn(mockFormatService, 'get').and.returnValue(Observable.of(order));
    expect(app.ngOnInit).toBeDefined();
  });

  it('#hasMoreThenOne: should return 1 object for abcd-efgh-ijkl-mnop', () => {
    app.order = order;
    let result = app.hasMoreThenOne('abcd-efgh-ijkl-mnop');
    expect(result.length).toEqual(1);
  });

  it('#getFormatActivity: should return 1 object', () => {
    let result = app.getFormatActivity(lineItem);
    expect(result).toEqual(jasmine.any(Object));
  });

  it('#deleteVersion: should create deleteOptions object', () => {
    app.deleteVersion(lineItem);
    expect(app.deleteModalOptions).toBeDefined();
  });

  it('should have dataSubscription defined', async(() => {
    spyOn(mockFormatService, 'get').and.returnValue(Observable.of(order));
    app.initialize();
    expect(app.dataSubscription).toBeDefined();
  }));

});
