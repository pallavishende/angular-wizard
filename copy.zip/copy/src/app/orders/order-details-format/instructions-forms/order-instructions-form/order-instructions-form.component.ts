import { Component, OnInit, OnChanges, OnDestroy, SimpleChanges, Input, Output, EventEmitter } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { Observable } from 'rxjs/Observable';
import { cloneDeep, forEach, indexOf, find, keys } from 'lodash';
import { OrderDetailsFormatService } from '../../../order-details-format/order-details-format.service';
import { OrderInstructionFormFields } from '../../../../models/generic-form-field';
import { UtilityService } from '../../../../services/utility.service';
import { Activity } from '../../../../models/activity';
import { LineItem } from '../../../../models/line-item';
import { Order } from '../../../../models/order';
import { EnvironmentService } from '../../../../services/environment.service';

@Component({
  selector: 'app-order-instructions-form',
  templateUrl: './order-instructions-form.component.html',
  styleUrls: ['./../instructions-forms.scss']
})
export class OrderInstructionsFormComponent implements OnInit, OnChanges, OnDestroy {
  // TO DO: integrate order draft formatting step with this component
  @Input() order;
  @Input() selectedLineItem;
  @Input() updateOrderEvent: Observable<string>;
  @Input() isNewForm: boolean;
  @Input() instructionsFormEndpoint: string;
  @Output() updatedOrder = new EventEmitter<any>();
  @Output() versionTitle = new EventEmitter<any>();
  @Output() isValid = new EventEmitter<any>();

  instructionsFormFields: OrderInstructionFormFields;
  instructionsFormObj;
  selectedLineItemRef: LineItem;
  orderRef: Order;
  initializeEditor: boolean;
  orderUpdateSubscription: Subscription;
  subscriptions = new Subscription();
  isEnvGreaterThanUAT = false;

  constructor(private orderDetailsFormatService: OrderDetailsFormatService, 
              private utilityService: UtilityService,
              private environmentService: EnvironmentService) {
                this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
              }

  ngOnInit() {
    if (typeof this.updateOrderEvent !== 'undefined') {
      this.orderUpdateSubscription = this.updateOrderEvent.subscribe((data) => {
        if (this.isNewForm) {
          const instructionsPayload = this.constructInstructionsPayload(this.instructionsFormObj);
          this.updatedOrder.emit(instructionsPayload);
        } else {
          let targetLineItemIndex;
          forEach(this.orderRef.lineItems, (lineItem, index) => {
            if (lineItem.id === this.selectedLineItemRef.id) {
              targetLineItemIndex = index;
              return false;
            }
          });
          this.orderRef.lineItems[targetLineItemIndex] = cloneDeep(this.selectedLineItemRef);
          this.updatedOrder.emit(this.orderRef);
        }
      });
      this.subscriptions.add(this.orderUpdateSubscription);
    }
    this.initializeInstructionsForm();
    this.initializeOrderModification();
    this.initializeCustomEditor();
    this.isValid.emit(this.validateInstructionsFormObj());
  }

  initializeCustomEditor() {
    setTimeout(() => {
      this.initializeEditor = true;
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (typeof changes['selectedLineItem'] !== 'undefined' &&
      typeof changes['selectedLineItem'].currentValue !== 'undefined' &&
      typeof this.selectedLineItemRef === 'undefined') {
      this.selectedLineItemRef = cloneDeep(this.selectedLineItem);  // lodash clone
    }
    if (typeof changes['order'] !== 'undefined' &&
      typeof changes['order'].currentValue !== 'undefined') {
      this.orderRef = cloneDeep(this.order);  // lodash clone
    }
    // the following needs to be dynamic
    if (typeof changes['instructionsFormEndpoint'] !== 'undefined' &&
        typeof changes['instructionsFormEndpoint'].currentValue !== 'undefined' &&
        changes['instructionsFormEndpoint'].currentValue === 'Viacom Sites & Apps') {
          this.instructionsFormObj.aspectRatio = '16 : 9';
        }
  }

  initializeInstructionsForm() {
    this.subscriptions.add(this.orderDetailsFormatService.getOrderInstructictionsFormFields().subscribe((data: OrderInstructionFormFields) => {
      this.instructionsFormFields = data;
    }));
  }

  initializeOrderModification(versionType?: string) {
    this.instructionsFormObj = {
      // versionType is defined when reset modal on changing version type
      versionTitle: versionType ? this.instructionsFormObj.versionTitle : '',
      versionType: versionType || 'Video with captioning',
      aspectRatio: '16 : 9',
      captions: versionType !== 'Still frames only' ? ['Deliver a closed caption file (SRT, SCC, etc.)'] : [],
      stillFrames: versionType !== 'Still frames only' ? 0 : 1,
      slatesAndGraphics: [],
      slatesAndGraphicsSourceInfo: '',
      budgetCode: '',
      fileDropOffLocation: '',
      additionalNotes: ''
    };
  }

  updateInstructionsForm(value: string, valueKey: string, isTextType?: boolean) {
    const metadataObj = {
      'label': valueKey,
      'values': [value]
    };
    let lineItemActivity: Activity;
    let formFields;
    lineItemActivity = this.utilityService.getLineItemActivity(1, this.selectedLineItemRef);
    formFields = this.instructionsFormFields;
    const selectedMetadataItemIndex = this.getArrayItemIndex(lineItemActivity.instructions, valueKey);
    if (selectedMetadataItemIndex < 0) {
      lineItemActivity.instructions.push(metadataObj);
    } else {
      if (formFields[valueKey].multiSelection) {
        lineItemActivity.instructions[selectedMetadataItemIndex].values.push(value);
      } else {
        if (this.isNewForm) {
          this.instructionsFormObj[valueKey] = value.trim();
        } else {
          if (isTextType) {
            if (value !== '') {
              lineItemActivity.instructions[selectedMetadataItemIndex].values[0] = value;
            } else {
              lineItemActivity.instructions.splice(selectedMetadataItemIndex, 1);
            }

          } else {
            lineItemActivity.instructions[selectedMetadataItemIndex] = metadataObj;
            this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.orderRef);
          }
        }
      }
    }
    if (!this.isNewForm) {
      this.syncOrderIntructionUpdates();
    }
    this.isValid.emit(this.validateInstructionsFormObj());
  }

  /**
   *
   * @param event : input type checkbox check/uncheck event
   * @param metadataType : target form field
   * @param value : checked/unchecked
   */
  checkboxHandler(event, metadataType, value?) {
    const videoActivity = this.utilityService.getLineItemActivity(1, this.selectedLineItemRef);
    const metadataIndex = this.getArrayItemIndex(videoActivity.instructions, metadataType);
    let videoActivityIndex;
    forEach(this.selectedLineItemRef.activities, (activity, index) => {
      if (activity['id'] === videoActivity['id']) {
        videoActivityIndex = index;
        return false; // breaking out of the loop
      }
    });
    switch (metadataType) {
      case 'stillFrames':
        if (event.target.checked) {
          if (this.isNewForm) {
            this.instructionsFormObj.stillFrames = 1;
          } else {
            const stillFramesMetadata = {
              label: metadataType,
              values: [1]
            };
            videoActivity.instructions.push(stillFramesMetadata);
          }
        } else {
          if (this.isNewForm) {
            this.instructionsFormObj.stillFrames = 0;
          } else {
            videoActivity.instructions.splice(metadataIndex, 1);
          }
        }
        break;
      default:
        if (event.target.checked) {
          if (this.isNewForm) {
            this.instructionsFormObj[metadataType].push(value);
          } else {
            if (metadataIndex > -1) {
              videoActivity.instructions[metadataIndex].values.push(value);
            } else {
              const metadataPayload = {
                'label': metadataType,
                'values': [value]
              };
              videoActivity.instructions.push(metadataPayload);
            }
          }
        } else {
          if (this.isNewForm) {
            const valueIndex = indexOf(this.instructionsFormObj[metadataType], value);
            this.instructionsFormObj[metadataType].splice(valueIndex, 1);
          } else {
            const metadataIndex = this.getArrayItemIndex(videoActivity.instructions, metadataType);
            const valueIndex = indexOf(videoActivity.instructions[metadataIndex].values, value);
            videoActivity.instructions[metadataIndex].values.splice(valueIndex, 1);
            if (videoActivity.instructions[metadataIndex].values.length === 0) {
              videoActivity.instructions.splice(metadataIndex, 1);
            }
          }
        }
        break;
    }
    if (value === 'Deliver/include transcript file') {
      this.updateInstructionsForm('', 'budgetCode', true);
    }
    // if slate and graphics becomes none, clear slatesAndGraphicsSourceInfo form field
    if (metadataType === 'slatesAndGraphics' && metadataIndex === -1) {
      this.updateInstructionsForm('', 'slatesAndGraphicsSourceInfo', true);
    }
    if (!this.isNewForm) {
      this.syncOrderIntructionUpdates();
    }
    this.isValid.emit(this.validateInstructionsFormObj());
  }

  syncOrderIntructionUpdates() {
    let selectedLineItemIndex;
    forEach(this.orderRef.lineItems, (lineItem, index) => {
      if (lineItem.id === this.selectedLineItemRef.id) {
        selectedLineItemIndex = index;
        return false; // breaking out of the loop
      }
    });
    this.orderRef.lineItems[selectedLineItemIndex] = this.selectedLineItemRef;
    this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.orderRef);
  }

  contentChanged(event) {
    let eventContent;
    if (typeof event.content === 'undefined' || event.content.toString().replace(/&nbsp;|\s/g, '') === '') {
      eventContent = '';
    } else {
      eventContent = event.content;
    }
    if (this.isNewForm) {
      this.instructionsFormObj.additionalNotes = eventContent;
    } else {
      const videoActivity = this.getLineItemVideoActivity();
      videoActivity.description = eventContent;
    }
  }

  getArrayItemIndex(array: Array<any>, itemKey: string): number {
    let itemIndex = -1;
    forEach(array, (value, index) => {
      if (value.label === itemKey) {
        itemIndex = index;
        return;
      }
    });
    return itemIndex;
  }

  getAspectRatioIcon(label: string) {
    return 'ratio-' + label.replace(':', '-').replace(/[^0-9-]/g, '');
  }

  getLineItemVideoActivity() {
    return find(this.selectedLineItemRef.activities, { 'typeId': 1 });
  }

  updateStillFramesQuantity(addStillFrames: boolean) {
    if (this.isNewForm) {
      if (addStillFrames) {
        this.instructionsFormObj.stillFrames++;
      } else {
        if (this.instructionsFormObj.stillFrames > 0) {
          this.instructionsFormObj.stillFrames--;
        }
      }
    } else {
      const videoActivity = this.utilityService.getLineItemActivity(1, this.selectedLineItemRef);
      const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, 'stillFrames');
      if (stillFramesMetadataIndex > -1) {
        if (addStillFrames) {
          videoActivity.instructions[stillFramesMetadataIndex].values[0]++;
        } else {
          const stillFramesQuantity = videoActivity.instructions[stillFramesMetadataIndex].values[0];
          if (stillFramesQuantity > 1) {
            videoActivity.instructions[stillFramesMetadataIndex].values[0]--;
          }
        }
        this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
        this.syncOrderIntructionUpdates();
      }
    }
  }

  resetVideoInstructionsForm(value: string) {
    if (this.isNewForm) {
      this.initializeOrderModification(value);
    } else {
      const videoActivity = this.getLineItemVideoActivity();
      videoActivity.instructions = this.orderDetailsFormatService.setDefaultActivityInstructions('videoInstructions', value);
      videoActivity.description = '';
      this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.orderRef);
      this.syncOrderIntructionUpdates();
    }
    this.isValid.emit(this.validateInstructionsFormObj());
  }

  constructInstructionsPayload(object: any): Array<any> {
    this.removeNullPropertiesFromObj(object);
    const instructionsPayloadArray: Array<any> = [];
    forEach(keys(object), propertyKey => {
      instructionsPayloadArray.push(
        {
          'label': propertyKey,
          'values': Array.isArray(object[propertyKey]) ? object[propertyKey] : [object[propertyKey]]
        }
      );
    });
    return instructionsPayloadArray;
  }

  removeNullPropertiesFromObj(object: any) {
    forEach(keys(object), propertyKey => {
      if (this.instructionsFormObj[propertyKey] === '' ||
        this.instructionsFormObj[propertyKey] === 0) {
        delete this.instructionsFormObj[propertyKey];
        return;
      }
      if (Array.isArray(this.instructionsFormObj[propertyKey])) {
        if (this.instructionsFormObj[propertyKey].length === 0) {
          delete this.instructionsFormObj[propertyKey];
          return;
        }
      }
    });
  }

  onFocus(event) {
    event.target.select();
  }

  setVersionTitle(event) {
    const versionTitleValue = event.target.value.trim();
    if (this.isNewForm) {
      this.instructionsFormObj.versionTitle = versionTitleValue;
    } else {
      this.selectedLineItemRef.customConfig.version = versionTitleValue;
    }
    this.versionTitle.emit(versionTitleValue);
    this.isValid.emit(this.validateInstructionsFormObj());
  }

  validateInstructionsFormObj(): boolean {
    if (this.isNewForm) {
      if (!this.instructionsFormObj.versionTitle) {
        return false;
      }
      if (!this.instructionsFormObj.fileDropOffLocation || this.instructionsFormObj.fileDropOffLocation.length <= 0 || !this.instructionsFormObj.fileDropOffLocation[0]) {
        return false;
      }
      // if selected slates and graphics, slates and graphics source info is thus neccessary
      if (this.instructionsFormFields['slatesAndGraphics'].permittedVersionType.indexOf(this.instructionsFormObj.versionType) > -1 &&
          this.instructionsFormObj.slatesAndGraphics && this.instructionsFormObj.slatesAndGraphics.length > 0) {
        if (!this.instructionsFormObj.slatesAndGraphicsSourceInfo || this.instructionsFormObj.slatesAndGraphicsSourceInfo.trim() === '') {
          return false;
        }
      }
      // for version types that need captions selection
      if (this.instructionsFormFields['captions'].permittedVersionType.indexOf(this.instructionsFormObj.versionType) > -1) {
        if (!this.instructionsFormObj.captions || this.instructionsFormObj.captions.length <= 0 || !this.instructionsFormObj.captions[0] || this.isBudgetCodeNewFormEmpty()) {
          return false;
        }
      }
    } else if (this.selectedLineItemRef['videoInstructionsMetadata']) {
      if (!this.selectedLineItemRef.customConfig.version) { // if no version title
        return false;
      }
      if (!(this.selectedLineItemRef['videoInstructionsMetadata'].fileDropOffLocation
            && this.selectedLineItemRef['videoInstructionsMetadata'].fileDropOffLocation.length >= 1
            && this.selectedLineItemRef['videoInstructionsMetadata'].fileDropOffLocation[0])) {
        return false;
      }
      // if selected slates and graphics, slates and graphics source info is thus neccessary
      if (this.instructionsFormFields['slatesAndGraphics'].permittedVersionType.indexOf(this.selectedLineItemRef['videoInstructionsMetadata'].versionType[0]) > -1 &&
          this.selectedLineItemRef['videoInstructionsMetadata']['slatesAndGraphics']
          && this.selectedLineItemRef['videoInstructionsMetadata']['slatesAndGraphics'].length > 0) {
        if (!this.selectedLineItemRef['videoInstructionsMetadata'].slatesAndGraphicsSourceInfo || !this.selectedLineItemRef['videoInstructionsMetadata'].slatesAndGraphicsSourceInfo[0] || this.selectedLineItemRef['videoInstructionsMetadata'].slatesAndGraphicsSourceInfo[0].trim() === '') {
          return false;
        }
      }
      if (this.instructionsFormFields['captions'].permittedVersionType.indexOf(this.selectedLineItemRef['videoInstructionsMetadata'].versionType[0]) > -1) {
        if (!(this.selectedLineItemRef['videoInstructionsMetadata'].captions
            && this.selectedLineItemRef['videoInstructionsMetadata'].captions.length >= 1
            && this.selectedLineItemRef['videoInstructionsMetadata'].captions[0]
            && !this.isBudgetCodeOldFormEmpty())) {
          return false;
        }
      }
    } else {
      return false;
    }
    return true;
  }

  isBudgetCodeNewFormEmpty(): Boolean {
    return this.instructionsFormObj.captions.indexOf('Deliver/include transcript file') > -1 && (this.instructionsFormObj.budgetCode === undefined || this.instructionsFormObj.budgetCode.trim() === '');
  }

  isBudgetCodeOldFormEmpty(): Boolean {
    return this.selectedLineItemRef['videoInstructionsMetadata'].captions.indexOf('Deliver/include transcript file') > -1 && (this.selectedLineItemRef['videoInstructionsMetadata'].budgetCode === undefined || this.selectedLineItemRef['videoInstructionsMetadata'].budgetCode[0] === undefined || this.selectedLineItemRef['videoInstructionsMetadata'].budgetCode[0].trim() === '');
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

}
