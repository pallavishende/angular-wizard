import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PublishInstructionsFormComponent } from './publish-instructions-form.component';

xdescribe('PublishInstructionsFormComponent', () => {
  let component: PublishInstructionsFormComponent;
  let fixture: ComponentFixture<PublishInstructionsFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PublishInstructionsFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PublishInstructionsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
