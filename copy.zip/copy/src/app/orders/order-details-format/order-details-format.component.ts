import { Component, OnInit, OnChanges, OnDestroy, EventEmitter, ViewChild, Output } from '@angular/core';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsFormatService } from './order-details-format.service';
import { OrderDetailsPlatformService } from '../order-details-platform/order-details-platform.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsPackageService } from '../order-details-package/order-details-package.service';
import { UtilityService } from '../../services/utility.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { LineItem } from '../../models/line-item';
import { Activity, Instructions } from '../../models/activity';
import { OrderInstructionFormFields } from '../../models/generic-form-field';
import { ENTER } from '@angular/cdk/keycodes';
import { EnvironmentService } from '../../services/environment.service';
import { CatalogService } from '../../catalog/catalog.service';
import { FileUploaderService } from '../../shared/file-uploader/file-uploader.service';
import { RequestformService } from '../../shared/dynamic-form/request-form.service';
import { DynamicFormBaseService } from '../../shared/dynamic-form/dynamic-form-control.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { Modal } from 'app/shared/ng-modal';
import { forEach, uniqBy, pull, includes, remove, keys, map, indexOf, find, set, get } from 'lodash';
import { clone, cloneDeep } from 'lodash';
import { take, delay } from 'rxjs/operators';

const orderGraphicsFormFields = require('../../models/mock-payloads/order-graphic-request-instructions.json');
const orderPressFormFields = require('../../models/mock-payloads/order-press-form-instructions.json');

@Component({
  selector: 'app-order-details-format',
  templateUrl: './order-details-format.component.html',
  styleUrls: ['../../catalog/catalog-base/catalog-base.component.scss','./order-details-format.component.scss', '../order-customization-base/order-customization-base.component.scss'],
  providers: [
    OrderDetailsFormatService,
    OrderDetailsPlatformService,
    OrderDetailsPackageService,
    RequestformService,
    DynamicFormBaseService,
    FileUploaderService
  ]
})

export class OrderDetailsFormatComponent implements OnInit, OnChanges, OnDestroy {

  @ViewChild('confirmModal') confirmModal: Modal;
  @Output() isValid = new EventEmitter<any>();
  @Output() updatedOrder = new EventEmitter<any>();

  order;
  orderId;
  subscriptions = new Subscription();
  dataObservable: Observable<{}>;
  dataObservableTakeOne: Observable<{}>;
  selectedVersionIndex: number;
  counter: number;
  endpointProfiles;
  isNewLineitemAdded = false;
  deleteModalOptions = {
    version: 'NA',
    msg: '',
    btnMsg: '',
    action: () => {}
  };
  confirmModalOptions = {
    heading: '',
    msg: '',
    btnMsg: '',
    action: () => {}
  };
  isUpdatingOrder = false;
  isOrderInitialized = false;
  instructionsFormFields: OrderInstructionFormFields;
  publishingFormFields: OrderInstructionFormFields;
  videoCopyFormFields: OrderInstructionFormFields;
  graphicsInstructionsFormFields;
  graphicsInstrStaticFormFields;
  videoPressFormFields;

  publishingFormToggle = {};
  updateCustomEditor = new Subject<any>();
  separatorKeysCodes: number[] = [ENTER];
  isEnvGreaterThanUAT = false;
  formControls = [];
  dynamicRequestForm: FormGroup;
  graphicsSelectedRequest = [];
  graphicInstructions = [];
  addNewPlatform = true;
  platformTypeList = [];
  contenBrandName = undefined;
  editorDimensionTextArea = '300px';
  hideAddPlatform = false;
  showModalGraphicsDropDown = false;
  initializeEditor = true;
  initializeVideoEditor = false;
  isOpenInModal = false;
  isGraphicsFormValid = true;
  isPressFormValid = true;
  isDescriptionValid = true;
  isNoDeliverablesValid = true;
  isGraphicsScheduleValid = true;
  formValueChanges = false;
  graphicsBrandName = {
    id: '',
    value: '',
    options: []
  };

  graphicsRequestType = {
    id: '',
    value: ''
  };

  graphicsPLatformType = {
    id: '',
    value: ''
  };

  pressRequestType = {
    id: '',
    value: '',
    formType: ''
  };

  constructor(
    private router: Router,
    private ordersService: OrdersService,
    private orderDetailsFormatService: OrderDetailsFormatService,
    private orderDetailsPlatformService: OrderDetailsPlatformService,
    private orderDetailsPackageService: OrderDetailsPackageService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private utilityService: UtilityService,
    private endpointProfileService: EndpointProfileService,
    private alerts: SystemAlertsService,
    private activatedRoute: ActivatedRoute,
    private environmentService: EnvironmentService,
    private requestformService: RequestformService,
    private dynamicFormBaseService: DynamicFormBaseService,
    private catalogService: CatalogService,
    private fileUploaderService: FileUploaderService,
    private loadingMaskService: LoadingMaskService,
    private fb: FormBuilder
  ) {
    this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  ngOnInit() {
    const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
    this.orderId = undefined;
    if (snapshot.url.indexOf('/draft') > 0) {
      this.orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
      this.isOpenInModal = false;
      this.ordersService.setOrdersPageTitle('Draft - Viacom Bridge');
    } else if (snapshot.url.indexOf('/order-detail') > 0) {
      this.initializeEditor = false;
      this.orderId = snapshot.url.substring(8, snapshot.url.indexOf('/order-detail'));
      this.isOpenInModal = true;
    }

    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
    });
    this.videoPressFormFields = orderPressFormFields;
    this.graphicsRequestType = orderGraphicsFormFields.RequestTypeDropDown[0];
    this.graphicsInstructionsFormFields = orderGraphicsFormFields;
    this.graphicsInstrStaticFormFields = this.graphicsInstructionsFormFields['graphicsDetailForm'];
    this.initialize();
  }

  initializeInstructionsForm() {
    this.subscriptions.add(this.orderDetailsFormatService.getOrderInstructictionsFormFields().subscribe((data: OrderInstructionFormFields) => {
      this.instructionsFormFields = data;
    }));
    this.subscriptions.add(this.orderDetailsFormatService.getOrderPublishingFormFields().subscribe((data: OrderInstructionFormFields) => {
      this.publishingFormFields = data;
    }));
    this.subscriptions.add(this.orderDetailsFormatService.getOrderVideoCopyFormFields().subscribe((data: OrderInstructionFormFields) => {
      this.videoCopyFormFields = data;
    }));
  }

  initialize() {
    this.loadingMaskService.enableLoadingMask();
    this.initializeInstructionsForm();
    this.dataObservableTakeOne = this.orderDetailsFormatService.get().pipe(
      take(2), delay(0));
    this.initializeDynamicForm();
    this.dataObservable = this.orderDetailsFormatService.get();
    this.subscriptions.add(this.dataObservable.subscribe(
      data => {
        if (data['id'] && data['id'].toString() === this.orderId) {
          if ((data['metadata'].orderType === 'GRAPHICS' || data['metadata'].orderType === 'PRESS') && this.isOpenInModal) {
            this.order = cloneDeep(data);
          } else {
            this.order = data;
          }
          if (this.order.name && !this.isOpenInModal) {
            this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          }

          if (this.order.metadata.orderType === 'GRAPHICS') {
            this.graphicInstructions = this.order.lineItems[0].activities[0].instructions;
             if (this.isOpenInModal) {
                this.updatedOrder.emit(data);
              }
              this.isGraphicsFormValid = this.isOpenInModal && this.orderDetailsFormatService.checkGraphicsForm(this.order.lineItems);
              if (this.isOpenInModal) {
                this.isValid.emit(this.isGraphicsFormValid && this.isDescriptionValid && this.isNoDeliverablesValid && this.isGraphicsScheduleValid);
              }
          }

          if (this.order.metadata.orderType === 'PRESS') {
            if (this.order.lineItems && this.order.lineItems[0].activities && this.order.lineItems[0].activities[0].instructions.length <= 0 && this.pressRequestType.id) {
              this.setPressInstructions(this.pressRequestType.id);
            }
            if (this.isOpenInModal) {
              this.isPressFormValid = this.orderProgressTrackerService.checkPressForm(this.order.lineItems[0]);
              this.updatedOrder.emit(data);
              this.isValid.emit(this.isPressFormValid);
            }
          }
          this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
            data2 => {
              this.endpointProfiles = data2;
            }
          ));
          //this.initOrderActivities();
          this.initializeCustomEditor();
        }
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  initializeDynamicForm() {
    this.subscriptions.add(this.dataObservableTakeOne.subscribe(
      data => {
        if (data['id'] && data['id'].toString() === this.orderId) {
          this.order = data;
          if (this.order.metadata.orderType === 'GRAPHICS') {
            if (!this.isOrderInitialized) {
              this.setGraphicsDropDown();
              this.editorDimensionTextArea = '190px';
              this.isOrderInitialized = true;
            }
          } else if (this.order.metadata.orderType === 'PRESS') {
            if (!this.isOrderInitialized) {
              this.setPressDropDown();
              this.isOrderInitialized = true;
              if (this.isOpenInModal) {
                this.editorDimensionTextArea = '150px';
              }
            }
          }
        }
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  initializeCustomEditor() {
    setTimeout(() => {
      this.initializeEditor = true;
      this.initializeVideoEditor = true;
      this.loadingMaskService.disableLoadingMask();
    }, 500);
  }

  handleTags(event, target: Array<string>, lineItem, remove?: boolean): string {
    if (remove) {
      pull(target, event);
      this.updateInstructionsForm(target, 'tags', lineItem, 'publishInstructions', true);
    } else {
      const input = event.input;
      const value = event.value.trim();
      if (value) {
        // clear input field
        if (input) {
          input.value = '';
        }
        if (!target) {
          target = [];
        }
        if (includes(target, value)) {
          return;
        }
        target.push(value);
        this.updateInstructionsForm(target, 'tags', lineItem, 'publishInstructions', true);
      }
    }
  }

  updateInstructionsForm(value: any, valueKey: string, lineItem: LineItem, type: string, isTextType?: boolean) {
    if (typeof value === 'string') {
      value = [value];
    }
    const metadataObj = {
      'label': valueKey,
      'values': value,
      'type': ''
    };
    let lineItemActivity: Activity;
    let formFields;
    let isValidValue = true;
    switch (type) {
      case 'videoInstructions':
        lineItemActivity = this.utilityService.getLineItemActivity(1, lineItem);
        formFields = this.instructionsFormFields;
        break;
      case 'publishInstructions':
        lineItemActivity = this.utilityService.getLineItemActivity(13, lineItem);
        formFields = this.publishingFormFields;
        break;
      case 'videoCopyInstructions':
        lineItemActivity = this.utilityService.getLineItemActivity(13, lineItem);
        formFields = this.videoCopyFormFields;
        break;
      case 'graphicsInstructions':
        lineItemActivity = this.utilityService.getLineItemActivity(5, lineItem);
        formFields = this.graphicsInstrStaticFormFields;
        break;
    }
    const selectedMetadataItemIndex = this.getArrayItemIndex(lineItemActivity.instructions, valueKey);
    if (selectedMetadataItemIndex < 0) {
      if (value[0] && value[0].trim() !== '') {
        lineItemActivity.instructions.push(metadataObj);
        isValidValue = true;
      }
    } else {
      if (formFields[valueKey].multiSelection) {
        lineItemActivity.instructions[selectedMetadataItemIndex].values.push(value[0]);
      } else {
        if (isTextType) {
          if (formFields[valueKey].isRequiredField) {
            if (value[0].trim() !== '') {
              lineItemActivity.instructions[selectedMetadataItemIndex].values = value;
              isValidValue = true;
            } else if (valueKey === 'tags') {
              lineItemActivity.instructions[selectedMetadataItemIndex].values = value;
            } else {
              lineItemActivity.instructions.splice(selectedMetadataItemIndex, 1);
              isValidValue = false;
            }
          } else {
            if (value[0] !== '' || valueKey === 'adTargeting') {
              lineItemActivity.instructions[selectedMetadataItemIndex].values = value;
            } else {
              delete lineItemActivity.instructions[selectedMetadataItemIndex];
            }
          }
        } else {
          lineItemActivity.instructions[selectedMetadataItemIndex] = metadataObj;
        }
      }
    }
    lineItemActivity.instructions = lineItemActivity.instructions.filter(item => item !== undefined);
    /**
     * syncing istructions according to type
     */
    if (type === 'videoInstructions') {
      this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.order);
      this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
    } else if (type === 'graphicsInstructions') {
      this.orderDetailsFormatService.getOrderStore().setGraphicsInstructionsMetadata(this.order);
      this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      if (this.isOpenInModal && valueKey === 'noOfDelivarables') {
        this.isNoDeliverablesValid = isValidValue;
        this.isValid.emit(this.isGraphicsFormValid && this.isDescriptionValid && this.isNoDeliverablesValid);
      }
    } else {
      const correspondingLineItems = this.orderDetailsFormatService.getOrderStore().getCorrespondingLineItemsFromClipIdentifier(lineItem, this.order);
      this.syncPublishingInstructions(lineItemActivity.instructions, correspondingLineItems);
    }
  }

  resetVideoInstructionsForm(value: string, lineItem: LineItem) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    videoActivity.instructions = this.orderDetailsFormatService.setDefaultActivityInstructions('videoInstructions', value);
    videoActivity.description = '';
    const qaActivity = this.utilityService.getLineItemActivity(16, lineItem);
    if (lineItem.customConfig.endpoint === 'Viacom Sites & Apps' && value === 'Video with captioning') {
      if (!qaActivity) {
        const newQaActivity = this.orderDetailsFormatService.newActivity(16, this.utilityService.activityTypes.QA_VIDEO.description);
        lineItem.activities.push(newQaActivity);
      }
    } else {
      if (qaActivity) {
        remove(lineItem.activities, activity => Number(activity.typeId) === 16);
      }
    }
    this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  togglePublishingInstructionsForm(event, lineItem: LineItem, elementId: string) {
    const correspondingLineItems = this.orderDetailsFormatService.getOrderStore().getCorrespondingLineItemsFromClipIdentifier(lineItem, this.order);
    this.publishingFormToggle[elementId] = event.target.checked;
    forEach(correspondingLineItems, (item: LineItem) => {
      const publishActivity = this.utilityService.getLineItemActivity(13, item);
      if (typeof publishActivity === 'undefined' && event.target.checked) {
        if (event.srcElement.name === 'publishing-instructions') {
          this.createPublishActivity(item, 'CMSdefault');
        } else {
          this.createPublishActivity(item, 'videoCopyDefault');
        }
      } else if (typeof publishActivity !== 'undefined' && event.target.checked) {
        if (event.srcElement.name === 'publishing-instructions') {
          publishActivity.instructions = publishActivity.instructions.concat(this.orderDetailsFormatService.setDefaultActivityInstructions('publishInstructions'));
        } else if (event.srcElement.name === 'video-copy-instructions') {
          publishActivity.instructions = publishActivity.instructions.concat(this.orderDetailsFormatService.setDefaultActivityInstructions('videoCopyInstructions'));
        }
      } else if (typeof publishActivity !== 'undefined' && !event.target.checked) {
        if (event.srcElement.name === 'publishing-instructions') {
          publishActivity.instructions = this.deleteFormFieldInstructions(publishActivity.instructions, this.publishingFormFields);
        } else if (event.srcElement.name === 'video-copy-instructions') {
          publishActivity.instructions = this.deleteFormFieldInstructions(publishActivity.instructions, this.videoCopyFormFields);
        }
      }
    });
    this.orderDetailsFormatService.getOrderStore().setPublishInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  deleteFormFieldInstructions(instructions, formField) {
    if (!instructions || instructions.length <= 0) {
      return [];
    }
    forEach(keys(formField), key => {
      remove(instructions, metadata => metadata['label'] === key);
    });
    return instructions;
  }

  syncPublishingInstructions(instructions: Array<Instructions>, lineItems) {
    const rawInstructions = map(instructions, (instruction) => {
      return {
        label: instruction.label,
        values: instruction.values
      };
    });
    forEach(lineItems, (item: LineItem) => {
      const publishActivity = this.utilityService.getLineItemActivity(13, item);
      if (typeof publishActivity === 'undefined') {
        this.createPublishActivity(item, rawInstructions);
      } else if (typeof publishActivity !== 'undefined') {
        publishActivity.instructions = rawInstructions;
      }
    });
    this.orderDetailsFormatService.getOrderStore().setPublishInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  createPublishActivity(item, instructions?) {
    // 1. create if publish content activity does not exist
    const publishActivityObj = find(item.activities, (activity) => {
      return activity['typeId'] === this.utilityService.activityTypes.PUBLISH_VIDEO.type;
    });
    if (publishActivityObj === undefined) {
      const activityObj = new Activity();
      activityObj.quantity = 1;
      activityObj.typeId = this.utilityService.activityTypes.PUBLISH_VIDEO.type;
      activityObj.description = this.utilityService.activityTypes.PUBLISH_VIDEO.description;
      activityObj.generationMode = this.utilityService.activityGenerationMode.Automatic;
      if (instructions === 'CMSdefault') {
        activityObj.instructions = this.orderDetailsFormatService.setDefaultActivityInstructions('publishInstructions');
      } else if (instructions === 'videoCopyDefault') {
        activityObj.instructions = this.orderDetailsFormatService.setDefaultActivityInstructions('videoCopyInstructions');
      } else {
        activityObj.instructions = instructions || [];
      }

      this.orderDetailsPackageService.createActivityObj(activityObj, item);
    }
  }

  increaseStillFrames(lineItem: LineItem) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, 'stillFrames');
    if (stillFramesMetadataIndex > -1) {
      videoActivity.instructions[stillFramesMetadataIndex].values[0]++;
      this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
    }
  }

  decreaseStillFrames(lineItem: LineItem) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, 'stillFrames');
    if (stillFramesMetadataIndex > -1) {
      const stillFramesQuantity = videoActivity.instructions[stillFramesMetadataIndex].values[0];
      if (stillFramesQuantity > 1) {
        videoActivity.instructions[stillFramesMetadataIndex].values[0]--;
      }
      this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
    }
  }

  getTotalStills(lineItem: LineItem): number {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, 'stillFrames');
    if (stillFramesMetadataIndex > -1) {
      return videoActivity.instructions[stillFramesMetadataIndex].values[0];
    } else {
      return 0;
    }
  }

  checkboxHandler(event, metadataType, lineItem: LineItem, value?) {
    const videoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    const metadataIndex = this.getArrayItemIndex(videoActivity.instructions, metadataType);
    let valueIndex;
    if (metadataIndex && videoActivity.instructions[metadataIndex]) {
      valueIndex = indexOf(videoActivity.instructions[metadataIndex].values, value);
    }
    switch (metadataType) {
      case 'stillFrames':
        if (event.target.checked) {
          const stillFramesMetadata = {
            label: metadataType,
            values: [1]
          };
          videoActivity.instructions.push(stillFramesMetadata);
        } else {
          const stillFramesMetadataIndex = this.getArrayItemIndex(videoActivity.instructions, metadataType);
          videoActivity.instructions.splice(stillFramesMetadataIndex, 1);
        }
        break;
      default:
        if (event.target.checked) {
          if (metadataIndex > -1) {
            videoActivity.instructions[metadataIndex].values.push(value);
          } else {
            const metadataPayload = {
              'label': metadataType,
              'values': [value]
            };
            videoActivity.instructions.push(metadataPayload);
          }
        } else {
          videoActivity.instructions[metadataIndex].values.splice(valueIndex, 1);
          if (videoActivity.instructions[metadataIndex].values.length === 0) {
            videoActivity.instructions.splice(metadataIndex, 1);
          }
        }
        break;
    }
    if (value === 'Deliver/include transcript file') {
      this.updateInstructionsForm('', 'budgetCode', lineItem, 'videoInstructions', true);
    }
    // if slate and graphics becomes none, clear slatesAndGraphicsSourceInfo form field
    if (metadataType === 'slatesAndGraphics' && metadataIndex === -1) {
      this.updateInstructionsForm('', 'slatesAndGraphicsSourceInfo', lineItem, 'videoInstructions', true);
    }
    this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  publishingInstructionsCheckboxHandler(event, metadataType: string, lineItem: LineItem, value?: string) {
    const publishActivity = this.utilityService.getLineItemActivity(13, lineItem);
    switch (metadataType) {
      case 'hideVideoPageToggle':
      case 'includeBetNowApp':
        if (event.target.checked) {
          const metadata = {
            label: metadataType,
            values: [true]
          };
          publishActivity.instructions.push(metadata);
        } else {
          const metadataIndex = this.getArrayItemIndex(publishActivity.instructions, metadataType);
          publishActivity.instructions.splice(metadataIndex, 1);
        }
        break;

      case 'adTargeting':
        if (event.target.checked) {
          if (typeof value === 'undefined') {
            value = '';
          }
          const adTargetingMetadata = {
            label: metadataType,
            values: [value]
          };
          publishActivity.instructions.push(adTargetingMetadata);
        } else {
          const adTargetingMetadataIndex = this.getArrayItemIndex(publishActivity.instructions, metadataType);
          publishActivity.instructions.splice(adTargetingMetadataIndex, 1);
        }
        break;

      case 'secondarySiteCategory':
        if (event.target.checked) {
          const secondarySiteCategoryMetadataIndex = this.getArrayItemIndex(publishActivity.instructions, metadataType);
          if (secondarySiteCategoryMetadataIndex > -1) {
            publishActivity.instructions[secondarySiteCategoryMetadataIndex].values.push(value);
          } else {
            const slatesAndGraphicsMetadata = {
              'label': metadataType,
              'values': [value]
            };
            publishActivity.instructions.push(slatesAndGraphicsMetadata);
          }
        } else {
          const slatesAndGraphicsMetadataIndex = this.getArrayItemIndex(publishActivity.instructions, metadataType);
          const valueIndex = indexOf(publishActivity.instructions[slatesAndGraphicsMetadataIndex].values, value);
          publishActivity.instructions[slatesAndGraphicsMetadataIndex].values.splice(valueIndex, 1);
          if (publishActivity.instructions[slatesAndGraphicsMetadataIndex].values.length === 0) {
            publishActivity.instructions.splice(slatesAndGraphicsMetadataIndex, 1);
          }
        }
        break;
    }
    const viacomSiteAndAppLineItems = this.orderDetailsFormatService.getOrderStore().getCorrespondingLineItemsFromClipIdentifier(lineItem, this.order);
    this.syncPublishingInstructions(publishActivity.instructions, viacomSiteAndAppLineItems);
    this.orderDetailsFormatService.getOrderStore().setInstructionsMetadata(this.order);
  }

  getArrayItemIndex(array: Array<any>, itemKey: string): number {
    let itemIndex = -1;
    forEach(array, (value, index) => {
      if (value.label === itemKey) {
        itemIndex = index;
        return;
      }
    });
    return itemIndex;
  }

  initOrderActivities() {
    // init activities on page loads and on adding versions, to obtain activity id for uploading attachment metadata
    // only called by Video & Captions orders
    let modified = false;
    const composeActivity = this.orderDetailsFormatService.newActivity(1, '');
    const publishActivity = this.orderDetailsFormatService.newActivity(13);
    const qaActivity = this.orderDetailsFormatService.newActivity(16, this.utilityService.activityTypes.QA_VIDEO.description);
    forEach(this.order.lineItems, (item) => {
      if (item['activities'] === undefined || !item['activities'].length) {
        item['activities'] = [];
        item['activities'].push(composeActivity);
        item['activities'].push(publishActivity);
        if (item.customConfig && item.customConfig.endpoint === 'Viacom Sites & Apps' && this.isVideoWithCaptioning(item)) {
          item.activities.push(qaActivity);
        }
        modified = true;
      }
    });
    if (modified) {
      this.orderProgressTrackerService.saveOrder(this.order, '', () => { this.isUpdatingOrder = false; });
    }
  }

  isVideoWithCaptioning(lineItem: LineItem) {
    const composeActivity = this.utilityService.getLineItemActivity(1, lineItem);
    if (composeActivity && composeActivity.instructions) {
      const versionType = find(composeActivity.instructions, instruction => instruction['label'] === 'versionType');
      if (versionType && versionType['values'][0] === 'Video with captioning') {
        return true;
      }
    }
    return false;
  }

  getCorrespondingVersions(lineItem: LineItem): Array<any> {
    const lineItemVersions = this.orderDetailsFormatService.getOrderStore().getCorrespondingLineItemsFromClipIdentifier(lineItem, this.order);
    return lineItemVersions;
  }

  addItem(lineItem: LineItem, platform) {
    this.isUpdatingOrder = true;
    this.orderDetailsPlatformService.increasePlatforms(this.order, lineItem, platform);
    this.isNewLineitemAdded = true;
    this.initOrderActivities();
  }

  saveToModel(item: LineItem, version, event) {
    const formatActivity = this.getFormatActivity(item);
    set(item, 'customConfig.version', version);
    if (formatActivity === undefined) {
      this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
    } else {
      if (event.content === undefined || event.content.toString().replace(/&nbsp;|\s/g, '') === '') {
        formatActivity.description = '';
      } else {
        formatActivity.description = event.content;
      }
    }
    this.orderDetailsFormatService.getOrderStore().notify();
  };

  saveNonVideoContentToModel(event) {
    if (event.content !== undefined) {
      const content = event.content.toString().replace(/&nbsp;|\s/g, '');
      if ((content !== '') || (content === '' && (this.order.lineItems[0].activities[0].description !== '' &&
        this.order.lineItems[0].activities[0].description !== undefined))) {
        this.order.lineItems[0].activities[0].description = event.content;
        this.updatePressOrder(this.order);
        this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      }
      if(this.order.lineItems[0].activities[0].description.length > 0) {
        this.isDescriptionValid = true;
      } else {
        this.isDescriptionValid = false;
      }
    } else {
      this.isDescriptionValid = false;
    }
    if (this.isOpenInModal) {
      if (this.order && this.order.metadata.orderType === 'GRAPHICS') {
        this.isValid.emit(this.isGraphicsFormValid && this.isDescriptionValid && this.isNoDeliverablesValid && this.isGraphicsScheduleValid);
      } else if (this.order && this.order.metadata.orderType === 'PRESS') {
        this.isValid.emit(this.isPressFormValid);
      }
    }
  }

  saveNonVideoContentToModelBrand(event) {
    if (typeof event === 'string') {
      const brandName = event.trim() !== '' ? event : '';
      if (brandName !== undefined) {
        let metadataObj;
        if(this.order.lineItems[0].activities[0].instructions && this.order.lineItems[0].activities[0].instructions.length > 0) {
          this.order.lineItems[0].activities[0].instructions[0].values = [brandName];
        } else {
          metadataObj = [{
            'label': 'brandName',
            'values': [brandName]
          }];
          this.order.lineItems[0].activities[0].instructions = metadataObj;
        }
        this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      }
    }
  }

  applyInstructionsToAllVersions(lineItem: LineItem) {
    const correspondingVersions = this.getCorrespondingVersions(lineItem);
    const parentVideoActivity = this.utilityService.getLineItemActivity(1, lineItem);
    forEach(correspondingVersions, (version) => {
      console.log('version id and line item:', version, lineItem);
      if (version.id !== lineItem.id) { // different lineItem
        const videoActivity = this.utilityService.getLineItemActivity(1, version);
        let rawParentInstructionMetadata = [];
        forEach(parentVideoActivity.instructions, (instruction) => {
          // deal with invalid aspect ratio fore viacom site & app
          if (version.customConfig.endpoint && version.customConfig.endpoint === 'Viacom Sites & Apps'
          && instruction.label === 'aspectRatio' && (instruction.values[0] === '1 : 1' || instruction.values[0] === '9 : 16')) {
            if (version.videoInstructionsMetadata['aspectRatio']) {
              rawParentInstructionMetadata.push({
                label: instruction.label,
                values: version.videoInstructionsMetadata['aspectRatio']
              });
            } else {
              rawParentInstructionMetadata.push({label: instruction.label, values: ['16 : 9']}); // default aspect ratio
            }
          } else {
            rawParentInstructionMetadata.push({label: instruction.label, values: instruction.values});
          }
        });
        videoActivity.instructions = rawParentInstructionMetadata;
        videoActivity.description = parentVideoActivity.description;
      }
    });
    this.orderDetailsFormatService.getOrderStore().setVideoInstructionsMetadata(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
    this.updateCustomEditor.next(
      {
        description: parentVideoActivity.description,
        parentIdentifier: this.getLineItemClipIdentifier(lineItem)
      });
  }


  updateAttachmentsMetadata(activity, event) {
    let OrderActivity = activity;
    if (this.order && this.order.metadata.orderType !== 'PRESS') {
      this.updateAttachmentsMetaDataByActivity(activity, event);
    } else {
      forEach(this.order.lineItems, item => {
        let uploadLineItem = item;
        uploadLineItem.activities[0].input.attachments = OrderActivity.input.attachments;
        this.updateAttachmentsMetaDataByActivity(uploadLineItem.activities[0], event);
      });
    }
  }

  updateAttachmentsMetaDataByActivity(activity, event) {
    let evenClone = clone(event);
    evenClone.activityId = activity.id;
    evenClone.source = 'S3';
    this.subscriptions.add(this.orderDetailsFormatService.updateAttachmentsMetadata([evenClone]).subscribe(
      data => {
        find(activity.input.attachments, { 'name': data[0].name })['id'] = data[0].id;
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  updateTrackerStatus(activity, event) {
    const isUploading = event.uploadingInProgressQueue.length > 0;
    activity.input.isUploading = isUploading;
    if (typeof activity.input.isUploading !== 'undefined' && !isUploading) {
      delete activity.input.isUploading;
    }
    this.orderDetailsFormatService.getOrderStore().notify();
  }

  isAttachmentsUploading() {
    for (let i = 0; i < this.order.lineItems.length; i++) {
      const lineItemAttachments = this.getFormatActivity(this.order.lineItems[i]) ? this.getFormatActivity(this.order.lineItems[i]).input : {};
      if (lineItemAttachments && lineItemAttachments.isUploading) {
        return true;
      }
    }
    return false;
  }

  saveVersionToModel(item: LineItem, version: string) {
    set(item, 'customConfig.version', version);
    this.orderDetailsFormatService.getOrderStore().notify();
  }

  getFormatActivity(item: LineItem) {
    return find(item.activities, { 'typeId': 1 });
  }

  deleteVersion(lineItem) {
    this.deleteModalOptions.version =
      get(lineItem, 'customConfig.version') === undefined ? '' : get(lineItem, 'customConfig.version').toString();
    this.deleteModalOptions.msg = `This clip version will be removed from the order and can’t be undone.`;
    this.deleteModalOptions.btnMsg = 'YES, DELETE VERSION';
    this.deleteModalOptions.action = () => {
      const orderStore = this.orderDetailsFormatService.getOrderStore();
      orderStore.removeLineItem(lineItem);
      this.orderProgressTrackerService.saveOrder(this.order, get(lineItem, 'customConfig.version') + ' has been removed from the order.');
    };
  }

  getTotalsForActivity(lineItem, endpoint, typeId, i) {
    const arr = [];
    forEach(lineItem['activities'], (item, li) => {
      if (item['typeId'] === typeId) {
        arr.push(item);
      }
    });
    return arr.length;
  }

  changeCounter(direction, i, lineItem: LineItem, typeId, endpoint: string) {
    this.selectedVersionIndex = i;
    if (i === this.selectedVersionIndex) {
      if (this.counter === 1 && direction === 'minus') {
        return false;
      }
      if (direction === 'plus') {
        this.counter = (this.getTotalStills(lineItem) + 1);
      } else {
        this.counter = (this.getTotalStills(lineItem) - 1);
      }
      const lineItemIndex = indexOf(lineItem.activities, find(lineItem.activities, { typeId: typeId }));
      lineItem.activities[lineItemIndex].quantity = this.counter;
    }
  }

  getLineItemClipIdentifier(lineItem: LineItem) {
      if (typeof lineItem.metadata[0]['clipId'] !== 'undefined' && lineItem.metadata[0]['clipId'] !== null) {
        return lineItem.metadata[0]['clipId'];
      } else {
        return lineItem.metadata[0]['clipTitle'];
      }
  }

  onKeypress(event) {
    if (event.code === 'Enter') {
      return false;
    }
  }

  getAspectRatioIcon(label: string) {
    return 'ratio-' + label.replace(':', '-').replace(/[^0-9-]/g, '');
  }

  setGraphicsDropDown() {
    let graphicFormFields = this.graphicsInstructionsFormFields;
    const brandNameList = graphicFormFields.BrandDropDown.map(x => x);

    let vmid = get(this.order, 'metadata.vmId') === undefined ? '' : get(this.order, 'metadata.vmId').toString();
    const contentType = this.order.metadata['contentType'];
      if ( vmid !== '' && typeof this.contenBrandName === 'undefined') {
        this.subscriptions.add(this.catalogService.getItemDetails(vmid, contentType).subscribe(
          data => {
            try {
              if (contentType === 'BRAND' && data.minimumBrands.length > 0) {
                this.contenBrandName = data.minimumBrands[0].name;
              } else if ((contentType === 'SERIES' || contentType === 'SPECIAL' || contentType === 'EPISODE') && data.contentDetails) {
                this.contenBrandName = data.contentDetails.originBrandName ? data.contentDetails.originBrandName : '';
              }

              if (!this.contenBrandName) {
                this.contenBrandName = brandNameList[0].value;
              }
              this.setDropDownValues(graphicFormFields, brandNameList);
            } catch (e) {
              this.graphicsBrandName = brandNameList[0];
              this.setDropDownValues(graphicFormFields, brandNameList);
            }
          },
          error => {
            this.graphicsBrandName = brandNameList[0];
          }
        ));
        }
  }

  setDropDownValues(graphicFormFields, brandNameList) {
    if (this.order.lineItems[0].activities[0].instructions && this.order.lineItems[0].activities[0].instructions.length > 0) {

      let requestIndex = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'requestType');
      let index = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'brand');

      if (requestIndex >= 0) {
        let reqTypeValue = this.order.lineItems[0].activities[0].instructions[requestIndex].values[0];
        let reqDropdownIndex = graphicFormFields.RequestTypeDropDown.findIndex(req => req.id === reqTypeValue);
        if (reqDropdownIndex >= 0) {
          this.graphicsRequestType = graphicFormFields.RequestTypeDropDown[reqDropdownIndex];
        } else {
          this.graphicsRequestType = graphicFormFields.RequestTypeDropDown[1];
        }
      } else {
        this.graphicsRequestType = graphicFormFields.RequestTypeDropDown[1];
        this.order.lineItems[0].activities[0].instructions.push({
          label: 'requestType',
          values: [this.graphicsRequestType.id],
          type: ''
        });
      }

      if (index >= 0) {
        let brandIndex = brandNameList.findIndex(b => b.id === this.order.lineItems[0].activities[0].instructions[index].values[0]);
        if (brandIndex >= 0) {
          this.graphicsBrandName = Object.assign({}, brandNameList[brandIndex]);
        } else {
          this.graphicsBrandName = Object.assign({}, brandNameList[0]);
        }
      } else {
        this.graphicsBrandName = Object.assign({}, brandNameList[0]);
        this.order.lineItems[0].activities[0].instructions.push({
          label: 'brand',
          values: [this.graphicsBrandName.id],
          type: ''
        });
      }
    } else {
      this.graphicsRequestType = graphicFormFields.RequestTypeDropDown[1];
      this.order.lineItems[0].activities[0].instructions.push({
        label: 'requestType',
        values: [this.graphicsRequestType.id],
        type: ''
      });

      if (this.contenBrandName && this.contenBrandName !== 'n/a') {
        this.graphicsBrandName = brandNameList.filter(brand => brand.value === this.contenBrandName)[0];
        if (!this.graphicsBrandName) {
          this.graphicsBrandName = brandNameList[0];
        }
      } else {
        this.graphicsBrandName = brandNameList[0];
      }
      this.order.lineItems[0].activities[0].instructions.push({
        label: 'brand',
        values: [this.graphicsBrandName.id],
        type: ''
      });
    }
    if (this.graphicsRequestType.id !== 'VMN') {
      if (this.isOpenInModal) {
        this.isGraphicsFormValid = true;
      } else {
        this.isGraphicsFormValid = false;
      }
      if (this.isOpenInModal) {
        this.isValid.emit(this.isGraphicsFormValid && this.isDescriptionValid && this.isNoDeliverablesValid && this.isGraphicsScheduleValid);
      }
    }
    this.setOrderInstructions();
  }

  setPressDropDown() {
    const pressFormFields = this.videoPressFormFields;
    if (this.order.lineItems[0].activities[0].instructions && this.order.lineItems[0].activities[0].instructions.length > 0) {

      const requestIndex = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'requestType');
      if (requestIndex >= 0) {
        const reqTypeValue = this.order.lineItems[0].activities[0].instructions[requestIndex].values[0];
        const reqDropdownIndex = pressFormFields.RequestTypeDropDown.findIndex(req => req.id === reqTypeValue);
        if (reqDropdownIndex >= 0) {
          this.pressRequestType = pressFormFields.RequestTypeDropDown[reqDropdownIndex];
        } else {
          this.pressRequestType = pressFormFields.RequestTypeDropDown[0];
          this.setFormToInstructions('requestType', this.pressRequestType.id, '');
        }
      } else {
        this.pressRequestType = pressFormFields.RequestTypeDropDown[0];
        this.setFormToInstructions('requestType', this.pressRequestType.id, '');
      }
    } else {
      this.pressRequestType = pressFormFields.RequestTypeDropDown[0];
      this.setFormToInstructions('requestType', this.pressRequestType.id, '');
    }
    this.setOrderInstructions();
  }

  setOrderInstructions() {
    let result;

    if (this.order && this.order.metadata.orderType === 'GRAPHICS') {
      this.platformTypeList = this.graphicsBrandName.options.map(x => x);
      this.platformTypeList.forEach(p => p.display = true);
      this.hideAddPlatform = true;
      this.graphicsSelectedRequest = [];
    }

    this.dynamicRequestForm = undefined;
    this.formControls = [];
    const platformIndx = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'platformList');
    if (platformIndx >= 0) {
      result = uniqBy(this.order.lineItems[0].activities[0].instructions, (inst) => {
        return inst['type'];
      });

      if (typeof result !== 'undefined' && result.length >= 0) {
        result = result.filter(res => (typeof res['type'] !== 'undefined' && res['type'].length > 0));
        let platformList = result.map(res => res.type);
        result = platformList;
        if (platformList.length > 0) {
          this.order.lineItems[0].activities[0].instructions[platformIndx].values = result;
        }
      }
    } else {
      result = uniqBy(this.order.lineItems[0].activities[0].instructions, (inst) => {
        return inst['type'];
      });

      if (typeof result !== 'undefined' && result.length >= 0) {
        result = result.filter(res => (typeof res['type'] !== 'undefined' && res['type'].length > 0));
        let platformList = result.map(res => res.type);
        result = platformList;
        if (platformList.length > 0) {
          this.order.lineItems[0].activities[0].instructions.push({
            label: 'platformList',
            values: platformList,
            type: ''
          });
        }
      }

    }

    if (this.order && this.order.metadata.orderType === 'GRAPHICS') {
      const platformListBackup = result;
      result = [];
      this.platformTypeList.forEach(platformType => {
        if (platformListBackup.findIndex(plt => plt === platformType.id) >= 0) {
          result.push(platformType.id);
        }
      });

      if (result && result.length > 0) {
        this.addNewPlatform = false;
        result.forEach(res => {
          const index = this.platformTypeList.findIndex(platform => platform.id === res);
          if (index >= 0) {
            this.platformTypeList[index].display = false;
          }
          if (!this.dynamicRequestForm) {
            this.intializeRequestType(this.platformTypeList[index]);
          } else {
            this.addRequestDynamicForm(this.platformTypeList[index]);
          }
          this.hideAddPlatform = this.platformTypeList.filter(p => p.display === false).length <= 0 ? false : true;
        });
      } else {
        this.addNewPlatform = true;
      }
    }

    if (this.order && this.order.metadata.orderType === 'PRESS') {
      if (this.pressRequestType.id !== '') {
          this.intializeRequestType(this.pressRequestType.formType);
      }
    }
    // this.loadingMaskService.disableLoadingMask();
    this.updatePressOrder(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  intializeRequestType(platformType) {
    if (this.order && this.order.metadata.orderType === 'GRAPHICS') {
      this.resetGraphicsForm(platformType);
    } else if (this.order && this.order.metadata.orderType === 'PRESS') {
      this.resetPressForm(platformType);
    }

    this.dynamicRequestForm = this.fb.group({
      'Request': this.fb.array([
        this.dynamicFormBaseService.toFormGroup(this.formControls[0])
      ])
    });

    let instructions = [];

    this.dynamicRequestForm.valueChanges.subscribe((formValues) => {
      if (this.order && this.order.lineItems[0].activities[0].instructions) {
        instructions = this.order.lineItems[0].activities[0].instructions;
      }
      this.formValueChanges = true;
      this.graphicsSelectedRequest.forEach((req, graphicindex) => {
        let formObj = formValues.Request[graphicindex];
        if (formObj) {
          Object.keys(formObj).forEach(function(key, index) {
            let indexInst = instructions.findIndex(j => j && j.label === key && j.type === req);
            if (key === 'Description') {
              let content = formObj[key];
              if (content.toString().replace(/&nbsp;|\s/g, '') === '') {
                formObj[key] = '';
              }
            }
            if (formObj[key] && ((typeof formObj[key] === 'string' &&  formObj[key].length > 0 && formObj[key].trim() !== '') || (typeof formObj[key] === 'boolean'))) {

              if (indexInst >= 0) {
                instructions[indexInst].values = [formObj[key]];
              } else {
                instructions.push({
                  label: key,
                  values: [formObj[key]],
                  type: req
                });
              }
            } else if (indexInst >= 0) {
              delete instructions[indexInst];
              if (key === 'Custom') {
                formObj['dimensions'] = '';
                const deleteIndex = instructions.findIndex(j => j && j.label === 'dimensions' && j.type === req);
                delete instructions[deleteIndex];
              }
            }
          });
        }
        this.order.lineItems[0].activities[0].instructions = instructions.filter(i => i !== undefined);
        this.updatePressOrder(this.order);
        if (this.order && this.order.metadata.orderType === 'GRAPHICS') {
          if (this.isOpenInModal && this.orderDetailsFormatService.checkGraphicsForm(this.order.lineItems) ) {
            this.isGraphicsFormValid = true;
          } else {
            this.isGraphicsFormValid = false;
          }
          if (this.isOpenInModal) {
            this.isValid.emit(this.isGraphicsFormValid && this.isDescriptionValid && this.isNoDeliverablesValid && this.isGraphicsScheduleValid);
          }
        } else if (this.isOpenInModal && this.order && this.order.metadata.orderType === 'PRESS') {
          this.isPressFormValid = this.orderProgressTrackerService.checkPressForm(this.order.lineItems[0]);
          this.isValid.emit(this.isPressFormValid);
        }
        this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
      });
    });
    this.setPressInstructions(platformType);
  }

  setPressInstructions (requestType) {

    this.setFormToInstructions('requestType', this.pressRequestType.id, '');

    const formField = Object.assign({}, this.videoPressFormFields.RequestType);
    if (!this.formValueChanges && this.order.metadata.orderType === 'PRESS') {
      if (formField[requestType]) {
        formField[requestType].forEach(field => {
          this.setFormToInstructions(field.key, field.defaultValue, requestType);
        });
      }
      this.updatePressOrder(this.order);
      this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
    }
  }

  setFormToInstructions(key, value, type = '') {
    const indexInst = this.order.lineItems[0].activities[0].instructions.findIndex(j => j && j.label === key && j.type === type);
    if (indexInst < 0 && (typeof value === 'string' && value.length > 0)) {
      this.order.lineItems[0].activities[0].instructions.push({
        label: key,
        values: [value],
        type: type
      });
    }
  }

  addRequestDynamicForm(platformType) {
    this.addNewPlatform = false;
    const formField = Object.assign({}, this.graphicsInstructionsFormFields.RequestType);
    this.graphicsSelectedRequest.push(platformType.id);
    this.clearFormFields(formField, platformType.id);
    this.formControls.push(this.requestformService.getForm(formField, platformType.id, this.order.lineItems[0].activities[0].instructions));
    this.formControls[this.formControls.length - 1].requestType = platformType;
    const control = <FormArray>this.dynamicRequestForm.controls['Request'];
    control.push( this.dynamicFormBaseService.toFormGroup(this.formControls[this.formControls.length - 1]));
  }

  resetGraphicsForm(platformType) {
    this.dynamicRequestForm = undefined;
    this.formControls = [];
    this.graphicsSelectedRequest = [];
    this.addNewPlatform = false;
    const graphicsInstrFormData = Object.assign({}, this.graphicsInstructionsFormFields);

    const formField = Object.assign({}, graphicsInstrFormData.RequestType);
    this.graphicsSelectedRequest.push(platformType.id);

    const instructionsFormFields = this.order.lineItems[0].activities[0].instructions.filter(ins => ins.type === platformType.id);
    this.showModalGraphicsDropDown = instructionsFormFields.length > 0 ? true : false;
    this.clearFormFields(formField, platformType.id);
    this.formControls[0] = this.requestformService.getForm(formField, platformType.id, instructionsFormFields);
    this.formControls[0].requestType = platformType;
  }

  resetPressForm(requestType) {
    this.dynamicRequestForm = undefined;
    this.formControls = [];
    this.graphicsSelectedRequest = [];
    const pressInstrFormData = Object.assign({}, this.videoPressFormFields);
    this.graphicsSelectedRequest.push(requestType);
    const formField = Object.assign({}, pressInstrFormData.RequestType);
    const instructionsFormFields = this.order.lineItems[0].activities[0].instructions.filter(ins => ins.type === requestType);
    const indexDeliveryMethod = instructionsFormFields.findIndex(list => list.label === 'DeliveryMethod');
    let deliveryLocHidden = true;
    if (formField[requestType]) {
      formField[requestType].forEach(field => {
        field.value = field.defaultValue;
        if (field.key === 'deliveryLocation') {
          deliveryLocHidden = field.defaultHidden;
        }
      });
    }
    if (indexDeliveryMethod >= 0) {
      deliveryLocHidden = instructionsFormFields[indexDeliveryMethod].values[0] !== 'Other' ? true : false;
    }
    this.clearFormFieldsPress(formField, requestType, deliveryLocHidden);

    let isDeliveryMethodMediasilo = false;
    const deliverMethod = instructionsFormFields.findIndex(instruction => instruction.label === 'DeliveryMethod');
      if (deliverMethod >= 0) {
        isDeliveryMethodMediasilo = instructionsFormFields[deliverMethod].values[0] === 'Mediasilo';
        if (formField[requestType]) {
          formField[requestType].forEach(field => {
            if (field.key === 'deliveryOptions') {
              field.hidden = !isDeliveryMethodMediasilo;
              field.options.forEach(option => {
                option.hidden = !isDeliveryMethodMediasilo;
              });
            }
          });
        }
      }

    this.formControls[0] = this.requestformService.getForm(formField, requestType, instructionsFormFields);
    this.formControls[0].requestType = requestType;
  }

  getSelectedBrandName() {
    return this.graphicsBrandName;
  }

  getSelectedRequestType() {
    return this.graphicsRequestType;
  }

  getPressSelectedRequestType() {
    return this.pressRequestType;
  }

  loadBrandPlatform(brandName) {
    this.showModalGraphicsDropDown = false;
    this.graphicsBrandName = brandName;
    this.platformTypeList = brandName.options;
    this.platformTypeList.forEach(p => p.display = true);
    this.hideAddPlatform = true;
    this.graphicsSelectedRequest = [];
    this.dynamicRequestForm = undefined;
    this.formControls = [];
    this.addNewPlatform = true;
    this.order.lineItems[0].activities[0].description = '';
    const instructionDetails = ['noOfDelivarables', 'assetLocation', 'fileDropOffLocation', 'dueDateReason'];

    if (this.order.lineItems[0]) {
      this.order.lineItems[0].dueDateTime = undefined;
      this.order.lineItems[0].launchDateTime = undefined;
    }

    if (this.order.lineItems[0].activities[0].instructions && this.order.lineItems[0].activities[0].instructions.length > 0) {

      instructionDetails.forEach(ins => {
        const inx = this.order.lineItems[0].activities[0].instructions.findIndex(list => list.label === ins);
        if (inx >= 0) {
          this.order.lineItems[0].activities[0].instructions.splice(inx, 1);
        }
      });

      const instructions = this.order.lineItems[0].activities[0].instructions;

      instructions.forEach((ins, index) => {
        if (ins && ins.type !== '') {
          delete this.order.lineItems[0].activities[0].instructions[index];
        }
      });

      delete this.order.lineItems[0].activities[0].instructions;
      this.order.lineItems[0].activities[0]['instructions'] = instructions.filter(f => f !== undefined);

      const brandIndex = this.order.lineItems[0].activities[0].instructions.findIndex(list => list.label === 'brand');
      if (brandIndex >= 0) {
        this.order.lineItems[0].activities[0].instructions[brandIndex].values = [brandName.id];
      }
      const index = this.order.lineItems[0].activities[0].instructions.findIndex(list => list.label === 'platformList');
      if (index >= 0) {
        this.order.lineItems[0].activities[0].instructions[index].values = [];
      }
    }

    if (this.order.lineItems[0].activities[0].input && this.order.lineItems[0].activities[0].input.attachments.length > 0) {
      this.order.lineItems[0].activities[0].input.attachments.forEach(fileItem => {
        this.fileUploaderService.deleteUploadedFileMetadata(fileItem, this.order.lineItems[0].activities[0].input.attachments);
      });
    }

    this.orderDetailsFormatService.getOrderStore().setGraphicsInstructionsMetadata(this.order);
    this.updatePressOrder(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  loadRequestType(requestType) {
    this.showModalGraphicsDropDown = false;
    this.graphicsRequestType = requestType;
    this.graphicsSelectedRequest = [];
    this.dynamicRequestForm = undefined;
    this.formControls = [];
    this.addNewPlatform = true;
    this.order.lineItems[0].activities[0].description = '';
    if (this.order.lineItems[0]) {
      this.order.lineItems[0].dueDateTime = undefined;
      this.order.lineItems[0].launchDateTime = undefined;
    }
      if (this.order && this.order.lineItems[0].activities[0].instructions) {
        const brandIndex = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'brand');
        const reqIndex = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'requestType');
        let instructions;
        let requestType;
        // const dateResponse;

        if (brandIndex >= 0) {
          instructions = this.order.lineItems[0].activities[0].instructions[brandIndex];
        }
        if (reqIndex >= 0) {
          requestType = this.order.lineItems[0].activities[0].instructions[reqIndex];
          requestType.values = [this.graphicsRequestType.id];
        } else {
          requestType = {
            label: 'requestType',
            values: [this.graphicsRequestType.id],
            type: ''
          };
        }

        const instructionsBackup = this.order.lineItems[0].activities[0].instructions;

        instructionsBackup.forEach((instruction, index) => {
          if (instruction.type !== '') {
            delete this.order.lineItems[0].activities[0].instructions[index];
          }
        });

        this.order.lineItems[0].activities[0].instructions = [];

        if (this.graphicsRequestType.id === 'VMN') {
          if (brandIndex < 0) {
            this.order.lineItems[0].activities[0].instructions.push({
              label: 'brand',
              values: [this.graphicsBrandName.id],
              type: ''
            });
            this.platformTypeList = this.graphicsBrandName.options;
            this.platformTypeList.forEach(p => p.display = true);
          } else if (instructions) {
            this.order.lineItems[0].activities[0].instructions.push(instructions);
          }
        }
        // if (dateResponse) {
        //   this.order.lineItems[0].activities[0].instructions.push(dateResponse);
        // }
        if (requestType) {
          this.order.lineItems[0].activities[0].instructions.push(requestType);
        }
      }

      if (this.order.lineItems[0].activities[0].input && this.order.lineItems[0].activities[0].input.attachments.length > 0) {
        this.order.lineItems[0].activities[0].input.attachments.forEach(fileItem => {
          this.fileUploaderService.deleteUploadedFileMetadata(fileItem, this.order.lineItems[0].activities[0].input.attachments);
        });
      }

      this.orderDetailsFormatService.getOrderStore().setGraphicsInstructionsMetadata(this.order);
      this.updatePressOrder(this.order);
      this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
  }

  loadRequestTypePress(requestTypeObj) {
    this.order.lineItems[0].activities[0].description = '';
    this.pressRequestType = requestTypeObj;
    let requestType;
    if (this.order && this.order.lineItems[0].activities[0].instructions) {
      const reqIndex = this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === 'requestType');
      if (reqIndex >= 0) {
        requestType = this.order.lineItems[0].activities[0].instructions[reqIndex];
        requestType.values = [this.pressRequestType.id];
      } else {
        requestType = {
          label: 'requestType',
          values: [this.pressRequestType.id],
          type: ''
        };
      }
      const inst = this.order.lineItems[0].activities[0].instructions;
      inst.forEach((ins, index) => {
        delete this.order.lineItems[0].activities[0].instructions[index];
      });
      this.order.lineItems[0].activities[0].instructions = [];
      if (requestType) {
        this.order.lineItems[0].activities[0].instructions.push(requestType);
      }
    } else {
      requestType = {
        label: 'requestType',
        values: [this.pressRequestType.id],
        type: ''
      };
      this.order.lineItems[0].activities[0].instructions.push(requestType);
    }
    this.intializeRequestType(requestTypeObj.formType);

  }

  onDeleteFormGroupReset(event) {
    if (this.order && this.order.lineItems[0].activities[0].instructions) {
      let instructions = undefined;
      instructions = cloneDeep(this.graphicInstructions);
      instructions.forEach((ins, index) => {
        if (ins && ins.type === event) {
          delete instructions[index];
        }
      });
      instructions = instructions.filter(f => f !== undefined);
      this.order.lineItems[0].activities[0].instructions = cloneDeep(instructions.map(f => f));
      const index = this.order.lineItems[0].activities[0].instructions.findIndex(list => list.label === 'platformList');
      if (index >= 0) {
        const values = this.order.lineItems[0].activities[0].instructions[index].values;
        const valuesIndex = values.findIndex(val => val === event);
        if (valuesIndex >= 0) {
          this.order.lineItems[0].activities[0].instructions[index].values.splice(valuesIndex, 1);
        }
      }
      this.setOrderInstructions();
    }
  }

  setNewPlatformTemplate() {
    this.addNewPlatform = !this.addNewPlatform;
  }

  getNewPlatformTemplate() {
    return this.addNewPlatform;
  }

  getSelectedPlatform() {
    return this.graphicsPLatformType;
  }

  loadDynamicForm(platformType) {
    const index = this.platformTypeList.findIndex(list => list.id === platformType.id);
    if (index >= 0) {
      this.platformTypeList[index].display = false;
    }
    this.hideAddPlatform = this.platformTypeList.filter(p => p.display === true).length <= 0 ? false : true;
    const platformIndx = this.graphicInstructions.findIndex(ins => ins.label === 'platformList');
    if (platformIndx >= 0) {
      this.order.lineItems[0].activities[0].instructions[platformIndx].values.push(platformType.id);
    } else {
      this.order.lineItems[0].activities[0].instructions.push({
        label: 'platformList',
        values: [platformType.id],
        type: ''
      });
    }
    this.updatePressOrder(this.order);
    this.orderDetailsFormatService.getOrderStore().updateCurrentOrder(this.order);
    if (!this.dynamicRequestForm) {
      this.intializeRequestType(platformType);
    } else {
      this.addRequestDynamicForm(platformType);
    }
  }

  openModal(type, typeObj) {
    if (type === 'brand') {
      const instructionDetails = ['noOfDelivarables', 'assetLocation', 'fileDropOffLocation', 'dueDateReason'];

      if (!this.showModalGraphicsDropDown) {
        const inst = instructionDetails.filter(ins => this.order.lineItems[0].activities[0].instructions.findIndex(inst => inst.label === ins) >= 0 ? ins : undefined);
        this.showModalGraphicsDropDown = inst.length > 0 ? true : false;
      }

      if (this.order.lineItems[0] && (this.order.lineItems[0].activities[0].description || this.order.lineItems[0].dueDateTime || this.order.lineItems[0].launchDateTime)) {
        this.showModalGraphicsDropDown = true;
      }
      const platformIndx = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'platformList');
      if (!this.showModalGraphicsDropDown && platformIndx >= 0) {
        this.showModalGraphicsDropDown = this.order.lineItems[0].activities[0].instructions[platformIndx].values.length > 0 ? true : false;
      }
      if (!this.showModalGraphicsDropDown && this.order.lineItems[0].activities[0].input && this.order.lineItems[0].activities[0].input.attachments.length > 0) {
        this.showModalGraphicsDropDown = true;
      }
    } else {
      this.showModalGraphicsDropDown = true;
    }

    if (this.showModalGraphicsDropDown) {
      if (type === 'requestType') {
        this.confirmModalOptions.heading = `Are You Sure You Want To Change the Request Type?`;
        this.confirmModalOptions.msg = `Changing the Request Type will clear the form.`;
        this.confirmModalOptions.btnMsg = 'CHANGE REQUEST TYPE';
        this.confirmModalOptions.action = () => {
          this.platformTypeList.forEach(p => p.display = true);
          this.loadRequestType(typeObj);
        };
      } else {
        this.confirmModalOptions.heading = `Are You Sure You Want To Change the Brand?`;
        this.confirmModalOptions.msg = `Changing the Brand will reset the platform fields.`;
        this.confirmModalOptions.btnMsg = 'CHANGE BRAND';
        this.confirmModalOptions.action = () => {
          this.platformTypeList.forEach(p => p.display = true);
          this.loadBrandPlatform(typeObj);
        };
      }
      this.confirmModal.open();
    } else {
      if (type === 'requestType') {
        this.loadRequestType(typeObj);
      } else {
        this.loadBrandPlatform(typeObj);
      }
    }

  }

  openModalPressOrder(type, typeObj) {
    this.formValueChanges = false;
    this.confirmModalOptions.heading = `Are You Sure You Want To Change the Request Type?`;
        this.confirmModalOptions.msg = `Changing the Request Type will clear the form.`;
        this.confirmModalOptions.btnMsg = 'CHANGE REQUEST TYPE';
        this.confirmModalOptions.action = () => {
          this.loadRequestTypePress(typeObj);
        };
        this.confirmModal.open();
  }

  clearFormFields(formField, platformType) {
    if (formField[platformType] && formField[platformType][1]) {
      const formFields = formField[platformType][1].options;
      if (formFields) {
        formFields.forEach(f => {
          f.value = undefined;
          f.checked = undefined;
        });
      }
      const formFieldsDesc = formField[platformType][1];
      if (formFieldsDesc && formFieldsDesc.type === 'textbox') {
        formFieldsDesc.value = '';
      }
    }
  }

  clearFormFieldsPress(formField, requestType, deliveryLocHidden) {
    if (formField[requestType]) {
      formField[requestType].forEach(field => {
        field.value = field.defaultValue;
        if (field.key === 'deliveryLocation') {
          field.hidden = deliveryLocHidden;
        }
        if (field.key === 'deliveryOptions') {
          field.hidden = field.defaultHidden;
          field.options.forEach(option => {
            option.hidden = option.defaultHidden;
          });
        }
      });
    }
  }

  handleGraphicsScheduleValidation(event) {
    this.isGraphicsScheduleValid = event;
      this.isValid.emit(this.isGraphicsFormValid && this.isDescriptionValid && this.isNoDeliverablesValid && this.isGraphicsScheduleValid);
      this.updatedOrder.emit(this.order);
      // this.enableSubmitGraphicsInstructions = this.isGraphicsFieldValid && this.isGraphicsScheduleValid;
  }

  updateOrderData(event) {
    this.order = clone(event);
  }

  updatePressOrder(orderData) {
    let pressOrderInstructions;
    let pressOrderDescription;
    let pressOrderDueDate;
    if (orderData.metadata.orderType.toLowerCase() === 'press') {
      pressOrderInstructions = orderData.lineItems[0].activities[0].instructions;
      pressOrderDescription = orderData.lineItems[0].activities[0].description;
      pressOrderDueDate = orderData.lineItems[0].dueDateTime ? orderData.lineItems[0].dueDateTime : undefined;
      pressOrderInstructions.forEach(instructions => {
        delete instructions.id;
      });
      orderData.lineItems.forEach(item => {
        item.activities[0].instructions = pressOrderInstructions;
        item.activities[0].description = pressOrderDescription;
        item.dueDateTime = pressOrderDueDate ? pressOrderDueDate : undefined;
      });
      orderData.lineItemsClipId.forEach(item => {
        item.activities[0].instructions = pressOrderInstructions;
        item.activities[0].description = pressOrderDescription;
        item.dueDateTime = pressOrderDueDate ? pressOrderDueDate : undefined;
      });
    }
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  ngOnChanges() {
    this.orderDetailsFormatService.getOrderStore().notify();
  }
}