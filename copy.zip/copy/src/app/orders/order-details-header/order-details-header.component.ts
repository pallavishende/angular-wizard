import { Component, OnInit, OnDestroy } from '@angular/core';
import { RouterStateSnapshot, Router } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/mergeMap';
import { OrderDetailsHeaderService } from './order-details-header.service';
import { CatalogService } from '../../catalog/catalog.service';
import { OrderStore } from '../../models/order-store';
import { UserService } from '../../services/user.service';
import { OrdersService } from '../orders/orders.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { UtilityService } from '../../services/utility.service';
import { get } from 'lodash';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { forkJoin } from 'rxjs/observable/forkJoin';

@Component({
  selector: 'app-order-details-header',
  templateUrl: './order-details-header.component.html',
  styleUrls: ['./order-details-header.component.scss'],
  providers: [OrderDetailsHeaderService]
})
export class OrderDetailsHeaderComponent implements OnInit, OnDestroy {
  order;
  orderId;
  userLoginInfo;
  subscriptions = new Subscription();
  pageSubheader = '';
  isLoadingAssignee = false;
  contentDetails;

  constructor(
    private orderProgressTrackerService: OrderProgressTrackerService,
    private catalogService: CatalogService,
    private orderStore: OrderStore,
    private ordersService: OrdersService,
    private userService: UserService,
    private utiltyService: UtilityService,
    private router: Router,
    private alerts: SystemAlertsService
   ) {
  }

  ngOnInit() {
    const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
    this.userLoginInfo = this.userService.getUserLoginInfo();
    this.orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
    this.subscriptions.add(this.orderStore.orderStream
    // get first data that's not a shell and is not from old order
    .first(data => get(data, 'metadata.vmId') && data['id'] && data['id'].toString() === this.orderId)
    .subscribe(
      data => {
        let vmid = get(data, 'metadata.vmId') === undefined ? '' : get(data, 'metadata.vmId').toString();
        if ( vmid !== '' ) {
          const contentType = data.metadata['contentType'];
          let catalogPromise = this.catalogService.getItemDetails(vmid, contentType).toPromise();
          catalogPromise.then(
            data => {
              this.contentDetails = data.contentDetails;
              if (contentType === 'BRAND' && data.minimumBrands.length > 0) {
                this.pageSubheader = data.minimumBrands[0].name;
                this.contentDetails = data.minimumBrands[0];
              } else if ((contentType === 'SERIES' || contentType === 'SPECIAL') && data.contentDetails) {
                this.pageSubheader = data.contentDetails.title;
              } else {
                this.pageSubheader = this.utiltyService.getHeaderForContentType(data.contentDetails, contentType);
              }
            }
          );
          this.subscriptions.add(this.orderStore.orderStream.subscribe(
            data => {
              this.order = data;
            }
          ));
        }
      }
    ));
  }

  onSelectNameNotify(event) {
    const payload = {
      orderId: event.id,
      assigneeEmail: event.assigneeEmail,
      assignedByEmail: event.assignedByEmail,
      teamId: event.teamId
    };
    this.isLoadingAssignee = true;
    this.subscriptions.add(this.ordersService.setOrderOwner(payload).subscribe(
      (data) => {
        this.ordersService.getOrderDetails(data.id).subscribe(
          orderData => {
            this.order['assigneeName'] = orderData.assigneeName;
            this.order['assigneeEmail'] = orderData.assigneeEmail;
            this.order['teamName'] = orderData.teamName;
            this.order['teamId'] = orderData.teamId;
            this.isLoadingAssignee = false;
          }
        );
      },
      (error) => {
        this.alerts.addErrorAlerts('Error: Order owner could not be updated. Please try again.');
        this.isLoadingAssignee = false;
      }
    ));
  }

  onUpdateWatchersNotify(payload) {
    let editWatchersObservable = [];
    let alertMsg;
    if (payload.toBeAdded.length === 1 && payload.toBeAdded[0] === this.userLoginInfo.email && payload.toBeRemoved.length === 0) {
      alertMsg = 'You\'re now watching this Order. You can change your notifications in <a href="/settings/" target="_blank">User Settings</a>.';
    } else if (payload.toBeAdded.length === 0 && payload.toBeRemoved.length === 1 && payload.toBeRemoved[0] === this.userLoginInfo.email) {
      alertMsg = 'You\'ve stopped watching this Order.';
    } else {
      alertMsg = 'Watchers have been updated successfully.';
    }
    if (payload.toBeAdded.length > 0) {
      const postPayload = {'watcherEmails': payload.toBeAdded, 'watcherAssignedBy': this.userLoginInfo.email};
      editWatchersObservable.push(this.ordersService.watchOrder(this.orderId, postPayload));
    }
    if (payload.toBeRemoved.length > 0) {
      const postPayload = {'watcherEmails': payload.toBeRemoved, 'watcherAssignedBy': this.userLoginInfo.email};
      editWatchersObservable.push(this.ordersService.unwatchOrder(this.orderId, postPayload));
    }
    forkJoin(editWatchersObservable).subscribe(
      (data) => {
        this.alerts.addSuccessAlerts(alertMsg);
        this.ordersService.getOrderDetails(this.orderId).subscribe(
          data => {
            this.order.userWatchers = data.userWatchers;
          }
        );
      },
      (error) => {
        this.alerts.addErrorAlerts('There is an error watching this Order, please try again.');
      }
    );
  }

  updateOrderName(name) {
    this.orderProgressTrackerService.updateOrderName(this.order, name);
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
