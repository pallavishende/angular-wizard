import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { OrderStore } from '../../models/order-store';

@Injectable()
export class OrderDetailsHeaderService {
  storedHeaderInfo = {};

  constructor(private orderStore: OrderStore) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }
}
