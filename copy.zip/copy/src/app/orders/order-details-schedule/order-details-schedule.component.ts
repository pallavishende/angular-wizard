import { Component, OnDestroy, OnInit, Output,EventEmitter } from '@angular/core';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { set, get, find, forEach } from 'lodash';
import * as moment from 'moment/moment';
import { Subscription } from 'rxjs';
import { Activity } from '../../models/activity';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsScheduleService } from './order-details-schedule.service';

@Component({
  selector: 'app-order-details-schedule',
  templateUrl: './order-details-schedule.component.html',
  styleUrls: ['./order-details-schedule.component.scss', '../order-customization-base/order-customization-base.component.scss']
})
export class OrderDetailsScheduleComponent implements OnInit, OnDestroy {

  @Output() isValid = new EventEmitter<any>();
  @Output() updatedOrder = new EventEmitter<any>();
  order;
  today;
  uniqueLineItems;
  subscriptions = new Subscription();
  endpointProfiles;
  isOpenInModal;
  reasonForDueDate = '';
  requestTypeVmn = false;
  isFormValid = true;
  dateType = {
    DUE: 1,
    PUBLISH: 2
  };

  constructor(
    private router: Router,
    private alerts: SystemAlertsService,
    private ordersService: OrdersService,
    private orderDetailsScheduleService: OrderDetailsScheduleService,
    private endpointProfileService: EndpointProfileService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private activatedRoute: ActivatedRoute) {
    this.alerts = alerts;
  }

  ngOnInit() {
    const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
    if (snapshot.url.indexOf('/draft') > 0) {
      this.isOpenInModal = false;
    } else if (snapshot.url.indexOf('/order-detail') > 0) {
      this.isOpenInModal = true;
    }

    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
    });
    this.today =  moment().format('YYYY-MM-DD').toString();
    this.subscriptions.add(this.orderDetailsScheduleService.get()
    .subscribe(
      data => {
        if (data.lineItems && data.lineItems.length > 0) {
          this.order = data;

          if (!this.isOpenInModal) {
            this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          }

          if (this.order.metadata.orderType.toLowerCase() !== 'video') {
            this.initializeDueDateTime();
          }
          this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
            data => {
              this.endpointProfiles = data;
            }
          ));
        }
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  applyToAll(item, type) {
    const localOrderDetailsScheduleService = this.orderDetailsScheduleService;  // maintain ref
    const localDateType = this.dateType;  // maintain ref

    forEach(this.order.lineItems, (lineItem) => {
      if ( type === localDateType.DUE ) {
        set(lineItem, 'customConfig.dueByDate', get(item, 'customConfig.dueByDate'));
        set(lineItem, 'customConfig.dueByTime', get(item, 'customConfig.dueByTime'));
        set(lineItem, 'dueDateTime', get(item, 'dueDateTime'));
      } else {
        set(lineItem, 'customConfig.publishOnDate', get(item, 'customConfig.publishOnDate'));
        set(lineItem, 'customConfig.publishOnTime', get(item, 'customConfig.publishOnTime'));
        set(lineItem, 'publishDateTime', get(item, 'publishDateTime'));
      }
      if ( lineItem.publishDateTime ) {
        if ( localOrderDetailsScheduleService.isPast(get(lineItem, 'publishDateTime')) ) {
          set(lineItem, 'publishDatePastError', true);
        } else {
          set(lineItem, 'publishDatePastError', false);
        }
      }
      if ( lineItem.dueDateTime ) {
        if ( localOrderDetailsScheduleService.isTooSoon(get(lineItem, 'dueDateTime')) ) {
          set(lineItem, 'dateWarning', true);
        } else {
          set(lineItem, 'dateWarning', false);
        }
        if ( localOrderDetailsScheduleService.isPast(get(lineItem, 'dueDateTime')) ) {
          set(lineItem, 'dueDatePastError', true);
        } else {
          set(lineItem, 'dueDatePastError', false);
        }
        if ( lineItem.publishDateTime ) {
          if ( localOrderDetailsScheduleService.isValidDate(get(lineItem, 'dueDateTime'), get(lineItem, 'publishDateTime') )) {
            set(lineItem, 'dateError', false);
          } else {
            set(lineItem, 'dateError', true);
          }
        }
      }
    });
    this.orderDetailsScheduleService.getOrderStore().notify();
  }

  /**
   *
   * @param sourceAsset: source asset/lineitem from which schedule will be copied
   * Additional notes: This function will replace add to all function as part of the refactor
   */
  applyScheduleToAllAssets(sourceAsset): void {
    const targetAssets = this.order.lineItems.slice(1);
    forEach(targetAssets, (asset) => {
      set(asset, 'dueByDate', sourceAsset.dueByDate);
      set(asset, 'dueDateTime', sourceAsset.dueDateTime);
      set(asset, 'dueByTime', sourceAsset.dueByTime);
    });
  }

  saveToModel(item) {
    if (!item.customConfig['dueByTime']) {
      item.customConfig['dueByTime'] = '12:00 PM';
    } else if (!item.customConfig['publishOnTime']) {
      item.customConfig['publishOnTime'] = '12:00 PM';
    }
    set(item, 'dateError', false);
    set(item, 'dateWarning', false);
    set(item, 'dueDatePastError', false);
    set(item, 'publishDatePastError', false);

    const dueDateTime = new Date(item.customConfig['dueByDate'] + ' ' + item.customConfig['dueByTime']);
    const publishDateTime = new Date(item.customConfig['publishOnDate'] + ' ' + item.customConfig['publishOnTime']);
    item['dueDateTime'] = moment.utc(dueDateTime).toISOString();
    item['publishDateTime'] = moment.utc(publishDateTime).toISOString();

    if (!this.timeValidator(item.customConfig['dueByTime']) || !moment(item.customConfig['dueByDate'], 'MM/DD/YYYY').isValid()) {
      item['dueDateTime'] = '';
    } else if (!this.timeValidator(item.customConfig['publishOnTime'])
    || !moment(item.customConfig['publishOnDate'], 'MM/DD/YYYY').isValid()) {
      item['publishDateTime'] = '';
    }

    this.orderDetailsScheduleService.getOrderStore().notify();

    try {
      if ( publishDateTime.toString() !== 'Invalid date' && moment(publishDateTime).isValid()) {
        if ( this.orderDetailsScheduleService.isPast(get(item, 'publishDateTime')) ) {
          set(item, 'publishDatePastError', true);
        } else {
          set(item, 'publishDatePastError', false);
        }
      }
      if ( dueDateTime.toString() !== 'Invalid date' && moment(dueDateTime).isValid() ) {
        if ( this.orderDetailsScheduleService.isTooSoon(get(item, 'dueDateTime')) ) {
          set(item, 'dateWarning', true);
        } else {
          set(item, 'dateWarning', false);
        }
        if ( this.orderDetailsScheduleService.isPast(get(item, 'dueDateTime')) ) {
          set(item, 'dueDatePastError', true);
        } else {
          set(item, 'dueDatePastError', false);
        }
        if ( publishDateTime.toString() !== 'Invalid date' && moment(publishDateTime).isValid()) {
          if ( this.orderDetailsScheduleService.isValidDate(get(item, 'dueDateTime'), get(item, 'publishDateTime') )) {
            set(item, 'dateError', false);
          } else {
            set(item, 'dateError', true);
          }
        }
      }
    } catch (e) {
      console.log('Date not in proper format.');
    }
  }

  saveNonVideoContentToModel(event, dataType) {
    const orderStore = this.orderDetailsScheduleService.getOrderStore();

    set(this.order.lineItems[0], 'dateError', false);
    set(this.order.lineItems[0], 'dateWarning', false);
    set(this.order.lineItems[0], 'dueDatePastError', false);
    set(this.order.lineItems[0], 'launchDatePastError', false);

    if (dataType === 'dueByDate') {
      if (!moment(event.date, 'MM/DD/YYYY').isValid()) {
        this.order.lineItems[0].dueByDate = event.date;
        this.order.lineItems[0].dueDateTime = undefined;
        orderStore.notify();
        return;
      }
      if (!this.order.lineItems[0].dueByTime) {
        this.order.lineItems[0].dueByTime = '12:00 PM';
      }
      this.order.lineItems[0].dueByDate = event.date;
    } else if (dataType === 'dueByTime') {
      if (!this.timeValidator(event.time)) {
        this.order.lineItems[0].dueByTime = event.time;
        this.order.lineItems[0].dueDateTime = undefined;
        orderStore.notify();
        return;
      } else {
        this.order.lineItems[0].dueByTime = event.time;
      }
    } else if (dataType === 'launchByDate') {
      if (!moment(event.date, 'MM/DD/YYYY').isValid()) {
        this.order.lineItems[0].launchByDate = event.date;
        if (event.isFilled && !event.isValid && this.order.metadata.orderType.toLowerCase() === 'site_app_updates') {
          this.order.lineItems[0].launchDateTime = 'notValid';
          if (!this.order.lineItems[0].launchByTime) {
            this.order.lineItems[0].launchByTime = '12:00 PM';
          }
        } else {
          this.order.lineItems[0].launchDateTime = undefined;
        }
        this.order.lineItems[0].launchDateError = event.isFilled && !event.isValid;
        orderStore.notify();
        return;
      }
      if (!this.order.lineItems[0].launchByTime) {
        this.order.lineItems[0].launchByTime = '12:00 PM';
      }
      this.order.lineItems[0].launchByDate = event.date;
      set(this.order.lineItems[0], 'launchDateError', false);
    } else if (dataType === 'launchByTime') {
      if (!this.timeValidator(event.time)) {
        this.order.lineItems[0].launchByTime = event.time;
        this.order.lineItems[0].launchDateTime = undefined;
        orderStore.notify();
        return;
      } else {
        this.order.lineItems[0].launchByTime = event.time;
      }
    }

    const request = this.order.lineItems[0].activities[0].instructions.filter(item => item.label === 'requestType')[0];

    if (this.order.lineItems[0]['dueByDate'] && this.order.lineItems[0]['dueByTime']) {
      if (moment(this.order.lineItems[0]['dueByDate'], ['YYYY-MM-DD', 'MM/DD/YYYY']).isValid()
      && this.timeValidator(this.order.lineItems[0]['dueByTime'])) {
        const dueDateTime = new Date(this.order.lineItems[0]['dueByDate'] + ' ' + this.order.lineItems[0]['dueByTime']);
        this.order.lineItems[0].dueDateTime = moment.utc(dueDateTime).toISOString();
        this.order.lineItems[0].dateWarning = this.orderDetailsScheduleService.isTooSoon(this.order.lineItems[0].dueDateTime);
        this.order.lineItems[0].dueDatePastError = this.orderDetailsScheduleService.isPast(this.order.lineItems[0].dueDateTime);
        if(this.order.metadata.orderType.toLowerCase() === 'graphics' && request && request.values[0] === 'VMN') {
          this.order.lineItems[0].dueDateFiveDaysError = this.orderDetailsScheduleService.isDateFiveDaysFurther(this.order.lineItems[0].dueDateTime);
        }
      }
    }
    if (this.order.lineItems[0]['launchByDate'] && this.order.lineItems[0]['launchByTime']) {
      if (moment(this.order.lineItems[0]['launchByDate'], ['YYYY-MM-DD', 'MM/DD/YYYY']).isValid()
      && this.timeValidator(this.order.lineItems[0]['launchByTime'])) {
        const launchDateTime = new Date(this.order.lineItems[0]['launchByDate'] + ' ' + this.order.lineItems[0]['launchByTime']);
        this.order.lineItems[0].launchDateTime = moment.utc(launchDateTime).toISOString();
        this.order.lineItems[0].launchDatePastError = this.orderDetailsScheduleService.isPast(this.order.lineItems[0].launchDateTime);
        this.order.lineItems[0].dateError = !this.orderDetailsScheduleService.isValidDate(this.order.lineItems[0].dueDateTime, this.order.lineItems[0].launchDateTime);
      }
    }
    if (request && request.values[0] !== 'VMN') {
      this.order.lineItems[0].launchDateTime = undefined;
    }

    if (this.order.metadata.orderType.toLowerCase() === 'graphics' && this.isOpenInModal) {
      this.isFormValid = this.orderDetailsScheduleService.checkSchedule(this.order.lineItems, this.requestTypeVmn);
      this.isValid.emit(this.isFormValid);
    }

    /**
     * Refactor due: the below function will replace applyToAll function for any
     * order types that has multiple assets
     */
    if (this.order.lineItems.length > 1) {
      this.applyScheduleToAllAssets(this.order.lineItems[0]);
    }
    orderStore.updateCurrentOrder(this.order);
  }

  updateReason(event) {
    if (typeof event === 'string') {
      const reason = event.trim() !== '' ? event : '';
      if (reason !== undefined) {
        const index = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'dueDateReason');
        if (index >= 0) {
          this.order.lineItems[0].activities[0].instructions[index].values = [reason];
        } else {
            this.order.lineItems[0].activities[0].instructions.push({
              label: 'dueDateReason',
              values: [reason],
              type: ''
            });
        }
        this.orderDetailsScheduleService.getOrderStore().updateCurrentOrder(this.order);
      }
    }
  }

  // for non-video orders, i.e. copy and graphics
  initializeDueDateTime() {
    const currentOrderDueDateTime = this.order.lineItems[0].dueDateTime;
    if (currentOrderDueDateTime) {
      this.order.lineItems[0].dateWarning = this.orderDetailsScheduleService.isTooSoon(currentOrderDueDateTime);
      this.order.lineItems[0].dueDatePastError = this.orderDetailsScheduleService.isPast(currentOrderDueDateTime);
      if (!this.order.lineItems[0].dueByDate) {
        this.order.lineItems[0].dueByDate = moment(currentOrderDueDateTime).format('YYYY-MM-DD');
      }
      if (!this.order.lineItems[0].dueByTime) {
        this.order.lineItems[0].dueByTime = moment(currentOrderDueDateTime).format('hh:mm A');
      }
    }
    if (this.getApprovableActivities(this.order.lineItems[0].activities, 14) || this.getApprovableActivities(this.order.lineItems[0].activities, 5)) {
      const currentOrderLaunchDateTime = this.order.lineItems[0].launchDateTime;
      if (currentOrderLaunchDateTime) {
        this.order.lineItems[0].launchDateWarning = this.orderDetailsScheduleService.isTooSoon(currentOrderLaunchDateTime);
        this.order.lineItems[0].launchDatePastError = this.orderDetailsScheduleService.isPast(currentOrderLaunchDateTime);
        if (!this.order.lineItems[0].launchByDate) {
          this.order.lineItems[0].launchByDate = moment(currentOrderLaunchDateTime).format('YYYY-MM-DD');
        }
        if (!this.order.lineItems[0].launchByTime) {
          this.order.lineItems[0].launchByTime = moment(currentOrderLaunchDateTime).format('hh:mm A');
        }
      }
    }
    if (this.order.metadata.orderType.toLowerCase() === 'graphics') {
        let requestIndex = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'requestType');
        let index = this.order.lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'dueDateReason');
        if (requestIndex >= 0 && this.order.lineItems[0].activities[0].instructions[requestIndex].values[0] === 'VMN') {
          this.requestTypeVmn = true;
        } else {
          this.requestTypeVmn = false;
        }
        if (index >= 0) {
          this.reasonForDueDate = this.order.lineItems[0].activities[0].instructions[index].values[0];
        } else {
          this.reasonForDueDate = '';
        }

        if (this.isOpenInModal) {
          this.isFormValid = this.orderDetailsScheduleService.checkSchedule(this.order.lineItems, this.requestTypeVmn);
          this.isValid.emit(this.isFormValid);
          //this.updatedOrder.emit(this.order);
        }
    }
  }

  timeValidator(timeStr: string): boolean {
    if (!timeStr) {
      return false;
    }
    const parserColon = timeStr.indexOf(':');
    const parserSpace = timeStr.indexOf(' ');
    const hourStr = timeStr.substr(0, parserColon);
    const minuteStr = timeStr.substr(parserColon + 1, parserSpace - parserColon - 1);
    const periodStr = timeStr.substr(parserSpace + 1);
    const h = Number(hourStr);
    const m = Number(minuteStr);
    if (h > 0 && h <= 12) {
      if (m >= 0 && m < 60 && minuteStr.length === 2) {
        if (periodStr === 'AM' || periodStr === 'PM') {
          return true;
        }
      }
    }
    return false;
  }

  getApprovableActivities(activities: Array<Activity>, typeId): boolean {
    return (find(activities, {'typeId': typeId})) ? true : false;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
