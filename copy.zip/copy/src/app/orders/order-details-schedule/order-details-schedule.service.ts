import { Injectable } from '@angular/core';
import * as moment from 'moment/moment';
import { OrderStore } from '../../models/order-store';

@Injectable()
export class OrderDetailsScheduleService {
  order;

  constructor(private orderStore: OrderStore) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  isValidDate(dueDate, publishDate) {
    if ( dueDate !== undefined || publishDate !== undefined ) {
      return moment.utc(publishDate) > moment.utc(dueDate);
    } else {
      return false;
    }
  }

  isTooSoon(dateTimeISO) {
    const now = new Date().getTime();
    const dateTime = new Date(dateTimeISO).getTime();
    return dateTime - now < 7200000 && dateTime > now;
  }

  isPast(dateTimeISO) {
    const now = new Date().getTime();
    const dateTime = new Date(dateTimeISO).getTime();
    return dateTime < now;
  }

  isDateFiveDaysFurther(dateTimeISO) {
    const fiveFuture = new Date();
    fiveFuture.setDate(fiveFuture.getDate() + 5);
    const now = fiveFuture.getTime();
    const dateTime = new Date(dateTimeISO).getTime();
    return dateTime < now;
  }

  checkForDueDateReason(lineItems) {
    const index = lineItems[0].activities[0].instructions.findIndex(ins => ins.label === 'dueDateReason');
    if (index >= 0) {
      if (lineItems[0].activities[0].instructions[index].values[0].length > 0) {
        return true;
      }
    }
    return false;
  }

  checkSchedule(lineItems, requestTypeVmn) {
      if (requestTypeVmn) {
        return lineItems[0].dueDateTime && !this.isPast(lineItems[0].dueDateTime) && 
        !this.isPast(lineItems[0].launchDateTime)
        && this.isValidDate(lineItems[0].dueDateTime, lineItems[0].launchDateTime)
        && this.checkForDueDateReason(lineItems);
      } else {
        return lineItems[0].dueDateTime && !this.isPast(lineItems[0].dueDateTime);
      }
  }
}
