/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/of';

import { OrderDetailsScheduleComponent } from './order-details-schedule.component';
import { OrderDetailsScheduleService } from './order-details-schedule.service';
import { OrderStore } from '../../models/order-store';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { StorageService } from '../../services/storage.service';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { SecretService } from '../../services/secret.service';
import { LoginService } from '../../login/login.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';

import { AdalService } from '../../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsFormatService } from '../order-details-format/order-details-format.service';
import { OrdersService } from '../orders/orders.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HtmlFormatDirective } from '../../directives/html-format.directive';

describe('OrderDetailsScheduleComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  let mockScheduleService = {
      get: () => {}
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderDetailsScheduleComponent, HtmlFormatDirective ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [HttpClientModule, FormsModule, RouterTestingModule],
      providers: [
        {provide: OrderDetailsScheduleService, useValue: mockScheduleService},
        OrderProgressTrackerService,
        OrderDetailsFormatService,
        OrdersService,
        OrderStore,
        {
          provide: ActivatedRoute, useValue: {
            data: Observable.of({ section: 'schedule' })
          }
        },
        SystemAlertsService,
        UtilityService,
        ConfigService,
        EndpointProfileService,
        StorageService,
        LoadingMaskService,
        UserService,
        LoginService,
        MockBackend,
        BaseRequestOptions,
        SecretService,
        AdalService,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrderDetailsScheduleComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    app = fixture.debugElement.componentInstance; // to access properties and methods
  }));

  beforeEach(inject([OrderDetailsScheduleService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
});
