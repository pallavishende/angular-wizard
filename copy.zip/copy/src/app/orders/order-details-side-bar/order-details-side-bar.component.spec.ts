/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ModalModule } from "app/shared/ng-modal";

import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/observable/of';

import { OrderDetailsSideBarComponent } from './order-details-side-bar.component';
import { HtmlFormatDirective } from '../../directives/html-format.directive';
import { OrderStore } from '../../models/order-store';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UtilityService } from '../../services/utility.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';

import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsReviewService } from '../order-details-review/order-details-review.service';
import { OrderDetailsScheduleService } from '../order-details-schedule/order-details-schedule.service';
import { OrderDetailsFormatService } from '../order-details-format/order-details-format.service';
import { OrdersService } from '../orders/orders.service';
import { UserService } from '../../services/user.service';

describe('OrderDetailsSideBarComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  let component: OrderDetailsSideBarComponent;
  let mockSideBarService = {
      get: () => {}
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderDetailsSideBarComponent, HtmlFormatDirective ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [HttpClientModule, FormsModule, ModalModule],
      providers: [
        {provide: OrderDetailsReviewService, useValue: mockSideBarService},
        {provide: OrderDetailsScheduleService, useValue: mockSideBarService},
        {provide: OrderDetailsFormatService, useValue: mockSideBarService},
        OrderProgressTrackerService,
        OrdersService,
        {provide: UserService, useValue: mockSideBarService},
        OrderStore,
        {
          provide: ActivatedRoute, useValue: {
            data: Observable.of({ section: 'sidebar' })
          }
        },
        {
          provide: Router, useValue: {
            param: Observable.of({ id: '1234' })
          }
        },
        SystemAlertsService,
        UtilityService,
        ConfigService,
        EndpointProfileService,
        LoadingMaskService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrderDetailsSideBarComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    app = fixture.debugElement.componentInstance; // to access properties and methods
  }));

  beforeEach(inject([OrderDetailsReviewService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  it('should create sidebar component', () => {
    expect(app).toBeTruthy();
  });
});
