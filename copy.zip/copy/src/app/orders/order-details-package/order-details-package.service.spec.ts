/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';

import { OrderStore } from '../../models/order-store';
import { UtilityService } from '../../services/utility.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { OrdersService } from '../orders/orders.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { UserService } from '../../services/user.service';

import { OrderDetailsPackageService } from './order-details-package.service';

import { AdalService } from '../../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { LoginService } from "../../login/login.service";
import { RouterTestingModule } from '@angular/router/testing';
import { SecretService } from "../../services/secret.service";
import { StorageService } from "../../services/storage.service";
import { ConfigurationManagerService} from '../../configuration/configuration-manager.service';
import { EnvironmentService } from '../../services/environment.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';

describe('OrderDetailsPackageService', () => {
  let service, orderStore, mockBackend;
  let fixture, greeter, element, debugElem, app;
  let mockPackageService = {
      get: () => {}
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, RouterTestingModule ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {provide: OrderDetailsPackageService, useValue: mockPackageService},
        {provide: OrderProgressTrackerService, useValue: mockPackageService},
        SystemAlertsService,
        ConfigService,
        EndpointProfileService,
        OrderStore,
        OrdersService,
        UtilityService,
        LoadingMaskService,
        MockBackend,
        UserService,
        StorageService,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        AdalService,
        LoginService,
        SecretService,
        ConfigurationManagerService,
        EnvironmentService
      ]
    })
    .compileComponents();
    // fixture = TestBed.createComponent(OrderDetailsPackageComponent);
    // element = fixture.nativeElement;              // to access DOM element
    // debugElem = fixture.debugElement;             // test helper
    //app = fixture.debugElement.componentInstance; // to access properties and methods
    // app = fixture.componentInstance; // to access properties and methods
    //fixture.detectChanges();
  });

  beforeEach(inject([OrderDetailsPackageService, OrderStore, MockBackend], (s, o, m) => {
    service = s;
    mockBackend = m;
    orderStore = o;
  }));

  it('should create an instance of the service', ()=> {
    expect(service).toBeTruthy();
  });
});
