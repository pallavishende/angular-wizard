/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ModalModule } from "app/shared/ng-modal";
import { HttpClientModule } from '@angular/common/http';
import { ConfigService } from '../../services/config.service';
import { RouterTestingModule } from '@angular/router/testing';

import { OrdersComponent } from './orders.component';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { AdalService } from '../../shared/auth/adal.service';
import { SecretService } from "../../services/secret.service";
import { Http, BaseRequestOptions} from "@angular/http";
import { MockBackend, MockConnection } from '@angular/http/testing';

describe('OrdersComponent', () => {
  let component: OrdersComponent;
  let fixture: ComponentFixture<OrdersComponent>;
  let adalContext;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ ModalModule, HttpClientModule, RouterTestingModule ],
      declarations: [ OrdersComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {provide: ConfigService, useValue: ConfigService},
        LoadingMaskService,
        {
            provide: AdalService,
            useFactory: (secretService) => {
              let service = new AdalService();
              service.init(secretService.adalConfig);
              return service;
              },
            deps: [SecretService]
        },
        SecretService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        }, ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
