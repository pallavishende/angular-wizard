import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { ConfigService } from '../../services/config.service';
import { UserService } from '../../services/user.service';
import { Order } from '../../models/order';
import { OrderInstruction } from '../../models/bridge-order/shared.model';

@Injectable()
export class OrdersService {

private lastSubmittedOrderId: string;
isNewSubmittedOrder: boolean;

private linkedOrdersSubject = new BehaviorSubject(null);
linkedOrdersStream = this.linkedOrdersSubject.asObservable();

  constructor(
    private title: Title,
    private configService: ConfigService,
    private userService: UserService,
    private authHttp: HttpClient
  ) { }

  getOrders(ordersQueryParam: any, page?: number, pageSize?: number) {
    let size: number;
    let searchQuery = '';
    let ordersType = '';
    let orderQuery = '';
    const filterQuery = ordersQueryParam.filterSearchTerms && ordersQueryParam.filterSearchTerms.length > 0 ? '&' + ordersQueryParam.filterQuery : '';
    if (page === undefined) {
      page = 0;
      size = 100;
    } else {
      if (!pageSize) {
        if (page === 0) {
          size = 50;
        } else {
          size = 25;
        }
      } else {
        page = 0;
        size = pageSize;
      }
    }

    if (ordersQueryParam.ordersType && ordersQueryParam.ordersType !== '') {
      ordersType = '&' + ordersQueryParam.ordersType;
    }
    if (ordersQueryParam.ordersSearchTerm && ordersQueryParam.ordersSearchTerm !== '') {
      searchQuery = '&q=' + encodeURIComponent(ordersQueryParam.ordersSearchTerm);
    }
    if (ordersQueryParam.ordersId && ordersQueryParam.ordersId.length > 0) {
      orderQuery = '&orders=' + ordersQueryParam.ordersId.join();
    }
    return this.authHttp.get(this.configService.ordersUrl
      + '?size=' + size + '&page=' + page + '&sort=lastModifiedDate,desc' + ordersType + searchQuery + filterQuery + orderQuery)
      .map((response: any) => response);
  }

  getMyDraftOrders() {
    return this.authHttp.get(this.configService.ordersUrl
      + '?sort=lastModifiedDate,desc' + '&statuses=DRAFT&userEmails=' + this.userService.getUserLoginInfo().email + '&size=100');
  }

  deleteOrder(id) {
    return this.authHttp.delete(this.configService.omfUrl + id);
  }

  cancelOrder(id) {
  return this.authHttp.put(this.configService.omfUrl + id + '/cancelOrder', {});
  }

  createOrder(payload) {
    const body = payload;
     return this.authHttp.post(this.configService.omfUrl, body)
     .map((response: any) => response);
  }

  getOrder(id): Observable<Order> {
    return this.authHttp.get(this.configService.orderDetailsUrl + 'customise-order/' + id)
    .map((response: any) => response);
  }

  getOrderDetails(id): Observable<Order> {
    return this.authHttp.get(this.configService.orderDetailsUrl + id)
    .map((response: any) => response);
  }

  getRawOrder(id) {
    return this.authHttp.get(this.configService.orderDetailsUrl + id);
  }

  modifyOrder(id, payload) {
    return this.authHttp.put(this.configService.omfUrl + id, payload)
    .map((response: any) => response);
  }

  placeOrder(id) {
    return this.authHttp.put(this.configService.omfUrl + id + '/placeOrder', {});
  }

  setOrderOwner(payload) {
    return this.authHttp.put(this.configService.orderOwnerAssignmentUrl, payload)
    .map((response: any) => response);
  }

  updateOrderName(id, name) {
    return this.authHttp.put(this.configService.omfUrl + id + '/name?orderName=' + encodeURIComponent(name), {})
    .map((response: any) => response);
  }

  linkOrders(orderId: number, linkIdArr: Array<number>) {
    const payload = {orderIds: linkIdArr, reverseRelation: true};
    return this.authHttp.put(this.configService.omfUrl + orderId + '/relate', payload)
    .map((response: any) => response);
  }

  unlinkOrders(orderId: number, linkIdArr: Array<number>) {
    const payload = {orderIds: linkIdArr, reverseRelation: true};
    return this.authHttp.put(this.configService.omfUrl + orderId + '/unrelate', payload)
    .map((response: any) => response);
  }

  watchOrder(orderId: number, payload: any) {
    return this.authHttp.post(this.configService.omfUrl + orderId + '/watchers', payload)
    .map((response: any) => response);
  }

  unwatchOrder(orderId: number, payload: any) {
    return this.authHttp.put(this.configService.omfUrl + orderId + '/watchers', payload)
    .map((response: any) => response);
  }

  notifyLinkOrderUpdate(payload) {
    this.linkedOrdersSubject.next(payload);
  }

  getLinkedOrdersObservable() {
    return this.linkedOrdersStream;
  }

  getFilters(ordersType, id?: string) {
    let orderTypeParam;
    switch (ordersType) {
      case 'my-orders':
        orderTypeParam = '?ownedBy=' + this.userService.getUserLoginInfo().email;
        break;
      case 'my-drafts':
        orderTypeParam = '?ownedBy=' + this.userService.getUserLoginInfo().email + '&status=DRAFT';
        break;
      case 'my-teams-orders':
        orderTypeParam = '?ownedByTeams=' + id;
        break;
      case 'all-orders':
        orderTypeParam = '';
        break;
      case 'watching':
        orderTypeParam = '?watcherEmail=' + this.userService.getUserLoginInfo().email;
        break;
      default:
        orderTypeParam = '';
        break;
    }
    return this.authHttp.get(this.configService.orderFiltersUrl + orderTypeParam)
    .map((response: any) => response);
  }

  setOrdersPageTitle(title: string) {
    this.title.setTitle(title);
  }

  getLastSubmittedOrderId(): string {
    return this.lastSubmittedOrderId;
  }

  setLastSubmittedOrderId(orderId: string): void {
    this.lastSubmittedOrderId = orderId;
  }

  clearLastSubmittedOrderId(): void {
    delete this.lastSubmittedOrderId;
  }

  generatePressOrderEmptyLineItem(activityObj, orderType) {
    const emptyLineItemObj = {
      activities: activityObj ? [activityObj] : [],
      metadata: [
        {
          clipTitle: orderType === 'press' ? null : '',
          clipId: orderType === 'press' ? null : '',
          dsId: orderType === 'press' ? null : '',
          clipDSId: orderType === 'press' ? null : '',
          duration: orderType === 'press' ? null : '',
          assetInputs: [
            {
              assetNumber: 'Asset 1',
              assetName: '',
              assetSource: '',
              inOutPoint: null,
              clipId: null
            }
          ]
        }
      ]
    };
    return emptyLineItemObj;
  }

  createOrderInstructions(): OrderInstruction {
    return {
      siteAndAppPresets: null,
      dropOffLocation: null,
      captions: null,
      captionsBillingGroup: null,
      instructions: '',
      dueDateTime: '',
      publishDateTime: null,
      launchDateTime: null,
      deliveryFormat: '',
      budgetCode: '',
      rollingDueDate: '',
      deliveryLocation: null
    };
  }

}
