import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { OrderStore } from '../../models/order-store';

@Injectable()
export class OrderDetailsReviewService {
  order;

  constructor(private orderStore: OrderStore) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  updateOrderStore(item) {
    let orderStore = this.getOrderStore();
    orderStore.updateExistingLineItem(item);
  }

  removeLineItemsFromOrder(clipIdentifier) {
    let orderStore = this.getOrderStore();
    console.log('service > removeLineItemsFromOrder > clipTitle: ', clipIdentifier.value );
    orderStore.removeLineItemsByProperty(clipIdentifier.property, clipIdentifier.value);
  }

  getGraphicsOrderSummary(graphicsInstrFormFields, instructions) {

    let instructionMap = {};
    let platformList = [];
    let brandName;
    let platformNames = [];
    const orderGraphicsFormFields = graphicsInstrFormFields;
    if (instructions && instructions.length > 0) {
      const requestIndex = this.getInstructionsIndex(instructions, 'requestType');
      if (requestIndex >= 0) {
        const requestType = instructions[requestIndex].values[0];
        if (requestType === 'VMN') {
          const resultForm = instructions.filter(inst => inst.type === '');

          if (resultForm.length > 0) {
            resultForm.map(f => {
              if (f.label !== 'platformList') {
                instructionMap[f.label] = f.values[0];
              }
            });
          }

          const brandIndex = this.getInstructionsIndex(instructions, 'brand');
          if (brandIndex >= 0) {
            const brandCode = instructions[brandIndex].values[0];
            brandName = orderGraphicsFormFields.BrandDropDown.filter(b => b.id === brandCode)[0];
            instructionMap['brand'] = brandName['value'];
            platformNames = brandName['options'];
          }

          const inx = this.getInstructionsIndex(instructions, 'platformList');
          const platformLst = [];
          if (inx >= 0) {
            const platformLstBkp = instructions[inx].values;
            platformNames.forEach(pltName => {
              if (platformLstBkp.findIndex(plt => plt === pltName.id) >= 0) {
                platformLst.push(pltName.id);
              }
            });

            if (platformLst && platformLst.length >= 0) {

              platformLst.forEach(platform => {
                const specification = orderGraphicsFormFields.RequestType[platform][1].options;

                const specificationMap = {};
                if (specification) {
                  specification.map(spe => {
                    specificationMap[spe.key] = spe.label;
                  });
                }

                const result = instructions.filter(inst => inst.type === platform);
                if (result && result.length >= 0) {
                  const options = [];
                  const specsList = [];
                  let cta = undefined;
                  result.forEach(res => {
                    if (res.label === 'CTA') {
                      const label = 'Copy or Special Instructions';
                      cta = {label: label, value: res.values[0]};
                    } else if (res.label === 'dimensions') {
                      const label = 'Custom Dimensions';
                      options.push({label: label, value: res.values[0]});
                    } else if (res.label === 'Description') {
                      const label = 'Description';
                      options.push({label: label, value: res.values[0]});
                    } else {
                      specsList.push(specificationMap[res.label]);
                    }
                  });

                  const platFormName = brandName['options'].filter(opt => opt.id === platform)[0].value;
                  if (specsList.length > 0) {
                    options.unshift({label: 'Specs', value: specsList});
                  }
                  if (cta) {
                    options.push(cta);
                  }
                    platformList.push({platformName: platFormName, options});
                }
              });
            }
          }
        }
      }

    }
    return {instructionMap: instructionMap, platformList: platformList};
  }

  getPressOrderSummary(pressInstrFormFields, instructions) {
    let instructionsList = [];
    if (typeof instructions !== 'undefined' && instructions.length > 0) {
      const requestIndex = this.getInstructionsIndex(instructions, 'requestType');
      if (requestIndex >= 0) {
        const requestType = instructions[requestIndex].values[0];
        if (typeof requestType !== 'undefined' && typeof pressInstrFormFields !== 'undefined') {
          let options = [];
              const requestLabel = pressInstrFormFields.RequestTypeDropDown.filter(request => request.id === requestType)[0];
              if (requestLabel) {
                instructionsList.push({specificationName: 'Request Type', value: requestLabel.value});
              }
              pressInstrFormFields.RequestType[requestType].forEach(request => {
                const specification = request.options;
                const specificationMap = {};
                if (specification) {
                  specification.map(spec => {
                    specificationMap[spec.key] = spec.label;
                  });
                }
                const result = instructions.filter(inst => inst.label === request.key);
                if (result && result.length >= 0) {

                  result.forEach(res => {
                      instructionsList.push({specificationName: request.label, value: specificationMap[res.values[0]] ? specificationMap[res.values[0]] : res.values[0]});
                  });
                }
                options = [];
                if (request.key === 'VideoOptions') {
                  specification.forEach(spec => {
                    const specOptions = instructions.filter(inst => inst.label === spec.key);
                    if (specOptions && specOptions[0] && specOptions[0].values) {
                      options.push(spec.label);
                    }
                  });
                  if (options.length > 0) {
                    instructionsList.push({specificationName: request.label, value: options});
                  }
                }
                options = [];
                if (request.key === 'deliveryOptions') {
                  specification.forEach(spec => {
                    const specOptions = instructions.filter(inst => inst.label === spec.key);
                    if (specOptions && specOptions[0] && specOptions[0].values) {
                      options.push(spec.label);
                    }
                  });
                  if (options.length > 0) {
                    instructionsList.push({specificationName: request.label, value: options});
                  }
                }
              });
        }
      }

    }

    return instructionsList;
  }

  getInstructionsIndex(instructions, label) {
    return instructions.findIndex(inst => inst.label === label);
  }
}