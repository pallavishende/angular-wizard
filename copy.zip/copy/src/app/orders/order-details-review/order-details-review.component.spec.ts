/* tslint:disable:no-unused-variable */
import { TestBed, async, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { UserService } from '../../services/user.service';
import 'rxjs/add/observable/of';

import { OrderStore } from '../../models/order-store';
import { UtilityService } from '../../services/utility.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { HtmlFormatDirective } from '../../directives/html-format.directive';

import { OrdersService } from '../orders/orders.service';
import { OrderDetailsReviewComponent } from './order-details-review.component';
import { OrderDetailsReviewService } from './order-details-review.service';

import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';

xdescribe('OrderDetailsReviewComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  let mockReviewService = {
      get: () => {}
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ OrderDetailsReviewComponent, HtmlFormatDirective ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        OrdersService,
        {provide: OrderDetailsReviewService, useValue: mockReviewService},
        {provide: OrderProgressTrackerService, useValue: mockReviewService},
        {provide: UserService, useValue: mockReviewService},
        OrderStore,
        {
          provide: ActivatedRoute, useValue: {
            params: Observable.of({ id: 'test' })
          }
        },
        UtilityService,
        SystemAlertsService,
        EndpointProfileService,
        ConfigService,
        LoadingMaskService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OrderDetailsReviewComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    //app = fixture.debugElement.componentInstance; // to access properties and methods
    app = fixture.componentInstance; // to access properties and methods
    //fixture.detectChanges();
  }));

  beforeEach(inject([OrderDetailsReviewService, MockBackend], (s, m) => {
    service = s;
    mockBackend = m;
  }));

  it('should create review component', async(() => {
    expect(app).toBeDefined();
  }));

});
