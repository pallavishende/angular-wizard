import { Injectable } from '@angular/core';
import { OrderStore } from '../../models/order-store';
import { Order } from '../../models/order';
import { LineItem } from '../../models/line-item';
import { CustomConfig } from '../../models/custom-config';
import { filter, get, map, sortBy, find } from 'lodash';
import { UtilityService } from '../../services/utility.service';

@Injectable()
export class OrderDetailsPlatformService {
  order: Order;

  constructor(private orderStore: OrderStore, private utilityService: UtilityService) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  generateVersionName(clipId: string, clipTitle: string, platform: string) {
    const numberPattern = /\d+/g;
    let latestVersion;
    let versionIncrease = 1;
    // 1. get all line items with version in customConfig version
    let similarNames = filter(this.order.lineItems, (lineItem) => {
      if (get(lineItem, 'customConfig.version') !== undefined) {
        if (lineItem['metadata'][0]['clipId']) {
          return lineItem['metadata'][0]['clipId'] === clipId
            && get(lineItem, 'customConfig.version').toString().indexOf('Version') !== -1
            && get(lineItem, 'customConfig.endpoint') === platform;
        } else {
          return lineItem['metadata'][0]['clipTitle'] === clipTitle
            && get(lineItem, 'customConfig.version').toString().indexOf('Version') !== -1
            && get(lineItem, 'customConfig.endpoint') === platform;
        }
      }
    });

    // 2. strip out the heighest version and increase it by 1
    if (similarNames !== undefined && similarNames.length > 0) {
      map(similarNames, (item) => {
        let tmp = item;
        item['n'] = {
          namePart: name,
          versionPart: (get(item, 'customConfig.version').toString().match(numberPattern)) ? (get(item, 'customConfig.version').toString().match(numberPattern))[0] : 0
        };
        return item;
      });
      similarNames = sortBy(similarNames, (name) => {
        let tmp = get(name, 'n.versionPart').toString();
        return parseInt(tmp, 10);
      });
      latestVersion = get(similarNames[similarNames.length - 1], 'n.versionPart');
      versionIncrease = 1 + parseInt(latestVersion);
    }
    return 'Version ' + versionIncrease.toString();
  }

  increasePlatforms(orderData: Order, lineItem: LineItem, platform) {
    this.order = orderData;
    let orderStore = this.getOrderStore();

    let FilterFn = this.utilityService.propertyFilter;  // maintain reference

    // 1. find a line item that has matching platform and vmid
    let existingLineItem = find(this.order.lineItems, (item) => {
      if (item['metadata'][0]['clipId']) {
        return FilterFn(item, 'customConfig.endpoint', platform) && item['metadata'][0]['clipId'] === lineItem['metadata'][0]['clipId'];
      } else {
        if (lineItem['metadata'][0]['clipId']) {
          return false;
        }
        return FilterFn(item, 'customConfig.endpoint', platform) && item['metadata'][0]['clipTitle'] === lineItem['metadata'][0]['clipTitle'];
      }
    });
    // 1a. NOT FOUND
    if (existingLineItem === undefined) {
      let updatedLineItem = {};
      // 1a.a get an empty line item with matching vmid and no custom config
      let emptyLineItem = find(this.order.lineItems, (item) => {
        if (item['metadata'][0]['clipId']) {
          return !item['customConfig'] && item['metadata'][0]['clipId'] === lineItem['metadata'][0]['clipId'];
        } else {
          if (lineItem['metadata'][0]['clipId']) {
            return false;
          }
          return !item['customConfig'] && item['metadata'][0]['clipTitle'] === lineItem['metadata'][0]['clipTitle'];
        }
      });
      // 1a.a.a. NOT FOUND
      if (emptyLineItem == undefined) {
        // get an empty line item with matching vmid only
        // we will create a new object with this and add to line items
        let lineItemWithMatchingVmid = find(this.order.lineItems, (item) => {
          if (item['metadata'][0]['clipId']) {
            return item['metadata'][0]['clipId'] === lineItem['metadata'][0]['clipId'];
          } else {
            if (lineItem['metadata'][0]['clipId']) {
              return false;
            }
            return item['metadata'][0]['clipTitle'] === lineItem['metadata'][0]['clipTitle'];
          }
        });
        const brandNewLineItem = new LineItem();
        brandNewLineItem.metadata = lineItemWithMatchingVmid['metadata'];
        brandNewLineItem.customConfig = new CustomConfig();
        brandNewLineItem.customConfig.endpoint = platform;
        brandNewLineItem.customConfig.version = this.generateVersionName(lineItemWithMatchingVmid['metadata'][0]['clipId'],
        lineItemWithMatchingVmid['metadata'][0]['clipTitle'], platform);
        // brandNewLineItem.metadata = lineItemWithMatchingVmid['metadata'][0];

        orderStore.addNewLineItem(brandNewLineItem);
      } else {
        // 1a.a.b. FOUND
        updatedLineItem = emptyLineItem;
        updatedLineItem['customConfig'] = {
          endpoint: platform,
          version: this.generateVersionName(emptyLineItem['metadata'][0]['clipId'], emptyLineItem['metadata'][0]['clipTitle'], platform)
        };
        updatedLineItem['lineItemId'] = this.utilityService.generateGuid();
        orderStore.updateExistingLineItem(updatedLineItem);
      }
    } else {
      // 1b. FOUND
      // we will create a new object with this and added to line items
      const newLineItem = new LineItem();
      newLineItem.metadata = existingLineItem['metadata'];
      newLineItem.customConfig = new CustomConfig();
      newLineItem.customConfig.endpoint = platform;
      newLineItem.customConfig.version = this.generateVersionName(existingLineItem['metadata'][0]['clipId'], existingLineItem['metadata'][0]['clipTitle'], platform);
      // newLineItem.metadata = existingLineItem['metadata'][0];
      // 2. add a new line item
      orderStore.addNewLineItem(newLineItem);
    }
  }

  decreasePlatforms(orderData, lineItem, platform) {
    this.order = orderData;
    const orderStore = this.getOrderStore();
    const FilterFn = this.utilityService.propertyFilter; // maintain reference
    // check any existing newly added lineItems need to be deleted, only newly added lineItems have lineItemId
    const existingLineItems = filter(this.order.lineItems, (item) => {
      if (item['metadata'][0]['clipId']) {
        return FilterFn(item, 'customConfig.endpoint', platform)
              && item['metadata'][0]['clipId'] === lineItem['metadata'][0]['clipId']
              && item['lineItemId'];
      } else {
        if (lineItem['metadata'][0]['clipId']) {
          return false;
        }
        return FilterFn(item, 'customConfig.endpoint', platform)
              && item['metadata'][0]['clipTitle'] === lineItem['metadata'][0]['clipTitle']
              && item['lineItemId'];
      }
    });
    if (existingLineItems.length > 1) {
      // more then 1. good to delete from top
      orderStore.removeLineItem(existingLineItems[existingLineItems.length - 1]);
    } else if (existingLineItems.length === 1) {
      // equals 1. don't want to remove the only lineItem in clip, let's check if other lineItems in this clip that's not removable exist

      // submitted lineItems, not removable by + -
      const submittedLineItems = filter(this.order.lineItems, (item) => {
        if (item['metadata'][0]['clipId']) {
          return FilterFn(item, 'customConfig.endpoint', platform)
                && item['metadata'][0]['clipId'] === lineItem['metadata'][0]['clipId']
                && !item['lineItemId'];
        } else {
          if (lineItem['metadata'][0]['clipId']) {
            return false;
          }
          return FilterFn(item, 'customConfig.endpoint', platform)
                && item['metadata'][0]['clipTitle'] === lineItem['metadata'][0]['clipTitle']
                && !item['lineItemId'];
        }
      });

      // lineItems belonging to same clip but under different platform
      const lineItemsWithOtherPlatforms = filter(this.order.lineItems, (item) => {
        if (item['metadata'][0]['clipId']) {
          return !FilterFn(item, 'customConfig.endpoint', platform)
                && item['metadata'][0]['clipId'] === lineItem['metadata'][0]['clipId'];
        } else {
          if (lineItem['metadata'][0]['clipId']) {
            return false;
          }
          return !FilterFn(item, 'customConfig.endpoint', platform)
                && item['metadata'][0]['clipTitle'] === lineItem['metadata'][0]['clipTitle'];
        }
      });
      if (lineItemsWithOtherPlatforms.length > 0 || submittedLineItems.length > 0) {
        // submitted lineItems or lineItems from other platforms exist, removing lineItem won't remove the clip, fine. so good to delete from top
        orderStore.removeLineItem(existingLineItems[0]);
      } else {
        // this is the only lineItem in clip, so only modify current lineItem
        const updatedlineItem = existingLineItems[0];
        delete updatedlineItem['customConfig'];
        delete updatedlineItem['activities'];
        delete updatedlineItem['dueDateTime'];
        delete updatedlineItem['publishDateTime'];
        orderStore.updateExistingLineItem(updatedlineItem);
      }
    }
  }
}
