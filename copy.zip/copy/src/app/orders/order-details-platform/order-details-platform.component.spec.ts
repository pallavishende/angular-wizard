/* tslint:disable:no-unused-variable */
import { TestBed, async, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { Subject, BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import 'rxjs/add/observable/of';

import { LoginService } from '../../login/login.service';
import { OrderStore } from '../../models/order-store';
import { UtilityService } from '../../services/utility.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { ConfigService } from '../../services/config.service';
import { UserService } from '../../services/user.service';
import { SecretService } from '../../services/secret.service';
import { StorageService } from '../../services/storage.service';
import { CatalogService } from '../../catalog/catalog.service';
import { ModalModule } from "app/shared/ng-modal";

import { OrdersService } from '../orders/orders.service';
import { OrderDetailsPlatformComponent } from './order-details-platform.component';
import { OrderDetailsPlatformService } from './order-details-platform.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';

import { AdalService } from '../../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { EnvironmentService } from '../../services/environment.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';

xdescribe('OrderDetailsPlatformComponent', () => {
  let fixture, greeter, element, debugElem, app;
  let mockBackend, service;
  let mockPlatformService = {
      get: () => {}
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, RouterTestingModule, ModalModule ],
      declarations: [ OrderDetailsPlatformComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        LoginService,
        OrdersService,
        UserService,
        SecretService,
        StorageService,
        CatalogService,
        {provide: OrderDetailsPlatformService, useValue: mockPlatformService},
        {provide: OrderProgressTrackerService, useValue: mockPlatformService},
        OrderStore,
        {
          provide: ActivatedRoute, useValue: {
            params: Observable.of({ id: 'test' })
          }
        },
        UtilityService,
        SystemAlertsService,
        EndpointProfileService,
        ConfigService,
        LoadingMaskService,
        AdalService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
          provide: HttpClient,
          useFactory: (http: Http) => http,
          deps: [Http],
        },
        EnvironmentService,
        ConfigurationManagerService
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(OrderDetailsPlatformComponent);
    element = fixture.nativeElement;              // to access DOM element
    debugElem = fixture.debugElement;             // test helper
    //app = fixture.debugElement.componentInstance; // to access properties and methods
    app = fixture.componentInstance; // to access properties and methods
    //fixture.detectChanges();
  }));

  it('should create platform component', async(() => {
    expect(app).toBeDefined();
  }));

  it('should have ngOnInit defined', () => {
    spyOn(mockPlatformService, 'get').and.returnValue(Observable.of({id: 111}));
    expect(app.ngOnInit).toBeDefined();
  });

  it('should have dataSubscription defined', async(() => {
    spyOn(mockPlatformService, 'get').and.returnValue(Observable.of({id: 111}));
    app.initialize();
    expect(app.dataSubscription).toBeDefined();
  }));

  it('should have order defined', async(() => {
    spyOn(mockPlatformService, 'get').and.returnValue(Observable.of({id: 111}));
    app.initialize();
    expect(app.order).toBeDefined();
  }));

  it('component #increasePlatforms should have 2 parameters', () => {
    expect(app.increasePlatforms.length).toEqual(2);
  });

  it('component #decreasePlatforms should have 2 parameters', () => {
    expect(app.decreasePlatforms.length).toEqual(2);
  });

  it('#getTotalsForEndpoint should have 2 parameters', () => {
    expect(app.getTotalsForEndpoint.length).toEqual(2);
  });

  it('#getTotalsForEndpoint should return 2', () => {
    let lineItem = {
      endpoint_info: {
        'cc.com': [{id:1,lineItemId:'fasdfasdfasdf'},{id:2,lineItemId:'fasdfasdfasdf',}]
      }
    };
    let result = app.getTotalsForEndpoint(lineItem, 'cc.com');
    expect(result).toEqual(2);
  });

});
