import { Component, OnInit, OnDestroy, ElementRef, ViewChildren, ViewChild, Renderer2, QueryList, TemplateRef } from '@angular/core';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { OrdersService } from '../orders/orders.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsPlatformService } from './order-details-platform.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { CatalogService } from '../../catalog/catalog.service';
import { OrderStore } from '../../models/order-store';
import { filter, find, forEach, map, clone, remove, findIndex } from 'lodash';
import 'rxjs/add/operator/mergeMap';
import { Subscription } from 'rxjs/Subscription';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-order-details-platform',
  templateUrl: './order-details-platform.component.html',
  styleUrls: ['./order-details-platform.component.scss', '../order-customization-base/order-customization-base.component.scss'],
  providers: [OrderDetailsPlatformService]
})
export class OrderDetailsPlatformComponent implements OnInit, OnDestroy {

  @ViewChildren('assetClips') assetClips: QueryList<ElementRef>;
  @ViewChild('dropDownContainer') dropDownContainer;

  order;
  uniqueLineItems;
  subscriptions = new Subscription();
  versionSubscription: Subscription;
  endpointProfiles;
  itemDetailsObj;
  activeVmid;
  activeDsid;
  hasVersions;
  searchVersionDetailsObj: any = {};
  versionCount = 0;
  dataLoaded = false;
  hasVersionInfo;
  contentType;
  showEllipsisLoader = false;
  selectedClip;
  materialId;
  customClipsArr = [];
  customClip = {};
  customClipTitle = '';
  customClipSource = '';
  isTitleDuplicate = false;
  showClipsWhenEmpty = false;
  validationResponse = {};
  selectedVersionName;
  isEpisodeOrSpecial = false;
  activeTab: string;
  isVersionContentRestricted: boolean;
  initializeEditor = false;

  constructor(
    private alerts: SystemAlertsService,
    private ordersService: OrdersService,
    private orderDetailsPlatformService: OrderDetailsPlatformService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private endpointProfileService: EndpointProfileService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public catalogService: CatalogService,
    private renderer: Renderer2,
    private orderStore: OrderStore,
    private dialog: MatDialog
  ) {
    this.alerts = alerts;
  }

  openDialog(ref: TemplateRef<any>, width, height) {
    this.initializeEditor = false;
    this.dialog.open(ref, {
      width: width + 'px',
      height: height + 'px'
    });
    this.clearDialogContent();
    this.versionCount = 0;
    this.activeVmid = this.order.metadata.vmId || '';
    if (this.isEpisodeOrSpecial) {
      this.getItemDetails();
    }
    this.catalogService.catalogOrderClipsArr.length = 0;
    this.uncheckClips();

    if (this.activeTab === 'ADD CUSTOM ASSET') {
      setTimeout(() => {
        this.initializeEditor = true;
      });
    }
  }

  clearDialogContent() {
    this.customClip = {};
    this.customClipTitle = '';
    this.customClipSource = '';
    this.catalogService.catalogOrderClipsArr = [];
    this.isTitleDuplicate = false;
    this.initializeEditor = false;
  }

  closeDialog() {
    this.clearDialogContent();
    this.dialog.closeAll();
  }

  onTabChange(e) {
    this.activeTab = e.tab.textLabel;
    this.clearDialogContent();
    if (this.activeTab === 'ADD CUSTOM ASSET') {
      setTimeout(() => {
        this.initializeEditor = true;
      });
    }
  }

  contentChanged(e) {
    this.customClipSource = e.content;
  }

  validateCustomInput() {
    return this.customClipTitle.trim().length > 0 && this.customClipSource.replace(/&nbsp;|\s/g, '').length > 0;
  }

  ngOnInit() {
    this.ordersService.setOrdersPageTitle('Draft - Viacom Bridge');
    this.activatedRoute.data.subscribe(data => {      
      this.orderProgressTrackerService.saveRouteData(data);
      this.initialize();
    });
  }

  initialize() {
    this.subscriptions.add(this.orderDetailsPlatformService.get().subscribe(
      data => {
        const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
        const orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
        if (data['id'] && data['id'].toString() === orderId) {
          console.log('platform > initialize > data: ', data);
          this.order = data;
          if (this.order.name) {
            this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          }
          this.contentType = this.order.metadata.contentType;
          if (this.contentType === 'EPISODE' || this.contentType === 'SPECIAL') {
            this.isEpisodeOrSpecial = true;
            this.activeTab = 'CHOOSE FROM CATALOG';
          } else {
            this.activeTab = 'ADD CUSTOM ASSET';
          }
          this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
            endPointData => {
              this.endpointProfiles = endPointData;
            }
          ));
        }
      },
      error => {
        console.log('ORDER CUSTOMIZATION PLATFORM: Data not loaded');
      }
    ));
  }

  increasePlatforms(lineItem, platform) {
    this.orderDetailsPlatformService.increasePlatforms(this.order, lineItem, platform);
  }

  decreasePlatforms(lineItem, platform) {
    this.orderDetailsPlatformService.decreasePlatforms(this.order, lineItem, platform);
  }

  getTotalsForEndpoint(lineItem, endpoint) {
    return filter(lineItem.endpoint_info[endpoint], (item) => {
      return item['lineItemId'];
    }).length;
  }

  getItemDetails() {
    this.showEllipsisLoader = true;
    this.subscriptions.add(this.catalogService.getItemDetails(this.activeVmid).subscribe(
      data => {
        this.itemDetailsObj = data.contentDetails;
        if (this.order.lineItems.length) {
          this.activeDsid = this.order.lineItems[0].metadata[0].dsId || this.catalogService.selectedVersion.dsid;
          if (this.itemDetailsObj.versions.length > 0) {
            if (!this.activeDsid || this.activeDsid.length === 0) {
              this.activeDsid = this.itemDetailsObj.versions[0].dsid;
            }
            this.selectedVersionName = find(this.itemDetailsObj.versions, ['dsid', this.activeDsid])['name'];
          }
          this.getVersionDetails();
        } else if (this.itemDetailsObj.versions.length) {
          this.activeDsid = this.itemDetailsObj.versions[0].dsid;
          if (this.itemDetailsObj.versions.length > 0) {
            this.selectedVersionName = find(this.itemDetailsObj.versions, ['dsid', this.activeDsid])['name'];
          }
          this.showEllipsisLoader = false;
          if (this.activeDsid) {
            this.getVersionDetails();
          }
        } else {
          this.dataLoaded = true;
          this.showEllipsisLoader = false;
          this.hasVersions = false;
          this.showClipsWhenEmpty = true;
        }
      },
      error => {
        this.showEllipsisLoader = false;
        console.log('Error occurred while getting the item details..');
      }
    ));
  }

  getVersionDetails() {
    this.searchVersionDetailsObj = {};
    this.showEllipsisLoader = true;
    if (this.itemDetailsObj.hasVersions) {
      this.hasVersions = true;
      if (!this.catalogService.selectedVersion.dsid) {
        this.catalogService.selectedVersion = this.itemDetailsObj.versions[0];
      }
      if (!this.catalogService.selectedVersion.name) {
        for (const version of this.itemDetailsObj.versions) {
          if (version.dsid === this.catalogService.selectedVersion.dsid) {
            this.catalogService.selectedVersion.name = version.name;
            break;
          }
        }
      }
      if (this.versionSubscription) {
        this.versionSubscription.unsubscribe();
      }
      this.versionSubscription = this.catalogService.getVersionDetails(this.activeVmid, this.activeDsid).subscribe(
        (data) => {
          this.showEllipsisLoader = false;
          this.dataLoaded = true;
          this.hasVersionInfo = true;
          this.versionCount = data.assetMaterial.clips.length;
          const searchVersionDetailsObjRaw = data.assetMaterial;
          if (searchVersionDetailsObjRaw) {
            this.materialId = searchVersionDetailsObjRaw.material_id;
          }
          if (this.order.metadata.isFullEpisode) {
            if (this.order.lineItems && this.order.lineItems[0]) {
              forEach(this.order.lineItems[0].metadata, (clipMetadata) => {
                if (searchVersionDetailsObjRaw) {
                  forEach(searchVersionDetailsObjRaw.clips, (clip) => {
                    if (clip && clipMetadata.clipId === clip['id']) {
                      searchVersionDetailsObjRaw.clips.splice(searchVersionDetailsObjRaw.clips.indexOf(clip), 1);
                    }
                  });
                }
              });
            }
          } else {
            forEach(this.order['lineItems'], (orderItem) => {
              if (searchVersionDetailsObjRaw) {
                forEach(searchVersionDetailsObjRaw.clips, (clip) => {
                  if (clip && orderItem.metadata[0].clipId === clip['id']) {
                    searchVersionDetailsObjRaw.clips.splice(searchVersionDetailsObjRaw.clips.indexOf(clip), 1);
                  }
                });
              }
            });
          }
          this.searchVersionDetailsObj = searchVersionDetailsObjRaw;
        },
        (errorData) => {
          this.showEllipsisLoader = false;
          console.log('Error occurred while getting the version details..');
          if (errorData.error.status === `FORBIDDEN`) {
            if (errorData.error.message === `Unable to open content for version with VMID [${this.itemDetailsObj.vmid}] and DSID [${this.catalogService.selectedVersion.dsid}]` ||
                errorData.error.message === `Unable to preview proxy for version with VMID [${this.itemDetailsObj.vmid}] and DSID [${this.catalogService.selectedVersion.dsid}]`) {
              this.isVersionContentRestricted = true;
            }
          } else {
            if (this.isVersionContentRestricted) {
              this.isVersionContentRestricted = false;
            }
          }
          this.hasVersionInfo = false;
          this.dataLoaded = true;
        }
      );
    } else {
      this.showEllipsisLoader = false;
      this.hasVersions = false;
      this.dataLoaded = true;
    }
  }

  loadItemVersion(version, event) {
    event.stopPropagation();
    if (this.catalogService.selectedVersion.dsid !== version.dsid) {
      this.activeDsid = version.dsid;
      this.selectedVersionName = version.name;
      this.catalogService.selectedVersion = version;
      this.getVersionDetails();
    }
    this.renderer.removeClass(this.dropDownContainer.nativeElement, 'open');
  }

  isClipAlreadyAddedtoOrder(clipTitle) {
    if (map(this.catalogService.catalogOrderClipsArr, 'id').indexOf(clipTitle) > -1) {
      return true;
    } else {
      return false;
    }
  }

  addToPreorder($event) {
    $event.stopPropagation();
    const isChecked = $event.target.checked;
    const itemId = $event.target.attributes['data-id'].value;
    const itemsArray = this.searchVersionDetailsObj['clips'];
    const item = itemsArray.find((obj) => {
      return obj.id.toString() === itemId;
    });
    item.clipDSID = clone(item.dsid);
    item.dsid = this.searchVersionDetailsObj['dsid'];
    if (isChecked) {
      this.catalogService.catalogOrderClipsArr.push(item);
    } else {
      remove(this.catalogService.catalogOrderClipsArr, (clip) => {
        return item.id === clip.id;
      });
    }
  }

  addItemToOrder() {
    const clipArray = this.catalogService.catalogOrderClipsArr;
    if (this.activeTab === 'ADD CUSTOM ASSET') {
      this.customClip['clipTitle'] = this.customClipTitle.trim();
      this.customClip['type'] = 'custom';
      this.customClip['clipSource'] = this.customClipSource.trim();
      this.findDuplicates(this.customClip['clipTitle']);
      if (!this.isTitleDuplicate) {
        this.catalogService.catalogOrderClipsArr.push(this.customClip);
      } else {
        return;
      }
    }
    for (let i = 0; i < clipArray.length; i++) {
      let clipItem = {};
      if (clipArray[i]['type'] === 'custom' && clipArray[i]['clipTitle']) { // case custom clip
        clipItem = {
          'metadata': [{
            'assetInputs': [],
            'clipTitle': clipArray[i]['clipTitle'],
            'clipSource': this.customClipSource.trim()
          }]
        };
      } else if (clipArray[i]['title']) { // case archive clip
        clipItem = {
          'metadata': [{
            'assetInputs': [],
            'clipTitle': clipArray[i]['title'],
            'clipId': clipArray[i] ? clipArray[i].id : '',
            'dsId': clipArray[i].dsid || '',
            'clipDSId': clipArray[i].clipDSID
          }]
        };
      }
      if (this.order.metadata.isFullEpisode && this.order.lineItems.length) {
        this.orderStore.addNewAssetToFullEpisode(clipItem['metadata'][0]);
      } else {
        this.orderStore.addNewLineItem(clipItem);
      }
    }
    this.orderProgressTrackerService.saveOrder(this.order, 'Your clips have been added.');
    this.catalogService.catalogOrderClipsArr.length = 0;
    this.orderStore.loadInitialModel(this.order);
    this.closeDialog();
  }

  findDuplicates(targetTitle) {
    const lineItems = this.order.lineItems;
    if (lineItems.length === 0) {
      this.isTitleDuplicate = false;
      return;
    }
    if (this.order.metadata.isFullEpisode) {
      const metadatas = lineItems[0]['metadata'];
      if (findIndex(metadatas, metadata => {
        if (!metadata['clipTitle']) {
          return false;
        } else {
          return metadata['clipTitle'].toLowerCase().trim() === targetTitle.toLowerCase().trim() && !metadata['clipId'];
        }
      }) !== -1) {
        this.isTitleDuplicate = true;
      } else {
        this.isTitleDuplicate = false;
      }
    } else {
      if (findIndex(lineItems, lineItem => {
        if (!lineItem['metadata'][0]['clipTitle']) {
          return false;
        } else {
          return lineItem['metadata'][0]['clipTitle'].toLowerCase().trim() === targetTitle.toLowerCase().trim() && !lineItem['metadata'][0]['clipId'];
        }
      }) !== -1) {
        this.isTitleDuplicate = true;
      } else {
        this.isTitleDuplicate = false;
      }
    }
  }

  createEndpointInfoObject() {
    const obj = {};
    let key = '';
    forEach(this.endpointProfiles, (item) => {
      key = item.name;
      obj[key] = [];
    });
    return obj;
  }

  uncheckClips() {
    this.assetClips.forEach((element) => {
      element.nativeElement.checked = false;
    });
  }

  ngOnDestroy() {
    if (this.versionSubscription) {
      this.versionSubscription.unsubscribe();
    }
    this.subscriptions.unsubscribe();
  }
}