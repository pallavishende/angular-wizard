import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { BridgeUI } from 'app/models/bridge-order/bridge-ui.model';
import { VideoOrderModel, VideoEndpoint, VideoAsset } from 'app/models/bridge-order/order-models/video-order.model';
import { remove, isEmpty, cloneDeep } from 'lodash';
import * as moment from 'moment/moment';
import { Subscription } from 'rxjs/Subscription';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { EnvironmentService } from '../../services/environment.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { DynamicFormBaseService } from '../../shared/dynamic-form/dynamic-form-control.service';
import { RequestformService } from '../../shared/dynamic-form/request-form.service';
import { FileUploaderService } from '../../shared/file-uploader/file-uploader.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { OrderDetailsPackageService } from '../order-details-package/order-details-package.service';
import { OrderDetailsPlatformService } from '../order-details-platform/order-details-platform.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsMetadataService } from './order-details-metadata.service';
import { DatePipe } from '@angular/common';
import { DateTimeObject } from 'app/models/bridge-order/order-models/date-time.model';
import { OrderRequestTypes } from 'app/models/bridge-order/shared.model';
import { isArray } from 'util';
import { ENTER } from '@angular/cdk/keycodes';

@Component({
  selector: 'app-order-details-metadata',
  templateUrl: './order-details-metadata.component.html',
  styleUrls: ['../../catalog/catalog-base/catalog-base.component.scss', './order-details-metadata.component.scss', '../order-customization-base/order-customization-base.component.scss'],
  providers: [
    OrderDetailsMetadataService,
    OrderDetailsPlatformService,
    OrderDetailsPackageService,
    RequestformService,
    DynamicFormBaseService,
    FileUploaderService
  ]
})

export class OrderDetailsMetadataComponent implements OnInit, OnDestroy {

  order;
  orderId;
  subscriptions = new Subscription();
  isEnvGreaterThanUAT: boolean;
  initializeEditor: boolean;
  initializeVideoEditor: boolean;

  uiOrder: BridgeUI.Order;

  orderModel: VideoOrderModel;
  orderUpdateTimeout: any;

  OrderRequestTypes = OrderRequestTypes;

  separatorKeysCodes: number[] = [ENTER];

  saaMetadataOptions = {
    primarySiteCategory: [
      'Shows',
      'Music',
      'Celebs',
      'Lifestyle',
      'News'
    ],
    secondarySiteCategory: [
      'Shows',
      'Music',
      'Celebs',
      'Lifestyle',
      'News'
    ],
    subFranchise: [
      'Acceptance Speech',
      'Behind-the-Scenes',
      'Digital Original',
      'Full Episode',
      'Highlight',
      'Performance'
    ],
    videoType: [
      'Trailer',
      'Exclusive',
      'Sneak Peek',
      'Highlight',
      'Interview',
      'Backstage',
      'Red Carpet',
      'Performance'
    ]
  };

  assetMetadataShown: {
    [key: number]: boolean
  } = {};

  constructor(
    private router: Router,
    private ordersService: OrdersService,
    private orderDetailsMetadataService: OrderDetailsMetadataService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private endpointProfileService: EndpointProfileService,
    private alerts: SystemAlertsService,
    private activatedRoute: ActivatedRoute,
    private environmentService: EnvironmentService,
    private loadingMaskService: LoadingMaskService
  ) {
    this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  ngOnInit() {
    const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
    this.orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
    this.ordersService.setOrdersPageTitle('Draft - Viacom Bridge');

    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
    });
    this.initialize();
  }

  initialize() {
    this.loadingMaskService.enableLoadingMask();

    this.subscriptions.add(this.orderDetailsMetadataService.get().subscribe(
      data => {
        if (data['id'] && data['id'].toString() === this.orderId) {
          console.log('instruction > data: ', data);
          this.order = data;
          if (this.order.name) {
            this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          }
          this.initializeCustomEditor();

          if (!this.uiOrder) {
            this.uiOrder = new BridgeUI.Order(this.order);
          } else {
            this.uiOrder.update(this.order);
          }

          this.orderModel = this.uiOrder.videoModel;

          this.orderModel.assets.forEach((asset, assetIndex) => {

            // init/reset toggle status
            const assetId = asset.customClipId || asset.clipId || assetIndex;
            if (this.assetMetadataShown[assetId] === undefined) {
              this.assetMetadataShown[assetId] = assetIndex === 0 ? true : false;
            }

            // force metadata.tags to be array, if its string
            if (asset.endpoints) {
              asset.endpoints.forEach(endpoint => {
                if (endpoint.metadata.tags && !isArray(endpoint.metadata.tags)) {
                  endpoint.metadata.tags = [endpoint.metadata.tags] as any;
                }
              });
            }
          });
        }
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  initializeCustomEditor() {
    setTimeout(() => {
      this.initializeEditor = true;
      this.initializeVideoEditor = true;
      this.loadingMaskService.disableLoadingMask();
    }, 500);
  }

  toggleAssetMetadataShown(asset: VideoAsset) {
    const assetId = asset.customClipId || asset.clipId;
    this.assetMetadataShown[assetId] = !this.assetMetadataShown[assetId];
  }

  isAssetMetadataShown(asset: VideoAsset) {
    const assetId = asset.customClipId || asset.clipId;
    return this.assetMetadataShown[assetId] === true;
  }
  editorContentChanged(event, endpoint: VideoEndpoint, metadataKey: string) {
    if (event.eventType !== 'init') {
      const textValue: string = event.content.replace(/&nbsp;|\s/g, ' ').trim();
      endpoint.metadata[metadataKey] = textValue;
      this.broadcastUpdate();
    }
  }

  applySAAMetadataToAllAssets(sourceAsset: VideoAsset) {
    if (sourceAsset.endpoints && sourceAsset.endpoints.length > 0) {
      const sourceEndpoint = sourceAsset.endpoints[0];
      for (const asset of this.orderModel.assets) {
        if (asset.endpoints && asset.endpoints.length > 0) {
          asset.endpoints[0].metadata = cloneDeep(sourceEndpoint.metadata);
        }
      }
      this.broadcastUpdate();
    }
  }

  updateEndpointMetadataArray(event, endpoint: VideoEndpoint, metadataKey: string, value: string) {
    if (!endpoint.metadata[metadataKey]) {
      endpoint.metadata[metadataKey] = [];
    }
    if (!isArray(endpoint.metadata[metadataKey])) {
      endpoint.metadata[metadataKey] = [endpoint.metadata[metadataKey] as string];
    }

    const metadataItem = endpoint.metadata[metadataKey] as string[];

    if (event.currentTarget.checked) {
      if (!metadataItem.includes(value)) {
        metadataItem.push(value);
      }
    } else {
      if (metadataItem.includes(value)) {
        metadataItem.splice(metadataItem.indexOf(value), 1);
      }
    }

    this.broadcastUpdate();
  }

  handleTags($event, endpoint: VideoEndpoint, doRemove = false) {
    if (!endpoint.metadata.tags) {
      endpoint.metadata.tags = [];
    }
    if (!isArray(endpoint.metadata.tags)) {
      endpoint.metadata.tags = [endpoint.metadata.tags as string];
    }

    const metadataItem = endpoint.metadata.tags as string[];

    if (doRemove) {
      if (metadataItem.includes($event)) {
        metadataItem.splice(metadataItem.indexOf($event), 1);
      }
    } else {
      const input = $event.input;
      const value = $event.value.trim();
      if (value) {
        // clear input field
        if (input) {
          input.value = '';
        }
        if (!metadataItem.includes(value)) {
          metadataItem.push(value);
        }
      }
    }

    this.broadcastUpdate();
  }

  broadcastUpdate() {
    if (this.orderUpdateTimeout !== null) {
      clearTimeout(this.orderUpdateTimeout);
    }
    this.orderUpdateTimeout = setTimeout(() => {
      this.orderUpdateTimeout = null;
      this.order = this.uiOrder.generateDSOrder();
      this.orderDetailsMetadataService.getOrderStore().updateCurrentOrder(this.order);
    }, 500);
  }

  // feature flags

  get isPublishDateAvailable() {
    if (this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.SAA) {
      return true;
    }
    return false;
  }
  get isVideoSAAOrder() {
    return this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.SAA;
  }
  get isVideoTranscriptsOrder() {
    return this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.TRANSCRIPTS;
  }
  get isVideoCaptionsOrder() {
    return this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.CAPTIONS;
  }
  // end feature flags

  trackByAsset(index: any, item: any) {
    return index;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
