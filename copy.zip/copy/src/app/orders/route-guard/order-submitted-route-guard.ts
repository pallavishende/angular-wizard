import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/observable/of';
import { OrdersService } from '../orders/orders.service';

@Injectable()
export class OrderSubmittedRouteGuard {
    constructor(private router: Router,
                private ordersService: OrdersService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        let isDraftOrder;
        return this.ordersService.getOrderDetails(route.params['id']).map((data) => {
            isDraftOrder = data.currentMilestone.status === 'DRAFT';
            if (isDraftOrder) {
                this.router.navigate(['orders', route.params['id'], 'draft']);
            }
            return data.currentMilestone.status !== 'DRAFT';
        }).defaultIfEmpty(false).catch(error => {
            if (error.status === 404) {
                this.router.navigate(['invalid-request'], { queryParams: { returnUrl: state.url }});
            }
            return Observable.of(false);
        });
    }
}
