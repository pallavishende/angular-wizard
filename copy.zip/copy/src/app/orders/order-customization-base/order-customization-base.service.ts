import { Injectable } from '@angular/core';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { OrdersService } from '../orders/orders.service';
import { OrderStore } from '../../models/order-store';

@Injectable()
export class OrderCustomizationBaseService {
  orderType: string;
  orderCustomizationSteps = ['endpoint', 'instructions', 'package', 'approval', 'schedule', 'review'];

  constructor(
    private ordersService: OrdersService,
    private orderStore: OrderStore,
    private loadingMask: LoadingMaskService
  ) {}

  initializeModel(orderId: string) {
    let orderObservable;
    orderObservable = this.ordersService.getOrder(orderId);
    orderObservable.subscribe(
      data => {
        this.orderStore.loadInitialModel(data, data.metadata.orderType);
        this.loadingMask.disableLoadingMask();
      },
      error => {
        console.log('ORDER CUSTOMIZATION: Data could not be loaded.');
      });
  }
}
