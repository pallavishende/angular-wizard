/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { OrderCustomizationBaseComponent } from './order-customization-base.component';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsScheduleService } from '../order-details-schedule/order-details-schedule.service';
import { ConfigService } from '../../services/config.service';
import { RouterTestingModule } from '@angular/router/testing';
import { AdalService } from '../../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { Http, BaseRequestOptions} from "@angular/http";
import { MockBackend, MockConnection } from '@angular/http/testing';
import { OrderCustomizationBaseService } from './order-customization-base.service';
import { ConfigurationManagerService } from '../../configuration/configuration-manager.service';
import { OrdersService } from '../orders/orders.service';
import { OrderStore } from '../../models/order-store';
import { UtilityService } from '../../services/utility.service';
import { UserService } from '../../services/user.service';
import { SecretService } from '../../services/secret.service';
import { LoginService } from '../../login/login.service';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { StorageService } from '../../services/storage.service';
import { Routes, ActivatedRoute, RouterModule, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { EnvironmentService, RuntimeEnvironments } from '../../services/environment.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import 'rxjs/add/observable/of';


describe('OrderCustomizationBaseComponent', () => {
  let component: OrderCustomizationBaseComponent;
  let fixture: ComponentFixture<OrderCustomizationBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule, RouterTestingModule ],
      declarations: [ OrderCustomizationBaseComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {provide: ConfigService, useValue: ConfigService},
        AdalService,
        MockBackend,
        UserService,
        SecretService,
        LoginService,
        StorageService,
        OrderCustomizationBaseService,
        OrderProgressTrackerService,
        OrderDetailsScheduleService,
        ConfigurationManagerService,
        {
          provide: ActivatedRoute, useValue: {
            params: Observable.of({ id: 'test' })
          }
        },
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
            provide: HttpClient,
            useFactory: (http: Http) => http,
            deps: [Http]
        },
        OrdersService,
        OrderCustomizationBaseService,
        OrderStore,
        UtilityService,
        EndpointProfileService,
        EnvironmentService,
        SystemAlertsService,
        LoadingMaskService
       ]
    })
    .overrideComponent(
      OrderCustomizationBaseComponent,
      {set: {providers: [{provide: HttpClient, useClass: HttpClient}]}}
    )
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderCustomizationBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
