import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { OrderCustomizationBaseService } from './order-customization-base.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';

@Component({
  selector: 'app-order-customization-base',
  templateUrl: './order-customization-base.component.html',
  styleUrls: ['./order-customization-base.component.scss'],
  providers: [OrderCustomizationBaseService]
})
export class OrderCustomizationBaseComponent implements OnInit {
  orderId: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private orderCustomizationBaseService: OrderCustomizationBaseService,
    private loadingMask: LoadingMaskService
  ) {}

  ngOnInit() {
    this.loadingMask.enableLoadingMask('orders');
    this.activatedRoute.params.subscribe(params => { // activatedRoute will be destroyed, doesn't need unsubscribe
      this.orderId = params['id'];
      this.orderCustomizationBaseService.initializeModel(this.orderId);
    });
  }
}
