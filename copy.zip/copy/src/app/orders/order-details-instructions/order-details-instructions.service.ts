import { Injectable } from '@angular/core';
import { OrderStore } from '../../models/order-store';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from 'app/services/config.service';

@Injectable()
export class OrderDetailsInstructionsService {

  constructor(
    private http: HttpClient,
    private orderStore: OrderStore,
    private configService: ConfigService) { }

  get() {
    return this.orderStore.orderStream;
  }

  getOrderStore() {
    return this.orderStore;
  }

  updateAttachmentsMetadata(payload) {
    const header = new Headers();
    header.append('Content-type', 'application/json');
    const body = payload;
    return this.http.post(this.configService.fileHandlerUrl + '-metadata', body)
      .map((response: any) => response);
  }
}
