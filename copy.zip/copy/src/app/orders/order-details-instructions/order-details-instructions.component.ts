import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { BridgeUI } from 'app/models/bridge-order/bridge-ui.model';
import { VideoOrderModel, VideoEndpoint, VideoAsset } from 'app/models/bridge-order/order-models/video-order.model';
import { remove, isEmpty, cloneDeep, clone, find } from 'lodash';
import * as moment from 'moment/moment';
import { Subscription } from 'rxjs/Subscription';
import { EndpointProfileService } from '../../services/endpoint-profile.service';
import { EnvironmentService } from '../../services/environment.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { DynamicFormBaseService } from '../../shared/dynamic-form/dynamic-form-control.service';
import { RequestformService } from '../../shared/dynamic-form/request-form.service';
import { FileUploaderService } from '../../shared/file-uploader/file-uploader.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { OrderDetailsPackageService } from '../order-details-package/order-details-package.service';
import { OrderDetailsPlatformService } from '../order-details-platform/order-details-platform.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrdersService } from '../orders/orders.service';
import { OrderDetailsInstructionsService } from './order-details-instructions.service';
import { DatePipe } from '@angular/common';
import { DateTimeObject } from 'app/models/bridge-order/order-models/date-time.model';
import { OrderRequestTypes, Attachment, Activity } from 'app/models/bridge-order/shared.model';
import { isArray } from 'util';

@Component({
  selector: 'app-order-details-instructions',
  templateUrl: './order-details-instructions.component.html',
  styleUrls: ['../../catalog/catalog-base/catalog-base.component.scss', './order-details-instructions.component.scss', '../order-customization-base/order-customization-base.component.scss'],
  providers: [
    OrderDetailsInstructionsService,
    OrderDetailsPlatformService,
    OrderDetailsPackageService,
    RequestformService,
    DynamicFormBaseService,
    FileUploaderService
  ]
})

export class OrderDetailsInstructionsComponent implements OnInit, OnDestroy {

  order;
  orderId;
  subscriptions = new Subscription();
  isEnvGreaterThanUAT: boolean;
  initializeEditor: boolean;
  initializeVideoEditor: boolean;

  uiOrder: BridgeUI.Order;

  orderModel: VideoOrderModel;
  orderUpdateTimeout: any;

  today =  moment().format('YYYY-MM-DD').toString();
  OrderRequestTypes = OrderRequestTypes;

  firstCreateActivity: Activity;

  saaEndpointOptions = {
    slatesAndGraphics: [
      'Open Slate',
      'End Slate',
      'Lower Third',
      'Brand Bug',
      'Other Graphic Overlay'
    ],
    additionalDeliverables: [
      'Alexa Video',
      'Alexa Audio',
      'Podcast (.mp3)',
      'Evergreen Version'
    ]
  };

  constructor(
    private router: Router,
    private ordersService: OrdersService,
    private orderDetailsInstructionsService: OrderDetailsInstructionsService,
    private orderProgressTrackerService: OrderProgressTrackerService,
    private endpointProfileService: EndpointProfileService,
    private alerts: SystemAlertsService,
    private activatedRoute: ActivatedRoute,
    private environmentService: EnvironmentService,
    private loadingMaskService: LoadingMaskService
  ) {
    this.isEnvGreaterThanUAT = this.environmentService.isRuntimeEnvironmentGreaterThan(3);
  }

  ngOnInit() {
    const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
    this.orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
    this.ordersService.setOrdersPageTitle('Draft - Viacom Bridge');

    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
    });
    this.initialize();
  }

  initialize() {
    this.loadingMaskService.enableLoadingMask();

    this.subscriptions.add(this.orderDetailsInstructionsService.get().subscribe(
      data => {
        if (data['id'] && data['id'].toString() === this.orderId) {
          console.log('instruction > data: ', data);
          this.order = data;
          if (this.order.name) {
            this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          }
          this.initializeCustomEditor();

          if (!this.uiOrder) {
            this.uiOrder = new BridgeUI.Order(this.order);
          } else {
            this.uiOrder.update(this.order);
          }

          if (this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.CAPTIONS) {
            // set presets
            this.uiOrder.videoModel.orderInstruction.deliveryFormat = 'Closed caption file (SRT & SCC)';
            this.uiOrder.videoModel.orderInstruction.deliveryLocation = 'Attachment';
          }

          this.orderModel = this.uiOrder.videoModel;

          if (!this.orderModel.dueDateTime) {
            this.orderModel.dueDateTime = new DateTimeObject();
          }

          if (!this.orderModel.publishDateTime && (this.orderModel.requestType === OrderRequestTypes.SAA || this.orderModel.requestType === OrderRequestTypes.SOCIAL)) {
            this.orderModel.publishDateTime = new DateTimeObject();
          }

          if (this.isVideoSAAOrder) {
            this.orderModel.orderInstruction.siteAndAppPresets = 'Aspect Ratio: 16:9';
            if (isEmpty(this.orderModel.orderInstruction.captions)) {
              this.orderModel.orderInstruction.captions = 'Closed caption file (SRT & SCC)';
            }
          }

          this.firstCreateActivity = this.orderModel.getFirstCreateActivity();

        }
      },
      error => {
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addErrorAlerts('Sorry, there was a problem loading some content on this page. – <a href="#">Try reloading</a>');
      }
    ));
  }

  initializeCustomEditor() {
    setTimeout(() => {
      this.initializeEditor = true;
      this.initializeVideoEditor = true;
      this.loadingMaskService.disableLoadingMask();
    }, 500);
  }

  deliveryFormatCheckboxHandler(event, value) {
    const deliveryFormats = this.orderModel.orderInstruction.deliveryFormat ? this.orderModel.orderInstruction.deliveryFormat.split(',') : [];
    if (!event.target.checked && deliveryFormats.includes(value)) {
      remove(deliveryFormats, (val) => val === value);
    } else if (event.target.checked && !deliveryFormats.includes(value)) {
      deliveryFormats.push(value);
    }
    this.orderModel.orderInstruction.deliveryFormat =  deliveryFormats.length > 0 ? deliveryFormats.join(',') : '';
    this.broadcastUpdate();
  }

  editorContentChanged(event, endpoint: VideoEndpoint, instructionKey: string) {
    if (event.eventType !== 'init') {
      const textValue: string = event.content.replace(/&nbsp;|\s/g, ' ').trim();
      endpoint.instructions[instructionKey] = textValue;
      this.broadcastUpdate();
    }
  }

  applySAAInstructionsToAllAssets(sourceAsset: VideoAsset) {
    if (sourceAsset.endpoints && sourceAsset.endpoints.length > 0) {
      const sourceEndpoint = sourceAsset.endpoints[0];
      for (const asset of this.orderModel.assets) {
        if (asset.endpoints && asset.endpoints.length > 0) {
          asset.endpoints[0].instructions = cloneDeep(sourceEndpoint.instructions);
        }
      }
      this.broadcastUpdate();
    }
  }

  updateEndpointInstructionArray(event, endpoint: VideoEndpoint, instructionKey: string, value: string) {
    if (!endpoint.instructions[instructionKey]) {
      endpoint.instructions[instructionKey] = [];
    }
    if (!isArray(endpoint.instructions[instructionKey])) {
      endpoint.instructions[instructionKey] = [endpoint.instructions[instructionKey] as string];
    }

    const instructionItem = endpoint.instructions[instructionKey] as string[];

    if (event.currentTarget.checked) {
      if (!instructionItem.includes(value)) {
        instructionItem.push(value);
      }
      if (instructionKey === 'additionalDeliverables' && value === 'Podcast (.mp3)') {
        endpoint.instructions.podcastDestination = '';
      }
      if (instructionKey === 'slatesAndGraphics' && endpoint.instructions.slatesAndGraphicsSourceInfo === undefined ) {
        endpoint.instructions.slatesAndGraphicsSourceInfo = '';
      }
    } else {
      if (instructionItem.includes(value)) {
        instructionItem.splice(instructionItem.indexOf(value), 1);
      }
      if (instructionKey === 'additionalDeliverables' && value === 'Podcast (.mp3)') {
        endpoint.instructions.podcastDestination = undefined;
      }
      if (instructionKey === 'slatesAndGraphics' && instructionItem.length === 0 ) {
        endpoint.instructions.slatesAndGraphicsSourceInfo = undefined;
      }
    }

    this.broadcastUpdate();
  }

  // attachments
  updateAttachmentsMetadata(attachment: Attachment) {
    if (!this.firstCreateActivity) {
      return;
    }
    console.log(attachment);
    const attachmentObj = clone(attachment);
    attachmentObj.activityId = this.firstCreateActivity.id;
    attachmentObj.source = 'S3';
    this.subscriptions.add(this.orderDetailsInstructionsService.updateAttachmentsMetadata([attachmentObj]).subscribe(
      data => {
        find(this.orderModel.attachments, { 'name': data[0].name })['id'] = data[0].id;
        this.broadcastUpdate();
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
      }
    ));
  }

  updateTrackerStatus(event) {
    const isUploading = event.uploadingInProgressQueue.length > 0;
    this.orderModel.isUploading = isUploading;
    this.broadcastUpdate();
  }

  broadcastUpdate() {
    if (this.orderUpdateTimeout !== null) {
      clearTimeout(this.orderUpdateTimeout);
    }
    this.orderUpdateTimeout = setTimeout(() => {
      this.orderUpdateTimeout = null;
      this.order = this.uiOrder.generateDSOrder();
      this.orderDetailsInstructionsService.getOrderStore().updateCurrentOrder(this.order);
    }, 500);
  }

  // helpers

  getInstructionHint() {
    if (this.isVideoTranscriptsOrder) {
      return 'transcripts';
    } else if (this.isVideoCaptionsOrder) {
      return 'captions';
    }
    return 'assets in the order';
  }

  // feature flags

  get isPublishDateAvailable() {
    if (this.uiOrder.isVideoOrder() && (this.uiOrder.videoModel.requestType === OrderRequestTypes.SAA ||
      this.uiOrder.videoModel.requestType === OrderRequestTypes.SOCIAL) ) {
      return true;
    }
    return false;
  }
  get isVideoSAAOrder() {
    return this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.SAA;
  }
  get isVideoSocialOrder() {
    return this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.SOCIAL;
  }
  get isVideoTranscriptsOrder() {
    return this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.TRANSCRIPTS;
  }
  get isVideoCaptionsOrder() {
    return this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType === OrderRequestTypes.CAPTIONS;
  }
  // end feature flags

  trackByAsset(index: any, item: any) {
    return index;
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
