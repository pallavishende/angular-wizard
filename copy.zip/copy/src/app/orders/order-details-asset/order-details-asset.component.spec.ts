import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderDetailsAssetComponent } from './order-details-asset.component';

xdescribe('OrderDetailsAssetComponent', () => {
  let component: OrderDetailsAssetComponent;
  let fixture: ComponentFixture<OrderDetailsAssetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderDetailsAssetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderDetailsAssetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
