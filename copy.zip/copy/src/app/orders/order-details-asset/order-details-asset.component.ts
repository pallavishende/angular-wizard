import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, RouterStateSnapshot } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { MatDialog } from '@angular/material';
import { sortBy } from 'lodash';

import { OrdersService } from '../orders/orders.service';
import { OrderProgressTrackerService } from '../order-progress-tracker/order-progress-tracker.service';
import { OrderDetailsAssetService } from '../order-details-asset/order-details-asset.service';
import { OrderStore } from '../../models/order-store';
import { ContentTypes } from '../../models/constants/content-type';
import { CustomEditorService } from 'app/shared/custom-editor/custom-editor.service';
import { BridgeUI } from 'app/models/bridge-order/bridge-ui.model';
import { BridgeDS } from 'app/models/bridge-order/bridge-ds.model';
import { PressOrderModel, PressAsset } from 'app/models/bridge-order/order-models/press-order.model';
import { VideoOrderModel } from 'app/models/bridge-order/order-models/video-order.model';
import { OrderRequestTypes } from 'app/models/bridge-order/shared.model';
import { EndpointProfileService } from 'app/services/endpoint-profile.service';

@Component({
  selector: 'app-order-details-asset',
  templateUrl: './order-details-asset.component.html',
  providers: [CustomEditorService],
  styleUrls: ['./order-details-asset.component.scss', '../order-customization-base/order-customization-base.component.scss']
})
export class OrderDetailsAssetComponent implements OnInit, OnDestroy {

  @ViewChild('addAssetDialog') addAssetDialog;

  subscriptions = new Subscription();
  order;
  endpointProfiles;
  contentType: string;
  isEpisodeOrSpecial: boolean;
  activeTab: string;
  activeVmid: string;
  activeDsid: string;
  showArchiveAssets: boolean;
  orderUpdateTimeout: any;

  uiOrder: BridgeUI.Order;
  orderModel: VideoOrderModel | PressOrderModel;
  OrderRequestTypes = OrderRequestTypes;
  allEndpointProfiles: any;

  filteredEndpointProfiles: any;

  endpointIds = {
    [OrderRequestTypes.SAA] : [8, 9, 10],
    [OrderRequestTypes.SOCIAL] : [2, 3, 5, 6, 7, 8, 9, 1251, 1301]
  };

  constructor(private router: Router,
              private activatedRoute: ActivatedRoute,
              public dialog: MatDialog,
              private ordersService: OrdersService,
              private orderDetailsAssetService: OrderDetailsAssetService,
              private orderProgressTrackerService: OrderProgressTrackerService,
              private orderStore: OrderStore,
              public customEditorService: CustomEditorService,
              private endpointProfileService: EndpointProfileService) { }

  ngOnInit() {
    this.ordersService.setOrdersPageTitle('Draft - Viacom Bridge');
    this.activatedRoute.data.subscribe(data => {
      this.orderProgressTrackerService.saveRouteData(data);
      this.initialize();
    });
  }

  initialize() {
    this.subscriptions.add(this.orderDetailsAssetService.get().subscribe(
      data => {
        const snapshot: RouterStateSnapshot = this.router.routerState.snapshot;
        const orderId = snapshot.url.substring(8, snapshot.url.indexOf('/draft'));
        if (data['id'] && data['id'].toString() === orderId) {
          this.order = data;
          if (!this.uiOrder) {
            this.uiOrder = new BridgeUI.Order(data as BridgeDS.Order);
            this.order = this.uiOrder.generateDSOrder();
            this.orderStore.loadInitialModel(this.order, this.uiOrder.metadata.orderType.toLowerCase());
          } else {
            this.uiOrder.update(data as BridgeDS.Order);
          }

          if (this.uiOrder.isVideoOrder()) {
            this.orderModel = this.uiOrder.videoModel;
          } else  {
            this.orderModel = this.uiOrder.pressModel;
          }

          console.log('in assets:', this.order);
          if (this.order.name) {
            this.ordersService.setOrdersPageTitle(this.order.name + ' - Draft - Viacom Bridge');
          }
          this.contentType = this.order.metadata.contentType;
          if (this.contentType === ContentTypes.Episode || this.contentType === ContentTypes.Special) {
            this.isEpisodeOrSpecial = true;
            this.activeTab = 'CHOOSE FROM CATALOG';
            this.showArchiveAssets = true;
          }

          if (this.uiOrder.isVideoOrder() && this.uiOrder.videoModel.requestType && this.uiOrder.videoModel.supportsEndpoints()) {
            this.subscriptions.add(this.endpointProfileService.getEndpointProfiles().subscribe(
              endPointData => {
                if (endPointData && endPointData.length > 0) {
                  this.allEndpointProfiles = endPointData;
                  this.filteredEndpointProfiles = this.allEndpointProfiles.filter((endpoint) => {
                    return this.endpointIds[this.uiOrder.videoModel.requestType]
                            && this.endpointIds[this.uiOrder.videoModel.requestType].includes(endpoint.id);
                  });
                  this.filteredEndpointProfiles = sortBy(this.filteredEndpointProfiles, ['id']);
                }
              }
            ));
          }
        }
      },
      error => {
        console.log('Error: Assets data not loaded');
      }
    ));
  }

  addAssetsToOrder(assetsInfo: any[]): void {
    for (const assetInfo of assetsInfo) {
      this.orderModel.addAsset({
        clipTitle: assetInfo.title,
        clipSource: null,
        clipId: assetInfo.id,
        clipDSId: assetInfo.dsid,
        dsId: assetInfo.versionDsid,
        inOutPoint: null,
        duration: ''
      });
    }
    this.order = this.uiOrder.generateDSOrder();
    this.orderProgressTrackerService.saveOrder(this.order, 'Your assets have been added.');
  }

  addCustomAsset(): void {
    this.orderModel.addAsset({
      clipTitle: '',
      clipSource: '',
      clipId: null,
      clipDSId: null,
      dsId: null,
      inOutPoint: null
    });
    this.order = this.uiOrder.generateDSOrder();
    this.orderProgressTrackerService.saveOrder(this.order, 'Your asset has been added.');
  }

  removeAsset(assetIndex) {
    this.orderModel.removeAsset(assetIndex);
    this.order = this.uiOrder.generateDSOrder();
    this.orderProgressTrackerService.saveOrder(this.order, 'Your asset has been removed.');
  }

  openAddAssetDialog() {
    this.dialog.open(this.addAssetDialog, {
      width: '660px',
      height: '620px'
    });
    this.activeVmid = this.order.metadata.vmId || '';
  }

  editorContentChanged(event, asset: PressAsset) {
    if (event.eventType !== 'init') {
      asset.inOutPoint = event.content.replace(/&nbsp;|\s/g, ' ').trim();
      this.updateOrder();
    }
  }

  addAssetAdditionalInfo(asset: PressAsset) {
    asset.inOutPoint = ' ';
    this.updateOrder();
  }

  removeAdditionalAssetInfo(asset: PressAsset) {
    asset.inOutPoint = null;
    this.updateOrder();
  }

  trackByAsset(index: any, item: any) {
    return index;
  }

  isInOutAvailable(): boolean {
    if (this.uiOrder.isPressOrder()) {
      return true;
    } else if (this.uiOrder.isVideoOrder()) {
      if (this.uiOrder.videoModel.requestType === this.OrderRequestTypes.CAPTIONS || this.uiOrder.videoModel.requestType === this.OrderRequestTypes.SAA) {
        return true;
      }
    }
    return false;
  }

  updateOrder() {
    if (this.orderUpdateTimeout !== null) {
      clearTimeout(this.orderUpdateTimeout);
    }
    this.orderUpdateTimeout = setTimeout(() => {
      this.orderUpdateTimeout = null;
      this.order = this.uiOrder.generateDSOrder();
      this.orderStore.loadInitialModel(this.order, this.uiOrder.metadata.orderType.toLowerCase());
    }, 300);
  }

  checkForSocialPlatform (name) {
    return name === 'App Only' || name === 'Site & App' || name === 'Site Only' || name === 'Viacom Sites & Apps';
  }

  checkEndpointInAsset(name, asset) {
    return this.uiOrder.videoModel.checkEndpointInAsset(name, asset);
  }

  endPointChangeEvent(event, name, asset) {
    if (!event.currentTarget.checked) {
      //let cloneAsset = cloneDeep(asset);
      if (asset.endpoints.length === 1) {
        this.uiOrder.videoModel.addEndpointToAsset('', asset);
      }
      this.uiOrder.videoModel.removeEndpointfromAsset(name, asset);
    } else {
      this.uiOrder.videoModel.addEndpointToAsset(name, asset);
      if (asset.endpoints.length >= 2) {
        this.uiOrder.videoModel.removeEndpointfromAsset('', asset);
      }
    }
    console.log(asset.endpoints);
    this.updateOrder();
  }

  closeDialog() {
    this.dialog.closeAll();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
