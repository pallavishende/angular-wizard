import { TestBed, inject } from '@angular/core/testing';

import { OrderDetailsAssetService } from './order-details-asset.service';

xdescribe('OrderDetailsAssetService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OrderDetailsAssetService]
    });
  });

  it('should be created', inject([OrderDetailsAssetService], (service: OrderDetailsAssetService) => {
    expect(service).toBeTruthy();
  }));
});
