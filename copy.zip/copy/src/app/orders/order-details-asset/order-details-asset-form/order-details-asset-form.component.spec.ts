import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderDetailsAssetFormComponent } from './order-details-asset-form.component';

xdescribe('OrderDetailsAssetFormComponent', () => {
  let component: OrderDetailsAssetFormComponent;
  let fixture: ComponentFixture<OrderDetailsAssetFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderDetailsAssetFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderDetailsAssetFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
