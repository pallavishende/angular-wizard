import { Component, OnInit, Input, Output, ViewEncapsulation, EventEmitter } from '@angular/core';
import { cloneDeep } from 'lodash';

import { LineItem } from '../../../models/line-item';
import { CustomEditorService } from 'app/shared/custom-editor/custom-editor.service';

@Component({
  selector: 'app-order-details-asset-form',
  providers: [CustomEditorService],
  templateUrl: './order-details-asset-form.component.html',
  styleUrls: ['../order-details-asset.component.scss', './order-details-asset-form.component.scss'],
  encapsulation: ViewEncapsulation.Emulated
})
export class OrderDetailsAssetFormComponent implements OnInit {

  @Input() lineItem: LineItem;
  @Output() updatedLineItem = new EventEmitter<LineItem>();
  updatedLineItemTimeout = null;
  clonedLineItem: LineItem;

  constructor(public customEditorService: CustomEditorService) { }

  ngOnInit() {
    this.clonedLineItem = cloneDeep(this.lineItem);
  }

  addAssetAdditionalInfo(): void {
    this.clonedLineItem.metadata[0].assetInputs[0].inOutPoint = '';
    this.emitUpdatedLineItem();
  }

  updateAssetInfo(rawValue: string, assetInfoType: string, lineItem: LineItem): void {
    const value = rawValue.trim();
    lineItem.metadata[0].assetInputs[0][assetInfoType] = value;
    this.emitUpdatedLineItem();
  }

  editorContentChanged(event): void {
    if (event.eventType !== 'init') {
      this.clonedLineItem.metadata[0].assetInputs[0].inOutPoint = event.content.replace(/&nbsp;|\s/g, ' ').trim();
      this.emitUpdatedLineItem();
    }
  }

  removeAdditionalAssetInfo(): void {
    this.clonedLineItem.metadata[0].assetInputs[0].inOutPoint = null;
    this.emitUpdatedLineItem();
  }

  emitUpdatedLineItem(): void {
    if (this.updatedLineItemTimeout !== null) {
      clearTimeout(this.updatedLineItemTimeout);
    }
    this.updatedLineItemTimeout = setTimeout(() => {
      this.updatedLineItemTimeout = null;
      this.updatedLineItem.emit(this.clonedLineItem);
    }, 300);
  }

}
