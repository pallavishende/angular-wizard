import { Injectable } from '@angular/core';

import { OrderStore } from '../../models/order-store';


@Injectable()
export class OrderDetailsAssetService {

  constructor(private orderStore: OrderStore) { }

  get() {
    return this.orderStore.orderStream;
  }
}
