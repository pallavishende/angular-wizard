import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrdersBaseComponent } from './orders-base/orders-base.component';
import { OrdersComponent } from './orders/orders.component';
import { OrderDetailsPlatformComponent } from './order-details-platform/order-details-platform.component';
import { OrderDetailsAssetComponent } from './order-details-asset/order-details-asset.component';
import { OrderDetailsFormatComponent } from './order-details-format/order-details-format.component';
import { OrderDetailsInstructionsComponent } from './order-details-instructions/order-details-instructions.component';
import { OrderDetailsScheduleComponent } from './order-details-schedule/order-details-schedule.component';
import { OrderDetailsReviewComponent } from './order-details-review/order-details-review.component';
import { OrderProgressTrackerComponent } from './order-progress-tracker/order-progress-tracker.component';
import { OrderDetailsSideBarComponent } from './order-details-side-bar/order-details-side-bar.component';
import { OrderCustomizationBaseComponent } from './order-customization-base/order-customization-base.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { OrdersViewComponent } from './orders-view/orders-view.component';
import { SiteHeaderComponent } from '../shared/site-header/site-header.component';
import { OrderDraftRouteGuard } from './route-guard/order-draft-route-guard';
import { OrderSubmittedRouteGuard } from './route-guard/order-submitted-route-guard';
import { OrderListRouteGuard } from './route-guard/order-list-route-guard';
import { OrderDraftNavigatorComponent } from './order-draft-navigator/order-draft-navigator.component';
import { OrderDetailsMetadataComponent } from './order-details-metadata/order-details-metadata.component';


const OrdersRoutes: Routes = [
  { path: '', component: OrdersBaseComponent, canActivate: [ OrderListRouteGuard ], data: {title: 'Orders'},
    children: [
      { path: '', component: SiteHeaderComponent, outlet: 'header' },
      { path: '', component: OrdersViewComponent,
        children: [
            { path: '', redirectTo: 'all-orders', pathMatch: 'full' },
            { path: 'my-orders', component: OrdersComponent },
            { path: 'my-drafts', component: OrdersComponent },
            { path: 'my-teams-orders', component: OrdersComponent},
            { path: 'all-orders', component: OrdersComponent },
            { path: 'watching', component: OrdersComponent }
        ],
      }
    ]
  },
  { path: ':id/order-detail', component: OrdersBaseComponent, canActivate: [ OrderSubmittedRouteGuard ], data: {title: 'Order Detail'},
    children: [
      { path: '', component: OrderDetailsComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  },
  { path: ':id/draft', component: OrderCustomizationBaseComponent, canActivate: [ OrderDraftRouteGuard ], data: {title: 'Order Draft'},
    children: [
      { path: '', component: SiteHeaderComponent, outlet: 'header' },
      { path: '', component: OrderProgressTrackerComponent, outlet: 'order-progress-tracker'},
      { path: '', component: OrderDetailsSideBarComponent, outlet: 'order-details-side-bar' },
      { path: '', component: OrderDraftNavigatorComponent, outlet: 'order-draft-navigator' },
      { path: 'endpoint', component: OrderDetailsPlatformComponent, data: {section: 'endpoint'} },
      { path: 'assets', component: OrderDetailsAssetComponent, data: {section: 'assets'} },
      { path: 'instructions', component: OrderDetailsFormatComponent, data: {section: 'instructions'} },
      { path: 'instruction', component: OrderDetailsInstructionsComponent, data: {section: 'instruction'} },
      { path: 'metadata', component: OrderDetailsMetadataComponent, data: {section: 'metadata'} },
      { path: 'schedule', component: OrderDetailsScheduleComponent, data: {section: 'schedule'} },
      { path: 'review', component: OrderDetailsReviewComponent, data: {section: 'review'} }
    ]
  }
];

@NgModule({
  imports: [ RouterModule.forChild(OrdersRoutes) ],
  exports: [ RouterModule ]
})

export class OrdersRoutesModule {}