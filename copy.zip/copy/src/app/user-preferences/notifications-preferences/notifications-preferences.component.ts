import { Component, OnInit, ViewChildren, QueryList, OnDestroy, TemplateRef } from '@angular/core';
import { UserPreferencesService } from '../user-preferences.service';
import { UserService } from '../../services/user.service';
import { LoadingMaskService } from '../../shared/loading-mask/loading-mask.service';
import { SystemAlertsService } from '../../services/system-alerts.service';
import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { forkJoin } from 'rxjs/observable/forkJoin';
import { MatDialog, MatTabGroup } from '@angular/material';

import { forEachRight, indexOf, isEmpty, cloneDeep } from 'lodash';
import { Team } from '../../models/team';
import { AzureUser, UPDUser } from '../../models/user';

const duplicateTeamNameApiResponse = `Team with this name already exists`;
const duplicateMemberNameResponse = `Oops, that user already belongs to this team!`;
const duplicateTeamMemberResponse = `Sorry, that user already belongs to another team. Once they leave the other team, you can add them here.`;

@Component({
  selector: 'app-notifications-preferences',
  templateUrl: './notifications-preferences.component.html',
  styleUrls: ['./notifications-preferences.component.scss'],
  providers: [UserPreferencesService]
})
export class NotificationsPreferencesComponent implements OnInit, OnDestroy {

  settingsUpdated = false;
  userLoginInfo: AzureUser;
  userTeamInfo;
  loggedInUser;
  userId: number;
  userName: string;
  userInitial: string;
  userTitle: string;
  userEmail: string;
  photoLoaded: boolean;
  userPreferences = [];
  checkedUserPreferences = [];
  subscriptions = new Subscription();
  customTeamObj = new Team();
  editTeamMembersObj = {
    toBeAdded: [],
    toBeRemoved: []
  };
  addTeamMember: boolean;
  modalType: string;
  hasDuplicateName: boolean;
  hasDuplicateMemberMessage: string;
  showDeleteTeamConfirmation: boolean;
  isAssignEventSuccessful = new Subject<boolean>();

  @ViewChildren('notificationPref') notificationPreferenceRef: QueryList<any>;

  constructor(private userPreferenceService: UserPreferencesService,
    private userService: UserService,
    private loadingMaskService: LoadingMaskService,
    private alerts: SystemAlertsService,
    private matDialog: MatDialog) { }

  ngOnInit() {
    this.userPreferenceService.setOrdersPageTitle('My Settings - Viacom Bridge');
    this.getUserInfo();
  }

  getUserInfo() {
    this.userLoginInfo = this.userService.getUserLoginInfo();

    this.userService.getUserInfo(this.userLoginInfo.email).subscribe(
      (data: UPDUser) => {
        this.userName = data.displayName;
        this.userInitial = data.firstName.charAt(0) || '';
        this.userEmail = data.login;
        this.userService.getUserPhoto(this.photoLoadHandler, this);
        this.userId = data.id;
        this.userTitle = data.jobTitle;
        this.getUserNotificationPreference();
        this.getUserTeam();
      }
    );
  }

  private photoLoadHandler(result: string, callerComponent: any) {
    const image = document.getElementById('userPhoto');
    if (result !== null) {
      image.setAttribute('src', result);
      callerComponent.photoLoaded = true;
    } else {
      callerComponent.photoLoaded = false;
    }
  }

  getUserNotificationPreference() {
    this.subscriptions.add(this.userPreferenceService.getUserNotificationPreference(this.userId).subscribe(
      data => {
        this.userPreferences = data;
        this.populateFilterChecks();
      }));
  }

  updateUserPreferences(event) {
    const isSelected =  event.target.checked;
    const selectedNotificationCheckBoxName =  event.srcElement.name;
    const notificationPreferenceRefElements = this.notificationPreferenceRef.filter(element => element.nativeElement.name === selectedNotificationCheckBoxName);
    notificationPreferenceRefElements.forEach((element) => {
        this.checkedUserPreferences.push(this.userPreferences[element.nativeElement.name].id);
    });

    if (this.checkedUserPreferences.length === 0) {
      this.subscriptions.add(this.userPreferenceService.resetUserNotificationPreference(this.userId).subscribe(
        data => {
          console.log('User Preferences update');
          this.checkedUserPreferences = [];
          this.alerts.addSuccessAlerts('Great! Your settings have been updated successfully.');
        },
        error => {
          this.checkedUserPreferences = [];
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
          console.log('Error in updating User Preferences');
        }
      ));
    } else {
      const selectedNotificationId =  +this.checkedUserPreferences[0];
      this.subscriptions.add(this.userPreferenceService.updateUserNotificationPreference(this.userId, selectedNotificationId, isSelected).subscribe(
        data => {
          console.log('User Preferences update');
          this.checkedUserPreferences = [];
          this.alerts.addSuccessAlerts('Great! Your settings have been updated successfully.');
        },
        error => {
          this.checkedUserPreferences = [];
          this.alerts.addErrorAlerts('Sorry, it looks like there was an error. Try again, or refresh the page.');
          console.log('Error in updating User Preferences');
        }
      ));
    }
  }

  getUserTeam() {
    this.subscriptions.add(this.userService.getUpdatedMyTeamsInfo().subscribe(
      data => {
        if (data) {
          this.userTeamInfo = data;
          if (this.userTeamInfo.length > 0) {
            this.userTeamInfo[0].name = data[0].name;
          }
        }
        this.loadingMaskService.disableLoadingMask();
      },
      error => {
        this.alerts.addErrorAlerts('Sorry, there was a problem loading team information');
        this.loadingMaskService.disableLoadingMask();
      }
    ));
  }

  addUserToTeam(event) {
    if (indexOf(this.customTeamObj.memberEmails, event.assigneeEmail) < 0) {
      if (indexOf(this.editTeamMembersObj.toBeRemoved, event.assigneeEmail) < 0) {
        this.loadingMaskService.enableLoadingMask();
        this.userService.getUserTeamsInfo(event.assigneeEmail).subscribe((teamsData) => {
          this.loadingMaskService.disableLoadingMask();
          if (teamsData.length === 0) {
            this.customTeamObj.memberEmails.unshift(event.assigneeEmail);
            if (this.modalType === 'editTeam') {
              this.editTeamMembersObj.toBeAdded.unshift(event.assigneeEmail);
            }
            this.hasDuplicateMemberMessage = '';
          } else {
            this.hasDuplicateMemberMessage = duplicateTeamMemberResponse;
            this.isAssignEventSuccessful.next(false);
            setTimeout(() => {
              this.hasDuplicateMemberMessage = '';
            }, 6000);
          }
        });
      } else {
        this.editTeamMembersObj.toBeRemoved.splice(indexOf(this.editTeamMembersObj.toBeRemoved, event.assigneeEmail), 1);
        this.customTeamObj.memberEmails.unshift(event.assigneeEmail);
      }
      this.addTeamMember = false;
      return;
    }
    this.hasDuplicateMemberMessage = duplicateMemberNameResponse;
    this.isAssignEventSuccessful.next(false);
    setTimeout(() => {
      this.hasDuplicateMemberMessage = '';
    }, 6000);
    console.log('team member already exists!:', this.customTeamObj);
  }

  populateFilterChecks() {
    this.notificationPreferenceRef.forEach(element => {
      if (this.userPreferences[+element.nativeElement.name].isSelected) {
        element.nativeElement.checked = true;
      }
    });
    this.loadingMaskService.disableLoadingMask();
  }

  createTeam(matTabGroup?: MatTabGroup): void {
    this.loadingMaskService.enableLoadingMask();
    this.removeMarkedMembers();
    this.customTeamObj.createdBy = this.userEmail;
    this.subscriptions.add(this.userService.setUserTeam(this.customTeamObj).subscribe(data => {
      this.editTeamMembersObj.toBeRemoved = [];
      this.closeDialog();
      this.getUserNotificationPreference();
      this.getUserTeam();
      this.alerts.addSuccessAlerts(`${data.name} was created successfully!`);
    },
      (errorData) => {
        this.loadingMaskService.disableLoadingMask();
        if (errorData.status === 400 && errorData.error.message === duplicateTeamNameApiResponse) {
          this.hasDuplicateName = true;
          if (typeof matTabGroup !== 'undefined' && matTabGroup.selectedIndex !== 0) {
            matTabGroup.selectedIndex = 0;
          }
        }
      }
    ));
  }

  deleteTeam(): void {
    this.loadingMaskService.enableLoadingMask();
    this.closeDialog();
    this.subscriptions.add(this.userService.deleteUserTeam(this.userTeamInfo[0].id).subscribe((data) => {
      this.getUserTeam();
      this.alerts.addSuccessAlerts('Requested team has been successfully deleted.');
    },
      (error) => {
        console.log('Error: couldn\'t delete the team.');
        this.loadingMaskService.disableLoadingMask();
        this.alerts.addErrorAlerts('Team could not be deleted. Please try again.');
      }
    ));
  }

  leaveTeam(): void {
    const teamMemberToBeRemoved = [this.userEmail];
    this.loadingMaskService.enableLoadingMask();
    this.subscriptions.add(this.userService.removeMembersFromTeam(this.userTeamInfo[0].id, teamMemberToBeRemoved).subscribe((data) => {
      console.log('Success: User has successfully left the team');
      this.alerts.addSuccessAlerts('Successfully removed user from the team.');
      this.getUserTeam();
      this.closeDialog();
    }, (error) => {
      console.log('Error: Failed to remove user from this team');
      this.loadingMaskService.disableLoadingMask();
      this.alerts.addErrorAlerts('Failed to remove user from the current team. Please try again.');
    }));
  }

  removeTeam(): void {
    if (this.showDeleteTeamConfirmation) {
      this.deleteTeam();
      this.showDeleteTeamConfirmation = false;
    } else {
      this.leaveTeam();
    }
  }

  cancelDialogAction(): void {
    if (this.showDeleteTeamConfirmation) {
      this.showDeleteTeamConfirmation = false;
    } else {
      this.closeDialog();
    }
  }

  editTeam(matTabGroup?: MatTabGroup): void {
    this.loadingMaskService.enableLoadingMask();
    const editTeamPayload = this.customTeamObj;
    editTeamPayload['id'] = this.userTeamInfo[0].id;
    this.subscriptions.add(this.getEditTeamObservable(editTeamPayload).subscribe(
      (data) => {
        this.alerts.addSuccessAlerts(`Changes to ${data[0]['name']} saved.`);
        this.getUserTeam();
        this.closeDialog();
      },
      (errorData) => {
        this.loadingMaskService.disableLoadingMask();
        if (errorData.status === 400 && errorData.error.message === duplicateTeamNameApiResponse) {
          this.loadingMaskService.disableLoadingMask();
          this.hasDuplicateName = true;
          if (typeof matTabGroup !== 'undefined' && matTabGroup.selectedIndex !== 0) {
            matTabGroup.selectedIndex = 0;
          }
        } else {
          this.alerts.addErrorAlerts(`Sorry, some of your changes couldn't be saved. Please try editing again.`);
          /* updating team info that may have been saved while editing the team */
          this.getUserTeam();
          this.closeDialog();
        }
      },
      () => {
        this.closeDialog();
        this.loadingMaskService.disableLoadingMask();
      }
    ));
  }

  getEditTeamObservable(editTeamPayload) {
    const editTeamObservableArray = [];
    const editTeamMetadataPayload = {};
    if (this.userTeamInfo[0].name.toLowerCase() !== editTeamPayload.name.toLowerCase()) {
      editTeamMetadataPayload['name'] = editTeamPayload.name;
    }
    if (this.userTeamInfo[0].description !== editTeamPayload.description) {
      editTeamMetadataPayload['description'] = editTeamPayload.description;
    }
    if (!isEmpty(editTeamMetadataPayload)) {
      editTeamMetadataPayload['id'] = editTeamPayload.id;
      editTeamObservableArray.push(this.userService.editUserTeamMetadata(editTeamMetadataPayload));
    }
    if (this.editTeamMembersObj.toBeAdded.length > 0) {
      editTeamObservableArray.push(this.userService.addMembersToTeam(editTeamPayload.id, this.editTeamMembersObj.toBeAdded));
    }
    if (this.editTeamMembersObj.toBeRemoved.length > 0) {
      editTeamObservableArray.push(this.userService.removeMembersFromTeam(editTeamPayload.id, this.editTeamMembersObj.toBeRemoved));
    }
    return forkJoin(editTeamObservableArray);
  }


  removeMarkedMembers(): void {
    forEachRight(this.customTeamObj.memberEmails, (userEmail, index) => {
      const memberIndex = indexOf(this.editTeamMembersObj.toBeRemoved, userEmail);
      if (memberIndex > -1) {
        this.customTeamObj.memberEmails.splice(index, 1);
      }
    });
    this.editTeamMembersObj.toBeRemoved = [];
  }

  removeMember(userEmail: string): void {
    const userIndex = indexOf(this.customTeamObj.memberEmails, userEmail);
    const userTempIndex = indexOf(this.editTeamMembersObj.toBeAdded, userEmail);
    this.customTeamObj.memberEmails.splice(userIndex, 1);
    if (this.modalType === 'editTeam') {
      if (userTempIndex > -1) {
        this.editTeamMembersObj.toBeAdded.splice(userTempIndex, 1);
      } else {
        this.editTeamMembersObj.toBeRemoved.push(userEmail);
      }
    }
  }

  openDialog(dialogRef: TemplateRef<any>, width, height) {
    if (typeof this.customTeamObj.memberEmails === 'undefined' || this.customTeamObj.memberEmails.length < 1) {
      this.customTeamObj.memberEmails = new Array<string>(this.userEmail);
    }
    this.matDialog.open(dialogRef, {
      width: width + 'px',
      height: height + 'px',
      disableClose: true
    });
    this.initializeEditTeamObject();
  }

  initializeEditTeamObject() {
    if (typeof this.userTeamInfo[0] !== 'undefined') {
      const userTeamInfoClone = cloneDeep(this.userTeamInfo[0]); // to avoid copying reference
      this.customTeamObj = {
        name: userTeamInfoClone.name,
        description: userTeamInfoClone.description,
        memberEmails: userTeamInfoClone.memberEmails,
        createdBy: userTeamInfoClone.createdBy
      };
    }
  }

  onTabChange(event) {
    this.addTeamMember = false;
  }

  closeDialog() {
    this.resetDialogObject();
    this.matDialog.closeAll();
  }

  returnUserIcon(userInputValue) {
    return userInputValue.charAt(0).toUpperCase();
  }

  getDisplayName(userEmail: string): string {
    return this.userService.getDisplayNameFromEmail(userEmail);
  }

  resetDialogObject(): void {
    this.editTeamMembersObj.toBeRemoved.length = 0;
    this.editTeamMembersObj.toBeAdded.length = 0;
    this.hasDuplicateName = false;
    this.showDeleteTeamConfirmation = false;
    delete this.customTeamObj;
    this.customTeamObj = new Team();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}