import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationsPreferencesComponent } from './notifications-preferences/notifications-preferences.component';
import { UserPreferencesBaseComponent } from './user-preferences-base/user-preferences-base.component';
import { UserPreferencesRoutesModule } from './user-preferences-routes.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  imports: [
    CommonModule,
    UserPreferencesRoutesModule,
    SharedModule
  ],
  declarations: [ NotificationsPreferencesComponent, UserPreferencesBaseComponent]
})
export class UserPreferencesModule { }
