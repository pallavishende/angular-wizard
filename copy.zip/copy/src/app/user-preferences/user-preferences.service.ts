import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { Title } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { ConfigService } from '../services/config.service';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UserPreferencesService {

  constructor(private authHttp: HttpClient, private title: Title, private configService: ConfigService) { }

  getAllNotificationPreference(): Observable<any> {
    return this.authHttp.get(this.configService.notificationsUrl)
      .map((response: any) => response);
  }

  getUserNotificationPreference(userId: number) {
    return this.authHttp.get(this.configService.updUrl + userId + '/notifications/preferences')
      .map((response: any) => response);
  }

  updateUserNotificationPreference(userId: number, notificationId: number, isSelected: boolean) {
    return this.authHttp.put(this.configService.updUrl + userId + '/notifications/preferences?userNotificationId=' + notificationId + '&isSelected=' + isSelected, {});
  }

  resetUserNotificationPreference(userId: number) {
    return this.authHttp.put(this.configService.updUrl + userId + '/notifications/reset', {});
  }

  updateAllUserNotificationPreferences(userId: number): Observable<any> {
    return this.getAllNotificationPreference().map(
      (allNotificationsData) => {
        const notificationIds: Array<number> = [];
        allNotificationsData.forEach((notification) => {
          if (typeof notification.id !== 'undefined') {
            notificationIds.push(notification.id);
          }
        });
        return this.authHttp.put(this.configService.updUrl + userId + '/notifications/' + notificationIds.toString(), {}).subscribe(
          (updateNotificationsData: any) => {
            return Observable.of(updateNotificationsData);
          },
          (error) => {
            console.log('Error occurred while updating user preferences for the new user.');
          }
        );
      }
    );
  }

  setOrdersPageTitle(title: string) {
    this.title.setTitle(title);
  }

}
