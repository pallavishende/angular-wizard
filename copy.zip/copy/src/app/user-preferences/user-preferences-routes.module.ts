import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SiteHeaderComponent } from '../shared/site-header/site-header.component';
import { NotificationsPreferencesComponent } from './notifications-preferences/notifications-preferences.component';
import { UserPreferencesBaseComponent } from './user-preferences-base/user-preferences-base.component';

const UserPreferenceRoutes: Routes = [
  { path: '', component: UserPreferencesBaseComponent, data: {title: 'My Settings'},
    children: [
      { path: '', component: NotificationsPreferencesComponent },
      { path: '', component: SiteHeaderComponent, outlet: 'header' }
    ]
  }

];

@NgModule({
  imports: [ RouterModule.forChild(UserPreferenceRoutes) ],
  exports: [ RouterModule ]
})

export class UserPreferencesRoutesModule {}
