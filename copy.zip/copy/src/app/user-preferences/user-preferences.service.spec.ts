import { Injectable } from '@angular/core';
import { Response, RequestOptions, Http, BaseRequestOptions, XHRBackend, ResponseOptions } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subject, BehaviorSubject } from 'rxjs';
import { AdalService } from '../shared/auth/adal.service';
import { TestBed, fakeAsync, inject, tick } from '@angular/core/testing';
import { MockBackend } from '@angular/http/testing';

import { UserPreferencesService } from './user-preferences.service';
import { EnvironmentService } from '../services/environment.service';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';
import { ConfigService } from '../services/config.service';


describe('UserPreferencesService', () => {
  let service, mockBackend;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientModule ],
      providers: [
        UserPreferencesService,
        ConfigService,
        EnvironmentService,
        ConfigurationManagerService,
        { provide: XHRBackend, useClass: MockBackend },
        AdalService
      ]
    });
  });


  it('should create the service', inject([UserPreferencesService], (service) => {
    expect(service).toBeTruthy();
  }));

  it('all the methods should be defined', inject([UserPreferencesService], (service) =>{
    expect(service.getUserNotificationPreference(1111)).toBeDefined();
    expect(service.updateUserNotificationPreference(1111, [])).toBeDefined();
    expect(service.resetUserNotificationPreference(1111)).toBeDefined();
  }));

  it('#getUserPreferencesService should return user preference data object',
  inject([UserPreferencesService, XHRBackend], (userPreferencesService, mockBackend) => {
    mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse.data)
          })));
        });
        userPreferencesService.getUserNotificationPreference(1111).subscribe((preferences) => {
          expect(JSON.parse(preferences._body).length).toEqual(6);
          expect(JSON.parse(preferences._body)[0].id).toEqual(2051);
        });
  }));

  it('#updateUserNotificationPreference should return user preference data object',
  inject([UserPreferencesService, XHRBackend], (userPreferencesService, mockBackend) => {
    mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: JSON.stringify(mockResponse)
          })));
        });
        userPreferencesService.updateUserNotificationPreference(1111, [1,0]).subscribe((preferences) => {
          expect(JSON.parse(preferences._body).data.length).toEqual(6);
          expect(JSON.parse(preferences._body).data[2].id).toEqual(2053);
        });
  }));

  it('#resetUserNotificationPreference should be truthy ',
  inject([UserPreferencesService, XHRBackend], (userPreferencesService, mockBackend) => {
    mockBackend.connections.subscribe((connection) => {
          connection.mockRespond(new Response(new ResponseOptions({
            body: null
          })));
        });
        userPreferencesService.resetUserNotificationPreference(1111).subscribe((preferences) => {
          expect(preferences._body).toBeNull();
        });
  }));

});

const mockResponse = {
          data: [
            { 
              id: 2051,
              isSelected: true,
              name: 'An activity has been asssigned to me',
              notificationType: 'ACTIVITY_ASSIGNED'
            },
            { 
              id: 2052,
              isSelected: true,
              name: 'An activity has been asssigned to me',
              notificationType: 'ACTIVITY_READY_TO_WORK_ON'
            },
            { 
              id: 2053,
              isSelected: true,
              name: 'An activity has been asssigned to me',
              notificationType: 'ORDER_SUBMITTED'
            },
            { 
              id: 2054,
              isSelected: true,
              name: 'An activity has been asssigned to me',
              notificationType: 'ORDER_CANCELLED'
            },
            { 
              id: 2055,
              isSelected: true,
              name: 'An activity has been asssigned to me',
              notificationType: 'ACTIVITY_REJECTED'
            },
            { 
              id: 2056,
              isSelected: true,
              name: 'An activity has been asssigned to me',
              notificationType: 'ORDER_COMPLETED'
            },
          ]
        };