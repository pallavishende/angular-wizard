/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { UserService } from './user.service';
import { LoginService } from '../login/login.service';
import { AdalService } from '../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { SecretService } from "../services/secret.service"
import { Router } from '@angular/router';
import { ConfigService } from './config.service';
import { Http, Response, ResponseOptions, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { ConfigurationManagerService} from '../configuration/configuration-manager.service';
import { EnvironmentService } from '../services/environment.service';
import { StorageService } from '../services/storage.service'; 

describe('UserService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        UserService,
        LoginService,
        AdalService,
        SecretService,
        ConfigService,
        {provide: Router},
        {provide: HttpClient},
        ConfigurationManagerService,
        EnvironmentService,
        StorageService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
      ]
    });
  });

  it('should ...', inject([UserService], (service: UserService) => {
    expect(service).toBeTruthy();
  }));
});
