import { TestBed, inject } from '@angular/core/testing';
import { StorageService } from './storage.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { EnvironmentService } from './environment.service';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';
import { HttpClient, HttpHandler } from '@angular/common/http';

describe('StorageService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        StorageService, EnvironmentService, ConfigurationManagerService, HttpClient,HttpHandler,
        {provide: Router, useValue: RouterTestingModule },
       ]
    });
  });

  it('should be created', inject([StorageService], (service: StorageService) => {
    expect(service).toBeTruthy();
  }));
});
