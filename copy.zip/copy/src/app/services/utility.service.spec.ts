/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { UtilityService } from './utility.service';
import { UserService } from './user.service';
import { SecretService } from './secret.service';
import { LoginService } from '../login/login.service';
import { AdalService } from '../shared/auth/adal.service';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';
import { RouterTestingModule } from '@angular/router/testing';
import { Http, ConnectionBackend, RequestOptions} from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

xdescribe('UtilityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule, HttpClientModule ],
      providers: [ Http, ConnectionBackend, RequestOptions, UtilityService, UserService, SecretService, LoginService, AdalService, ConfigurationManagerService]
    });
  });

  it('should ...', inject([UtilityService], (service: UtilityService) => {
    expect(service).toBeTruthy();
  }));
});
