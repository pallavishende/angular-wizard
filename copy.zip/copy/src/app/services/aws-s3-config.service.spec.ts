import { TestBed, inject } from '@angular/core/testing';

import { AwsS3ConfigService } from './aws-s3-config.service';
import { ConfigService } from './config.service';

xdescribe('AwsS3ConfigService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ AwsS3ConfigService, ConfigService ]
    });
  });

  it('should be created', inject([AwsS3ConfigService], (service: AwsS3ConfigService) => {
    expect(service).toBeTruthy();
  }));
});
