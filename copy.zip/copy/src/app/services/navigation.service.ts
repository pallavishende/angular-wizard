import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { StorageService } from './storage.service';

@Injectable()
export class NavigationService {

  private activeOrdersListTab: string;
  private activeActivityListTab: string;
  private bypassRouteGuard: boolean = false;

  constructor(private title: Title, private storageService: StorageService) { }

  getActiveOrdersListTab(): string {
    this.activeOrdersListTab = this.storageService.getOrdersTabFromLocal();
    if (this.activeOrdersListTab === null) {
      this.activeOrdersListTab = '/orders/my-orders';
    }
    return this.activeOrdersListTab;
  }

  getActiveActivitiesTab(): string {
     this.activeActivityListTab = this.storageService.getActivitiesTabFromLocal();
    if (this.activeActivityListTab === null) {
      this.activeActivityListTab = '/tasks/my-tasks';
    }
    return this.activeActivityListTab;
  }

  setActiveOrdersListTab(activeOrderTab: string) {
    this.activeOrdersListTab = '/orders/' + activeOrderTab;
    this.storageService.setOrdersTabFromLocal(this.activeOrdersListTab);
  }

  setActivityDetailsPreviousUrl(url: string) {
    this.storageService.setActivityDetailsPreviousUrl(url);
  }

  getActivityDetailsPreviousUrl(): string {
    return this.storageService.getActivityDetailsPreviousUrl();
  }

  disableRouteGuard(): void {
    this.bypassRouteGuard = true;
  }

  isRouteGuardCheckDisabled(): boolean {
    return this.bypassRouteGuard;
  }

  clearRouteGuardCheck(): void {
    this.bypassRouteGuard = false;
  }

  setPageTitle(title: string) {
    this.title.setTitle(title);
  }
}
