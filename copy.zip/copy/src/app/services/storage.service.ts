import { Injectable } from '@angular/core';
import { Router, Event, NavigationEnd, NavigationCancel } from '@angular/router';
import { EnvironmentService } from './environment.service';

const localStorageKey = 'bridge.session.currentUrl';
const activityDetailsStorageKey = 'bridge.session.activityDetailsPreviousPage';
const catalogStorageKey = 'bridge.session.catalog';
const siteBannerStorageKey = 'bridge.site.banner';

@Injectable()
export class StorageService {

  constructor(private router: Router, private environmentService: EnvironmentService) {
  }

  setBannerObjToLocal(value: string) {
    localStorage.setItem(siteBannerStorageKey, value);
  }

  getBannerObjFromLocal(): boolean {
    if (this.environmentService.getEnvironmentName() === 'prod') { return false; }

    return localStorage.getItem(siteBannerStorageKey) === 'true' ? true : false;
  }

  removeBannerObjFromLocal() {
    localStorage.removeItem(siteBannerStorageKey);
  }

  setCatalogObjToLocal(catalogObj: any) {
    localStorage.setItem(catalogStorageKey, JSON.stringify(catalogObj));
  }

  getCatalogObjFromLocal() {
    return JSON.parse(localStorage.getItem(catalogStorageKey));
  }

  resetCatalogObjInLocal() {
    localStorage.removeItem(catalogStorageKey);
  }

  // orders persistence
  getOrdersObjFromLocal() {
    return localStorage.getItem('ordersObj');
  }

  setOrdersObjToLocal(ordersObj: any) {
    JSON.stringify(localStorage.setItem('ordersObj', JSON.stringify(ordersObj)));
  }

  resetOrdersObjInLocal() {
    localStorage.removeItem('ordersObj');
    localStorage.removeItem('ordersTab');
  }

  getOrdersTabFromLocal() {
    let activeOrdersTab = localStorage.getItem('ordersTab');
    if (activeOrdersTab === null) {
      activeOrdersTab = '/orders/my-orders';
    }
    return activeOrdersTab;
  }

  setOrdersTabFromLocal(tab: string) {
    localStorage.setItem('ordersTab', tab);
  }

  // activity assign persistence
  getActivitiesAssignmentFromLocal() {
    return JSON.parse(localStorage.getItem('activitiesAssignment'));
  }

  setActivitiesAssignmentToLocal(obj) {
    let assignment = this.getActivitiesAssignmentFromLocal() ? this.getActivitiesAssignmentFromLocal() : {};
    assignment[obj.type] = obj.value;
    JSON.stringify(localStorage.setItem('activitiesAssignment', JSON.stringify(assignment)));
  }

  // activities persistence
  getActivitesObjFromLocal() {
    return localStorage.getItem('activitiesObj');
  }

  setActivitiesObjToLocal(activitesObj: any) {
    console.log('persisted acivities obj at service', activitesObj);
    JSON.stringify(localStorage.setItem('activitiesObj', JSON.stringify(activitesObj)));
  }

  setActivityDetailsPreviousUrl(url: string) {
    localStorage.setItem(activityDetailsStorageKey, JSON.stringify(url));
  }

  getActivityDetailsPreviousUrl(): string {
    return JSON.parse(localStorage.getItem(activityDetailsStorageKey));
  }

  resetActivitiesObjInLocal() {
    localStorage.removeItem('activitiesObj');
  }

  getActivitiesTabFromLocal() {
    let activeActivitiesTab = '/tasks/my-tasks';
    if (localStorage.getItem('activitiesObj') !== null) {
      activeActivitiesTab = '/tasks/' + JSON.parse(localStorage.getItem('activitiesObj')).activeTab;
    }
    return activeActivitiesTab;
  }

  public enableLastUrlPersistence() {
    // hooks into router events to save url
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationEnd || event instanceof NavigationCancel) {
        this.setCurrentUrl(event.url.toString());
      }
    });
  }

  // Video Request Type
  getVideoRequestTypeFromLocal() {
    return JSON.parse(localStorage.getItem('videoRequestType'));
  }

  setVideoRequestTypeToLocal(obj) {
    const requestType = this.getVideoRequestTypeFromLocal() ? this.getVideoRequestTypeFromLocal() : {};
    requestType['requestType'] = obj;
    JSON.stringify(localStorage.setItem('videoRequestType', JSON.stringify(requestType)));
  }

  // saves url in local storage
  private setCurrentUrl(url: string) {
     // do not store urls used by login and adal for token retrieval
     if (url !== '/login' && !url.startsWith('/#') && !url.startsWith('/?')) {
      localStorage.setItem(localStorageKey, url);
    }
  }

  // navigates to the last saved url if possible
  public navigateToLastUrlIfAvailable() {
    const lastUrl: string = localStorage.getItem(localStorageKey);
    if (window.location.pathname.toString() === '/' || window.location.pathname.toString() === '/login') {
      if (lastUrl !== null && lastUrl !== '/') {
        this.router.navigateByUrl(lastUrl);
      } else {
        this.router.navigateByUrl('catalog');
      }
    }
  }
}
