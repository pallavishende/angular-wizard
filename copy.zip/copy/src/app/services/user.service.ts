import { Injectable, OnDestroy } from '@angular/core';
import { LoginService } from '../login/login.service';
import { HttpClient } from '@angular/common/http';
import { Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject, Subject, Subscription } from 'rxjs';
import { ConfigService } from './config.service';
import { ConfigurationManagerService } from '../configuration/configuration-manager.service';
import { Team } from '../models/team';
import { UPDUser, AzureUser } from '../models/user';
import { find } from 'lodash';

@Injectable()
export class UserService implements OnDestroy {
  private usersSubject = new BehaviorSubject(null);
  usersStream = this.usersSubject.asObservable();   // stream
  userSubscription: Subscription;
  subscriptions = new Subscription();
  isActiveUser;
  isNewUser: boolean;
  usersCount = 0;
  allUsersDataObservable: Observable<any>;
  allTeamsDataObservable: Observable<any>;
  myTeamsSubject = new BehaviorSubject([]);
  isMyTeamsObservablePending: boolean;

  constructor(
    private loginService: LoginService,
    private authHttp: HttpClient,
    private configService: ConfigService,
    private configurationManagerService: ConfigurationManagerService
  ) {
  }

  getUserLoginInfo() {
    return this.loginService.getUserInfo();
  }

  createNewUser(userData) {
    const header = new Headers();
    const body = userData;
    header.append('Content-type', 'application/json');
    return this.authHttp.post(this.configService.updUrl, body);
  }

  getUserInfo(userEmail: string) {
    return this.authHttp.get(this.configService.updUrl + 'email/' + userEmail);
  }

  updateUserInfo(userUpdId: number, userUpdatedInfo: UPDUser) {
    return this.authHttp.put(`${this.configService.updUrl}${userUpdId}`, userUpdatedInfo);
  }

  getUserTeamsInfo(userEmail: string): Observable<any> {
    return this.authHttp.get<Array<any>>(`${this.configService.teamUrl}members?memberEmail=${userEmail}`)
      .map((response: any) => response);
  }

  getMyTeamsInfo(): Observable<any> {
    if (this.myTeamsSubject.getValue().length === 0 && !this.isMyTeamsObservablePending) {
      this.isMyTeamsObservablePending = true;
      this.getMyTeams()
        .subscribe((teamsData) => {
          this.myTeamsSubject.next(teamsData);
          this.isMyTeamsObservablePending = false;
        });
    }
    return this.myTeamsSubject.asObservable();
  }

  getUpdatedMyTeamsInfo(): Observable<any> {
    this.isMyTeamsObservablePending = true;
    this.getMyTeams().subscribe(
      (teamsData) => {
        this.myTeamsSubject.next(teamsData);
        this.isMyTeamsObservablePending = false;
      });
    return this.myTeamsSubject;
  }

  getMyTeams(): Observable<any> {
    const email = this.getUserLoginInfo().email;
    return this.authHttp.get<Array<any>>(`${this.configService.teamUrl}members?memberEmail=${email}`);
  }

  deleteUserTeam(teamId: string) {
    return this.authHttp.delete(`${this.configService.teamUrl}${teamId}`);
  }

  setUserTeam(teamData: Team): Observable<any> {
    const header = new Headers();
    const body = teamData;
    header.append('Content-type', 'application/json');
    return this.authHttp.post(this.configService.teamUrl, body);
  }

  editUserTeamMetadata(teamData: any): Observable<any> {
    const header = new Headers();
    const body = {};
    let queryParams = '';
    if (typeof teamData.name !== 'undefined') {
      queryParams = `teamName=${encodeURIComponent(teamData.name)}&`;
    }
    if (typeof teamData.description !== 'undefined') {
      queryParams = `${queryParams}description=${encodeURIComponent(teamData.description)}`;
    }
    header.append(`Content-type`, `application/json`);
    return this.authHttp.patch(`${this.configService.teamUrl}${teamData['id']}?${queryParams}`, body);
  }

  addMembersToTeam(teamId: string, teamMembers: Array<string>): Observable<any> {
    const header = new Headers();
    const body = teamMembers;
    header.append('Content-type', 'application/json');
    return this.authHttp.post(`${this.configService.teamUrl}${teamId}/members`, body);
  }

  removeMembersFromTeam(teamId: string, teamMembers: Array<string>): Observable<any> {
    const header = new Headers();
    const body = teamMembers;
    header.append('Content-type', 'application/json');
    return this.authHttp.put(`${this.configService.teamUrl}${teamId}/members`, body);
  }

  private getAllUsersData() {
    if (!this.allUsersDataObservable) {
      this.allUsersDataObservable = this.authHttp.get(this.configService.updUrl + '?size=500')
        .map((response: any) => response)
        .publishReplay(1)
        .refCount();
    }
    return this.allUsersDataObservable;
  }

  getAllUsers() {
    if (this.usersCount === 0) {
      this.subscriptions.add(this.getAllUsersData().subscribe(
        data => {
          const users = data['content'];
          this.usersCount = users.length;
          this.usersSubject.next(data);
        }
      ));
    }
    return this.usersStream;
  }

  getAllTeams() {
    if (!this.allTeamsDataObservable) {
      this.allTeamsDataObservable = this.authHttp.get<Array<any>>(this.configService.teamUrl)
        .map((response: any) => response);
        // .publishReplay()
        // .refCount();
    }
    return this.allTeamsDataObservable;
  }

  getUsers(query: string, size?: number) {
    let userListSize;
    size === undefined ? userListSize = 50 : userListSize = size;
    return this.authHttp.get(this.configService.updUrl + 'search?q=' + encodeURIComponent(query) + '&size=' + userListSize)
      .map((response: any) => response);
  }

  getUsersAndTeams(query: string, size?: number) {
    let userListSize;
    typeof size === 'undefined' ? userListSize = 50 : userListSize = size;
    return this.authHttp.get(this.configService.assigneeUrl + 'search?q=' + encodeURIComponent(query) + '&size=' + userListSize)
      .map((response: any) => response);
  }

  public getUserPhoto(handler: any, callerComponent: any): Promise<void> {
    const ADServiceUrl = this.configService.ADProfilePhotoUrl;
    let promise: Promise<void>;

    if (this.isUserPhotoInCache()) {
      promise = new Promise((resolve) => {
        resolve();
      }).then(() => {
        handler(this.getUserPhotoObjectAsBase64StringFromCache(), callerComponent);
      });
    } else {
      promise = this.authHttp.get(ADServiceUrl, { responseType: 'blob' }).map((res: any) => res).toPromise()
        .then((response) => {
          if (response != null) {
            const fileReader = new FileReader();
            fileReader.readAsDataURL(new Blob([response], { type: 'image/png' }));
            fileReader.onloadend = () => {
              this.saveUserPhotoAsBase64StringInCache(fileReader.result as string);
              handler(this.getUserPhotoObjectAsBase64StringFromCache(), callerComponent);
            };
          }
        }).catch((error) => {
          console.log('Error fetching user profile picture.');
        });
    }
    return promise;
  }

  getDisplayNameFromEmail(email) {
    let displayName = '';
    this.subscriptions.add(this.getAllUsers().subscribe(
      data => {
        if (data) {
          const users = data['content'];
          if (email && email !== 'UNASSIGNED') {
            const tmp = find(users, (user) => {
              if (user['login'].toLowerCase() === email.toLowerCase()) {
                return user;
              }
            });
            displayName = tmp ? tmp['displayName'] : 'NA';
            return displayName;
          } else {
            displayName = 'Unassigned';
            return displayName;
          }
        }
      },
      error => {
        console.log('Error: failed to get bridge users.');
      }
    ));
    return displayName;
  }

  public validateUserInfo(userInfo: UPDUser): Observable<any> {
    const userInfoValidationSubject = new Subject();
    const userLoginInfo: AzureUser = this.getUserLoginInfo();
    if (userInfo.firstName !== userLoginInfo.firstName ||
        userInfo.lastName !== userLoginInfo.familyName ||
        userInfo.displayName !== userLoginInfo.displayName) {
          const updatedUserInfo: UPDUser = userInfo;
          updatedUserInfo.firstName = userLoginInfo.firstName;
          updatedUserInfo.lastName = userLoginInfo.familyName;
          updatedUserInfo.displayName = userLoginInfo.displayName;

          this.updateUserInfo(userInfo.id, updatedUserInfo).subscribe(
            (data: any) => {
              userInfoValidationSubject.complete();
              return Observable.of(true)
            },
            (error: any) => {
              console.error('User info was not updated in UPD.', error);
              userInfoValidationSubject.complete();
            }
          );
        } else {
          userInfoValidationSubject.complete();
        }
    return Observable.of(userInfoValidationSubject);
  }

  public getFavoritedTeams(email) {
    return this.authHttp.get(this.configService.assigneeUrl + 'team-followers/search?userEmail=' + email)
      .map((response: any) => response);
  }

  public postFavoritedTeams(suUrl, body) {
    return this.authHttp.post(this.configService.teamUrl + suUrl, body)
      .map((response: any) => response);
  }

  public deleteFavoritedTeam(suburl: string) {
    return this.authHttp.delete(`${this.configService.teamUrl}${suburl}`);
  }

  public isUserPhotoInCache(): Boolean {
    return this.getUserPhotoObjectAsBase64StringFromCache() !== null;
  }

  public getUserPhotoObjectAsBase64StringFromCache() {
    return this.configurationManagerService.getUserPhotoObjectAsBase64StringFromCache();
  }

  public saveUserPhotoAsBase64StringInCache(value: string) {
    return this.configurationManagerService.saveUserPhotoAsBase64StringInCache(value);
  }

  public removeUserPhotoObjectUrlFromCache() {
    return this.configurationManagerService.removeUserPhotoFromCache();
  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
}
