/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { EndpointProfileService } from './endpoint-profile.service';

describe('EndpointProfileService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EndpointProfileService]
    });
  });

  xit('should ...', inject([EndpointProfileService], (service: EndpointProfileService) => {
    expect(service).toBeTruthy();
  }));
});
