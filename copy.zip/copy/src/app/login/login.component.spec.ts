/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Http, Headers, Response, RequestOptions, BaseRequestOptions } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';

import { LoginComponent } from './login.component';
import { LoadingMaskService } from '../shared/loading-mask/loading-mask.service';
import { LoginService } from "./login.service"
import { AdalService } from '../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { SecretService } from '../services/secret.service';
import { StorageService } from '../services/storage.service';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { ConfigurationManagerService} from '../configuration/configuration-manager.service';
import { EnvironmentService } from '../services/environment.service';
import { ConfigService }  from "../services/config.service";
import { ModalModule } from 'app/shared/ng-modal';


describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ FormsModule, HttpClientModule, RouterTestingModule, ModalModule ],
      declarations: [ LoginComponent ],
      providers: [
        LoadingMaskService, LoginService, AdalService, SecretService, StorageService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        {
            provide: HttpClient,
            useFactory: (http: Http) => http,
            deps: [Http]
        },
        ConfigurationManagerService,
        EnvironmentService,
        ConfigService
       ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
