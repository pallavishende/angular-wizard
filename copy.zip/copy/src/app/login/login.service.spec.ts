import { TestBed, async, inject } from '@angular/core/testing';
import { Http, BaseRequestOptions, Response, ResponseOptions, RequestMethod, Headers} from '@angular/http';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { LoginService } from './login.service';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { AdalService } from '../shared/auth/adal.service';
import { HttpClient } from '@angular/common/http';
import { Router  } from '@angular/router';
import { SecretService } from '../services/secret.service'
import { ConfigurationManagerService} from '../configuration/configuration-manager.service';
import { EnvironmentService } from '../services/environment.service';
import { ConfigService } from '../services/config.service';
import { StorageService } from '../services/storage.service';

describe('LoginService', () => {

  let loginValues = {
    username: "john",
    password: "password",
    emptyusername: null,
    emptypassowrd: null
  };

  let subject: LoginService = null;
  let backend: MockBackend = null;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        LoginService,
        StorageService,
        MockBackend,
        BaseRequestOptions,
        {
          provide: Http,
          useFactory: (backendInstance: MockBackend, defaultOptions: BaseRequestOptions) => {
            return new Http(backendInstance, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        },
        AdalService,
        {provide: Router},
        SecretService,
        {
            provide: HttpClient,
            useFactory: (http: Http) => http,
            deps: [Http]
        },
        ConfigurationManagerService,
        EnvironmentService,
        ConfigService
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    });
  });

  it('should call the service', inject([LoginService], (service: LoginService) => {
    expect(service).toBeTruthy();
  }));

  xit('#login should accept a username and password', inject([LoginService], (service: LoginService) => {
    //expect(service.login(loginValues.username, loginValues.password)).toBeTruthy();
  }));

  xit('#login should not accept a username only', inject([LoginService], (service: LoginService) => {
    //expect(service.login(loginValues.username, null)).toBeFalsy();
  }));

  xit('#login should not accept a password only', inject([LoginService], (service: LoginService) => {
    //expect(service.login("", loginValues.password)).toBeFalsy();
  }));

  it('#login should send the login request to the server', (done) => {
    done();
  });

  xit('#login should call endpoint and return success response', inject([LoginService, MockBackend], (service: LoginService, mockBackend: MockBackend) => {

    mockBackend.connections.subscribe((connection: MockConnection) => {
        let options = new ResponseOptions({
          body: JSON.stringify({ user: loginValues.username }),
        });

        let header = new Headers();
        let auth = btoa(loginValues.username + ":" + loginValues.password);
        header.append('Authorization', auth);
        header.append('Content-Type', 'application/json');
        connection.mockRespond(new Response(options));
      });

      let subject = service;

      /*subject
        .login(loginValues.username, loginValues.password)
        .subscribe((data) => {
          expect(data.json()).toEqual({ user: loginValues.username });
        });*/
  }));

  it('#logout should remove user from localStorage', inject([LoginService], (service: LoginService) => {
    expect(localStorage['currentUser']).toBeUndefined;
  }));

  it('#logout should set logged in user to false', inject([LoginService], (service: LoginService) => {
    expect(service.isAuthenticated).toBeFalsy;
  }));

});
