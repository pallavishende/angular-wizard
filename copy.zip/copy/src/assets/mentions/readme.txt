mentions - build: 1.1.1-55

Documentation
-----------------
For detailed documentation, please see the following location:
https://www.tinymce.com/docs/plugins/

Support
-----------------
For further support, please use the Ephox Support website, located here: https://support.ephox.com/home
