#!/bin/bash

dockerTask="$(docker ps | grep 'bridge-ui')"
echo "current docker process:"
echo "${dockerTask}"

IFS=', ' read -r -a taskItems <<< ${dockerTask}
echo "stoping the docker process with Id: "
echo "${taskItems[0]}"

docker stop ${taskItems[0]}

echo "pulling git content"
git pull origin staging

echo "update npm install to handle new libraries"
npm cache clean
npm install

echo "building angularjs content"
ng build

echo "building docker image"
docker build -t bridge-ui .

echo "running bridge-ui image"
docker run -d -p 80:80 bridge-ui
